let chatHistory = [];

// Toast notifications
function showToast(type, title, message) {
    const container = document.getElementById('toastContainer');
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-times-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="fas ${icons[type]}"></i>
        </div>
        <div class="toast-content">
            <div class="toast-title">${title}</div>
            <div class="toast-message">${message}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideInRight 0.4s ease reverse';
        setTimeout(() => toast.remove(), 400);
    }, 3000);
}

// Mobile menu toggle
function toggleMobileMenu() {
    const menu = document.getElementById('navMenu');
    const toggle = document.getElementById('mobileMenuToggle');
    menu.classList.toggle('active');
    toggle.classList.toggle('active');
}

// Dropdown toggle
function toggleDropdown(event) {
    if (window.innerWidth <= 768) {
        event.preventDefault();
        const navItem = event.target.closest('.nav-item');
        navItem.classList.toggle('active');
    }
}

// Subdropdown toggle for Azure
function toggleSubdropdown(event) {
    event.preventDefault();
    event.stopPropagation();
    const dropdownParent = event.currentTarget;
    const subdropdown = dropdownParent.nextElementSibling;
    
    if (subdropdown && subdropdown.classList.contains('subdropdown-menu')) {
        subdropdown.classList.toggle('active');
        dropdownParent.classList.toggle('active');
    }
}

// User menu toggle
function toggleUserMenu() {
    const userInfo = document.querySelector('.user-info');
    userInfo.classList.toggle('active');
}

document.addEventListener('click', function(event) {
    const userInfo = document.querySelector('.user-info');
    if (userInfo && !userInfo.contains(event.target)) {
        userInfo.classList.remove('active');
    }
});

// Chat functions
function toggleChat() {
    const chat = document.getElementById('chatPanel');
    const overlay = document.getElementById('chatOverlay');
    const btn = document.getElementById('floatingChatBtn');
    chat.classList.toggle('open');
    overlay.classList.toggle('active');
    btn.classList.toggle('active');
    
    if (chat.classList.contains('open')) {
        document.getElementById('chatInput').focus();
    }
}

function maximizeChat() {
    document.getElementById('chatPanel').classList.add('maximized');
    document.getElementById('chatModalOverlay').classList.add('active');
    document.getElementById('chatInputModal').focus();
    
    const modalMessages = document.getElementById('chatMessagesModal');
    const panelMessages = document.getElementById('chatMessages');
    modalMessages.innerHTML = panelMessages.innerHTML;
}

function minimizeChat() {
    document.getElementById('chatPanel').classList.remove('maximized');
    document.getElementById('chatModalOverlay').classList.remove('active');
    
    const panelMessages = document.getElementById('chatMessages');
    const modalMessages = document.getElementById('chatMessagesModal');
    panelMessages.innerHTML = modalMessages.innerHTML;
    
    toggleChat();
}

function closeModal() {
    document.getElementById('chatModalOverlay').classList.remove('active');
    document.getElementById('chatPanel').classList.remove('maximized');
    document.getElementById('floatingChatBtn').classList.remove('active');
}

function switchChatTab(tabName) {
    document.querySelectorAll('#chatPanel .chat-tab').forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');
    
    document.querySelectorAll('#chatPanel .chat-content').forEach(content => content.classList.remove('active'));
    
    if (tabName === 'chat') {
        document.getElementById('chatContent').classList.add('active');
        document.getElementById('chatInput').focus();
    } else if (tabName === 'help') {
        document.getElementById('helpContent').classList.add('active');
    } else if (tabName === 'history') {
        document.getElementById('historyContent').classList.add('active');
    }
}

function switchChatTabModal(tabName) {
    document.querySelectorAll('#chatModalOverlay .chat-tab').forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');
    
    document.querySelectorAll('#chatModalOverlay .chat-content').forEach(content => content.classList.remove('active'));
    
    if (tabName === 'chat') {
        document.getElementById('chatContentModal').classList.add('active');
        document.getElementById('chatInputModal').focus();
    } else if (tabName === 'help') {
        document.getElementById('helpContentModal').classList.add('active');
    } else if (tabName === 'history') {
        document.getElementById('historyContentModal').classList.add('active');
    }
}

function handleChatKeypress(event) {
    if (event.key === 'Enter') {
        sendChatMessage();
    }
}

function handleChatKeypressModal(event) {
    if (event.key === 'Enter') {
        sendChatMessageModal();
    }
}

function sendChatMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    const messagesDiv = document.getElementById('chatMessages');
    const typingIndicator = document.getElementById('typingIndicator');
    const sendBtn = document.getElementById('chatSendBtn');
    
    addMessageToPanel(message, messagesDiv, typingIndicator, sendBtn);
    addToHistory(message);
    
    input.value = '';
}

function sendChatMessageModal() {
    const input = document.getElementById('chatInputModal');
    const message = input.value.trim();
    
    if (!message) return;
    
    const messagesDiv = document.getElementById('chatMessagesModal');
    const typingIndicator = document.getElementById('typingIndicatorModal');
    const sendBtn = document.getElementById('chatSendBtnModal');
    
    addMessageToPanel(message, messagesDiv, typingIndicator, sendBtn);
    addToHistory(message);
    
    input.value = '';
}

function addMessageToPanel(message, messagesDiv, typingIndicator, sendBtn) {
    const userMsg = document.createElement('div');
    userMsg.className = 'chat-message user';
    userMsg.innerHTML = `<div class="chat-message-content">${escapeHtml(message)}</div>`;
    messagesDiv.appendChild(userMsg);
    
    sendBtn.disabled = true;
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
    
    typingIndicator.classList.add('active');
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
    
    setTimeout(() => {
        typingIndicator.classList.remove('active');
        
        const responses = [
            `I understand: "${escapeHtml(message)}". How can I help you further? 😊`,
            `Great question about "${escapeHtml(message)}"! Let me help you with that.`,
            `Thanks for asking about "${escapeHtml(message)}". Here's what I can tell you...`,
            `I can assist with "${escapeHtml(message)}". Would you like more details?`,
            `Regarding "${escapeHtml(message)}", here are some insights...`,
            `That's a great inquiry about "${escapeHtml(message)}". Let me provide some guidance.`
        ];
        
        const randomResponse = responses[Math.floor(Math.random() * responses.length)];
        
        const aiMsg = document.createElement('div');
        aiMsg.className = 'chat-message ai';
        aiMsg.innerHTML = `<div class="chat-message-content">${randomResponse}</div>`;
        messagesDiv.appendChild(aiMsg);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
        
        sendBtn.disabled = false;
    }, 1500);
}

function addToHistory(message) {
    chatHistory.push(message);
    const historyList = document.getElementById('historyList');
    const historyListModal = document.getElementById('historyListModal');
    
    const emptyState = historyList.querySelector('.empty-state');
    if (emptyState) emptyState.remove();
    
    const emptyStateModal = historyListModal.querySelector('.empty-state');
    if (emptyStateModal) emptyStateModal.remove();
    
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    const historyItem = document.createElement('div');
    historyItem.className = 'history-item';
    historyItem.innerHTML = `
        <div class="history-time">${time}</div>
        <div class="history-text">${escapeHtml(message)}</div>
    `;
    
    historyList.insertBefore(historyItem, historyList.firstChild);
    historyListModal.insertBefore(historyItem.cloneNode(true), historyListModal.firstChild);
}

function clearChat() {
    document.getElementById('chatMessages').innerHTML = `
        <div class="chat-message ai">
            <div class="chat-message-content">
                👋 Hello! I'm your AI Assistant. Ask me anything about your dashboard, integrations, or data management.
            </div>
        </div>
    `;
    showToast('info', 'Chat Cleared', 'Chat history has been cleared');
}

function clearChatModal() {
    document.getElementById('chatMessagesModal').innerHTML = `
        <div class="chat-message ai">
            <div class="chat-message-content">
                👋 Hello! I'm your AI Assistant. Ask me anything about your dashboard, integrations, or data management.
            </div>
        </div>
    `;
    showToast('info', 'Chat Cleared', 'Chat history has been cleared');
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

function goToProfile(event) {
    event.preventDefault();
    showToast('info', 'Profile', 'Navigating to profile page...');
}

function goToSettings(event) {
    event.preventDefault();
    showToast('info', 'Settings', 'Navigating to settings page...');
}

async function logout(event) {
    event.preventDefault();
    try {
        const response = await fetch('/api/auth/logout', { method: 'POST' });
        if (response.ok) {
            showToast('success', 'Logged Out', 'Redirecting to login...');
            setTimeout(() => {
                window.location.href = '/login';
            }, 1500);
        }
    } catch (error) {
        console.error('Logout error:', error);
        showToast('error', 'Error', 'Failed to logout');
    }
}

async function loadUserInfo() {
    try {
        const response = await fetch('/api/auth/me');
        if (response.ok) {
            const user = await response.json();
            document.getElementById('userName').textContent = `Welcome, ${user.name}`;
            document.getElementById('userAvatar').textContent = user.name.charAt(0).toUpperCase();
            showToast('success', 'Welcome!', `Logged in as ${user.email}`);
        }
    } catch (error) {
        console.error('Error loading user:', error);
    }
}

document.addEventListener('click', function(event) {
    const menu = document.getElementById('navMenu');
    const toggle = document.getElementById('mobileMenuToggle');
    
    if (menu.classList.contains('active') && 
        !menu.contains(event.target) && 
        !toggle.contains(event.target)) {
        menu.classList.remove('active');
        toggle.classList.remove('active');
    }
});

window.addEventListener('load', loadUserInfo);