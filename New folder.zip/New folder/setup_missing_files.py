#!/usr/bin/env python
"""
360° Enterprise Dashboard - Setup Missing Files
Creates all missing configuration and template files
Run this script from the project root directory
"""

import os
import sys

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    END = '\033[0m'

def print_header(text):
    print(f"\n{Colors.BLUE}{'='*70}{Colors.END}")
    print(f"{Colors.BLUE}{text}{Colors.END}")
    print(f"{Colors.BLUE}{'='*70}{Colors.END}\n")

def create_file(path, content, description):
    """Create a file with content"""
    try:
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        # Check if file exists
        if os.path.exists(path):
            print(f"{Colors.YELLOW}⚠{Colors.END} Already exists: {description}")
            return False
        
        # Create file
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"{Colors.GREEN}✓{Colors.END} Created: {description}")
        return True
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.END} Failed to create {description}: {e}")
        return False

def main():
    print_header("360° Enterprise Dashboard - Setup Missing Files")
    
    print(f"Project Root: {os.getcwd()}\n")
    
    # 1. Create .env file
    print_header("Setting up Environment Configuration")
    
    env_content = """# 360° Enterprise Dashboard - Environment Variables
# Change these values for your environment

# Flask Configuration
SECRET_KEY=your-super-secret-key-change-this-in-production
FLASK_ENV=development
DEBUG=True

# Database
DATABASE_URL=sqlite:///instance/dashboard.db
# For PostgreSQL: postgresql://username:password@localhost:5432/dashboard

# Session
SESSION_COOKIE_SECURE=False
SESSION_COOKIE_HTTPONLY=True
SESSION_COOKIE_SAMESITE=Lax
PERMANENT_SESSION_LIFETIME=604800

# Azure Configuration (Optional)
# AZURE_SUBSCRIPTION_ID=your-subscription-id
# AZURE_TENANT_ID=your-tenant-id
# AZURE_CLIENT_ID=your-client-id
# AZURE_CLIENT_SECRET=your-client-secret

# SharePoint Configuration (Optional)
# SHAREPOINT_SITE_URL=https://your-org.sharepoint.com/sites/your-site
# SHAREPOINT_CLIENT_ID=your-client-id
# SHAREPOINT_CLIENT_SECRET=your-client-secret

# Splunk Configuration (Optional)
# SPLUNK_HOST=your-splunk-host
# SPLUNK_PORT=8089
# SPLUNK_USERNAME=your-username
# SPLUNK_PASSWORD=your-password

# GitHub Configuration (Optional)
# GITHUB_TOKEN=your-github-token
# GITHUB_API_BASE_URL=https://api.github.com

# Jenkins Configuration (Optional)
# JENKINS_HOST=your-jenkins-host
# JENKINS_USERNAME=your-username
# JENKINS_TOKEN=your-token

# API Configuration
API_TIMEOUT=30
API_RETRY_ATTEMPTS=3
API_RATE_LIMIT=100

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/app.log

# CORS
CORS_ORIGINS=http://localhost:5000,http://localhost:3000

# Email (Optional - for notifications)
# MAIL_SERVER=smtp.gmail.com
# MAIL_PORT=587
# MAIL_USERNAME=your-email@gmail.com
# MAIL_PASSWORD=your-app-password
# MAIL_USE_TLS=True

# Application
APP_NAME=360° Enterprise Dashboard
APP_VERSION=3.0.0
"""
    
    create_file('backend/.env', env_content, 'backend/.env')
    
    # 2. Create .gitignore
    print_header("Creating .gitignore")
    
    gitignore_content = """# Virtual Environment
venv/
env/
ENV/
.venv/

# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
pip-wheel-metadata/
share/python-wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# Database
*.db
*.sqlite
*.sqlite3
instance/

# Environment
.env
.env.local
.env.*.local
.venv

# IDE
.vscode/
.idea/
*.swp
*.swo
*~
.project
.pydevproject
.settings/
*.sublime-project
*.sublime-workspace

# Logs
*.log
logs/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# OS
.DS_Store
Thumbs.db
.AppleDouble
.LSOverride

# Testing
.pytest_cache/
.coverage
htmlcov/
.tox/

# Node (if using frontend tools)
node_modules/
dist/
.next/

# IDE Extensions
*.code-workspace

# Temporary files
*.tmp
*.bak
*.swp
*~

# Distribution / packaging
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/

# Unit test / coverage reports
htmlcov/
.tox/
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover

# Flask stuff:
instance/
.webassets-cache

# Scrapy stuff:
.scrapy

# Sphinx documentation
docs/_build/

# PyBuilder
target/

# Jupyter Notebook
.ipynb_checkpoints

# pyenv
.python-version

# celery beat schedule file
celerybeat-schedule

# SageMath parsed files
*.sage.py

# Environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# Spyder project settings
.spyderproject
.spyproject

# Rope project settings
.ropeproject

# mkdocs documentation
/site

# mypy
.mypy_cache/
.dmypy.json
dmypy.json

# Pyre type checker
.pyre/
"""
    
    create_file('.gitignore', gitignore_content, '.gitignore')
    
    # 3. Create frontend/index.html
    print_header("Creating Frontend Templates")
    
    index_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>360° Enterprise Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #005841;
            --accent: #ffc32e;
            --gradient: linear-gradient(135deg, #005841 0%, #003d2e 100%);
            --shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            color: #333;
        }
        .nav {
            background: rgba(250, 251, 255, 0.95);
            backdrop-filter: blur(40px);
            padding: 1rem 2rem;
            border-bottom: 2px solid var(--accent);
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 900;
            font-size: 1.5rem;
            color: var(--primary);
        }
        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            background: var(--gradient);
            color: white;
            text-decoration: none;
            transition: all 0.3s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 88, 65, 0.3);
        }
        .hero {
            max-width: 1400px;
            margin: 0 auto;
            padding: 100px 40px;
            text-align: center;
        }
        .hero h1 {
            font-size: 3.5rem;
            color: var(--primary);
            margin-bottom: 20px;
            font-weight: 900;
        }
        .hero p {
            font-size: 1.3rem;
            color: #64748b;
            margin-bottom: 40px;
        }
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin-top: 60px;
        }
        .feature-card {
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: var(--shadow);
            transition: all 0.3s;
        }
        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 40px rgba(0, 88, 65, 0.15);
        }
        .feature-icon {
            font-size: 3rem;
            color: var(--accent);
            margin-bottom: 15px;
        }
        .feature-card h3 {
            color: var(--primary);
            margin-bottom: 12px;
        }
    </style>
</head>
<body>
    <nav class="nav">
        <div class="nav-container">
            <a href="/" class="logo"><i class="fas fa-cube"></i> 360°</a>
            <a href="/login" class="btn"><i class="fas fa-sign-in-alt"></i> Login</a>
        </div>
    </nav>

    <div class="hero">
        <h1>360° Enterprise Integration Dashboard</h1>
        <p>Connect, Manage, and Monitor All Your Enterprise Systems</p>
        <a href="/login" class="btn"><i class="fas fa-arrow-right"></i> Get Started</a>

        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-cloud"></i></div>
                <h3>Azure Integration</h3>
                <p>Connect with Microsoft Azure</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-file-alt"></i></div>
                <h3>SharePoint</h3>
                <p>Sync documents seamlessly</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon"><i class="fas fa-chart-bar"></i></div>
                <h3>Real-time Reports</h3>
                <p>Generate comprehensive reports</p>
            </div>
        </div>
    </div>
</body>
</html>
"""
    
    create_file('frontend/index.html', index_html, 'frontend/index.html')
    
    # 4. Create frontend/auth/login.html
    login_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - 360° Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #005841;
            --accent: #ffc32e;
            --gradient: linear-gradient(135deg, #005841 0%, #003d2e 100%);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--gradient);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-card {
            background: white;
            border-radius: 24px;
            padding: 48px;
            max-width: 450px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        .logo-box {
            width: 80px;
            height: 80px;
            background: var(--accent);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 2.5rem;
            color: var(--primary);
        }
        .login-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
            text-align: center;
            margin-bottom: 12px;
        }
        .form-group {
            margin-bottom: 24px;
        }
        .form-label {
            display: block;
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
        }
        .form-input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e0e8e4;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
        }
        .form-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(0, 88, 65, 0.1);
        }
        .btn-submit {
            width: 100%;
            padding: 14px;
            background: var(--gradient);
            color: white;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 88, 65, 0.3);
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="logo-box"><i class="fas fa-cube"></i></div>
        <h1 class="login-title">Sign In</h1>
        <p style="text-align: center; color: #64748b; margin-bottom: 30px;">Access your Dashboard</p>

        <form onsubmit="handleLogin(event)">
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" class="form-input" id="email" placeholder="demo@example.com" required>
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" class="form-input" id="password" placeholder="demo123" required>
            </div>
            <button type="submit" class="btn-submit" id="submitBtn">Sign In</button>
        </form>

        <div style="text-align: center; margin: 20px 0; font-size: 0.9rem; color: #64748b;">
            <p><strong>Demo:</strong> demo@example.com / demo123</p>
        </div>

        <div class="back-link">
            <a href="/">← Back to Home</a>
        </div>
    </div>

    <script>
        async function handleLogin(event) {
            event.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const submitBtn = document.getElementById('submitBtn');

            submitBtn.disabled = true;
            submitBtn.textContent = 'Signing in...';

            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });

                const data = await response.json();

                if (response.ok) {
                    window.location.href = '/dashboard';
                } else {
                    alert(data.error || 'Login failed');
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Sign In';
                }
            } catch (error) {
                alert(error.message);
                submitBtn.disabled = false;
                submitBtn.textContent = 'Sign In';
            }
        }
    </script>
</body>
</html>
"""
    
    create_file('frontend/auth/login.html', login_html, 'frontend/auth/login.html')
    
    # Summary
    print_header("Setup Complete!")
    
    print(f"{Colors.GREEN}✓ All missing files have been created!{Colors.END}\n")
    
    print("Created files:")
    print(f"  {Colors.GREEN}✓{Colors.END} backend/.env - Environment configuration")
    print(f"  {Colors.GREEN}✓{Colors.END} .gitignore - Git ignore rules")
    print(f"  {Colors.GREEN}✓{Colors.END} frontend/index.html - Landing page")
    print(f"  {Colors.GREEN}✓{Colors.END} frontend/auth/login.html - Login page")
    
    print(f"\n{Colors.YELLOW}Next steps:{Colors.END}")
    print(f"  1. Update backend/.env with your configuration")
    print(f"  2. Create frontend/dashboard_overview/index.html with your enhanced dashboard")
    print(f"  3. Run: python backend/app.py")
    print(f"  4. Visit: http://localhost:5000\n")

if __name__ == '__main__':
    main()