"""
Utility Functions - Common helpers and utilities
"""

import os
import logging
import json
from datetime import datetime
from functools import wraps
from flask import jsonify

logger = logging.getLogger(__name__)


def safe_get(data, key, default=None):
    """Safely get dictionary value"""
    try:
        return data.get(key, default)
    except (AttributeError, TypeError):
        return default


def format_datetime(dt):
    """Format datetime to ISO string"""
    if dt:
        return dt.isoformat()
    return None


def parse_datetime(dt_string):
    """Parse ISO datetime string"""
    try:
        return datetime.fromisoformat(dt_string.replace('Z', '+00:00'))
    except (ValueError, AttributeError):
        return None


def format_response(data, status_code=200, message=None):
    """Format API response"""
    response = {
        'data': data,
        'status': 'success' if status_code < 400 else 'error',
        'timestamp': datetime.utcnow().isoformat()
    }
    if message:
        response['message'] = message
    return jsonify(response), status_code


def handle_error(error, status_code=500):
    """Handle and format error response"""
    logger.error(f"Error: {error}")
    return format_response(
        {'error': str(error)},
        status_code=status_code,
        message='An error occurred'
    )


def validate_required_fields(data, required_fields):
    """Validate required fields in request data"""
    missing_fields = [f for f in required_fields if f not in data or not data[f]]
    if missing_fields:
        return False, f"Missing required fields: {', '.join(missing_fields)}"
    return True, None


def paginate_query(query, page=1, per_page=50):
    """Paginate database query"""
    paginated = query.paginate(page=page, per_page=per_page)
    return {
        'items': [item.to_dict() for item in paginated.items],
        'total': paginated.total,
        'pages': paginated.pages,
        'current_page': page
    }


def retry(max_attempts=3, delay=1):
    """Retry decorator"""
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            for attempt in range(max_attempts):
                try:
                    return f(*args, **kwargs)
                except Exception as e:
                    if attempt == max_attempts - 1:
                        raise
                    logger.warning(f"Attempt {attempt + 1} failed: {e}")
                    import time
                    time.sleep(delay)
        return decorated
    return decorator


def log_action(action, resource_type, resource_id, details=None):
    """Log user action for audit trail"""
    logger.info(f"Action: {action}, Resource: {resource_type}/{resource_id}, Details: {details}")


def generate_id():
    """Generate unique ID"""
    import uuid
    return str(uuid.uuid4())


def is_valid_email(email):
    """Validate email format"""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None


def sanitize_input(data):
    """Sanitize user input"""
    if isinstance(data, dict):
        return {k: sanitize_input(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [sanitize_input(item) for item in data]
    elif isinstance(data, str):
        return data.strip()
    return data