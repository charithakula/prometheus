#!/usr/bin/env python
"""
Verify and Fix Password Hash - Fixed Version
No model re-initialization
"""

import sys
import os
backend_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, backend_path)

try:
    from app import create_app, db
    from werkzeug.security import generate_password_hash, check_password_hash
    
    print("\n" + "=" * 80)
    print("🔐 PASSWORD HASH VERIFICATION & FIX")
    print("=" * 80)
    
    app = create_app()
    
    with app.app_context():
        # Import User from app - it's already initialized!
        from app import User
        
        print("\n1️⃣ Checking User model...")
        print(f"✓ User model: {User}")
        print(f"✓ User type: {type(User)}")
        
        print("\n2️⃣ Finding demo user...")
        user = User.query.filter_by(email='demo@example.com').first()
        
        if not user:
            print("❌ Demo user not found!")
            sys.exit(1)
        
        print(f"✓ Found: {user.email}")
        print(f"✓ Hash in DB: {user.password[:70]}...")
        
        print("\n3️⃣ Testing current password...")
        result = user.check_password('demo123')
        print(f"   check_password('demo123'): {result}")
        
        if result:
            print("✅ PASSWORD WORKS! Ready to login.")
            print("\n" + "=" * 80)
            sys.exit(0)
        
        print("\n4️⃣ Password check failed. Regenerating hash...")
        
        # Generate new hash
        new_hash = generate_password_hash('demo123')
        print(f"✓ New hash: {new_hash[:70]}...")
        
        # Test new hash
        test_new = check_password_hash(new_hash, 'demo123')
        print(f"✓ Test new hash: {test_new}")
        
        if not test_new:
            print("❌ Even new hash doesn't work!")
            print("This indicates werkzeug is broken!")
            sys.exit(1)
        
        # Update database
        print("\n5️⃣ Updating database...")
        user.password = new_hash
        db.session.commit()
        print("✓ Database updated")
        
        # Final verification
        print("\n6️⃣ Final verification...")
        db.session.expire(user)
        user = User.query.filter_by(email='demo@example.com').first()
        
        final_test = user.check_password('demo123')
        print(f"   check_password('demo123'): {final_test}")
        
        if final_test:
            print("\n" + "=" * 80)
            print("✅ SUCCESS - Password fixed and verified!")
            print("=" * 80)
            print(f"\nReady to login:")
            print(f"  Email: demo@example.com")
            print(f"  Password: demo123")
            print(f"\nGo to: http://localhost:5000/login\n")
        else:
            print("\n❌ FAILED - Password still doesn't work!")
            print("Contact developer - werkzeug issue!")
            sys.exit(1)

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)