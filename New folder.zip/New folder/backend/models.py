"""
SQLAlchemy Database Models

Defines all database tables and relationships for:
- Users, Authentication
- Integrations
- Connectors
- Data Tables
- Chat History
- Audit Logs
"""

from app import db
from datetime import datetime
from sqlalchemy.dialects.postgresql import JSON, UUID
import uuid

class User(db.Model):
    """User model"""
    __tablename__ = 'users'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(120))
    last_name = db.Column(db.String(120))
    role = db.Column(db.String(20), default='user')  # admin, user, viewer
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Integration(db.Model):
    """Integration model"""
    __tablename__ = 'integrations'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(120), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # azure, splunk, sharepoint, etc.
    status = db.Column(db.String(20), default='inactive')  # active, inactive, error
    config = db.Column(JSON)
    last_sync = db.Column(db.DateTime)
    sync_frequency = db.Column(db.Integer, default=300)  # seconds
    is_enabled = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Connector(db.Model):
    """Connector model"""
    __tablename__ = 'connectors'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(120), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # github, jenkins, sharepoint, etc.
    status = db.Column(db.String(20), default='disconnected')
    credentials = db.Column(JSON)
    last_test = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class DataTable(db.Model):
    """Data Table model"""
    __tablename__ = 'data_tables'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(120), nullable=False)
    source_integration = db.Column(db.String(36))
    row_count = db.Column(db.Integer, default=0)
    column_count = db.Column(db.Integer, default=0)
    last_updated = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ChatMessage(db.Model):
    """Chat Message model"""
    __tablename__ = 'chat_messages'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'))
    message = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class AuditLog(db.Model):
    """Audit Log model"""
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36))
    action = db.Column(db.String(120))
    resource_type = db.Column(db.String(50))
    resource_id = db.Column(db.String(36))
    details = db.Column(JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SyncJob(db.Model):
    """Sync Job model"""
    __tablename__ = 'sync_jobs'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    integration_id = db.Column(db.String(36))
    status = db.Column(db.String(20))  # pending, running, completed, failed
    records_processed = db.Column(db.Integer, default=0)
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    error_message = db.Column(db.Text)