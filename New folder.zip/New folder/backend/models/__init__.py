"""
Models Package - 360° Enterprise Dashboard
All database models for the application
"""

from flask_sqlalchemy import SQLAlchemy

# Initialize SQLAlchemy
db = SQLAlchemy()


def init_models(db_instance):
    """Initialize all models with database instance"""
    
    from models.user import create_user_model
    from models.integrations import create_azure_integration_model, create_sharepoint_integration_model
    from models.storage import create_ai_interaction_model, create_storage_file_model
    from models.splunk import create_splunk_query_model
    
    # Create all models
    User = create_user_model(db_instance)
    AzureIntegration = create_azure_integration_model(db_instance)
    SharePointIntegration = create_sharepoint_integration_model(db_instance)
    AIInteraction = create_ai_interaction_model(db_instance)
    StorageFile = create_storage_file_model(db_instance)
    SplunkQuery = create_splunk_query_model(db_instance)
    
    return {
        'User': User,
        'AzureIntegration': AzureIntegration,
        'SharePointIntegration': SharePointIntegration,
        'AIInteraction': AIInteraction,
        'StorageFile': StorageFile,
        'SplunkQuery': SplunkQuery
    }


# Export models
__all__ = [
    'db',
    'init_models'
]