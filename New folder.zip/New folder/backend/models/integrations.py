"""
Integration Models - 360° Enterprise Dashboard
Handles Azure and SharePoint integration tracking
"""

from datetime import datetime
import logging

logger = logging.getLogger(__name__)


def create_azure_integration_model(db):
    """Factory function to create AzureIntegration model"""
    
    class AzureIntegration(db.Model):
        """Azure subscription integration tracking"""
        __tablename__ = 'azure_integrations'
        
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
        subscription_id = db.Column(db.String(255), nullable=False)
        tenant_id = db.Column(db.String(255), nullable=False)
        client_id = db.Column(db.String(255), nullable=False)
        status = db.Column(db.String(50), default='connected')
        last_sync = db.Column(db.DateTime)
        resources_count = db.Column(db.Integer, default=24)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        
        def to_dict(self):
            """Convert to dictionary"""
            try:
                return {
                    'id': self.id,
                    'subscription_id': self.subscription_id,
                    'tenant_id': self.tenant_id,
                    'status': self.status,
                    'last_sync': self.last_sync.isoformat() if self.last_sync else None,
                    'resources_count': self.resources_count,
                    'created_at': self.created_at.isoformat() if self.created_at else None
                }
            except Exception as e:
                logger.error(f"✗ Error converting AzureIntegration to dict: {e}")
                return {}
        
        def __repr__(self):
            return f"<AzureIntegration {self.subscription_id}>"
    
    return AzureIntegration


def create_sharepoint_integration_model(db):
    """Factory function to create SharePointIntegration model"""
    
    class SharePointIntegration(db.Model):
        """SharePoint site integration tracking"""
        __tablename__ = 'sharepoint_integrations'
        
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
        site_url = db.Column(db.String(255), nullable=False)
        status = db.Column(db.String(50), default='connected')
        last_sync = db.Column(db.DateTime)
        documents_count = db.Column(db.Integer, default=0)
        sites_count = db.Column(db.Integer, default=8)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        
        def to_dict(self):
            """Convert to dictionary"""
            try:
                return {
                    'id': self.id,
                    'site_url': self.site_url,
                    'status': self.status,
                    'last_sync': self.last_sync.isoformat() if self.last_sync else None,
                    'documents_count': self.documents_count,
                    'sites_count': self.sites_count,
                    'created_at': self.created_at.isoformat() if self.created_at else None
                }
            except Exception as e:
                logger.error(f"✗ Error converting SharePointIntegration to dict: {e}")
                return {}
        
        def __repr__(self):
            return f"<SharePointIntegration {self.site_url}>"
    
    return SharePointIntegration