"""
Azure Storage Connector
Handles all interactions with Azure Blob Storage and File Storage services
"""

import os
import logging
import io
from typing import Optional, List, Dict, Any, BinaryIO
from datetime import datetime, timedelta
import traceback
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


class AzureStorageConnectorError(Exception):
    """Custom exception for Azure Storage connector errors"""
    pass


class AzureStorageConnector:
    """
    Connector for Azure Storage services (Blob Storage)
    Handles file uploads, downloads, deletions, and container management
    """
    
    def __init__(self):
        """Initialize Azure Storage connector with configuration from environment"""
        try:
            self.account_name = os.getenv('AZURE_STORAGE_ACCOUNT_NAME')
            self.account_key = os.getenv('AZURE_STORAGE_ACCOUNT_KEY')
            self.connection_string = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
            self.container_name = os.getenv('AZURE_STORAGE_CONTAINER_NAME', 'uploads')
            
            # Validate required configuration
            if not self.connection_string:
                if not self.account_name or not self.account_key:
                    raise AzureStorageConnectorError(
                        "Missing Azure Storage configuration: "
                        "AZURE_STORAGE_CONNECTION_STRING or "
                        "AZURE_STORAGE_ACCOUNT_NAME and AZURE_STORAGE_ACCOUNT_KEY"
                    )
                # Build connection string from components
                self.connection_string = (
                    f"DefaultEndpointsProtocol=https;"
                    f"AccountName={self.account_name};"
                    f"AccountKey={self.account_key};"
                    f"EndpointSuffix=core.windows.net"
                )
            
            # Import Azure Storage clients
            try:
                from azure.storage.blob import BlobServiceClient, ContainerClient, BlobClient
                self.BlobServiceClient = BlobServiceClient
                self.ContainerClient = ContainerClient
                self.BlobClient = BlobClient
                
                # Initialize blob service client
                self.blob_service_client = BlobServiceClient.from_connection_string(
                    self.connection_string
                )
                
                logger.info("✓ Azure Storage client initialized successfully")
            except ImportError as import_err:
                raise AzureStorageConnectorError(
                    f"Failed to import Azure Storage library: {str(import_err)}\n"
                    f"Install with: pip install azure-storage-blob"
                )
            except Exception as client_err:
                raise AzureStorageConnectorError(
                    f"Failed to initialize Azure Storage client: {str(client_err)}"
                )
            
            # Extract account name from connection string if not set
            if not self.account_name and 'AccountName=' in self.connection_string:
                self.account_name = self.connection_string.split('AccountName=')[1].split(';')[0]
            
            self.is_connected = True
            
            # Ensure container exists
            try:
                self._ensure_container_exists()
                logger.info(f"✓ Container verified: {self.container_name}")
            except Exception as container_err:
                logger.warning(f"⚠ Failed to verify container: {container_err}")
            
            logger.info(f"✓ Azure Storage Connector ready")
            logger.info(f"  - Account: {self.account_name}")
            logger.info(f"  - Container: {self.container_name}")
            
        except AzureStorageConnectorError:
            raise
        except Exception as e:
            logger.error(f"✗ Failed to initialize Azure Storage Connector: {e}")
            self.is_connected = False
            raise AzureStorageConnectorError(f"Initialization failed: {str(e)}")
    
    
    def _ensure_container_exists(self) -> bool:
        """
        Ensure the container exists, create if it doesn't
        
        Returns:
            True if container exists or was created
        """
        try:
            container_client = self.blob_service_client.get_container_client(
                self.container_name
            )
            
            # Try to get container properties (tests if it exists)
            try:
                container_client.get_container_properties()
                logger.info(f"✓ Container '{self.container_name}' exists")
                return True
            except Exception:
                # Container doesn't exist, create it
                self.blob_service_client.create_container(name=self.container_name)
                logger.info(f"✓ Container '{self.container_name}' created successfully")
                return True
        
        except Exception as e:
            logger.error(f"✗ Error ensuring container exists: {e}")
            raise
    
    
    def upload_file(
        self,
        file_path: str,
        blob_name: Optional[str] = None,
        overwrite: bool = True,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Upload a file to Azure Blob Storage
        
        Args:
            file_path: Local file path to upload
            blob_name: Name for blob in storage (defaults to filename)
            overwrite: Whether to overwrite if blob exists
            user_id: Optional user identifier for tracking
        
        Returns:
            Dictionary with upload result
            {
                'success': bool,
                'blob_name': str,
                'blob_url': str,
                'file_size': int,
                'timestamp': str,
                'error': str (if failed)
            }
        """
        try:
            # Validate file exists
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")
            
            if not os.path.isfile(file_path):
                raise ValueError(f"Path is not a file: {file_path}")
            
            # Get file size
            file_size = os.path.getsize(file_path)
            
            # Use filename as blob name if not provided
            if not blob_name:
                blob_name = os.path.basename(file_path)
            
            # Organize by user if user_id provided
            if user_id:
                blob_name = f"user-{user_id}/{blob_name}"
            
            logger.info(f"📤 Uploading file: {blob_name} (size: {file_size} bytes, user: {user_id or 'anonymous'})")
            
            try:
                # Upload file
                blob_client = self.blob_service_client.get_blob_client(
                    container=self.container_name,
                    blob=blob_name
                )
                
                with open(file_path, "rb") as data:
                    blob_client.upload_blob(data, overwrite=overwrite)
                
                # Get blob URL
                blob_url = blob_client.url
                
                logger.info(f"✓ File uploaded successfully: {blob_name}")
                
                return {
                    'success': True,
                    'blob_name': blob_name,
                    'blob_url': blob_url,
                    'file_size': file_size,
                    'timestamp': datetime.utcnow().isoformat(),
                    'container': self.container_name
                }
            
            except Exception as upload_err:
                logger.error(f"✗ Upload error: {upload_err}")
                return {
                    'success': False,
                    'blob_name': blob_name,
                    'file_size': file_size,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(upload_err)
                }
        
        except FileNotFoundError as file_err:
            logger.error(f"✗ File error: {file_err}")
            return {
                'success': False,
                'blob_name': blob_name or os.path.basename(file_path),
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(file_err)
            }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in upload_file: {e}")
            logger.debug(traceback.format_exc())
            return {
                'success': False,
                'blob_name': blob_name or '',
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def upload_bytes(
        self,
        data: bytes,
        blob_name: str,
        overwrite: bool = True,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Upload bytes/data to Azure Blob Storage
        
        Args:
            data: Bytes to upload
            blob_name: Name for blob in storage
            overwrite: Whether to overwrite if blob exists
            user_id: Optional user identifier for tracking
        
        Returns:
            Dictionary with upload result
        """
        try:
            if not isinstance(data, bytes):
                raise TypeError("Data must be bytes")
            
            if not blob_name:
                raise ValueError("Blob name cannot be empty")
            
            file_size = len(data)
            
            # Organize by user if user_id provided
            if user_id:
                blob_name = f"user-{user_id}/{blob_name}"
            
            logger.info(f"📤 Uploading bytes: {blob_name} (size: {file_size} bytes)")
            
            try:
                blob_client = self.blob_service_client.get_blob_client(
                    container=self.container_name,
                    blob=blob_name
                )
                
                blob_client.upload_blob(data, overwrite=overwrite)
                blob_url = blob_client.url
                
                logger.info(f"✓ Bytes uploaded successfully: {blob_name}")
                
                return {
                    'success': True,
                    'blob_name': blob_name,
                    'blob_url': blob_url,
                    'file_size': file_size,
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as upload_err:
                logger.error(f"✗ Upload error: {upload_err}")
                return {
                    'success': False,
                    'blob_name': blob_name,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(upload_err)
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in upload_bytes: {e}")
            return {
                'success': False,
                'blob_name': blob_name,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def download_file(
        self,
        blob_name: str,
        local_path: str,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Download a file from Azure Blob Storage
        
        Args:
            blob_name: Name of blob to download
            local_path: Local path to save file
            user_id: Optional user identifier for tracking
        
        Returns:
            Dictionary with download result
        """
        try:
            # Organize by user if user_id provided
            if user_id:
                blob_name = f"user-{user_id}/{blob_name}"
            
            logger.info(f"📥 Downloading file: {blob_name}")
            
            try:
                blob_client = self.blob_service_client.get_blob_client(
                    container=self.container_name,
                    blob=blob_name
                )
                
                # Download blob
                download_stream = blob_client.download_blob()
                
                # Save to local file
                with open(local_path, "wb") as file:
                    file.write(download_stream.readall())
                
                file_size = os.path.getsize(local_path)
                
                logger.info(f"✓ File downloaded successfully: {blob_name} -> {local_path}")
                
                return {
                    'success': True,
                    'blob_name': blob_name,
                    'local_path': local_path,
                    'file_size': file_size,
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as download_err:
                logger.error(f"✗ Download error: {download_err}")
                return {
                    'success': False,
                    'blob_name': blob_name,
                    'local_path': local_path,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(download_err)
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in download_file: {e}")
            return {
                'success': False,
                'blob_name': blob_name,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def download_bytes(
        self,
        blob_name: str,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Download blob as bytes from Azure Blob Storage
        
        Args:
            blob_name: Name of blob to download
            user_id: Optional user identifier for tracking
        
        Returns:
            Dictionary with downloaded bytes
            {
                'success': bool,
                'data': bytes,
                'file_size': int,
                'timestamp': str,
                'error': str (if failed)
            }
        """
        try:
            # Organize by user if user_id provided
            if user_id:
                blob_name = f"user-{user_id}/{blob_name}"
            
            logger.info(f"📥 Downloading bytes: {blob_name}")
            
            try:
                blob_client = self.blob_service_client.get_blob_client(
                    container=self.container_name,
                    blob=blob_name
                )
                
                # Download blob
                download_stream = blob_client.download_blob()
                data = download_stream.readall()
                
                logger.info(f"✓ Bytes downloaded successfully: {blob_name} ({len(data)} bytes)")
                
                return {
                    'success': True,
                    'blob_name': blob_name,
                    'data': data,
                    'file_size': len(data),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as download_err:
                logger.error(f"✗ Download error: {download_err}")
                return {
                    'success': False,
                    'blob_name': blob_name,
                    'data': None,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(download_err)
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in download_bytes: {e}")
            return {
                'success': False,
                'blob_name': blob_name,
                'data': None,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def delete_file(self, blob_name: str, user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a file from Azure Blob Storage
        
        Args:
            blob_name: Name of blob to delete
            user_id: Optional user identifier for tracking
        
        Returns:
            Dictionary with delete result
        """
        try:
            # Organize by user if user_id provided
            if user_id:
                blob_name = f"user-{user_id}/{blob_name}"
            
            logger.info(f"🗑️ Deleting file: {blob_name}")
            
            try:
                blob_client = self.blob_service_client.get_blob_client(
                    container=self.container_name,
                    blob=blob_name
                )
                
                blob_client.delete_blob()
                
                logger.info(f"✓ File deleted successfully: {blob_name}")
                
                return {
                    'success': True,
                    'blob_name': blob_name,
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as delete_err:
                logger.error(f"✗ Delete error: {delete_err}")
                return {
                    'success': False,
                    'blob_name': blob_name,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(delete_err)
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in delete_file: {e}")
            return {
                'success': False,
                'blob_name': blob_name,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def list_files(self, prefix: Optional[str] = None, user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        List files in container
        
        Args:
            prefix: Optional prefix to filter blobs
            user_id: Optional user_id to list user's files only
        
        Returns:
            Dictionary with list of blobs
            {
                'success': bool,
                'files': List[Dict],
                'count': int,
                'timestamp': str,
                'error': str (if failed)
            }
        """
        try:
            # Set prefix to user folder if user_id provided
            if user_id:
                prefix = f"user-{user_id}/"
            
            logger.info(f"📋 Listing files (prefix: {prefix or 'none'})")
            
            try:
                container_client = self.blob_service_client.get_container_client(
                    self.container_name
                )
                
                # List blobs
                blobs = container_client.list_blobs(name_starts_with=prefix)
                
                files = []
                for blob in blobs:
                    files.append({
                        'name': blob.name,
                        'size': blob.size,
                        'last_modified': blob.last_modified.isoformat() if blob.last_modified else None,
                        'content_type': blob.content_settings.content_type if blob.content_settings else None
                    })
                
                logger.info(f"✓ Listed {len(files)} files")
                
                return {
                    'success': True,
                    'files': files,
                    'count': len(files),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as list_err:
                logger.error(f"✗ List error: {list_err}")
                return {
                    'success': False,
                    'files': [],
                    'count': 0,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(list_err)
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in list_files: {e}")
            return {
                'success': False,
                'files': [],
                'count': 0,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def get_file_url(self, blob_name: str, user_id: Optional[str] = None, sas_expiry_hours: int = 24) -> Dict[str, Any]:
        """
        Get URL for a blob (with optional SAS token for time-limited access)
        
        Args:
            blob_name: Name of blob
            user_id: Optional user identifier for tracking
            sas_expiry_hours: Hours until SAS token expires (default: 24)
        
        Returns:
            Dictionary with blob URL
            {
                'success': bool,
                'url': str,
                'blob_name': str,
                'expires_at': str,
                'timestamp': str,
                'error': str (if failed)
            }
        """
        try:
            # Organize by user if user_id provided
            if user_id:
                blob_name = f"user-{user_id}/{blob_name}"
            
            logger.info(f"🔗 Getting URL for blob: {blob_name}")
            
            try:
                blob_client = self.blob_service_client.get_blob_client(
                    container=self.container_name,
                    blob=blob_name
                )
                
                # Get blob URL
                blob_url = blob_client.url
                
                logger.info(f"✓ URL generated: {blob_name}")
                
                return {
                    'success': True,
                    'url': blob_url,
                    'blob_name': blob_name,
                    'timestamp': datetime.utcnow().isoformat(),
                    'expires_at': (datetime.utcnow() + timedelta(hours=sas_expiry_hours)).isoformat()
                }
            
            except Exception as url_err:
                logger.error(f"✗ URL generation error: {url_err}")
                return {
                    'success': False,
                    'blob_name': blob_name,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(url_err)
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_file_url: {e}")
            return {
                'success': False,
                'blob_name': blob_name,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """
        Get storage account statistics
        
        Returns:
            Dictionary with storage stats
            {
                'account_name': str,
                'container_name': str,
                'total_files': int,
                'total_size': int,
                'timestamp': str
            }
        """
        try:
            logger.info("📊 Gathering storage statistics...")
            
            try:
                container_client = self.blob_service_client.get_container_client(
                    self.container_name
                )
                
                # List all blobs
                blobs = container_client.list_blobs()
                
                total_files = 0
                total_size = 0
                
                for blob in blobs:
                    total_files += 1
                    total_size += blob.size if blob.size else 0
                
                logger.info(f"✓ Storage stats: {total_files} files, {total_size} bytes total")
                
                return {
                    'account_name': self.account_name,
                    'container_name': self.container_name,
                    'total_files': total_files,
                    'total_size': total_size,
                    'total_size_mb': round(total_size / (1024 * 1024), 2),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as stats_err:
                logger.error(f"✗ Stats error: {stats_err}")
                return {
                    'account_name': self.account_name,
                    'container_name': self.container_name,
                    'error': str(stats_err),
                    'timestamp': datetime.utcnow().isoformat()
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_storage_stats: {e}")
            return {
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check Azure Storage service health
        
        Returns:
            Dictionary with health status
            {
                'status': str ('healthy' or 'unhealthy'),
                'connected': bool,
                'account': str,
                'container': str,
                'timestamp': str,
                'error': str (if unhealthy)
            }
        """
        try:
            if not self.is_connected or not hasattr(self, 'blob_service_client'):
                return {
                    'status': 'unhealthy',
                    'connected': False,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': 'Client not initialized'
                }
            
            try:
                # Try to list containers
                list(self.blob_service_client.list_containers())
                
                logger.info("✓ Azure Storage health check passed")
                return {
                    'status': 'healthy',
                    'connected': True,
                    'account': self.account_name,
                    'container': self.container_name,
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as health_err:
                logger.error(f"✗ Azure Storage health check failed: {health_err}")
                return {
                    'status': 'unhealthy',
                    'connected': False,
                    'account': self.account_name,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(health_err)
                }
        
        except Exception as e:
            logger.error(f"✗ Error in health check: {e}")
            return {
                'status': 'unhealthy',
                'connected': False,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }


def get_azure_storage_connector() -> Optional[AzureStorageConnector]:
    """
    Factory function to get Azure Storage connector instance
    
    Returns:
        AzureStorageConnector instance or None if initialization fails
    """
    try:
        return AzureStorageConnector()
    except AzureStorageConnectorError as e:
        logger.error(f"✗ Failed to create Azure Storage connector: {e}")
        return None
    except Exception as e:
        logger.error(f"✗ Unexpected error creating connector: {e}")
        return None