"""
Database Connector
Handles PostgreSQL database connections with connection pooling and error handling
"""

import os
import logging
from typing import Optional, Dict, Any
from datetime import datetime
import traceback
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


class DatabaseConnectorError(Exception):
    """Custom exception for database connector errors"""
    pass


class DatabaseConnector:
    """
    Database connector for PostgreSQL
    Manages connections, pooling, and health checks
    """
    
    def __init__(self):
        """Initialize database connector with configuration from environment"""
        try:
            self.db_type = os.getenv('DB_TYPE', 'postgresql')
            self.db_host = os.getenv('DB_HOST', 'localhost')
            self.db_port = os.getenv('DB_PORT', '5432')
            self.db_name = os.getenv('DB_NAME', 'api_migration_db')
            self.db_user = os.getenv('DB_USER', 'api_user')
            self.db_password = os.getenv('DB_PASSWORD', '')
            self.db_sslmode = os.getenv('DB_SSLMODE', 'disable')
            
            # Validate required configuration
            if not self.db_password:
                logger.warning("⚠ Database password not configured in environment")
            
            # Build connection string
            self.connection_string = self._build_connection_string()
            self.is_connected = False
            self.connection_pool = None
            
            logger.info("✓ Database Connector initialized")
            logger.info(f"  - Type: {self.db_type}")
            logger.info(f"  - Host: {self.db_host}:{self.db_port}")
            logger.info(f"  - Database: {self.db_name}")
            logger.info(f"  - User: {self.db_user}")
            
        except Exception as e:
            logger.error(f"✗ Failed to initialize Database Connector: {e}")
            raise DatabaseConnectorError(f"Initialization failed: {str(e)}")
    
    
    def _build_connection_string(self) -> str:
        """
        Build database connection string
        
        Returns:
            Connection string for SQLAlchemy
        """
        try:
            if self.db_type == 'postgresql':
                # PostgreSQL connection string format
                connection_string = (
                    f"postgresql://{self.db_user}:{self.db_password}@"
                    f"{self.db_host}:{self.db_port}/{self.db_name}"
                )
                logger.info("✓ PostgreSQL connection string built successfully")
                return connection_string
            else:
                raise DatabaseConnectorError(f"Unsupported database type: {self.db_type}")
        
        except Exception as e:
            logger.error(f"✗ Error building connection string: {e}")
            raise DatabaseConnectorError(f"Connection string build failed: {str(e)}")
    
    
    def get_connection_string(self) -> str:
        """
        Get the full database connection string
        
        Returns:
            Database connection string
        """
        return self.connection_string
    
    
    def get_sqlalchemy_config(self) -> Dict[str, Any]:
        """
        Get SQLAlchemy configuration dictionary
        
        Returns:
            Dictionary with SQLAlchemy configuration
            {
                'SQLALCHEMY_DATABASE_URI': str,
                'SQLALCHEMY_TRACK_MODIFICATIONS': bool,
                'SQLALCHEMY_ENGINE_OPTIONS': dict
            }
        """
        try:
            config = {
                'SQLALCHEMY_DATABASE_URI': self.connection_string,
                'SQLALCHEMY_TRACK_MODIFICATIONS': False,
                'SQLALCHEMY_ENGINE_OPTIONS': {
                    'pool_size': 10,
                    'pool_recycle': 3600,
                    'pool_pre_ping': True,
                    'max_overflow': 20,
                    'echo': False,
                    'connect_args': {
                        'connect_timeout': 10,
                        'application_name': '360_dashboard',
                    }
                }
            }
            
            logger.info("✓ SQLAlchemy configuration prepared")
            return config
        
        except Exception as e:
            logger.error(f"✗ Error preparing SQLAlchemy config: {e}")
            raise DatabaseConnectorError(f"Config preparation failed: {str(e)}")
    
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Test database connection
        
        Returns:
            Dictionary with connection test result
            {
                'connected': bool,
                'timestamp': str,
                'error': str (if failed),
                'version': str (if successful)
            }
        """
        try:
            try:
                from psycopg2 import connect as pg_connect
            except ImportError:
                logger.error("✗ psycopg2 not installed. Install with: pip install psycopg2-binary")
                return {
                    'connected': False,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': 'psycopg2 library not installed'
                }
            
            try:
                # Build connection parameters
                conn_params = {
                    'host': self.db_host,
                    'port': int(self.db_port),
                    'database': self.db_name,
                    'user': self.db_user,
                    'password': self.db_password,
                    'connect_timeout': 10,
                }
                
                # If using SSL
                if self.db_sslmode != 'disable':
                    conn_params['sslmode'] = self.db_sslmode
                
                # Attempt connection
                conn = pg_connect(**conn_params)
                cursor = conn.cursor()
                
                # Get PostgreSQL version
                cursor.execute('SELECT version();')
                version = cursor.fetchone()[0]
                
                cursor.close()
                conn.close()
                
                logger.info("✓ Database connection test successful")
                self.is_connected = True
                
                return {
                    'connected': True,
                    'timestamp': datetime.utcnow().isoformat(),
                    'version': version,
                    'host': self.db_host,
                    'database': self.db_name
                }
            
            except Exception as pg_err:
                logger.error(f"✗ PostgreSQL connection test failed: {pg_err}")
                self.is_connected = False
                
                return {
                    'connected': False,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(pg_err),
                    'host': self.db_host,
                    'database': self.db_name
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in connection test: {e}")
            logger.debug(traceback.format_exc())
            
            return {
                'connected': False,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def health_check(self) -> Dict[str, Any]:
        """
        Perform comprehensive database health check
        
        Returns:
            Dictionary with health status
            {
                'status': str ('healthy', 'degraded', 'unhealthy'),
                'connected': bool,
                'response_time': float (in ms),
                'timestamp': str,
                'details': dict,
                'error': str (if unhealthy)
            }
        """
        try:
            import time
            from psycopg2 import connect as pg_connect
            
            start_time = time.time()
            
            try:
                conn_params = {
                    'host': self.db_host,
                    'port': int(self.db_port),
                    'database': self.db_name,
                    'user': self.db_user,
                    'password': self.db_password,
                    'connect_timeout': 5,
                }
                
                if self.db_sslmode != 'disable':
                    conn_params['sslmode'] = self.db_sslmode
                
                conn = pg_connect(**conn_params)
                cursor = conn.cursor()
                
                # Check if database is responding
                cursor.execute('SELECT 1;')
                cursor.fetchone()
                
                # Get database stats
                cursor.execute("""
                    SELECT 
                        datname,
                        pg_database_size(datname) as size,
                        numbackends
                    FROM pg_stat_database
                    WHERE datname = %s;
                """, (self.db_name,))
                
                db_stats = cursor.fetchone()
                
                cursor.close()
                conn.close()
                
                response_time = (time.time() - start_time) * 1000  # Convert to ms
                
                status = 'healthy' if response_time < 1000 else 'degraded'
                
                logger.info(f"✓ Database health check passed ({response_time:.2f}ms)")
                
                return {
                    'status': status,
                    'connected': True,
                    'response_time': response_time,
                    'timestamp': datetime.utcnow().isoformat(),
                    'details': {
                        'host': self.db_host,
                        'database': self.db_name,
                        'port': self.db_port,
                        'db_size': db_stats[1] if db_stats else 'N/A',
                        'active_connections': db_stats[2] if db_stats else 'N/A'
                    }
                }
            
            except Exception as pg_err:
                logger.error(f"✗ Database health check failed: {pg_err}")
                response_time = (time.time() - start_time) * 1000
                
                return {
                    'status': 'unhealthy',
                    'connected': False,
                    'response_time': response_time,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(pg_err),
                    'details': {
                        'host': self.db_host,
                        'database': self.db_name
                    }
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in health check: {e}")
            logger.debug(traceback.format_exc())
            
            return {
                'status': 'unhealthy',
                'connected': False,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def get_db_info(self) -> Dict[str, Any]:
        """
        Get detailed database information
        
        Returns:
            Dictionary with database information
        """
        try:
            info = {
                'type': self.db_type,
                'host': self.db_host,
                'port': self.db_port,
                'database': self.db_name,
                'user': self.db_user,
                'ssl_mode': self.db_sslmode,
                'connected': self.is_connected,
                'timestamp': datetime.utcnow().isoformat()
            }
            
            return info
        
        except Exception as e:
            logger.error(f"✗ Error getting database info: {e}")
            return {
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }


def get_database_connector() -> Optional[DatabaseConnector]:
    """
    Factory function to get database connector instance
    
    Returns:
        DatabaseConnector instance or None if initialization fails
    """
    try:
        return DatabaseConnector()
    except DatabaseConnectorError as e:
        logger.error(f"✗ Failed to create database connector: {e}")
        return None
    except Exception as e:
        logger.error(f"✗ Unexpected error creating connector: {e}")
        return None


def get_database_connection_string() -> Optional[str]:
    """
    Convenience function to get just the connection string
    
    Returns:
        Connection string or None if initialization fails
    """
    try:
        connector = DatabaseConnector()
        return connector.get_connection_string()
    except Exception as e:
        logger.error(f"✗ Error getting connection string: {e}")
        return None