"""
Azure OpenAI Connector
Handles all interactions with Azure OpenAI services with comprehensive error handling
"""

import os
import logging
import json
from typing import Optional, List, Dict, Any
from datetime import datetime
import traceback
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


class AzureOpenAIConnectorError(Exception):
    """Custom exception for Azure OpenAI connector errors"""
    pass


class AzureOpenAIConnector:
    """
    Connector for Azure OpenAI services
    Handles text generation, code review, and other AI operations
    """
    
    def __init__(self):
        """Initialize Azure OpenAI connector with configuration from environment"""
        try:
            self.endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
            self.api_key = os.getenv('AZURE_OPENAI_API_KEY')
            self.deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-5-mini')
            self.api_version = os.getenv('AZURE_OPENAI_VERSION', '2025-01-01-preview')
            
            # Validate required configuration
            if not self.endpoint or not self.api_key:
                raise AzureOpenAIConnectorError(
                    "Missing Azure OpenAI configuration: AZURE_OPENAI_ENDPOINT or AZURE_OPENAI_API_KEY"
                )
            
            # Import Azure OpenAI client
            try:
                from azure.ai.openai import AzureOpenAI
                self.client = AzureOpenAI(
                    api_key=self.api_key,
                    api_version=self.api_version,
                    azure_endpoint=self.endpoint
                )
                logger.info("✓ Azure OpenAI client initialized successfully")
            except ImportError as import_err:
                raise AzureOpenAIConnectorError(f"Failed to import Azure OpenAI library: {str(import_err)}")
            except Exception as client_err:
                raise AzureOpenAIConnectorError(f"Failed to initialize Azure OpenAI client: {str(client_err)}")
            
            self.is_connected = True
            logger.info(f"✓ Azure OpenAI Connector ready")
            logger.info(f"  - Endpoint: {self.endpoint}")
            logger.info(f"  - Deployment: {self.deployment}")
            logger.info(f"  - API Version: {self.api_version}")
            
        except AzureOpenAIConnectorError:
            raise
        except Exception as e:
            logger.error(f"✗ Failed to initialize Azure OpenAI Connector: {e}")
            self.is_connected = False
            raise AzureOpenAIConnectorError(f"Initialization failed: {str(e)}")
    
    
    def generate_text(
        self,
        prompt: str,
        max_tokens: int = 500,
        temperature: float = 0.7,
        top_p: float = 0.95,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Generate text using Azure OpenAI
        
        Args:
            prompt: The prompt to send to the model
            max_tokens: Maximum tokens in response (default: 500, max: 1000 for mini)
            temperature: Temperature for response creativity (0.0 to 2.0)
            top_p: Nucleus sampling parameter
            user_id: Optional user identifier for tracking
        
        Returns:
            Dictionary with generated text and metadata
            {
                'success': bool,
                'text': str,
                'tokens_used': int,
                'finish_reason': str,
                'timestamp': str,
                'error': str (if failed)
            }
        """
        try:
            # Validate inputs
            if not prompt or not isinstance(prompt, str):
                raise ValueError("Prompt must be a non-empty string")
            
            if max_tokens < 1 or max_tokens > 1000:
                logger.warning(f"⚠ max_tokens {max_tokens} out of range (1-1000), clamping to 1000")
                max_tokens = min(max_tokens, 1000)
            
            if temperature < 0 or temperature > 2:
                logger.warning(f"⚠ temperature {temperature} out of range (0-2), using 0.7")
                temperature = 0.7
            
            logger.info(f"🤖 Generating text (user: {user_id or 'anonymous'}, tokens: {max_tokens})")
            
            try:
                response = self.client.chat.completions.create(
                    model=self.deployment,
                    messages=[
                        {"role": "system", "content": "You are a helpful assistant."},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=max_tokens,
                    temperature=temperature,
                    top_p=top_p,
                    timeout=30
                )
                
                generated_text = response.choices[0].message.content
                tokens_used = response.usage.total_tokens if response.usage else 0
                finish_reason = response.choices[0].finish_reason
                
                logger.info(f"✓ Text generated successfully (tokens: {tokens_used}, reason: {finish_reason})")
                
                return {
                    'success': True,
                    'text': generated_text,
                    'tokens_used': tokens_used,
                    'finish_reason': finish_reason,
                    'timestamp': datetime.utcnow().isoformat(),
                    'model': self.deployment
                }
            
            except TimeoutError as timeout_err:
                logger.error(f"✗ Azure OpenAI request timeout: {timeout_err}")
                return {
                    'success': False,
                    'text': None,
                    'tokens_used': 0,
                    'finish_reason': None,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': 'Request timeout - service taking too long to respond'
                }
            
            except Exception as api_err:
                logger.error(f"✗ Azure OpenAI API error: {api_err}")
                return {
                    'success': False,
                    'text': None,
                    'tokens_used': 0,
                    'finish_reason': None,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(api_err)
                }
        
        except ValueError as val_err:
            logger.error(f"✗ Validation error: {val_err}")
            return {
                'success': False,
                'text': None,
                'tokens_used': 0,
                'finish_reason': None,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(val_err)
            }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in text generation: {e}")
            logger.debug(traceback.format_exc())
            return {
                'success': False,
                'text': None,
                'tokens_used': 0,
                'finish_reason': None,
                'timestamp': datetime.utcnow().isoformat(),
                'error': f'Unexpected error: {str(e)}'
            }
    
    
    def code_review(
        self,
        code: str,
        language: str = 'python',
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Perform code review using Azure OpenAI
        
        Args:
            code: The code to review
            language: Programming language (default: python)
            user_id: Optional user identifier for tracking
        
        Returns:
            Dictionary with review findings and recommendations
            {
                'success': bool,
                'review': str,
                'issues': List[str],
                'suggestions': List[str],
                'timestamp': str,
                'error': str (if failed)
            }
        """
        try:
            if not code or not isinstance(code, str):
                raise ValueError("Code must be a non-empty string")
            
            prompt = f"""Review the following {language} code and provide:
1. Any issues or bugs found
2. Suggestions for improvement
3. Best practices violations

Code:
```{language}
{code}
```

Provide a detailed review with specific line-by-line feedback."""
            
            logger.info(f"🔍 Code review initiated (language: {language}, user: {user_id or 'anonymous'})")
            
            result = self.generate_text(
                prompt=prompt,
                max_tokens=800,
                temperature=0.5,
                user_id=user_id
            )
            
            if result['success']:
                review_text = result['text']
                
                # Parse review for structure
                return {
                    'success': True,
                    'review': review_text,
                    'issues': self._extract_issues(review_text),
                    'suggestions': self._extract_suggestions(review_text),
                    'timestamp': result['timestamp'],
                    'tokens_used': result['tokens_used'],
                    'model': result['model']
                }
            else:
                return {
                    'success': False,
                    'review': None,
                    'issues': [],
                    'suggestions': [],
                    'timestamp': result['timestamp'],
                    'error': result['error']
                }
        
        except ValueError as val_err:
            logger.error(f"✗ Code review validation error: {val_err}")
            return {
                'success': False,
                'review': None,
                'issues': [],
                'suggestions': [],
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(val_err)
            }
        
        except Exception as e:
            logger.error(f"✗ Error in code review: {e}")
            logger.debug(traceback.format_exc())
            return {
                'success': False,
                'review': None,
                'issues': [],
                'suggestions': [],
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def summarize_text(
        self,
        text: str,
        max_length: int = 200,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Summarize text using Azure OpenAI
        
        Args:
            text: The text to summarize
            max_length: Maximum length of summary in words
            user_id: Optional user identifier for tracking
        
        Returns:
            Dictionary with summary
        """
        try:
            if not text or not isinstance(text, str):
                raise ValueError("Text must be a non-empty string")
            
            prompt = f"""Summarize the following text in approximately {max_length} words:

{text}

Provide a clear, concise summary capturing the main points."""
            
            logger.info(f"📝 Text summarization initiated (user: {user_id or 'anonymous'})")
            
            result = self.generate_text(
                prompt=prompt,
                max_tokens=300,
                temperature=0.5,
                user_id=user_id
            )
            
            if result['success']:
                return {
                    'success': True,
                    'summary': result['text'],
                    'timestamp': result['timestamp'],
                    'tokens_used': result['tokens_used'],
                    'model': result['model']
                }
            else:
                return {
                    'success': False,
                    'summary': None,
                    'timestamp': result['timestamp'],
                    'error': result['error']
                }
        
        except Exception as e:
            logger.error(f"✗ Error in text summarization: {e}")
            return {
                'success': False,
                'summary': None,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check Azure OpenAI service health
        
        Returns:
            Dictionary with health status
            {
                'status': str ('healthy' or 'unhealthy'),
                'connected': bool,
                'timestamp': str,
                'error': str (if unhealthy)
            }
        """
        try:
            if not self.is_connected or not hasattr(self, 'client'):
                return {
                    'status': 'unhealthy',
                    'connected': False,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': 'Client not initialized'
                }
            
            # Try a simple API call
            try:
                response = self.client.chat.completions.create(
                    model=self.deployment,
                    messages=[
                        {"role": "user", "content": "Say 'ok'"}
                    ],
                    max_tokens=10,
                    timeout=10
                )
                
                logger.info("✓ Azure OpenAI health check passed")
                return {
                    'status': 'healthy',
                    'connected': True,
                    'timestamp': datetime.utcnow().isoformat(),
                    'deployment': self.deployment
                }
            
            except Exception as api_err:
                logger.error(f"✗ Azure OpenAI health check failed: {api_err}")
                return {
                    'status': 'unhealthy',
                    'connected': False,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(api_err)
                }
        
        except Exception as e:
            logger.error(f"✗ Error in health check: {e}")
            return {
                'status': 'unhealthy',
                'connected': False,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
    
    
    @staticmethod
    def _extract_issues(text: str) -> List[str]:
        """Extract issues from review text"""
        try:
            lines = text.split('\n')
            issues = []
            for line in lines:
                if 'issue' in line.lower() or 'bug' in line.lower() or 'error' in line.lower():
                    issue = line.strip()
                    if issue and len(issue) > 10:
                        issues.append(issue)
            return issues[:5]  # Return top 5 issues
        except Exception as e:
            logger.warning(f"⚠ Error extracting issues: {e}")
            return []
    
    
    @staticmethod
    def _extract_suggestions(text: str) -> List[str]:
        """Extract suggestions from review text"""
        try:
            lines = text.split('\n')
            suggestions = []
            for line in lines:
                if 'suggest' in line.lower() or 'recommend' in line.lower() or 'improve' in line.lower():
                    suggestion = line.strip()
                    if suggestion and len(suggestion) > 10:
                        suggestions.append(suggestion)
            return suggestions[:5]  # Return top 5 suggestions
        except Exception as e:
            logger.warning(f"⚠ Error extracting suggestions: {e}")
            return []


def get_azure_openai_connector() -> Optional[AzureOpenAIConnector]:
    """
    Factory function to get Azure OpenAI connector instance
    
    Returns:
        AzureOpenAIConnector instance or None if initialization fails
    """
    try:
        return AzureOpenAIConnector()
    except AzureOpenAIConnectorError as e:
        logger.error(f"✗ Failed to create Azure OpenAI connector: {e}")
        return None
    except Exception as e:
        logger.error(f"✗ Unexpected error creating connector: {e}")
        return None