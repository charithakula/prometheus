"""
Main API Routes and Blueprints

Core API endpoints for dashboard, integrations, and data management
"""

from flask import Blueprint, jsonify, request
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

main_bp = Blueprint('main', __name__, url_prefix='/api')


# ==================== HEALTH & STATUS ====================

@main_bp.route('/status', methods=['GET'])
def get_status():
    """Get system status"""
    return jsonify({
        'status': 'operational',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '3.0.0'
    }), 200


# ==================== DASHBOARD ====================

@main_bp.route('/dashboard/overview', methods=['GET'])
def get_dashboard_overview():
    """Get dashboard overview metrics"""
    return jsonify({
        'active_integrations': 12,
        'data_tables': 45,
        'total_records': 2400000,
        'sync_success_rate': 99.7,
        'last_sync': datetime.utcnow().isoformat()
    }), 200


@main_bp.route('/dashboard/metrics', methods=['GET'])
def get_dashboard_metrics():
    """Get detailed metrics"""
    return jsonify({
        'cpu_usage': 45,
        'memory_usage': 62,
        'disk_usage': 78,
        'active_users': 23,
        'api_calls_24h': 156000,
        'errors_24h': 12
    }), 200


# ==================== INTEGRATIONS ====================

@main_bp.route('/integrations', methods=['GET'])
def list_integrations():
    """List all integrations"""
    integrations = [
        {
            'id': '1',
            'name': 'Microsoft Azure',
            'type': 'azure',
            'status': 'connected',
            'last_sync': '2 minutes ago',
            'tables': 18,
            'records': 1200000
        },
        {
            'id': '2',
            'name': 'Splunk Enterprise',
            'type': 'splunk',
            'status': 'connected',
            'last_sync': '5 minutes ago',
            'indices': 12,
            'events': 856000
        },
        {
            'id': '3',
            'name': 'SharePoint Online',
            'type': 'sharepoint',
            'status': 'connected',
            'last_sync': '8 minutes ago',
            'sites': 8,
            'lists': 34
        }
    ]
    return jsonify(integrations), 200


@main_bp.route('/integrations/<integration_id>', methods=['GET'])
def get_integration(integration_id):
    """Get specific integration details"""
    return jsonify({
        'id': integration_id,
        'name': 'Integration Name',
        'type': 'azure',
        'status': 'connected',
        'config': {
            'endpoint': 'https://...',
            'auth_type': 'oauth2'
        }
    }), 200


@main_bp.route('/integrations', methods=['POST'])
def create_integration():
    """Create new integration"""
    data = request.get_json()
    return jsonify({
        'id': 'new-id',
        'name': data.get('name'),
        'type': data.get('type'),
        'status': 'inactive'
    }), 201


@main_bp.route('/integrations/<integration_id>/sync', methods=['POST'])
def sync_integration(integration_id):
    """Trigger integration sync"""
    return jsonify({
        'sync_id': 'sync-123',
        'integration_id': integration_id,
        'status': 'running',
        'started_at': datetime.utcnow().isoformat()
    }), 200


# ==================== DATA TABLES ====================

@main_bp.route('/data-tables', methods=['GET'])
def list_data_tables():
    """List all data tables"""
    tables = [
        {
            'id': '1',
            'name': 'Azure Users',
            'rows': 5000,
            'columns': 15,
            'source': 'Azure',
            'last_updated': '2 hours ago'
        },
        {
            'id': '2',
            'name': 'Splunk Logs',
            'rows': 1500000,
            'columns': 8,
            'source': 'Splunk',
            'last_updated': '5 minutes ago'
        }
    ]
    return jsonify(tables), 200


@main_bp.route('/data-tables/<table_id>', methods=['GET'])
def get_data_table(table_id):
    """Get table data with pagination"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 50, type=int)
    
    return jsonify({
        'table_id': table_id,
        'page': page,
        'limit': limit,
        'total_rows': 5000,
        'data': []
    }), 200


# ==================== CHAT ====================

@main_bp.route('/chat/message', methods=['POST'])
def send_chat_message():
    """Send chat message"""
    data = request.get_json()
    message = data.get('message')
    
    return jsonify({
        'id': 'msg-123',
        'user_message': message,
        'ai_response': 'Response to: ' + message,
        'timestamp': datetime.utcnow().isoformat()
    }), 200


@main_bp.route('/chat/history', methods=['GET'])
def get_chat_history():
    """Get chat history"""
    return jsonify({
        'messages': [
            {'role': 'user', 'text': 'Hello', 'timestamp': '2025-01-01T00:00:00Z'},
            {'role': 'ai', 'text': 'Hi there!', 'timestamp': '2025-01-01T00:00:01Z'}
        ]
    }), 200


# ==================== NOTIFICATIONS ====================

@main_bp.route('/notifications', methods=['GET'])
def get_notifications():
    """Get notifications"""
    return jsonify({
        'notifications': [
            {'id': '1', 'title': 'Sync completed', 'type': 'info'},
            {'id': '2', 'title': 'Error in Azure sync', 'type': 'error'}
        ]
    }), 200


@main_bp.route('/notifications', methods=['POST'])
def send_notification():
    """Send notification"""
    data = request.get_json()
    return jsonify({
        'id': 'notif-123',
        'title': data.get('title'),
        'message': data.get('message'),
        'type': data.get('type', 'info'),
        'sent_at': datetime.utcnow().isoformat()
    }), 201


# ==================== ERROR HANDLERS ====================

@main_bp.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404


@main_bp.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal error: {error}")
    return jsonify({'error': 'Internal server error'}), 500