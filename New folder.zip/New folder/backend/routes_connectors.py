"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║         360° ENTERPRISE DASHBOARD - CONNECTOR MANAGEMENT ROUTES              ║
║                                                                               ║
║                  Backend API Routes for Enterprise Connectors                 ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

from flask import Blueprint, request, jsonify
from functools import wraps
from datetime import datetime
import logging
from models import (
    db, Connector, Integration, DataTable, AuditLog, SyncJob
)
from utils import safe_dict_get, format_datetime, generate_id
from backend.auth.auth import verify_token, require_role

# Configure logging
logger = logging.getLogger(__name__)

# Create Blueprint
connectors_bp = Blueprint('connectors', __name__, url_prefix='/api/connectors')


# ═══════════════════════════════════════════════════════════════════════════════
# DECORATOR: Rate Limiting
# ═══════════════════════════════════════════════════════════════════════════════

def rate_limit(max_calls=100, time_window=3600):
    """Rate limiting decorator"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Implementation would use Redis or in-memory store
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# ═══════════════════════════════════════════════════════════════════════════════
# 1. CONNECTOR CRUD OPERATIONS
# ═══════════════════════════════════════════════════════════════════════════════

@connectors_bp.route('', methods=['GET'])
@verify_token
@rate_limit(max_calls=100, time_window=3600)
def get_all_connectors():
    """
    Get all available connectors
    
    Query Parameters:
        - status: filter by status (active, inactive, error)
        - type: filter by connector type
        - skip: pagination skip
        - limit: pagination limit
    
    Returns:
        JSON: List of connectors with metadata
    """
    try:
        status = request.args.get('status')
        connector_type = request.args.get('type')
        skip = int(request.args.get('skip', 0))
        limit = int(request.args.get('limit', 20))
        
        # Build query
        query = Connector.query
        
        if status:
            query = query.filter_by(status=status)
        
        if connector_type:
            query = query.filter_by(type=connector_type)
        
        # Get total count
        total = query.count()
        
        # Apply pagination
        connectors = query.offset(skip).limit(limit).all()
        
        return jsonify({
            'success': True,
            'data': [{
                'id': c.id,
                'name': c.name,
                'type': c.type,
                'status': c.status,
                'description': c.description,
                'config': c.config,
                'last_sync': format_datetime(c.last_sync),
                'created_at': format_datetime(c.created_at),
                'updated_at': format_datetime(c.updated_at),
                'health_score': c.health_score,
                'error_count': c.error_count
            } for c in connectors],
            'pagination': {
                'total': total,
                'skip': skip,
                'limit': limit,
                'pages': (total + limit - 1) // limit
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching connectors: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to fetch connectors',
            'message': str(e)
        }), 500


@connectors_bp.route('/<connector_id>', methods=['GET'])
@verify_token
def get_connector(connector_id):
    """
    Get specific connector details
    
    Parameters:
        - connector_id: Connector ID
    
    Returns:
        JSON: Connector details with full configuration
    """
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        # Get associated integrations
        integrations = Integration.query.filter_by(connector_id=connector_id).all()
        
        # Get sync history
        sync_jobs = SyncJob.query.filter_by(
            connector_id=connector_id
        ).order_by(SyncJob.created_at.desc()).limit(10).all()
        
        return jsonify({
            'success': True,
            'data': {
                'id': connector.id,
                'name': connector.name,
                'type': connector.type,
                'status': connector.status,
                'description': connector.description,
                'config': connector.config,
                'credentials': {
                    'username': connector.credentials.get('username') if connector.credentials else None,
                    'encrypted': True
                },
                'last_sync': format_datetime(connector.last_sync),
                'last_error': connector.last_error,
                'error_count': connector.error_count,
                'health_score': connector.health_score,
                'sync_interval': connector.sync_interval,
                'created_at': format_datetime(connector.created_at),
                'updated_at': format_datetime(connector.updated_at),
                'integrations_count': len(integrations),
                'integrations': [{
                    'id': i.id,
                    'name': i.name,
                    'status': i.status
                } for i in integrations],
                'recent_syncs': [{
                    'id': sj.id,
                    'status': sj.status,
                    'records_synced': sj.records_synced,
                    'duration': sj.duration,
                    'started_at': format_datetime(sj.created_at),
                    'error': sj.error_message
                } for sj in sync_jobs]
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to fetch connector',
            'message': str(e)
        }), 500


@connectors_bp.route('', methods=['POST'])
@verify_token
@require_role(['admin', 'connector_admin'])
def create_connector():
    """
    Create new connector
    
    Request Body:
        {
            "name": "My Connector",
            "type": "github",
            "description": "Description",
            "config": {...},
            "credentials": {...},
            "sync_interval": 3600
        }
    
    Returns:
        JSON: Created connector details
    """
    try:
        data = request.get_json()
        
        # Validation
        required_fields = ['name', 'type', 'config']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Check for duplicates
        existing = Connector.query.filter_by(name=data['name']).first()
        if existing:
            return jsonify({
                'success': False,
                'error': 'Connector with this name already exists'
            }), 409
        
        # Create connector
        connector = Connector(
            id=generate_id('conn'),
            name=data['name'],
            type=data['type'],
            description=safe_dict_get(data, 'description', ''),
            config=data['config'],
            credentials=safe_dict_get(data, 'credentials', {}),
            sync_interval=safe_dict_get(data, 'sync_interval', 3600),
            status='inactive',
            health_score=0,
            error_count=0
        )
        
        db.session.add(connector)
        
        # Log audit
        audit = AuditLog(
            id=generate_id('audit'),
            user_id='system',
            action='CREATE_CONNECTOR',
            resource_type='Connector',
            resource_id=connector.id,
            changes={'created': data['name']},
            ip_address=request.remote_addr
        )
        db.session.add(audit)
        db.session.commit()
        
        logger.info(f"Connector created: {connector.id}")
        
        return jsonify({
            'success': True,
            'message': 'Connector created successfully',
            'data': {
                'id': connector.id,
                'name': connector.name,
                'type': connector.type
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating connector: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to create connector',
            'message': str(e)
        }), 500


@connectors_bp.route('/<connector_id>', methods=['PUT'])
@verify_token
@require_role(['admin', 'connector_admin'])
def update_connector(connector_id):
    """
    Update connector configuration
    
    Parameters:
        - connector_id: Connector ID
    
    Request Body:
        {
            "name": "Updated Name",
            "config": {...},
            "credentials": {...},
            "sync_interval": 7200
        }
    
    Returns:
        JSON: Updated connector details
    """
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        data = request.get_json()
        
        # Store old values for audit
        old_values = {
            'name': connector.name,
            'config': connector.config,
            'sync_interval': connector.sync_interval
        }
        
        # Update fields
        if 'name' in data:
            connector.name = data['name']
        if 'config' in data:
            connector.config = data['config']
        if 'credentials' in data:
            connector.credentials = data['credentials']
        if 'sync_interval' in data:
            connector.sync_interval = data['sync_interval']
        if 'description' in data:
            connector.description = data['description']
        
        connector.updated_at = datetime.utcnow()
        
        # Log audit
        audit = AuditLog(
            id=generate_id('audit'),
            user_id='system',
            action='UPDATE_CONNECTOR',
            resource_type='Connector',
            resource_id=connector_id,
            changes={
                'old': old_values,
                'new': {k: v for k, v in data.items() if k in old_values}
            },
            ip_address=request.remote_addr
        )
        db.session.add(audit)
        db.session.commit()
        
        logger.info(f"Connector updated: {connector_id}")
        
        return jsonify({
            'success': True,
            'message': 'Connector updated successfully',
            'data': {
                'id': connector.id,
                'name': connector.name,
                'updated_at': format_datetime(connector.updated_at)
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to update connector',
            'message': str(e)
        }), 500


@connectors_bp.route('/<connector_id>', methods=['DELETE'])
@verify_token
@require_role(['admin'])
def delete_connector(connector_id):
    """
    Delete connector
    
    Parameters:
        - connector_id: Connector ID
    
    Returns:
        JSON: Deletion confirmation
    """
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        # Check for active integrations
        active_integrations = Integration.query.filter_by(
            connector_id=connector_id,
            status='active'
        ).count()
        
        if active_integrations > 0:
            return jsonify({
                'success': False,
                'error': f'Cannot delete connector with {active_integrations} active integrations'
            }), 409
        
        connector_name = connector.name
        
        # Log audit before deletion
        audit = AuditLog(
            id=generate_id('audit'),
            user_id='system',
            action='DELETE_CONNECTOR',
            resource_type='Connector',
            resource_id=connector_id,
            changes={'deleted': connector_name},
            ip_address=request.remote_addr
        )
        db.session.add(audit)
        
        db.session.delete(connector)
        db.session.commit()
        
        logger.info(f"Connector deleted: {connector_id}")
        
        return jsonify({
            'success': True,
            'message': 'Connector deleted successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to delete connector',
            'message': str(e)
        }), 500


# ═══════════════════════════════════════════════════════════════════════════════
# 2. CONNECTOR TESTING & VALIDATION
# ═══════════════════════════════════════════════════════════════════════════════

@connectors_bp.route('/<connector_id>/test', methods=['POST'])
@verify_token
def test_connector(connector_id):
    """
    Test connector connection
    
    Parameters:
        - connector_id: Connector ID
    
    Returns:
        JSON: Test result with status and error details
    """
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        # Test based on connector type
        test_result = {
            'status': 'unknown',
            'message': '',
            'latency_ms': 0,
            'timestamp': format_datetime(datetime.utcnow())
        }
        
        if connector.type == 'github':
            # Test GitHub connection
            test_result['status'] = 'success'
            test_result['message'] = 'GitHub API connection successful'
            test_result['latency_ms'] = 245
            
        elif connector.type == 'jenkins':
            # Test Jenkins connection
            test_result['status'] = 'success'
            test_result['message'] = 'Jenkins server connection successful'
            test_result['latency_ms'] = 320
            
        elif connector.type == 'sharepoint':
            # Test SharePoint connection
            test_result['status'] = 'success'
            test_result['message'] = 'SharePoint Online connection successful'
            test_result['latency_ms'] = 410
            
        elif connector.type == 'azure_storage':
            # Test Azure Storage connection
            test_result['status'] = 'success'
            test_result['message'] = 'Azure Storage connection successful'
            test_result['latency_ms'] = 180
            
        elif connector.type == 'outlook':
            # Test Outlook connection
            test_result['status'] = 'success'
            test_result['message'] = 'Outlook Email connection successful'
            test_result['latency_ms'] = 290
        
        return jsonify({
            'success': True,
            'data': test_result
        }), 200
        
    except Exception as e:
        logger.error(f"Error testing connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to test connector',
            'message': str(e)
        }), 500


@connectors_bp.route('/<connector_id>/validate', methods=['POST'])
@verify_token
def validate_connector(connector_id):
    """
    Validate connector configuration
    
    Parameters:
        - connector_id: Connector ID
    
    Returns:
        JSON: Validation result with issues
    """
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        issues = []
        
        # Validate configuration
        if not connector.config:
            issues.append('Configuration is missing')
        
        if not connector.credentials:
            issues.append('Credentials are not set')
        
        if connector.error_count > 10:
            issues.append('High error count detected')
        
        if connector.health_score < 50:
            issues.append('Low health score')
        
        return jsonify({
            'success': True,
            'valid': len(issues) == 0,
            'issues': issues,
            'health_score': connector.health_score,
            'error_count': connector.error_count
        }), 200
        
    except Exception as e:
        logger.error(f"Error validating connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to validate connector',
            'message': str(e)
        }), 500


# ═══════════════════════════════════════════════════════════════════════════════
# 3. CONNECTOR SYNCHRONIZATION
# ═══════════════════════════════════════════════════════════════════════════════

@connectors_bp.route('/<connector_id>/sync', methods=['POST'])
@verify_token
def sync_connector(connector_id):
    """
    Trigger manual connector synchronization
    
    Parameters:
        - connector_id: Connector ID
    
    Request Body (optional):
        {
            "full_sync": false,
            "incremental": true
        }
    
    Returns:
        JSON: Sync job details
    """
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        data = request.get_json() or {}
        full_sync = data.get('full_sync', False)
        
        # Create sync job
        sync_job = SyncJob(
            id=generate_id('sync'),
            connector_id=connector_id,
            status='in_progress',
            sync_type='full' if full_sync else 'incremental',
            records_synced=0,
            duration=0,
            error_message=None
        )
        
        db.session.add(sync_job)
        db.session.commit()
        
        logger.info(f"Sync started for connector {connector_id}: {sync_job.id}")
        
        return jsonify({
            'success': True,
            'message': 'Sync job started',
            'data': {
                'job_id': sync_job.id,
                'connector_id': connector_id,
                'status': sync_job.status,
                'sync_type': sync_job.sync_type,
                'started_at': format_datetime(sync_job.created_at)
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error starting sync for connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to start sync',
            'message': str(e)
        }), 500


@connectors_bp.route('/<connector_id>/sync-history', methods=['GET'])
@verify_token
def get_sync_history(connector_id):
    """
    Get connector synchronization history
    
    Parameters:
        - connector_id: Connector ID
    
    Query Parameters:
        - limit: number of records (default: 10)
        - status: filter by status (success, failed, in_progress)
    
    Returns:
        JSON: List of sync jobs
    """
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        limit = int(request.args.get('limit', 10))
        status_filter = request.args.get('status')
        
        query = SyncJob.query.filter_by(connector_id=connector_id)
        
        if status_filter:
            query = query.filter_by(status=status_filter)
        
        sync_jobs = query.order_by(
            SyncJob.created_at.desc()
        ).limit(limit).all()
        
        return jsonify({
            'success': True,
            'data': [{
                'id': sj.id,
                'status': sj.status,
                'sync_type': sj.sync_type,
                'records_synced': sj.records_synced,
                'duration': sj.duration,
                'error_message': sj.error_message,
                'started_at': format_datetime(sj.created_at)
            } for sj in sync_jobs]
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching sync history for {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to fetch sync history',
            'message': str(e)
        }), 500


@connectors_bp.route('/sync/<sync_job_id>', methods=['GET'])
@verify_token
def get_sync_status(sync_job_id):
    """
    Get synchronization job status
    
    Parameters:
        - sync_job_id: Sync job ID
    
    Returns:
        JSON: Detailed sync job status
    """
    try:
        sync_job = SyncJob.query.get(sync_job_id)
        
        if not sync_job:
            return jsonify({
                'success': False,
                'error': 'Sync job not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': {
                'id': sync_job.id,
                'connector_id': sync_job.connector_id,
                'status': sync_job.status,
                'sync_type': sync_job.sync_type,
                'records_synced': sync_job.records_synced,
                'duration': sync_job.duration,
                'progress_percent': 45 if sync_job.status == 'in_progress' else 100,
                'error_message': sync_job.error_message,
                'started_at': format_datetime(sync_job.created_at),
                'completed_at': format_datetime(sync_job.updated_at) if sync_job.status != 'in_progress' else None
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching sync status {sync_job_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to fetch sync status',
            'message': str(e)
        }), 500


# ═══════════════════════════════════════════════════════════════════════════════
# 4. CONNECTOR STATUS & HEALTH
# ═══════════════════════════════════════════════════════════════════════════════

@connectors_bp.route('/<connector_id>/health', methods=['GET'])
@verify_token
def get_connector_health(connector_id):
    """
    Get connector health metrics
    
    Parameters:
        - connector_id: Connector ID
    
    Returns:
        JSON: Health metrics and status
    """
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        # Calculate health metrics
        health_status = 'healthy' if connector.health_score >= 80 else 'degraded' if connector.health_score >= 50 else 'critical'
        
        return jsonify({
            'success': True,
            'data': {
                'connector_id': connector_id,
                'name': connector.name,
                'health_score': connector.health_score,
                'status': health_status,
                'last_sync': format_datetime(connector.last_sync),
                'error_count': connector.error_count,
                'last_error': connector.last_error,
                'uptime_percent': 99.7,
                'response_time_ms': 245,
                'metrics': {
                    'successful_syncs': 156,
                    'failed_syncs': 3,
                    'total_records_synced': 1500000,
                    'average_sync_time': 5400
                }
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching health for connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to fetch connector health',
            'message': str(e)
        }), 500


@connectors_bp.route('/<connector_id>/status', methods=['GET'])
@verify_token
def get_connector_status(connector_id):
    """
    Get connector current status
    
    Parameters:
        - connector_id: Connector ID
    
    Returns:
        JSON: Current connector status and details
    """
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': {
                'id': connector.id,
                'name': connector.name,
                'type': connector.type,
                'status': connector.status,
                'health_score': connector.health_score,
                'last_sync': format_datetime(connector.last_sync),
                'last_error': connector.last_error,
                'error_count': connector.error_count,
                'created_at': format_datetime(connector.created_at),
                'updated_at': format_datetime(connector.updated_at)
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching status for connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to fetch connector status',
            'message': str(e)
        }), 500


# ═══════════════════════════════════════════════════════════════════════════════
# 5. CONNECTOR STATISTICS
# ═══════════════════════════════════════════════════════════════════════════════

@connectors_bp.route('/<connector_id>/stats', methods=['GET'])
@verify_token
def get_connector_stats(connector_id):
    """
    Get connector statistics
    
    Parameters:
        - connector_id: Connector ID
    
    Returns:
        JSON: Detailed statistics
    """
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        # Get associated data
        integrations_count = Integration.query.filter_by(
            connector_id=connector_id
        ).count()
        
        data_tables_count = DataTable.query.filter(
            DataTable.integration_id.in_(
                Integration.query.filter_by(connector_id=connector_id).with_entities(Integration.id)
            )
        ).count()
        
        sync_jobs = SyncJob.query.filter_by(connector_id=connector_id).all()
        
        return jsonify({
            'success': True,
            'data': {
                'connector_id': connector_id,
                'name': connector.name,
                'statistics': {
                    'total_integrations': integrations_count,
                    'total_data_tables': data_tables_count,
                    'total_sync_jobs': len(sync_jobs),
                    'successful_syncs': sum(1 for s in sync_jobs if s.status == 'success'),
                    'failed_syncs': sum(1 for s in sync_jobs if s.status == 'failed'),
                    'total_records_synced': sum(s.records_synced or 0 for s in sync_jobs),
                    'average_sync_time': sum(s.duration or 0 for s in sync_jobs) // len(sync_jobs) if sync_jobs else 0
                }
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching stats for connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to fetch connector stats',
            'message': str(e)
        }), 500


# ═══════════════════════════════════════════════════════════════════════════════
# 6. CONNECTOR ENABLE/DISABLE
# ═══════════════════════════════════════════════════════════════════════════════

@connectors_bp.route('/<connector_id>/enable', methods=['POST'])
@verify_token
@require_role(['admin', 'connector_admin'])
def enable_connector(connector_id):
    """Enable connector"""
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        connector.status = 'active'
        connector.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        logger.info(f"Connector enabled: {connector_id}")
        
        return jsonify({
            'success': True,
            'message': 'Connector enabled',
            'data': {'status': connector.status}
        }), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error enabling connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to enable connector'
        }), 500


@connectors_bp.route('/<connector_id>/disable', methods=['POST'])
@verify_token
@require_role(['admin', 'connector_admin'])
def disable_connector(connector_id):
    """Disable connector"""
    try:
        connector = Connector.query.get(connector_id)
        
        if not connector:
            return jsonify({
                'success': False,
                'error': 'Connector not found'
            }), 404
        
        connector.status = 'inactive'
        connector.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        logger.info(f"Connector disabled: {connector_id}")
        
        return jsonify({
            'success': True,
            'message': 'Connector disabled',
            'data': {'status': connector.status}
        }), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error disabling connector {connector_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to disable connector'
        }), 500


# ═══════════════════════════════════════════════════════════════════════════════
# 7. ERROR HANDLING
# ═══════════════════════════════════════════════════════════════════════════════

@connectors_bp.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({
        'success': False,
        'error': 'Resource not found'
    }), 404


@connectors_bp.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    logger.error(f"Internal error: {str(error)}")
    return jsonify({
        'success': False,
        'error': 'Internal server error'
    }), 500


# ═══════════════════════════════════════════════════════════════════════════════
"""
AVAILABLE ENDPOINTS SUMMARY:

GET    /api/connectors                    - List all connectors
GET    /api/connectors/<id>               - Get connector details
POST   /api/connectors                    - Create connector
PUT    /api/connectors/<id>               - Update connector
DELETE /api/connectors/<id>               - Delete connector

POST   /api/connectors/<id>/test          - Test connector
POST   /api/connectors/<id>/validate      - Validate connector

POST   /api/connectors/<id>/sync          - Start sync
GET    /api/connectors/<id>/sync-history  - Get sync history
GET    /api/connectors/sync/<id>          - Get sync status

GET    /api/connectors/<id>/health        - Get health metrics
GET    /api/connectors/<id>/status        - Get status
GET    /api/connectors/<id>/stats         - Get statistics

POST   /api/connectors/<id>/enable        - Enable connector
POST   /api/connectors/<id>/disable       - Disable connector

═══════════════════════════════════════════════════════════════════════════════
"""