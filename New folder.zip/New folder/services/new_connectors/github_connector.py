"""
GitHub Connector Service

Provides integration with GitHub API for:
- Repository management
- Pull request operations
- Issue tracking
- Commit history
- Branch management
- Release management

Usage:
    github = GitHubConnector()
    repos = github.list_repositories()
    pr = github.create_pull_request("repo-name", "feature-branch")
"""

import os
import logging
from typing import List, Dict, Any, Optional
from github import Github, GithubException
import requests

logger = logging.getLogger(__name__)


class GitHubConnector:
    """
    GitHub API Integration Connector
    
    Handles all GitHub operations including repositories, PRs, issues, and commits.
    
    Attributes:
        token (str): GitHub personal access token
        base_url (str): GitHub API base URL
        client (Github): PyGithub client instance
    """
    
    def __init__(self, token: Optional[str] = None):
        """
        Initialize GitHub Connector
        
        Args:
            token (str, optional): GitHub PAT. Uses GITHUB_TOKEN env var if not provided.
        
        Raises:
            ValueError: If token not provided and GITHUB_TOKEN not set
        """
        self.token = token or os.getenv('GITHUB_TOKEN')
        if not self.token:
            raise ValueError("GitHub token not provided. Set GITHUB_TOKEN environment variable.")
        
        self.base_url = "https://api.github.com"
        self.client = Github(self.token)
        self.user = None
        
        try:
            self.user = self.client.get_user()
            logger.info(f"GitHub Connector initialized for user: {self.user.login}")
        except GithubException as e:
            logger.error(f"Failed to authenticate with GitHub: {e}")
            raise
    
    def connect(self) -> bool:
        """
        Test GitHub connection
        
        Returns:
            bool: True if connection successful, False otherwise
        """
        try:
            self.user.get_repos().totalCount
            logger.info("GitHub connection successful")
            return True
        except Exception as e:
            logger.error(f"GitHub connection failed: {e}")
            return False
    
    # ==================== REPOSITORY OPERATIONS ====================
    
    def list_repositories(self, sort_by: str = "updated") -> List[Dict[str, Any]]:
        """
        List all repositories for authenticated user
        
        Args:
            sort_by (str): Sort by 'pushed', 'created', 'updated', 'name'
        
        Returns:
            List[Dict]: Repository information
        """
        try:
            repos = self.user.get_repos(sort=sort_by)
            result = []
            for repo in repos:
                result.append({
                    "id": repo.id,
                    "name": repo.name,
                    "full_name": repo.full_name,
                    "description": repo.description,
                    "url": repo.html_url,
                    "clone_url": repo.clone_url,
                    "private": repo.private,
                    "stars": repo.stargazers_count,
                    "forks": repo.forks_count,
                    "language": repo.language,
                    "created_at": repo.created_at.isoformat(),
                    "updated_at": repo.updated_at.isoformat()
                })
            logger.info(f"Retrieved {len(result)} repositories")
            return result
        except Exception as e:
            logger.error(f"Failed to list repositories: {e}")
            return []
    
    def get_repository(self, repo_name: str) -> Dict[str, Any]:
        """
        Get specific repository details
        
        Args:
            repo_name (str): Repository name (owner/repo format)
        
        Returns:
            Dict: Repository information
        """
        try:
            repo = self.client.get_repo(repo_name)
            return {
                "id": repo.id,
                "name": repo.name,
                "full_name": repo.full_name,
                "description": repo.description,
                "url": repo.html_url,
                "clone_url": repo.clone_url,
                "private": repo.private,
                "stars": repo.stargazers_count,
                "forks": repo.forks_count,
                "language": repo.language,
                "created_at": repo.created_at.isoformat(),
                "updated_at": repo.updated_at.isoformat(),
                "default_branch": repo.default_branch
            }
        except Exception as e:
            logger.error(f"Failed to get repository {repo_name}: {e}")
            return {}
    
    # ==================== PULL REQUEST OPERATIONS ====================
    
    def list_pull_requests(self, repo_name: str, state: str = "open") -> List[Dict[str, Any]]:
        """
        List pull requests for a repository
        
        Args:
            repo_name (str): Repository name (owner/repo format)
            state (str): PR state - 'open', 'closed', 'all'
        
        Returns:
            List[Dict]: Pull request information
        """
        try:
            repo = self.client.get_repo(repo_name)
            prs = repo.get_pulls(state=state)
            result = []
            for pr in prs:
                result.append({
                    "id": pr.id,
                    "number": pr.number,
                    "title": pr.title,
                    "description": pr.body,
                    "state": pr.state,
                    "url": pr.html_url,
                    "author": pr.user.login,
                    "created_at": pr.created_at.isoformat(),
                    "updated_at": pr.updated_at.isoformat(),
                    "head_branch": pr.head.ref,
                    "base_branch": pr.base.ref,
                    "additions": pr.additions,
                    "deletions": pr.deletions
                })
            logger.info(f"Retrieved {len(result)} pull requests for {repo_name}")
            return result
        except Exception as e:
            logger.error(f"Failed to list PRs for {repo_name}: {e}")
            return []
    
    def create_pull_request(self, repo_name: str, title: str, head: str, 
                          base: str, body: str = "") -> Dict[str, Any]:
        """
        Create a new pull request
        
        Args:
            repo_name (str): Repository name (owner/repo format)
            title (str): PR title
            head (str): Source branch
            base (str): Target branch
            body (str): PR description
        
        Returns:
            Dict: Created PR information
        """
        try:
            repo = self.client.get_repo(repo_name)
            pr = repo.create_pull(title=title, head=head, base=base, body=body)
            logger.info(f"Created PR #{pr.number} in {repo_name}")
            return {
                "number": pr.number,
                "title": pr.title,
                "url": pr.html_url,
                "state": pr.state
            }
        except Exception as e:
            logger.error(f"Failed to create PR in {repo_name}: {e}")
            return {}
    
    def get_pull_request(self, repo_name: str, pr_number: int) -> Dict[str, Any]:
        """
        Get specific pull request details
        
        Args:
            repo_name (str): Repository name (owner/repo format)
            pr_number (int): PR number
        
        Returns:
            Dict: PR information
        """
        try:
            repo = self.client.get_repo(repo_name)
            pr = repo.get_pull(pr_number)
            return {
                "number": pr.number,
                "title": pr.title,
                "description": pr.body,
                "state": pr.state,
                "url": pr.html_url,
                "author": pr.user.login,
                "created_at": pr.created_at.isoformat(),
                "head_branch": pr.head.ref,
                "base_branch": pr.base.ref,
                "additions": pr.additions,
                "deletions": pr.deletions,
                "commits": pr.commits,
                "review_comments": pr.review_comments
            }
        except Exception as e:
            logger.error(f"Failed to get PR #{pr_number} from {repo_name}: {e}")
            return {}
    
    def merge_pull_request(self, repo_name: str, pr_number: int) -> bool:
        """
        Merge a pull request
        
        Args:
            repo_name (str): Repository name (owner/repo format)
            pr_number (int): PR number
        
        Returns:
            bool: True if merge successful
        """
        try:
            repo = self.client.get_repo(repo_name)
            pr = repo.get_pull(pr_number)
            pr.merge()
            logger.info(f"Merged PR #{pr_number} in {repo_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to merge PR #{pr_number}: {e}")
            return False
    
    # ==================== ISSUE OPERATIONS ====================
    
    def list_issues(self, repo_name: str, state: str = "open") -> List[Dict[str, Any]]:
        """
        List issues for a repository
        
        Args:
            repo_name (str): Repository name (owner/repo format)
            state (str): Issue state - 'open', 'closed', 'all'
        
        Returns:
            List[Dict]: Issue information
        """
        try:
            repo = self.client.get_repo(repo_name)
            issues = repo.get_issues(state=state)
            result = []
            for issue in issues:
                result.append({
                    "number": issue.number,
                    "title": issue.title,
                    "description": issue.body,
                    "state": issue.state,
                    "url": issue.html_url,
                    "author": issue.user.login,
                    "created_at": issue.created_at.isoformat(),
                    "updated_at": issue.updated_at.isoformat(),
                    "labels": [label.name for label in issue.labels],
                    "assignees": [assignee.login for assignee in issue.assignees]
                })
            logger.info(f"Retrieved {len(result)} issues for {repo_name}")
            return result
        except Exception as e:
            logger.error(f"Failed to list issues for {repo_name}: {e}")
            return []
    
    def create_issue(self, repo_name: str, title: str, body: str = "", 
                    labels: List[str] = None) -> Dict[str, Any]:
        """
        Create a new issue
        
        Args:
            repo_name (str): Repository name (owner/repo format)
            title (str): Issue title
            body (str): Issue description
            labels (List[str]): Issue labels
        
        Returns:
            Dict: Created issue information
        """
        try:
            repo = self.client.get_repo(repo_name)
            issue = repo.create_issue(title=title, body=body, labels=labels or [])
            logger.info(f"Created issue #{issue.number} in {repo_name}")
            return {
                "number": issue.number,
                "title": issue.title,
                "url": issue.html_url,
                "state": issue.state
            }
        except Exception as e:
            logger.error(f"Failed to create issue in {repo_name}: {e}")
            return {}
    
    def search_issues(self, repo_name: str, query: str) -> List[Dict[str, Any]]:
        """
        Search issues in a repository
        
        Args:
            repo_name (str): Repository name (owner/repo format)
            query (str): Search query
        
        Returns:
            List[Dict]: Search results
        """
        try:
            search_query = f"{query} repo:{repo_name}"
            issues = self.client.search_issues(search_query)
            result = []
            for issue in issues:
                result.append({
                    "number": issue.number,
                    "title": issue.title,
                    "url": issue.html_url,
                    "state": issue.state
                })
            logger.info(f"Found {len(result)} issues matching '{query}' in {repo_name}")
            return result
        except Exception as e:
            logger.error(f"Failed to search issues: {e}")
            return []
    
    # ==================== COMMIT OPERATIONS ====================
    
    def list_commits(self, repo_name: str, branch: str = "main") -> List[Dict[str, Any]]:
        """
        List commits for a repository
        
        Args:
            repo_name (str): Repository name (owner/repo format)
            branch (str): Branch name
        
        Returns:
            List[Dict]: Commit information
        """
        try:
            repo = self.client.get_repo(repo_name)
            commits = repo.get_commits(sha=branch)
            result = []
            for commit in commits:
                result.append({
                    "sha": commit.sha,
                    "message": commit.commit.message,
                    "author": commit.commit.author.name,
                    "date": commit.commit.author.date.isoformat(),
                    "url": commit.html_url
                })
            logger.info(f"Retrieved {len(result)} commits from {repo_name}/{branch}")
            return result
        except Exception as e:
            logger.error(f"Failed to list commits for {repo_name}: {e}")
            return []
    
    # ==================== BRANCH OPERATIONS ====================
    
    def list_branches(self, repo_name: str) -> List[Dict[str, Any]]:
        """
        List all branches in a repository
        
        Args:
            repo_name (str): Repository name (owner/repo format)
        
        Returns:
            List[Dict]: Branch information
        """
        try:
            repo = self.client.get_repo(repo_name)
            branches = repo.get_branches()
            result = []
            for branch in branches:
                result.append({
                    "name": branch.name,
                    "sha": branch.commit.sha,
                    "protected": branch.protected
                })
            logger.info(f"Retrieved {len(result)} branches from {repo_name}")
            return result
        except Exception as e:
            logger.error(f"Failed to list branches for {repo_name}: {e}")
            return []
    
    # ==================== RELEASE OPERATIONS ====================
    
    def list_releases(self, repo_name: str) -> List[Dict[str, Any]]:
        """
        List all releases in a repository
        
        Args:
            repo_name (str): Repository name (owner/repo format)
        
        Returns:
            List[Dict]: Release information
        """
        try:
            repo = self.client.get_repo(repo_name)
            releases = repo.get_releases()
            result = []
            for release in releases:
                result.append({
                    "tag": release.tag_name,
                    "name": release.name,
                    "description": release.body,
                    "draft": release.draft,
                    "prerelease": release.prerelease,
                    "published_at": release.published_at.isoformat() if release.published_at else None,
                    "url": release.html_url
                })
            logger.info(f"Retrieved {len(result)} releases from {repo_name}")
            return result
        except Exception as e:
            logger.error(f"Failed to list releases for {repo_name}: {e}")
            return []
    
    def create_release(self, repo_name: str, tag: str, name: str = "", 
                      body: str = "") -> Dict[str, Any]:
        """
        Create a new release
        
        Args:
            repo_name (str): Repository name (owner/repo format)
            tag (str): Release tag
            name (str): Release name
            body (str): Release notes
        
        Returns:
            Dict: Created release information
        """
        try:
            repo = self.client.get_repo(repo_name)
            release = repo.create_git_release(tag=tag, name=name, message=body)
            logger.info(f"Created release {tag} in {repo_name}")
            return {
                "tag": release.tag_name,
                "name": release.name,
                "url": release.html_url
            }
        except Exception as e:
            logger.error(f"Failed to create release in {repo_name}: {e}")
            return {}
    
    # ==================== UTILITY METHODS ====================
    
    def get_rate_limit(self) -> Dict[str, Any]:
        """
        Get API rate limit information
        
        Returns:
            Dict: Rate limit details
        """
        try:
            rate_limit = self.client.get_rate_limit()
            return {
                "core_limit": rate_limit.core.limit,
                "core_remaining": rate_limit.core.remaining,
                "core_reset": rate_limit.core.reset.isoformat(),
                "search_limit": rate_limit.search.limit,
                "search_remaining": rate_limit.search.remaining
            }
        except Exception as e:
            logger.error(f"Failed to get rate limit: {e}")
            return {}


def get_github_connector() -> GitHubConnector:
    """Factory function to get GitHub connector instance"""
    return GitHubConnector()


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    try:
        github = GitHubConnector()
        
        # List repositories
        repos = github.list_repositories()
        print(f"Found {len(repos)} repositories")
        
        # Check rate limit
        rate_limit = github.get_rate_limit()
        print(f"Rate limit: {rate_limit['core_remaining']}/{rate_limit['core_limit']}")
        
    except Exception as e:
        print(f"Error: {e}")