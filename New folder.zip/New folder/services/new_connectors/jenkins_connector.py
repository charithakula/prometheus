"""
Jenkins Connector Service

Provides integration with Jenkins for:
- Job management and triggering
- Build execution and monitoring
- Build log retrieval
- Pipeline execution
- Artifact management
- Build status tracking

Usage:
    jenkins = JenkinsConnector()
    jobs = jenkins.list_jobs()
    build = jenkins.trigger_build("job-name")
    status = jenkins.get_build_status("job-name", 123)
"""

import os
import logging
from typing import List, Dict, Any, Optional
import jenkins
import requests
from datetime import datetime

logger = logging.getLogger(__name__)


class JenkinsConnector:
    """
    Jenkins CI/CD Integration Connector
    
    Handles job management, build triggering, monitoring, and artifact management.
    
    Attributes:
        url (str): Jenkins server URL
        username (str): Jenkins username
        password (str): Jenkins API token/password
        server (jenkins.Jenkins): Jenkins client instance
    """
    
    def __init__(self, url: Optional[str] = None, username: Optional[str] = None, 
                 password: Optional[str] = None):
        """
        Initialize Jenkins Connector
        
        Args:
            url (str, optional): Jenkins URL. Uses JENKINS_URL env var if not provided.
            username (str, optional): Jenkins username. Uses JENKINS_USERNAME if not provided.
            password (str, optional): Jenkins API token. Uses JENKINS_PASSWORD if not provided.
        
        Raises:
            ValueError: If required credentials not provided
        """
        self.url = url or os.getenv('JENKINS_URL')
        self.username = username or os.getenv('JENKINS_USERNAME')
        self.password = password or os.getenv('JENKINS_PASSWORD')
        
        if not all([self.url, self.username, self.password]):
            raise ValueError("Jenkins credentials not provided. Set JENKINS_URL, JENKINS_USERNAME, JENKINS_PASSWORD")
        
        try:
            self.server = jenkins.Jenkins(
                url=self.url,
                username=self.username,
                password=self.password,
                timeout=30
            )
            logger.info(f"Jenkins Connector initialized for {self.url}")
        except Exception as e:
            logger.error(f"Failed to initialize Jenkins connection: {e}")
            raise
    
    def connect(self) -> bool:
        """
        Test Jenkins connection
        
        Returns:
            bool: True if connection successful
        """
        try:
            self.server.get_version()
            logger.info("Jenkins connection successful")
            return True
        except Exception as e:
            logger.error(f"Jenkins connection failed: {e}")
            return False
    
    # ==================== JOB OPERATIONS ====================
    
    def list_jobs(self, folder: str = None) -> List[Dict[str, Any]]:
        """
        List all jobs in Jenkins
        
        Args:
            folder (str, optional): Specific folder path
        
        Returns:
            List[Dict]: Job information
        """
        try:
            jobs = self.server.get_all_jobs(folder_depth=0)
            result = []
            for job in jobs:
                result.append({
                    "name": job.get('name'),
                    "url": job.get('url'),
                    "color": job.get('color'),
                    "full_name": job.get('fullname')
                })
            logger.info(f"Retrieved {len(result)} jobs")
            return result
        except Exception as e:
            logger.error(f"Failed to list jobs: {e}")
            return []
    
    def get_job_info(self, job_name: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific job
        
        Args:
            job_name (str): Job name
        
        Returns:
            Dict: Job information
        """
        try:
            info = self.server.get_job_info(job_name)
            return {
                "name": info.get('name'),
                "url": info.get('url'),
                "description": info.get('description'),
                "buildable": info.get('buildable'),
                "builds": len(info.get('builds', [])),
                "last_build": info.get('lastBuild'),
                "last_stable_build": info.get('lastStableBuild'),
                "last_failed_build": info.get('lastFailedBuild'),
                "last_successful_build": info.get('lastSuccessfulBuild')
            }
        except Exception as e:
            logger.error(f"Failed to get job info for {job_name}: {e}")
            return {}
    
    def job_exists(self, job_name: str) -> bool:
        """
        Check if a job exists
        
        Args:
            job_name (str): Job name
        
        Returns:
            bool: True if job exists
        """
        try:
            self.server.get_job_info(job_name)
            return True
        except jenkins.NotFoundException:
            return False
        except Exception as e:
            logger.error(f"Error checking job existence: {e}")
            return False
    
    # ==================== BUILD OPERATIONS ====================
    
    def trigger_build(self, job_name: str, parameters: Dict[str, str] = None) -> int:
        """
        Trigger a build for a job
        
        Args:
            job_name (str): Job name
            parameters (Dict, optional): Build parameters
        
        Returns:
            int: Queue item number, or 0 if failed
        """
        try:
            queue_item = self.server.build_job(job_name, parameters=parameters)
            logger.info(f"Triggered build for {job_name}. Queue item: {queue_item}")
            return queue_item
        except Exception as e:
            logger.error(f"Failed to trigger build for {job_name}: {e}")
            return 0
    
    def get_build_info(self, job_name: str, build_number: int) -> Dict[str, Any]:
        """
        Get detailed information about a specific build
        
        Args:
            job_name (str): Job name
            build_number (int): Build number
        
        Returns:
            Dict: Build information
        """
        try:
            build_info = self.server.get_build_info(job_name, build_number)
            return {
                "number": build_info.get('number'),
                "url": build_info.get('url'),
                "result": build_info.get('result'),
                "timestamp": build_info.get('timestamp'),
                "duration": build_info.get('duration'),
                "building": build_info.get('building'),
                "description": build_info.get('description'),
                "display_name": build_info.get('displayName'),
                "estimated_duration": build_info.get('estimatedDuration')
            }
        except Exception as e:
            logger.error(f"Failed to get build info for {job_name}#{build_number}: {e}")
            return {}
    
    def get_build_status(self, job_name: str, build_number: int) -> str:
        """
        Get build status
        
        Args:
            job_name (str): Job name
            build_number (int): Build number
        
        Returns:
            str: Build status (SUCCESS, FAILURE, UNSTABLE, NOT_BUILT, ABORTED)
        """
        try:
            build_info = self.server.get_build_info(job_name, build_number)
            return build_info.get('result', 'UNKNOWN')
        except Exception as e:
            logger.error(f"Failed to get build status: {e}")
            return 'UNKNOWN'
    
    def get_build_logs(self, job_name: str, build_number: int) -> str:
        """
        Get build logs/console output
        
        Args:
            job_name (str): Job name
            build_number (int): Build number
        
        Returns:
            str: Build logs
        """
        try:
            logs = self.server.get_build_console_output(job_name, build_number)
            logger.info(f"Retrieved logs for {job_name}#{build_number}")
            return logs
        except Exception as e:
            logger.error(f"Failed to get build logs: {e}")
            return ""
    
    def stop_build(self, job_name: str, build_number: int) -> bool:
        """
        Stop/abort a running build
        
        Args:
            job_name (str): Job name
            build_number (int): Build number
        
        Returns:
            bool: True if stop was successful
        """
        try:
            self.server.stop_build(job_name, build_number)
            logger.info(f"Stopped build {job_name}#{build_number}")
            return True
        except Exception as e:
            logger.error(f"Failed to stop build: {e}")
            return False
    
    def delete_build(self, job_name: str, build_number: int) -> bool:
        """
        Delete a build
        
        Args:
            job_name (str): Job name
            build_number (int): Build number
        
        Returns:
            bool: True if deletion was successful
        """
        try:
            self.server.delete_build(job_name, build_number)
            logger.info(f"Deleted build {job_name}#{build_number}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete build: {e}")
            return False
    
    def get_last_build_number(self, job_name: str) -> Optional[int]:
        """
        Get the last build number for a job
        
        Args:
            job_name (str): Job name
        
        Returns:
            int: Last build number, or None if not available
        """
        try:
            info = self.server.get_job_info(job_name)
            last_build = info.get('lastBuild')
            if last_build:
                return last_build.get('number')
            return None
        except Exception as e:
            logger.error(f"Failed to get last build number: {e}")
            return None
    
    def get_build_history(self, job_name: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get build history for a job
        
        Args:
            job_name (str): Job name
            limit (int): Number of builds to retrieve
        
        Returns:
            List[Dict]: Build history
        """
        try:
            info = self.server.get_job_info(job_name)
            builds = info.get('builds', [])[:limit]
            result = []
            
            for build_ref in builds:
                build_number = build_ref.get('number')
                try:
                    build_info = self.server.get_build_info(job_name, build_number)
                    result.append({
                        "number": build_number,
                        "result": build_info.get('result'),
                        "timestamp": build_info.get('timestamp'),
                        "duration": build_info.get('duration'),
                        "url": build_info.get('url')
                    })
                except Exception as e:
                    logger.warning(f"Failed to get info for build {build_number}: {e}")
            
            logger.info(f"Retrieved {len(result)} builds for {job_name}")
            return result
        except Exception as e:
            logger.error(f"Failed to get build history: {e}")
            return []
    
    # ==================== ARTIFACT OPERATIONS ====================
    
    def get_build_artifacts(self, job_name: str, build_number: int) -> List[Dict[str, Any]]:
        """
        Get artifacts from a build
        
        Args:
            job_name (str): Job name
            build_number (int): Build number
        
        Returns:
            List[Dict]: Artifact information
        """
        try:
            build_info = self.server.get_build_info(job_name, build_number)
            artifacts = build_info.get('artifacts', [])
            result = []
            
            for artifact in artifacts:
                result.append({
                    "filename": artifact.get('fileName'),
                    "relative_path": artifact.get('relativePath'),
                    "display_path": artifact.get('displayPath')
                })
            
            logger.info(f"Retrieved {len(result)} artifacts for {job_name}#{build_number}")
            return result
        except Exception as e:
            logger.error(f"Failed to get artifacts: {e}")
            return []
    
    def download_artifact(self, job_name: str, build_number: int, 
                         artifact_path: str, save_path: str) -> bool:
        """
        Download an artifact from a build
        
        Args:
            job_name (str): Job name
            build_number (int): Build number
            artifact_path (str): Artifact relative path
            save_path (str): Local path to save artifact
        
        Returns:
            bool: True if download was successful
        """
        try:
            artifact_url = f"{self.url}/job/{job_name}/{build_number}/artifact/{artifact_path}"
            response = requests.get(
                artifact_url,
                auth=(self.username, self.password),
                stream=True,
                timeout=30
            )
            response.raise_for_status()
            
            with open(save_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            logger.info(f"Downloaded artifact to {save_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to download artifact: {e}")
            return False
    
    # ==================== PIPELINE OPERATIONS ====================
    
    def get_queue_info(self) -> List[Dict[str, Any]]:
        """
        Get information about queued builds
        
        Returns:
            List[Dict]: Queue information
        """
        try:
            queue = self.server.get_queue_info()
            result = []
            
            for item in queue:
                result.append({
                    "id": item.get('id'),
                    "task": item.get('task', {}).get('name'),
                    "why": item.get('why'),
                    "stuck": item.get('stuck'),
                    "buildable": item.get('buildable')
                })
            
            logger.info(f"Retrieved {len(result)} queued items")
            return result
        except Exception as e:
            logger.error(f"Failed to get queue info: {e}")
            return []
    
    # ==================== UTILITY METHODS ====================
    
    def is_job_building(self, job_name: str) -> bool:
        """
        Check if a job is currently building
        
        Args:
            job_name (str): Job name
        
        Returns:
            bool: True if job is building
        """
        try:
            info = self.server.get_job_info(job_name)
            return info.get('inQueue', False) or (
                info.get('lastBuild') and 
                self.server.get_build_info(job_name, info['lastBuild']['number']).get('building', False)
            )
        except Exception as e:
            logger.error(f"Failed to check if job is building: {e}")
            return False
    
    def enable_job(self, job_name: str) -> bool:
        """
        Enable a job
        
        Args:
            job_name (str): Job name
        
        Returns:
            bool: True if successful
        """
        try:
            self.server.enable_job(job_name)
            logger.info(f"Enabled job {job_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to enable job: {e}")
            return False
    
    def disable_job(self, job_name: str) -> bool:
        """
        Disable a job
        
        Args:
            job_name (str): Job name
        
        Returns:
            bool: True if successful
        """
        try:
            self.server.disable_job(job_name)
            logger.info(f"Disabled job {job_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to disable job: {e}")
            return False
    
    def get_jenkins_version(self) -> str:
        """
        Get Jenkins version
        
        Returns:
            str: Jenkins version
        """
        try:
            return self.server.get_version()
        except Exception as e:
            logger.error(f"Failed to get Jenkins version: {e}")
            return "Unknown"


def get_jenkins_connector() -> JenkinsConnector:
    """Factory function to get Jenkins connector instance"""
    return JenkinsConnector()


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    try:
        jenkins_conn = JenkinsConnector()
        
        # List jobs
        jobs = jenkins_conn.list_jobs()
        print(f"Found {len(jobs)} jobs")
        
        # Get Jenkins version
        version = jenkins_conn.get_jenkins_version()
        print(f"Jenkins version: {version}")
        
    except Exception as e:
        print(f"Error: {e}")