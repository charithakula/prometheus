"""
Outlook Email Connector Service

Provides integration with Microsoft Outlook/Office 365 for:
- Sending emails with attachments
- Email notifications
- Template-based emails
- Scheduled email sending
- Email tracking
- Distribution list management
- Draft management

Usage:
    outlook = OutlookEmailConnector()
    outlook.send_email(
        to="user@company.com",
        subject="Alert",
        body="Test notification",
        is_html=True
    )
    outlook.send_notification(
        recipients=["user1@company.com", "user2@company.com"],
        title="Alert",
        message="System alert notification"
    )
"""

import os
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import mimetypes

from office365.graph_client import GraphClient
from office365.runtime.auth.client_credential_auth_provider import ClientCredentialAuthProvider
from office365.mail.mail_client import MailClient

logger = logging.getLogger(__name__)


class OutlookEmailConnector:
    """
    Outlook/Office 365 Email Integration Connector
    
    Handles email sending, notifications, and mail management via Office 365 Graph API.
    
    Attributes:
        client_id (str): Azure AD Client ID
        client_secret (str): Azure AD Client Secret
        tenant_id (str): Azure AD Tenant ID
        sender_email (str): Sender email address
        sender_name (str): Sender display name
        graph_client (GraphClient): Microsoft Graph API client
    """
    
    def __init__(self, client_id: Optional[str] = None, client_secret: Optional[str] = None,
                 tenant_id: Optional[str] = None, sender_email: Optional[str] = None,
                 sender_name: Optional[str] = None):
        """
        Initialize Outlook Email Connector
        
        Args:
            client_id (str, optional): Azure AD Client ID. Uses OUTLOOK_CLIENT_ID if not provided.
            client_secret (str, optional): Azure AD Client Secret. Uses OUTLOOK_CLIENT_SECRET if not provided.
            tenant_id (str, optional): Azure AD Tenant ID. Uses OUTLOOK_TENANT_ID if not provided.
            sender_email (str, optional): Sender email. Uses OUTLOOK_SENDER_EMAIL if not provided.
            sender_name (str, optional): Sender display name. Uses OUTLOOK_SENDER_NAME if not provided.
        
        Raises:
            ValueError: If required credentials not provided
        """
        self.client_id = client_id or os.getenv('OUTLOOK_CLIENT_ID')
        self.client_secret = client_secret or os.getenv('OUTLOOK_CLIENT_SECRET')
        self.tenant_id = tenant_id or os.getenv('OUTLOOK_TENANT_ID')
        self.sender_email = sender_email or os.getenv('OUTLOOK_SENDER_EMAIL')
        self.sender_name = sender_name or os.getenv('OUTLOOK_SENDER_NAME', 'Notification Service')
        
        if not all([self.client_id, self.client_secret, self.tenant_id, self.sender_email]):
            raise ValueError("Outlook credentials not provided. Set OUTLOOK_CLIENT_ID, "
                           "OUTLOOK_CLIENT_SECRET, OUTLOOK_TENANT_ID, OUTLOOK_SENDER_EMAIL")
        
        try:
            auth_provider = ClientCredentialAuthProvider(
                client_id=self.client_id,
                client_secret=self.client_secret,
                tenant=self.tenant_id
            )
            self.graph_client = GraphClient(auth_provider)
            logger.info(f"Outlook Email Connector initialized for {self.sender_email}")
        except Exception as e:
            logger.error(f"Failed to initialize Outlook connection: {e}")
            raise
    
    def connect(self) -> bool:
        """
        Test Outlook connection
        
        Returns:
            bool: True if connection successful
        """
        try:
            # Try to get user profile to test connection
            me = self.graph_client.me.get().execute_query()
            logger.info(f"Outlook connection successful. Connected as: {me.user_principal_name}")
            return True
        except Exception as e:
            logger.error(f"Outlook connection failed: {e}")
            return False
    
    # ==================== EMAIL SENDING ====================
    
    def send_email(self, to: List[str], subject: str, body: str,
                  cc: List[str] = None, bcc: List[str] = None,
                  attachments: List[str] = None, is_html: bool = False) -> bool:
        """
        Send an email via Outlook
        
        Args:
            to (List[str]): Recipient email addresses
            subject (str): Email subject
            body (str): Email body
            cc (List[str], optional): CC recipients
            bcc (List[str], optional): BCC recipients
            attachments (List[str], optional): List of file paths to attach
            is_html (bool): Whether body is HTML
        
        Returns:
            bool: True if email sent successfully
        """
        try:
            # Prepare message
            message = {
                "subject": subject,
                "body": {
                    "contentType": "HTML" if is_html else "text",
                    "content": body
                },
                "toRecipients": [{"emailAddress": {"address": addr}} for addr in to],
                "from": {
                    "emailAddress": {
                        "address": self.sender_email,
                        "name": self.sender_name
                    }
                }
            }
            
            if cc:
                message["ccRecipients"] = [{"emailAddress": {"address": addr}} for addr in cc]
            
            if bcc:
                message["bccRecipients"] = [{"emailAddress": {"address": addr}} for addr in bcc]
            
            # Add attachments if provided
            if attachments:
                message["attachments"] = []
                for file_path in attachments:
                    if os.path.exists(file_path):
                        attachment = self._prepare_attachment(file_path)
                        if attachment:
                            message["attachments"].append(attachment)
            
            # Send email
            self.graph_client.me.send_mail(message).execute_query()
            
            logger.info(f"Email sent to {', '.join(to)} - Subject: {subject}")
            return True
        
        except Exception as e:
            logger.error(f"Failed to send email: {e}")
            return False
    
    def send_notification(self, recipients: List[str], title: str, message: str,
                         urgency: str = "normal", include_timestamp: bool = True) -> bool:
        """
        Send a notification email
        
        Args:
            recipients (List[str]): List of recipient emails
            title (str): Notification title
            message (str): Notification message
            urgency (str): Urgency level ('low', 'normal', 'high')
            include_timestamp (bool): Include timestamp in email
        
        Returns:
            bool: True if sent successfully
        """
        try:
            # Build HTML body with formatting
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S") if include_timestamp else ""
            
            urgency_color = {
                "low": "#4CAF50",
                "normal": "#2196F3",
                "high": "#FF5722"
            }.get(urgency, "#2196F3")
            
            html_body = f"""
            <html>
                <body style="font-family: Arial, sans-serif;">
                    <div style="border-left: 4px solid {urgency_color}; padding-left: 15px; margin: 10px 0;">
                        <h2 style="color: {urgency_color}; margin: 0 0 10px 0;">{title}</h2>
                        <p style="margin: 10px 0; color: #333;">{message}</p>
                        {f'<p style="color: #888; font-size: 0.9em; margin-top: 20px;">Sent: {timestamp}</p>' if timestamp else ''}
                    </div>
                </body>
            </html>
            """
            
            return self.send_email(
                to=recipients,
                subject=f"[{urgency.upper()}] {title}",
                body=html_body,
                is_html=True
            )
        
        except Exception as e:
            logger.error(f"Failed to send notification: {e}")
            return False
    
    def send_alert_notification(self, recipients: List[str], alert_type: str,
                               alert_message: str, severity: str = "WARNING") -> bool:
        """
        Send an alert notification with formatting
        
        Args:
            recipients (List[str]): Recipient emails
            alert_type (str): Type of alert (e.g., 'API_ERROR', 'SYSTEM_DOWN')
            alert_message (str): Alert message
            severity (str): Severity level ('INFO', 'WARNING', 'CRITICAL')
        
        Returns:
            bool: True if sent successfully
        """
        try:
            severity_colors = {
                "INFO": "#2196F3",
                "WARNING": "#FF9800",
                "CRITICAL": "#FF5722"
            }
            
            severity_color = severity_colors.get(severity, "#2196F3")
            
            html_body = f"""
            <html>
                <body style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 20px;">
                    <div style="background-color: white; padding: 20px; border-radius: 5px; 
                               border-left: 5px solid {severity_color};">
                        <h3 style="color: {severity_color}; margin-top: 0;">
                            🚨 {severity} - {alert_type}
                        </h3>
                        <p style="color: #333; line-height: 1.6; margin: 15px 0;">
                            {alert_message}
                        </p>
                        <p style="color: #888; font-size: 0.9em;">
                            <strong>Time:</strong> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}<br>
                            <strong>Source:</strong> Notification Service
                        </p>
                    </div>
                </body>
            </html>
            """
            
            return self.send_email(
                to=recipients,
                subject=f"[{severity}] {alert_type}",
                body=html_body,
                is_html=True
            )
        
        except Exception as e:
            logger.error(f"Failed to send alert notification: {e}")
            return False
    
    # ==================== TEMPLATE EMAILS ====================
    
    def send_template_email(self, recipients: List[str], template_name: str,
                           template_vars: Dict[str, Any] = None) -> bool:
        """
        Send email using a template
        
        Args:
            recipients (List[str]): Recipient emails
            template_name (str): Template name (e.g., 'welcome', 'alert', 'report')
            template_vars (Dict): Variables to fill in template
        
        Returns:
            bool: True if sent successfully
        """
        try:
            template_vars = template_vars or {}
            
            templates = {
                "welcome": {
                    "subject": "Welcome to {app_name}",
                    "body": "Welcome {user_name}! You have been added to {app_name}."
                },
                "alert": {
                    "subject": "Alert: {alert_type}",
                    "body": "Alert: {message}"
                },
                "report": {
                    "subject": "{report_type} Report - {date}",
                    "body": "Here is your {report_type} report for {date}:\n{content}"
                }
            }
            
            if template_name not in templates:
                logger.error(f"Template '{template_name}' not found")
                return False
            
            template = templates[template_name]
            subject = template["subject"].format(**template_vars)
            body = template["body"].format(**template_vars)
            
            return self.send_email(
                to=recipients,
                subject=subject,
                body=body
            )
        
        except Exception as e:
            logger.error(f"Failed to send template email: {e}")
            return False
    
    # ==================== DRAFT MANAGEMENT ====================
    
    def create_draft(self, to: List[str], subject: str, body: str,
                    cc: List[str] = None, bcc: List[str] = None) -> Optional[str]:
        """
        Create a draft email (not sent)
        
        Args:
            to (List[str]): Recipient emails
            subject (str): Email subject
            body (str): Email body
            cc (List[str], optional): CC recipients
            bcc (List[str], optional): BCC recipients
        
        Returns:
            str: Draft email ID, or None if failed
        """
        try:
            message = {
                "subject": subject,
                "body": {
                    "contentType": "text",
                    "content": body
                },
                "toRecipients": [{"emailAddress": {"address": addr}} for addr in to],
            }
            
            if cc:
                message["ccRecipients"] = [{"emailAddress": {"address": addr}} for addr in cc]
            
            if bcc:
                message["bccRecipients"] = [{"emailAddress": {"address": addr}} for addr in bcc]
            
            draft = self.graph_client.me.mailFolders.get_by_name('Drafts').messages.add(message).execute_query()
            
            logger.info(f"Draft created with ID: {draft.id}")
            return draft.id
        
        except Exception as e:
            logger.error(f"Failed to create draft: {e}")
            return None
    
    def send_draft(self, draft_id: str) -> bool:
        """
        Send a draft email
        
        Args:
            draft_id (str): Draft email ID
        
        Returns:
            bool: True if sent successfully
        """
        try:
            self.graph_client.me.messages[draft_id].send().execute_query()
            logger.info(f"Draft {draft_id} sent successfully")
            return True
        
        except Exception as e:
            logger.error(f"Failed to send draft: {e}")
            return False
    
    # ==================== BULK OPERATIONS ====================
    
    def send_bulk_emails(self, recipients_list: List[Dict[str, Any]], subject: str,
                        body_template: str = None) -> Dict[str, bool]:
        """
        Send emails to multiple recipients with personalization
        
        Args:
            recipients_list (List[Dict]): List of recipient dicts with 'email' and vars
            subject (str): Email subject
            body_template (str): Template with {var} placeholders
        
        Returns:
            Dict: Send status for each recipient
        """
        results = {}
        
        for recipient in recipients_list:
            try:
                email = recipient.get('email')
                if not email:
                    logger.warning("Recipient missing email address")
                    continue
                
                # Personalize body if template provided
                body = body_template
                if body_template:
                    body = body_template.format(**recipient)
                
                success = self.send_email(
                    to=[email],
                    subject=subject,
                    body=body
                )
                results[email] = success
            
            except Exception as e:
                logger.error(f"Failed to send email to {email}: {e}")
                results[email] = False
        
        logger.info(f"Bulk send complete: {sum(results.values())}/{len(results)} successful")
        return results
    
    # ==================== ATTACHMENT HANDLING ====================
    
    def _prepare_attachment(self, file_path: str) -> Optional[Dict[str, Any]]:
        """
        Prepare file attachment for email
        
        Args:
            file_path (str): Path to file
        
        Returns:
            Dict: Attachment object, or None if failed
        """
        try:
            if not os.path.exists(file_path):
                logger.warning(f"File not found: {file_path}")
                return None
            
            file_name = os.path.basename(file_path)
            content_type, _ = mimetypes.guess_type(file_path)
            content_type = content_type or "application/octet-stream"
            
            with open(file_path, 'rb') as f:
                file_content = f.read()
            
            import base64
            encoded_content = base64.b64encode(file_content).decode('utf-8')
            
            return {
                "@odata.type": "#microsoft.graph.fileAttachment",
                "name": file_name,
                "contentType": content_type,
                "contentBytes": encoded_content
            }
        
        except Exception as e:
            logger.error(f"Failed to prepare attachment: {e}")
            return None
    
    # ==================== UTILITY METHODS ====================
    
    def get_mailbox_info(self) -> Dict[str, Any]:
        """
        Get mailbox information
        
        Returns:
            Dict: Mailbox details
        """
        try:
            mailbox = self.graph_client.me.get().execute_query()
            
            return {
                "email": mailbox.user_principal_name,
                "name": mailbox.display_name,
                "office_location": mailbox.office_location,
                "mobile_phone": mailbox.mobile_phone
            }
        
        except Exception as e:
            logger.error(f"Failed to get mailbox info: {e}")
            return {}
    
    def get_sent_items_count(self) -> int:
        """
        Get count of sent items
        
        Returns:
            int: Number of sent emails
        """
        try:
            sent_folder = self.graph_client.me.mailFolders.get_by_name('Sent Items')
            self.graph_client.load(sent_folder)
            self.graph_client.execute_query()
            
            return sent_folder.total_item_count
        
        except Exception as e:
            logger.error(f"Failed to get sent items count: {e}")
            return 0
    
    def test_notification(self, recipient: str) -> bool:
        """
        Send a test notification email
        
        Args:
            recipient (str): Test email recipient
        
        Returns:
            bool: True if sent successfully
        """
        try:
            return self.send_notification(
                recipients=[recipient],
                title="Test Notification",
                message="This is a test notification from the Outlook Email Connector.",
                urgency="normal"
            )
        
        except Exception as e:
            logger.error(f"Failed to send test notification: {e}")
            return False


def get_outlook_email_connector() -> OutlookEmailConnector:
    """Factory function to get Outlook Email connector instance"""
    return OutlookEmailConnector()


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    try:
        outlook = OutlookEmailConnector()
        
        # Test connection
        if outlook.connect():
            print("✓ Connected to Outlook")
            
            # Get mailbox info
            info = outlook.get_mailbox_info()
            print(f"Mailbox: {info}")
            
            # Send test notification
            success = outlook.test_notification("test@example.com")
            print(f"Test notification sent: {success}")
        
    except Exception as e:
        print(f"Error: {e}")