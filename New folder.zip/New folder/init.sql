-- ============================================================================
-- 360° Enterprise Dashboard - Database Tables Creation Script (FIXED)
-- ============================================================================
-- Purpose: Create all tables for dashboard_360 database
-- Timezone: PST (America/Los_Angeles)
-- Run this in pgAdmin Query Tool
-- Database: dashboard_360
-- User: dashboard_360_user
-- ============================================================================

-- ============================================================================
-- 0. SET TIMEZONE TO PST
-- ============================================================================

SET timezone = 'America/Los_Angeles';

-- ============================================================================
-- 1. CREATE USERS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(120) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(120) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE,
    CONSTRAINT email_check CHECK (email ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$')
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_users_is_active ON users(is_active);

COMMENT ON TABLE users IS '360° Dashboard - User account information';
COMMENT ON COLUMN users.email IS 'User email address (unique identifier)';
COMMENT ON COLUMN users.password IS 'Hashed password using werkzeug.security';
COMMENT ON COLUMN users.name IS 'User full name';
COMMENT ON COLUMN users.is_active IS 'Account active status';

-- ============================================================================
-- 2. CREATE AZURE INTEGRATIONS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS azure_integrations (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subscription_id VARCHAR(255) NOT NULL,
    tenant_id VARCHAR(255) NOT NULL,
    client_id VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'connected' CHECK (status IN ('connected', 'disconnected', 'error')),
    last_sync TIMESTAMP WITH TIME ZONE,
    resources_count INTEGER DEFAULT 24,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_user_subscription UNIQUE(user_id, subscription_id)
);

CREATE INDEX IF NOT EXISTS idx_azure_user_id ON azure_integrations(user_id);
CREATE INDEX IF NOT EXISTS idx_azure_status ON azure_integrations(status);
CREATE INDEX IF NOT EXISTS idx_azure_created_at ON azure_integrations(created_at DESC);

COMMENT ON TABLE azure_integrations IS '360° Dashboard - Azure subscription integrations';
COMMENT ON COLUMN azure_integrations.subscription_id IS 'Azure subscription ID';
COMMENT ON COLUMN azure_integrations.tenant_id IS 'Azure tenant/directory ID';
COMMENT ON COLUMN azure_integrations.client_id IS 'Azure client/app ID';
COMMENT ON COLUMN azure_integrations.status IS 'Integration connection status';
COMMENT ON COLUMN azure_integrations.resources_count IS 'Number of Azure resources monitored';

-- ============================================================================
-- 3. CREATE SHAREPOINT INTEGRATIONS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS sharepoint_integrations (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    site_url VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'connected' CHECK (status IN ('connected', 'disconnected', 'error')),
    last_sync TIMESTAMP WITH TIME ZONE,
    documents_count INTEGER DEFAULT 0,
    sites_count INTEGER DEFAULT 8,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_user_site UNIQUE(user_id, site_url)
);

CREATE INDEX IF NOT EXISTS idx_sharepoint_user_id ON sharepoint_integrations(user_id);
CREATE INDEX IF NOT EXISTS idx_sharepoint_status ON sharepoint_integrations(status);
CREATE INDEX IF NOT EXISTS idx_sharepoint_created_at ON sharepoint_integrations(created_at DESC);

COMMENT ON TABLE sharepoint_integrations IS '360° Dashboard - SharePoint site integrations';
COMMENT ON COLUMN sharepoint_integrations.site_url IS 'SharePoint site URL';
COMMENT ON COLUMN sharepoint_integrations.documents_count IS 'Total documents in site';
COMMENT ON COLUMN sharepoint_integrations.sites_count IS 'Number of SharePoint sites connected';

-- ============================================================================
-- 4. CREATE AI INTERACTIONS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS ai_interactions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    interaction_type VARCHAR(50) NOT NULL CHECK (interaction_type IN ('code_review', 'summary', 'generation')),
    input_text TEXT NOT NULL,
    output_text TEXT,
    tokens_used INTEGER DEFAULT 0,
    status VARCHAR(20) DEFAULT 'success' CHECK (status IN ('success', 'failed')),
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_ai_user_id ON ai_interactions(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_type ON ai_interactions(interaction_type);
CREATE INDEX IF NOT EXISTS idx_ai_status ON ai_interactions(status);
CREATE INDEX IF NOT EXISTS idx_ai_created_at ON ai_interactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_user_type ON ai_interactions(user_id, interaction_type);

COMMENT ON TABLE ai_interactions IS '360° Dashboard - Azure OpenAI service interactions log';
COMMENT ON COLUMN ai_interactions.interaction_type IS 'Type: code_review, summary, or generation';
COMMENT ON COLUMN ai_interactions.input_text IS 'Input provided to AI service';
COMMENT ON COLUMN ai_interactions.output_text IS 'Output from AI service';
COMMENT ON COLUMN ai_interactions.tokens_used IS 'Azure OpenAI tokens consumed';
COMMENT ON COLUMN ai_interactions.error_message IS 'Error details if operation failed';

-- ============================================================================
-- 5. CREATE STORAGE FILES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS storage_files (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    filename VARCHAR(255) NOT NULL,
    blob_name VARCHAR(255) NOT NULL,
    blob_url VARCHAR(500) NOT NULL,
    file_size INTEGER NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    status VARCHAR(20) DEFAULT 'uploaded' CHECK (status IN ('uploaded', 'failed', 'deleted')),
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT file_size_check CHECK (file_size > 0 AND file_size <= 10485760)
);

CREATE INDEX IF NOT EXISTS idx_storage_user_id ON storage_files(user_id);
CREATE INDEX IF NOT EXISTS idx_storage_status ON storage_files(status);
CREATE INDEX IF NOT EXISTS idx_storage_type ON storage_files(file_type);
CREATE INDEX IF NOT EXISTS idx_storage_created_at ON storage_files(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_storage_filename ON storage_files(filename);
CREATE INDEX IF NOT EXISTS idx_storage_files_user_type ON storage_files(user_id, file_type);

COMMENT ON TABLE storage_files IS '360° Dashboard - Files uploaded to Azure Blob Storage';
COMMENT ON COLUMN storage_files.filename IS 'Original filename uploaded by user';
COMMENT ON COLUMN storage_files.blob_name IS 'Path in Azure Blob Storage (user-{id}/filename)';
COMMENT ON COLUMN storage_files.blob_url IS 'Public URL to access file in Azure';
COMMENT ON COLUMN storage_files.file_size IS 'File size in bytes (max 10MB limit)';
COMMENT ON COLUMN storage_files.file_type IS 'File extension (pdf, png, docx, xlsx, csv, py, js, etc.)';

-- ============================================================================
-- 6. INSERT DEMO USER
-- ============================================================================

INSERT INTO users (email, password, name, is_active)
VALUES (
    'demo@example.com',
    'pbkdf2:sha256:600000$RGvRRFbJwB0V9r5X$8ba9c2ab7bd1d2e4f8c7d6a5b4c3d2e1f0g9h8i7',
    'Demo User',
    TRUE
)
ON CONFLICT (email) DO NOTHING;

-- Note: The password hash above is for 'demo123'
-- If you need to generate a new hash, use Python:
-- from werkzeug.security import generate_password_hash
-- generate_password_hash('demo123')

-- ============================================================================
-- 7. DROP EXISTING VIEWS (If they exist)
-- ============================================================================

DROP VIEW IF EXISTS dashboard_360_storage_usage CASCADE;
DROP VIEW IF EXISTS dashboard_360_ai_usage CASCADE;
DROP VIEW IF EXISTS dashboard_360_integration_status CASCADE;
DROP VIEW IF EXISTS dashboard_360_user_stats CASCADE;

-- ============================================================================
-- 8. CREATE VIEWS FOR ANALYTICS
-- ============================================================================

-- User Statistics View
CREATE VIEW dashboard_360_user_stats AS
SELECT
    u.id,
    u.email,
    u.name,
    u.created_at AT TIME ZONE 'America/Los_Angeles' as created_at_pst,
    u.last_login AT TIME ZONE 'America/Los_Angeles' as last_login_pst,
    u.is_active,
    COUNT(DISTINCT ai.id) as ai_interactions_count,
    COUNT(DISTINCT sf.id) as storage_files_count,
    COUNT(DISTINCT azi.id) as azure_integrations_count,
    COUNT(DISTINCT spi.id) as sharepoint_integrations_count,
    COALESCE(SUM(sf.file_size), 0) as total_storage_used_bytes,
    COALESCE(ROUND((SUM(sf.file_size)::NUMERIC / (1024 * 1024))::NUMERIC, 2), 0) as total_storage_used_mb
FROM users u
LEFT JOIN ai_interactions ai ON u.id = ai.user_id
LEFT JOIN storage_files sf ON u.id = sf.user_id AND sf.status = 'uploaded'
LEFT JOIN azure_integrations azi ON u.id = azi.user_id
LEFT JOIN sharepoint_integrations spi ON u.id = spi.user_id
GROUP BY u.id, u.email, u.name, u.created_at, u.last_login, u.is_active;

COMMENT ON VIEW dashboard_360_user_stats IS '360° Dashboard - User statistics and usage metrics (PST Timezone)';

-- ============================================================================
-- 9. CREATE INTEGRATION STATUS VIEW
-- ============================================================================

CREATE VIEW dashboard_360_integration_status AS
SELECT
    'Azure' as integration_type,
    u.id as user_id,
    u.email,
    COUNT(CASE WHEN azi.status = 'connected' THEN 1 END) as connected_count,
    COUNT(CASE WHEN azi.status = 'error' THEN 1 END) as error_count,
    COUNT(azi.id) as total_count,
    MAX(azi.last_sync) AT TIME ZONE 'America/Los_Angeles' as last_sync_pst
FROM users u
LEFT JOIN azure_integrations azi ON u.id = azi.user_id
WHERE azi.id IS NOT NULL
GROUP BY u.id, u.email

UNION ALL

SELECT
    'SharePoint' as integration_type,
    u.id as user_id,
    u.email,
    COUNT(CASE WHEN spi.status = 'connected' THEN 1 END) as connected_count,
    COUNT(CASE WHEN spi.status = 'error' THEN 1 END) as error_count,
    COUNT(spi.id) as total_count,
    MAX(spi.last_sync) AT TIME ZONE 'America/Los_Angeles' as last_sync_pst
FROM users u
LEFT JOIN sharepoint_integrations spi ON u.id = spi.user_id
WHERE spi.id IS NOT NULL
GROUP BY u.id, u.email;

COMMENT ON VIEW dashboard_360_integration_status IS '360° Dashboard - Integration connection status by user (PST Timezone)';

-- ============================================================================
-- 10. CREATE AI USAGE VIEW
-- ============================================================================

CREATE VIEW dashboard_360_ai_usage AS
SELECT
    u.id,
    u.email,
    u.name,
    ai.interaction_type,
    COUNT(ai.id) as interaction_count,
    COUNT(CASE WHEN ai.status = 'success' THEN 1 END) as success_count,
    COUNT(CASE WHEN ai.status = 'failed' THEN 1 END) as failed_count,
    SUM(ai.tokens_used) as total_tokens_used,
    ROUND((AVG(ai.tokens_used)::NUMERIC), 2) as avg_tokens_per_interaction,
    MAX(ai.created_at) AT TIME ZONE 'America/Los_Angeles' as last_interaction_pst
FROM users u
LEFT JOIN ai_interactions ai ON u.id = ai.user_id
GROUP BY u.id, u.email, u.name, ai.interaction_type
ORDER BY u.id, ai.interaction_type;

COMMENT ON VIEW dashboard_360_ai_usage IS '360° Dashboard - AI service usage analytics (PST Timezone)';

-- ============================================================================
-- 11. CREATE STORAGE USAGE VIEW
-- ============================================================================

CREATE VIEW dashboard_360_storage_usage AS
SELECT
    u.id,
    u.email,
    u.name,
    COUNT(sf.id) as file_count,
    COUNT(CASE WHEN sf.status = 'uploaded' THEN 1 END) as uploaded_count,
    COUNT(CASE WHEN sf.status = 'failed' THEN 1 END) as failed_count,
    COALESCE(SUM(sf.file_size), 0) as total_size_bytes,
    COALESCE(ROUND((SUM(sf.file_size)::NUMERIC / (1024 * 1024))::NUMERIC, 2), 0) as total_size_mb,
    COALESCE(ROUND((SUM(sf.file_size)::NUMERIC / (1024 * 1024 * 1024))::NUMERIC, 2), 0) as total_size_gb,
    MAX(sf.created_at) AT TIME ZONE 'America/Los_Angeles' as last_upload_pst
FROM users u
LEFT JOIN storage_files sf ON u.id = sf.user_id
GROUP BY u.id, u.email, u.name
ORDER BY total_size_bytes DESC;

COMMENT ON VIEW dashboard_360_storage_usage IS '360° Dashboard - Storage usage statistics by user (PST Timezone)';

-- ============================================================================
-- 12. CREATE SUMMARY VIEW
-- ============================================================================

CREATE VIEW dashboard_360_summary AS
SELECT
    (SELECT COUNT(*) FROM users) as total_users,
    (SELECT COUNT(*) FROM users WHERE is_active = true) as active_users,
    (SELECT COUNT(*) FROM azure_integrations) as total_azure_integrations,
    (SELECT COUNT(*) FROM sharepoint_integrations) as total_sharepoint_integrations,
    (SELECT COUNT(*) FROM ai_interactions) as total_ai_interactions,
    (SELECT COUNT(*) FROM ai_interactions WHERE status = 'success') as successful_ai_interactions,
    (SELECT COUNT(*) FROM storage_files WHERE status = 'uploaded') as uploaded_files,
    (SELECT COALESCE(SUM(file_size), 0) FROM storage_files WHERE status = 'uploaded') as total_storage_bytes,
    ROUND((SELECT COALESCE(SUM(file_size)::NUMERIC, 0) FROM storage_files WHERE status = 'uploaded') / (1024 * 1024), 2) as total_storage_mb,
    NOW() AT TIME ZONE 'America/Los_Angeles' as last_updated_pst;

COMMENT ON VIEW dashboard_360_summary IS '360° Dashboard - Overall system summary statistics (PST Timezone)';

-- ============================================================================
-- 13. VERIFY SCRIPT EXECUTION
-- ============================================================================

-- Display all created tables
SELECT 'Tables created successfully!' as status;

-- Display table count
SELECT COUNT(*) as total_tables 
FROM information_schema.tables 
WHERE table_schema = 'public' AND table_type = 'BASE TABLE';

-- Display view count
SELECT COUNT(*) as total_views 
FROM information_schema.views 
WHERE table_schema = 'public';

-- Display demo user
SELECT 'Demo user created:' as status, email, name FROM users WHERE email = 'demo@example.com';

-- Display timezone
SELECT 'Database timezone set to PST' as status, current_setting('timezone') as current_timezone;

-- ============================================================================
-- 14. SUMMARY
-- ============================================================================

/*
TABLES CREATED (5):
  1. users - User account information
  2. azure_integrations - Azure subscription integrations
  3. sharepoint_integrations - SharePoint site integrations
  4. ai_interactions - Azure OpenAI interactions log
  5. storage_files - Uploaded files metadata

VIEWS CREATED (5):
  1. dashboard_360_user_stats - User statistics
  2. dashboard_360_integration_status - Integration status
  3. dashboard_360_ai_usage - AI usage analytics
  4. dashboard_360_storage_usage - Storage usage statistics
  5. dashboard_360_summary - Overall system summary

INDEXES CREATED: 21+

DEMO USER:
  Email: demo@example.com
  Password: demo123

TIMEZONE:
  All timestamps use PST (America/Los_Angeles)
  All timestamp columns are TIMESTAMP WITH TIME ZONE

FIXES APPLIED:
  ✓ Fixed ROUND() function - now uses NUMERIC::NUMERIC casting
  ✓ Fixed view creation - drops and recreates to avoid conflicts
  ✓ Added PST timezone support
  ✓ All timestamps include timezone information
  ✓ Improved numeric calculations with proper type casting
*/

-- ============================================================================
-- END OF SCRIPT - EXECUTION COMPLETE
-- ============================================================================