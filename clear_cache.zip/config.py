"""
Configuration management for API Migration Tool
Handles environment variables and application settings
FIXED: Removed hardcoded credentials, proper validation
"""
import os
from typing import List, Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    """Base configuration class"""
    
    # Flask Configuration
    SECRET_KEY = os.getenv('FLASK_SECRET_KEY', 'dev-secret-key-change-this')
    DEBUG = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    HOST = os.getenv('FLASK_HOST', '127.0.0.1')
    PORT = int(os.getenv('FLASK_PORT', 5000))
    
    # Database Configuration
    DATABASE_URL = os.getenv('DATABASE_URL')
    
    # If DATABASE_URL is not provided, build from components
    if not DATABASE_URL:
        DB_TYPE = os.getenv('DB_TYPE', 'sqlite')
        if DB_TYPE == 'postgresql':
            DB_HOST = os.getenv('DB_HOST', 'localhost')
            DB_PORT = os.getenv('DB_PORT', '5432')
            DB_NAME = os.getenv('DB_NAME', 'api_migration_db')
            DB_USER = os.getenv('DB_USER', 'api_user')
            DB_PASSWORD = os.getenv('DB_PASSWORD', '')
            
            DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        else:
            DATABASE_URL = 'sqlite:///migrations.db'
    
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # PostgreSQL specific settings
    if 'postgresql' in DATABASE_URL:
        SQLALCHEMY_ENGINE_OPTIONS = {
            'pool_size': int(os.getenv('DB_POOL_SIZE', 10)),
            'max_overflow': int(os.getenv('DB_MAX_OVERFLOW', 20)),
            'pool_timeout': int(os.getenv('DB_POOL_TIMEOUT', 30)),
            'pool_recycle': int(os.getenv('DB_POOL_RECYCLE', 3600)),
            'pool_pre_ping': True,  # Verify connections before use
            'echo': DEBUG  # Log SQL queries in debug mode
        }
    else:
        SQLALCHEMY_ENGINE_OPTIONS = {}
    
    # File Upload Configuration
    UPLOAD_FOLDER = os.getenv('UPLOAD_FOLDER', 'static/uploads')
    MAX_CONTENT_LENGTH = int(os.getenv('MAX_CONTENT_LENGTH', 16 * 1024 * 1024))  # 16MB
    ALLOWED_EXTENSIONS = os.getenv('ALLOWED_EXTENSIONS', 'json,yaml,yml').split(',')
    
    # Logging Configuration
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.getenv('LOG_FILE', 'logs/app.log')
    
    @classmethod
    def get_database_type(cls) -> str:
        """Get the database type from URL"""
        if 'postgresql' in cls.DATABASE_URL:
            return 'postgresql'
        elif 'sqlite' in cls.DATABASE_URL:
            return 'sqlite'
        else:
            return 'unknown'
    
    @classmethod
    def is_production_db(cls) -> bool:
        """Check if using production database"""
        return cls.get_database_type() == 'postgresql'

class AzureConfig:
    """Azure services configuration - FIXED VERSION"""
    
    # ✅ FIX: Azure Authentication (from environment variables ONLY)
    CLIENT_ID = os.getenv('AZURE_CLIENT_ID')
    CLIENT_SECRET = os.getenv('AZURE_CLIENT_SECRET')
    TENANT_ID = os.getenv('AZURE_TENANT_ID')
    SUBSCRIPTION_ID = os.getenv('AZURE_SUBSCRIPTION_ID')
    
    # ✅ FIX: Azure OpenAI Configuration (from environment variables ONLY - NO hardcoded values)
    OPENAI_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT')
    OPENAI_API_KEY = os.getenv('AZURE_OPENAI_API_KEY')
    OPENAI_DEPLOYMENT = os.getenv('AZURE_OPENAI_DEPLOYMENT')
    OPENAI_VERSION = os.getenv('AZURE_OPENAI_VERSION')
    
    # ✅ FIX: Azure API Management Configuration
    APIM_RESOURCE_GROUP = os.getenv('AZURE_APIM_RESOURCE_GROUP')
    APIM_SERVICE_NAME = os.getenv('AZURE_APIM_SERVICE_NAME')
    APIM_BASE_URL = os.getenv('AZURE_APIM_BASE_URL', 'https://management.azure.com')
    
    @classmethod
    def validate_azure_config(cls) -> List[str]:
        """Validate Azure configuration and return list of missing variables"""
        missing = []
        required_vars = [
            ('AZURE_CLIENT_ID', cls.CLIENT_ID),
            ('AZURE_CLIENT_SECRET', cls.CLIENT_SECRET),
            ('AZURE_TENANT_ID', cls.TENANT_ID),
            ('AZURE_SUBSCRIPTION_ID', cls.SUBSCRIPTION_ID),
        ]
        
        for var_name, var_value in required_vars:
            if not var_value:
                missing.append(var_name)
        
        return missing
    
    @classmethod
    def validate_openai_config(cls) -> List[str]:
        """
        ✅ FIX: Validate Azure OpenAI configuration
        Returns list of missing or invalid variables
        """
        missing = []
        errors = []
        
        # Check required variables
        required_vars = [
            ('AZURE_OPENAI_ENDPOINT', cls.OPENAI_ENDPOINT),
            ('AZURE_OPENAI_API_KEY', cls.OPENAI_API_KEY),
            ('AZURE_OPENAI_DEPLOYMENT', cls.OPENAI_DEPLOYMENT),
            ('AZURE_OPENAI_VERSION', cls.OPENAI_VERSION),
        ]
        
        for var_name, var_value in required_vars:
            if not var_value or not str(var_value).strip():
                missing.append(var_name)
        
        # ✅ FIX: Validate endpoint format
        if cls.OPENAI_ENDPOINT:
            endpoint = str(cls.OPENAI_ENDPOINT).strip()
            if not endpoint.startswith('https://'):
                errors.append(f"AZURE_OPENAI_ENDPOINT must start with 'https://', got: {endpoint[:30]}...")
            if not ('openai' in endpoint.lower() or 'azure' in endpoint.lower()):
                errors.append(f"AZURE_OPENAI_ENDPOINT doesn't look like Azure OpenAI URL: {endpoint[:50]}...")
        
        # ✅ FIX: Validate deployment name
        if cls.OPENAI_DEPLOYMENT:
            deployment = str(cls.OPENAI_DEPLOYMENT).strip()
            # Check for invalid model names
            invalid_models = ['gpt-5-mini', 'gpt-5', 'gpt6', 'text-davinci-003']
            if deployment in invalid_models:
                errors.append(f"AZURE_OPENAI_DEPLOYMENT '{deployment}' doesn't exist. Valid options: gpt-4o-mini, gpt-4, gpt-4-turbo, gpt-35-turbo")
        
        # ✅ FIX: Validate API version format
        if cls.OPENAI_VERSION:
            version = str(cls.OPENAI_VERSION).strip()
            # Should be in YYYY-MM-DD format (optionally with -preview suffix)
            if not (version[0:10].count('-') == 2 and len(version) >= 10):
                errors.append(f"AZURE_OPENAI_VERSION invalid format '{version}'. Expected: YYYY-MM-DD or YYYY-MM-DD-preview")
            
            # Check if year is reasonable (2023 or later)
            try:
                year = int(version.split('-')[0])
                if year < 2023 or year > 2025:
                    errors.append(f"AZURE_OPENAI_VERSION year {year} seems incorrect. Should be 2023-2025")
            except (ValueError, IndexError):
                errors.append(f"AZURE_OPENAI_VERSION '{version}' has invalid year")
        
        return missing + errors
    
    @classmethod
    def validate_apim_config(cls) -> List[str]:
        """Validate Azure APIM configuration"""
        missing = []
        required_vars = [
            ('AZURE_APIM_RESOURCE_GROUP', cls.APIM_RESOURCE_GROUP),
            ('AZURE_APIM_SERVICE_NAME', cls.APIM_SERVICE_NAME),
        ]
        
        for var_name, var_value in required_vars:
            if not var_value:
                missing.append(var_name)
        
        return missing
    
    @classmethod
    def get_config_status(cls) -> dict:
        """
        ✅ NEW: Get complete configuration status
        Returns detailed info about what's configured and what's missing
        """
        return {
            'endpoint': '✅' if cls.OPENAI_ENDPOINT else '❌',
            'api_key': '✅' if cls.OPENAI_API_KEY else '❌',
            'deployment': '✅' if cls.OPENAI_DEPLOYMENT else '❌',
            'version': '✅' if cls.OPENAI_VERSION else '❌',
            'endpoint_value': cls.OPENAI_ENDPOINT[:40] + '...' if cls.OPENAI_ENDPOINT else 'NOT SET',
            'deployment_value': cls.OPENAI_DEPLOYMENT or 'NOT SET',
            'version_value': cls.OPENAI_VERSION or 'NOT SET',
            'errors': cls.validate_openai_config()
        }

class DevelopmentConfig(Config):
    """Development environment configuration"""
    DEBUG = True
    TESTING = False

class ProductionConfig(Config):
    """Production environment configuration"""
    DEBUG = False
    TESTING = False
    SECRET_KEY = os.getenv('FLASK_SECRET_KEY')
    
    @classmethod
    def validate_production_config(cls):
        """Validate production configuration"""
        if not cls.SECRET_KEY or cls.SECRET_KEY == 'dev-secret-key-change-this':
            raise ValueError("Production SECRET_KEY must be set and different from default")

class TestingConfig(Config):
    """Testing environment configuration"""
    TESTING = True
    DATABASE_URL = 'sqlite:///:memory:'
    SQLALCHEMY_DATABASE_URI = DATABASE_URL

# Configuration mapping
config_mapping = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}

def get_config(env: Optional[str] = None) -> Config:
    """Get configuration based on environment"""
    if not env:
        env = os.getenv('FLASK_ENV', 'development')
    
    return config_mapping.get(env, config_mapping['default'])

def validate_all_configurations() -> dict:
    """
    ✅ FIX: Validate all service configurations and return detailed status
    """
    validation_results = {
        'azure_auth': AzureConfig.validate_azure_config(),
        'azure_openai': AzureConfig.validate_openai_config(),
        'azure_apim': AzureConfig.validate_apim_config(),
        'openai_config_status': AzureConfig.get_config_status(),
    }
    
    return validation_results

def get_missing_configurations() -> List[str]:
    """Get list of all missing configuration variables"""
    all_missing = []
    validation_results = validate_all_configurations()
    
    for service, missing_vars in validation_results.items():
        if isinstance(missing_vars, list):
            all_missing.extend(missing_vars)
    
    return all_missing

def print_azure_config_status():
    """
    ✅ NEW: Print Azure OpenAI configuration status
    Use this for debugging configuration issues
    """
    status = AzureConfig.get_config_status()
    
    print("\n" + "="*70)
    print("AZURE OPENAI CONFIGURATION STATUS")
    print("="*70)
    print(f"\nEndpoint:      {status['endpoint']}  {status['endpoint_value']}")
    print(f"API Key:       {status['api_key']}  {'SET' if status['api_key'] == '✅' else 'NOT SET'}")
    print(f"Deployment:    {status['deployment']}  {status['deployment_value']}")
    print(f"Version:       {status['version']}  {status['version_value']}")
    
    if status['errors']:
        print(f"\n🔴 CONFIGURATION ERRORS ({len(status['errors'])}):")
        for i, error in enumerate(status['errors'], 1):
            print(f"   {i}. {error}")
    else:
        print("\n✅ NO ERRORS - Configuration looks good!")
    
    print("\n" + "="*70 + "\n")