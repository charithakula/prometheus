#!/usr/bin/env python3
"""
Azure OpenAI Connector Diagnostic Script - MODEL-AWARE VERSION
Tests the updated connector with gpt-5-mini and all model support
"""

import os
import sys
from pathlib import Path

# ✅ FIX: Explicitly load .env from current directory
print("\n🔍 Loading environment variables...")
print("-" * 70)

# Find and load .env file
env_path = Path.cwd() / '.env'
print(f"Looking for .env at: {env_path}")
print(f"File exists: {env_path.exists()}")

if env_path.exists():
    print(f"✅ Found .env file: {env_path}\n")
    
    # Load using python-dotenv
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
        print("✅ Loaded environment variables from .env\n")
    except ImportError:
        print("❌ python-dotenv not installed!")
        print("   Install with: pip install python-dotenv")
        sys.exit(1)
else:
    print(f"❌ .env file not found at: {env_path}\n")
    print("Create a .env file in your project root with:")
    print("""
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your-key-here
AZURE_OPENAI_DEPLOYMENT=gpt-5-mini
AZURE_OPENAI_VERSION=2024-02-15-preview
""")
    sys.exit(1)

# Now run diagnostics
def print_header(title):
    print("\n" + "="*70)
    print(title)
    print("="*70)

def print_step(step_num, title):
    print(f"\n{step_num}️⃣  {title}")
    print("-" * 70)

def main():
    print_header("🔍 AZURE OPENAI CONNECTOR DIAGNOSTIC TOOL - MODEL-AWARE VERSION")
    
    # Step 1: Check environment variables
    print_step("1", "VERIFYING ENVIRONMENT VARIABLES")
    
    required_vars = {
        'AZURE_OPENAI_ENDPOINT': {
            'description': 'Must start with https:// and contain openai or azure',
            'example': 'https://my-resource.openai.azure.com/'
        },
        'AZURE_OPENAI_API_KEY': {
            'description': 'Must be at least 20 characters',
            'example': '(hidden for security)'
        },
        'AZURE_OPENAI_DEPLOYMENT': {
            'description': 'Must be valid deployment name',
            'example': 'gpt-5-mini, gpt-4o-mini, gpt-4, gpt-4-turbo'
        },
        'AZURE_OPENAI_VERSION': {
            'description': 'Must be YYYY-MM-DD format',
            'example': '2024-02-15-preview or 2025-01-01-preview'
        }
    }
    
    all_set = True
    for var_name, var_info in required_vars.items():
        value = os.getenv(var_name)
        
        if not value:
            print(f"❌ {var_name}: NOT SET")
            print(f"   Description: {var_info['description']}")
            print(f"   Example: {var_info['example']}")
            all_set = False
        else:
            if 'KEY' in var_name:
                display = value[:10] + '...' + value[-5:] if len(value) > 15 else '***'
            else:
                display = value
            
            print(f"✅ {var_name}")
            print(f"   Value: {display}")
    
    if not all_set:
        print_header("❌ ENVIRONMENT VARIABLES NOT SET")
        print("Check your .env file in project root")
        print(f"Current directory: {Path.cwd()}")
        print(f".env location should be: {Path.cwd() / '.env'}")
        return False
    
    # Step 2: Check deployment name for model config
    print_step("2", "CHECKING DEPLOYMENT MODEL")
    
    deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT').lower()
    
    # ✅ NEW: Check if deployment is in MODEL_CONFIGS
    model_configs = {
        'gpt-5-mini': 'max_completion_tokens (NOT max_tokens)',
        'gpt-5': 'max_completion_tokens (NOT max_tokens)',
        'gpt-4o-mini': 'max_tokens',
        'gpt-4o': 'max_tokens',
        'gpt-4': 'max_tokens',
        'gpt-4-turbo': 'max_tokens',
        'gpt-35-turbo': 'max_tokens',
    }
    
    print(f"Deployment: {deployment}")
    
    # Try to find matching model
    matching_model = None
    for model_name in model_configs.keys():
        if model_name in deployment or model_name.replace('-', '') in deployment.replace('-', ''):
            matching_model = model_name
            break
    
    if matching_model:
        print(f"✅ Recognized as: {matching_model}")
        print(f"✅ Will use: {model_configs[matching_model]}")
    else:
        print(f"⚠️  Unknown deployment name, will default to gpt-4o-mini config")
        print(f"    Supported: {', '.join(model_configs.keys())}")
    
    print(f"\nSupported models and their parameters:")
    for model, param in model_configs.items():
        print(f"   • {model}: {param}")
    
    # Step 3: Validate configuration
    print_step("3", "VALIDATING CONFIGURATION")
    
    try:
        from config_validator import ConfigValidator
        
        validation = ConfigValidator.validate_all()
        
        if validation['valid']:
            print("✅ Configuration is valid!")
        else:
            print(f"❌ Configuration errors ({len(validation['errors'])}):")
            for error in validation['errors']:
                print(f"   - {error}")
            return False
        
        if validation['warnings']:
            print(f"\n⚠️  Warnings ({len(validation['warnings'])}):")
            for warning in validation['warnings']:
                print(f"   - {warning}")
    except Exception as e:
        print(f"❌ Validation failed: {e}")
        return False
    
    # Step 4: Check openai library
    print_step("4", "CHECKING OPENAI LIBRARY")
    
    try:
        from openai import AzureOpenAI
        print("✅ openai library installed")
    except ImportError as e:
        print(f"❌ openai library not found: {e}")
        print("\nInstall with:")
        print("   pip install openai")
        return False
    
    # Step 5: Test client creation
    print_step("5", "TESTING CLIENT CREATION")
    
    try:
        from openai import AzureOpenAI
        
        endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
        api_key = os.getenv('AZURE_OPENAI_API_KEY')
        version = os.getenv('AZURE_OPENAI_VERSION')
        
        print(f"Creating client with:")
        print(f"  Endpoint: {endpoint}")
        print(f"  API Key: {api_key[:10]}...")
        print(f"  Version: {version}\n")
        
        client = AzureOpenAI(
            api_key=api_key,
            api_version=version,
            azure_endpoint=endpoint,
            timeout=120.0,
            max_retries=3
        )
        print("✅ Azure OpenAI client created successfully")
    except Exception as e:
        print(f"❌ Client creation failed: {e}")
        return False
    
    # Step 6: ✅ NEW - Test model-aware parameter building
    print_step("6", "TESTING MODEL-AWARE PARAMETER BUILDER")
    
    try:
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        
        if not connector.is_available:
            print(f"❌ Connector not available: {connector._initialization_error}")
            return False
        
        # Test _build_chat_completion_params
        deployment_name = os.getenv('AZURE_OPENAI_DEPLOYMENT')
        
        print(f"Testing parameter builder for: {deployment_name}\n")
        
        params = connector._build_chat_completion_params(
            deployment=deployment_name,
            messages=[
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "test"}
            ],
            temperature=0.7,
            max_tokens=100
        )
        
        print("✅ Parameter builder executed successfully!")
        print(f"\nGenerated parameters:")
        for key, value in params.items():
            if key == 'messages':
                print(f"   • {key}: [messages array]")
            else:
                print(f"   • {key}: {value}")
        
        # Validate parameters
        print(f"\nValidation:")
        if deployment_name.lower() in ['gpt-5-mini', 'gpt-5']:
            if 'max_completion_tokens' in params:
                print(f"   ✅ Correctly uses 'max_completion_tokens' for {deployment_name}")
            else:
                print(f"   ❌ Should use 'max_completion_tokens' for {deployment_name}")
                return False
            
            if 'max_tokens' in params:
                print(f"   ❌ Should NOT use 'max_tokens' for {deployment_name}")
                return False
        else:
            if 'max_tokens' in params:
                print(f"   ✅ Correctly uses 'max_tokens' for {deployment_name}")
            else:
                print(f"   ❌ Should use 'max_tokens' for {deployment_name}")
                return False
        
        print("\n✅ Parameter builder working correctly!")
        
    except Exception as e:
        print(f"❌ Parameter builder test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Step 7: Test API call with correct parameters
    print_step("7", "TESTING API CALL WITH MODEL-AWARE PARAMETERS")
    
    try:
        deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT')
        
        # Use the connector's parameter builder
        from connectors.azure_openai_connector import AzureOpenAIConnector
        connector = AzureOpenAIConnector()
        
        params = connector._build_chat_completion_params(
            deployment=deployment,
            messages=[
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "Say 'Test successful!' if you can hear me"}
            ],
            temperature=0.3,
            max_tokens=50
        )
        
        print(f"Calling {deployment} with model-aware parameters...\n")
        
        response = connector._client.chat.completions.create(**params)
        
        print(f"✅ API call successful!")
        print(f"   Response: {response.choices[0].message.content}")
        print(f"   Model: {response.model}")
        print(f"   Usage: {response.usage.completion_tokens} completion tokens")
        
    except Exception as e:
        print(f"❌ API call failed: {e}")
        error_str = str(e).lower()
        
        print(f"\nError type: {type(e).__name__}")
        print(f"Error message: {str(e)[:200]}")
        
        if "max_tokens" in error_str and "unexpected" in error_str:
            print("\n💡 This model doesn't support 'max_tokens'")
            print("   The updated connector should handle this automatically")
            print("   Make sure you're using the NEW connector file")
            print("   (azure_openai_connector_COMPLETE.py)")
        elif "max_completion_tokens" in error_str and "unexpected" in error_str:
            print("\n💡 This model doesn't support 'max_completion_tokens'")
            print("   The updated connector should handle this automatically")
        elif "404" in error_str or "not found" in error_str:
            deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT')
            print(f"\n💡 Deployment '{deployment}' not found")
            print("   Check Azure Portal → OpenAI Resource → Model deployments")
        elif "401" in error_str or "unauthorized" in error_str:
            print("\n💡 API key is invalid")
            print("   Check: AZURE_OPENAI_API_KEY in .env file")
        elif "endpoint" in error_str:
            endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
            print(f"\n💡 Endpoint URL might be wrong: {endpoint}")
        
        return False
    
    # Step 8: Test connector fully
    print_step("8", "TESTING CONNECTOR")
    
    try:
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        
        print(f"Connector status:")
        print(f"   is_available: {connector.is_available}")
        print(f"   is_initialized: {connector.is_initialized}")
        print(f"   has_client: {connector._client is not None}")
        print(f"   auth_method: {connector._auth_method}")
        
        if connector._initialization_error:
            print(f"   initialization_error: {connector._initialization_error}")
        
        if not connector.is_available:
            print(f"\n❌ Connector NOT available!")
            return False
        
        print(f"\n✅ Connector is ready!")
        
        # Test connection method
        print(f"\nTesting connector.test_connection()...")
        test_result = connector.test_connection()
        
        if test_result['status'] == 'success':
            print(f"✅ Connection test passed!")
            print(f"   Model: {test_result.get('model')}")
            print(f"   Auth: {test_result.get('auth_method')}")
            if 'response' in test_result:
                print(f"   Response: {test_result['response'][:100]}...")
        else:
            print(f"❌ Connection test failed: {test_result.get('message')}")
            return False
        
    except Exception as e:
        print(f"❌ Connector test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Success!
    print_header("✅ ALL CHECKS PASSED - CONNECTOR READY!")
    
    print("\n✨ Your Azure OpenAI connector is fully updated and working!")
    print("\nKey features verified:")
    print("   ✅ Environment variables configured")
    print("   ✅ Model-aware parameter builder working")
    print("   ✅ Correct parameters for your deployment")
    print("   ✅ Azure OpenAI client connected")
    print("   ✅ API calls successful")
    print("   ✅ Connector fully operational")
    
    print("\nNext steps:")
    print("   1. Restart your Flask app: python app.py")
    print("   2. Open chat widget in browser")
    print("   3. Send a message - Azure OpenAI will respond")
    print("   4. Watch logs for '📋 Building params' confirmation")
    
    print("\nSupported models:")
    print("   • gpt-5-mini (NEW! - uses max_completion_tokens)")
    print("   • gpt-5 (NEW! - uses max_completion_tokens)")
    print("   • gpt-4o-mini")
    print("   • gpt-4o")
    print("   • gpt-4")
    print("   • gpt-4-turbo")
    print("   • gpt-35-turbo")
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n❌ Diagnostic interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)