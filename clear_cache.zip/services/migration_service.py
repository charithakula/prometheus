"""
Migration Service
Orchestrates the complete migration process to Azure APIM
Updated with safe connector initialization
"""
import json
import logging
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from enum import Enum

from .conversion_service import ConversionService
from .validation_service import ValidationService
from models.database import MigrationRecord

logger = logging.getLogger(__name__)

class MigrationStatus(Enum):
    """Migration status enumeration"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    EXTRACTING = "extracting"
    CONVERTING = "converting"
    DEPLOYING = "deploying"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"

class MigrationService:
    """Service for orchestrating API migrations"""
    
    def __init__(self):
        """Initialize migration service with all required connectors"""
        # Initialize connectors safely
        self.azure_apim_connector = self._safe_init_connector('AzureAPIMConnector')
        self.azure_openai_connector = self._safe_init_connector('AzureOpenAIConnector')
        
        # Always initialize these services
        self.conversion_service = ConversionService()
        self.validation_service = ValidationService()
    
    def _safe_init_connector(self, connector_name: str):
        """Safely initialize a connector, returning None if it fails"""
        try:
            if connector_name == 'AzureAPIMConnector':
                from connectors import AzureAPIMConnector
                return AzureAPIMConnector()
            elif connector_name == 'AzureOpenAIConnector':
                from connectors import AzureOpenAIConnector
                return AzureOpenAIConnector()
        except Exception as e:
            logger.warning(f"Failed to initialize {connector_name}: {e}")
            return None
    
    def migrate_single_api(self, api_id: str, org_name: Optional[str] = None, 
                          options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Migrate a single API to Azure APIM
        
        Args:
            api_id: API ID
            org_name: Organization name
            options: Migration options
            
        Returns:
            Migration result
        """
        migration_start = datetime.now()
        migration_id = f"migration_{api_id}_{int(migration_start.timestamp())}"
        
        logger.info(f"Starting migration for API: {api_id}")
        
        try:
            # Initialize migration record
            migration_record = self._create_migration_record(
                migration_id, api_id, MigrationStatus.IN_PROGRESS
            )
            
            # Step 1: Extract API specification
            migration_record.status = MigrationStatus.EXTRACTING
            extraction_result = self._extract_api_specification(api_id, org_name)
            
            if extraction_result['status'] == 'error':
                return self._handle_migration_failure(migration_record, "extraction", extraction_result['message'])
            
            original_spec = extraction_result['data']['specification']
            api_info = extraction_result['data']['api_info']
            
            # Step 2: Convert OpenAPI 2.0 to 3.0
            migration_record.status = MigrationStatus.CONVERTING
            conversion_result = self.conversion_service.convert_specification(
                json.dumps(original_spec)
            )
            
            if conversion_result['status'] == 'error':
                return self._handle_migration_failure(migration_record, "conversion", conversion_result['message'])
            
            converted_spec = conversion_result['converted_spec']
            
            # Step 3: Deploy to Azure APIM
            migration_record.status = MigrationStatus.DEPLOYING
            deployment_result = self._deploy_to_azure_apim(
                converted_spec, api_id, options or {}
            )
            
            if deployment_result['status'] == 'error':
                return self._handle_migration_failure(migration_record, "deployment", deployment_result['message'])
            
            # Step 4: Complete migration
            migration_time = (datetime.now() - migration_start).total_seconds()
            migration_record.status = MigrationStatus.COMPLETED
            migration_record.completion_time = migration_time
            
            # Prepare success response
            result = {
                'status': 'success',
                'migration_id': migration_id,
                'api_id': api_id,
                'original_api_info': api_info,
                'converted_spec_preview': self._get_spec_preview(converted_spec),
                'azure_deployment': deployment_result,
                'migration_time_seconds': migration_time,
                'conversion_metadata': conversion_result.get('conversion_metadata', {}),
                'validation_results': {
                    'original_validation': conversion_result.get('validation', {}).get('original_validation', {}),
                    'converted_validation': conversion_result.get('validation', {}).get('converted_validation', {})
                },
                'message': f'API {api_id} migrated successfully to Azure APIM'
            }
            
            # Save migration record
            self._save_migration_record(migration_record, result)
            
            logger.info(f"Migration completed successfully for API: {api_id} in {migration_time:.2f} seconds")
            return result
            
        except Exception as e:
            logger.error(f"Migration failed for API {api_id}: {e}")
            return self._handle_migration_failure(
                migration_record if 'migration_record' in locals() else None,
                "general", str(e)
            )
    
    def migrate_multiple_apis(self, api_ids: List[str], org_name: Optional[str] = None,
                             options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Migrate multiple APIs in batch
        
        Args:
            api_ids: List of API IDs
            org_name: Organization name
            options: Migration options
            
        Returns:
            Batch migration results
        """
        batch_start = datetime.now()
        batch_id = f"batch_{int(batch_start.timestamp())}"
        
        logger.info(f"Starting batch migration for {len(api_ids)} APIs")
        
        results = []
        successful_migrations = 0
        failed_migrations = 0
        
        for i, api_id in enumerate(api_ids):
            logger.info(f"Migrating API {i+1}/{len(api_ids)}: {api_id}")
            
            # Migrate individual API
            migration_result = self.migrate_single_api(api_id, org_name, options)
            migration_result['batch_index'] = i + 1
            migration_result['batch_id'] = batch_id
            
            results.append(migration_result)
            
            if migration_result['status'] == 'success':
                successful_migrations += 1
            else:
                failed_migrations += 1
        
        batch_time = (datetime.now() - batch_start).total_seconds()
        
        return {
            'status': 'completed',
            'batch_id': batch_id,
            'total_apis': len(api_ids),
            'successful_migrations': successful_migrations,
            'failed_migrations': failed_migrations,
            'batch_time_seconds': batch_time,
            'average_time_per_migration': batch_time / len(api_ids) if api_ids else 0,
            'results': results,
            'summary': f"Migrated {successful_migrations}/{len(api_ids)} APIs successfully"
        }
    
    def _extract_api_specification(self, api_id: str, org_name: Optional[str] = None) -> Dict[str, Any]:
        """Extract API specification from source"""
        try:
            # This would be implemented to extract from your API source
            # For now, return placeholder
            return {
                'status': 'success',
                'data': {
                    'specification': {},
                    'api_info': {
                        'title': f'API {api_id}',
                        'version': '1.0.0'
                    }
                }
            }
        except Exception as e:
            logger.error(f"Failed to extract API specification: {e}")
            return {
                'status': 'error',
                'message': f'Failed to extract API: {str(e)}'
            }
    
    def _deploy_to_azure_apim(self, converted_spec: Dict[str, Any], 
                             original_api_id: str, options: Dict[str, Any]) -> Dict[str, Any]:
        """Deploy converted API to Azure APIM"""
        try:
            if not self.azure_apim_connector:
                return {
                    'status': 'error',
                    'message': 'Azure APIM connector not available'
                }
            
            if not self.azure_apim_connector.is_available:
                return {
                    'status': 'error',
                    'message': 'Azure APIM connector not configured or connected'
                }
            
            # Generate Azure API ID
            azure_api_id = options.get('azure_api_id') or self._generate_azure_api_id(converted_spec, original_api_id)
            
            # Create API in Azure APIM
            deployment_result = self.azure_apim_connector.create_api_from_openapi(
                converted_spec, azure_api_id
            )
            
            if deployment_result['status'] == 'error':
                return deployment_result
            
            # Optionally create product
            if options.get('create_product'):
                product_name = options.get('product_name') or f"Product for {azure_api_id}"
                product_result = self.azure_apim_connector.create_product(
                    product_name, [azure_api_id], options.get('product_description', '')
                )
                deployment_result['product'] = product_result
            
            # Add management URLs
            deployment_result['management_url'] = self.azure_apim_connector.get_api_management_url(azure_api_id)
            deployment_result['developer_portal_url'] = self.azure_apim_connector.get_developer_portal_url()
            
            logger.info(f"Successfully deployed API {azure_api_id} to Azure APIM")
            return deployment_result
            
        except Exception as e:
            logger.error(f"Failed to deploy API to Azure APIM: {e}")
            return {
                'status': 'error',
                'message': f'Failed to deploy to Azure APIM: {str(e)}'
            }
    
    def _create_migration_record(self, migration_id: str, api_id: str, 
                               status: MigrationStatus) -> MigrationRecord:
        """Create a migration record for tracking"""
        return MigrationRecord(
            migration_id=migration_id,
            original_api_id=api_id,
            status=status.value,
            start_time=datetime.now(),
            source_platform='file_upload',
            target_platform='azure_apim'
        )
    
    def _handle_migration_failure(self, migration_record: Optional[MigrationRecord],
                                 stage: str, error_message: str) -> Dict[str, Any]:
        """Handle migration failure"""
        if migration_record:
            migration_record.status = MigrationStatus.FAILED.value
            migration_record.error_message = f"{stage} failed: {error_message}"
            
        logger.error(f"Migration failed at {stage}: {error_message}")
        
        return {
            'status': 'error',
            'stage': stage,
            'message': error_message,
            'migration_id': migration_record.migration_id if migration_record else None
        }
    
    def _generate_azure_api_id(self, spec: Dict[str, Any], original_id: str) -> str:
        """Generate Azure API ID from spec or original ID"""
        info = spec.get('info', {})
        title = info.get('title', original_id)
        
        # Clean up title for API ID
        api_id = title.lower().replace(' ', '-').replace('_', '-')
        api_id = ''.join(c for c in api_id if c.isalnum() or c == '-')
        
        return api_id[:50]  # Limit length
    
    def _get_spec_preview(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """Get preview information from OpenAPI spec"""
        info = spec.get('info', {})
        paths = spec.get('paths', {})
        
        return {
            'title': info.get('title', 'Unknown API'),
            'version': info.get('version', 'Unknown'),
            'description': info.get('description', ''),
            'paths_count': len(paths),
            'servers': spec.get('servers', []),
            'has_security': bool(spec.get('security') or spec.get('components', {}).get('securitySchemes'))
        }
    
    def _save_migration_record(self, migration_record: MigrationRecord, result: Dict[str, Any]):
        """Save migration record to database"""
        try:
            # Update record with final details
            migration_record.azure_api_id = result.get('azure_deployment', {}).get('api_id')
            migration_record.api_name = result.get('converted_spec_preview', {}).get('title')
            migration_record.api_version = result.get('converted_spec_preview', {}).get('version')
            migration_record.completion_time = result.get('migration_time_seconds', 0)
            migration_record.conversion_notes = json.dumps({
                'conversion_metadata': result.get('conversion_metadata', {}),
                'validation_results': result.get('validation_results', {})
            })
            
            # In a real application, you would save to database here
            # For now, we'll just log the record
            logger.info(f"Migration record: {migration_record.__dict__}")
            
        except Exception as e:
            logger.error(f"Failed to save migration record: {e}")
    
    def get_migration_status(self, migration_id: str) -> Dict[str, Any]:
        """Get status of a specific migration"""
        # In a real application, retrieve from database
        # For now, return a placeholder
        return {
            'migration_id': migration_id,
            'status': 'completed',
            'message': 'Migration status would be retrieved from database'
        }
    
    def list_migrations(self, limit: int = 50, offset: int = 0) -> Dict[str, Any]:
        """List recent migrations"""
        # In a real application, retrieve from database
        # For now, return a placeholder
        return {
            'migrations': [],
            'total_count': 0,
            'limit': limit,
            'offset': offset
        }
    
    def rollback_migration(self, migration_id: str) -> Dict[str, Any]:
        """Rollback a completed migration"""
        try:
            # In a real implementation:
            # 1. Get migration details from database
            # 2. Delete API from Azure APIM
            # 3. Update migration status to rolled back
            
            logger.info(f"Rolling back migration: {migration_id}")
            
            return {
                'status': 'success',
                'migration_id': migration_id,
                'message': 'Migration rolled back successfully'
            }
            
        except Exception as e:
            logger.error(f"Failed to rollback migration {migration_id}: {e}")
            return {
                'status': 'error',
                'message': f'Rollback failed: {str(e)}'
            }
    
    def validate_migration_prerequisites(self) -> Dict[str, Any]:
        """Validate that all required services are available for migration"""
        validation_results = {}
        
        if self.azure_apim_connector:
            validation_results['azure_apim'] = self.azure_apim_connector.test_connection()
        else:
            validation_results['azure_apim'] = {
                'status': 'error',
                'message': 'Azure APIM connector not initialized'
            }
        
        if self.azure_openai_connector:
            validation_results['azure_openai'] = self.azure_openai_connector.test_connection()
        else:
            validation_results['azure_openai'] = {
                'status': 'error',
                'message': 'Azure OpenAI connector not initialized'
            }
        
        all_services_available = all(
            result['status'] == 'success' 
            for result in validation_results.values()
        )
        
        return {
            'all_services_available': all_services_available,
            'service_status': validation_results,
            'can_migrate': all_services_available,
            'recommendations': self._get_service_recommendations(validation_results)
        }
    
    def _get_service_recommendations(self, validation_results: Dict[str, Any]) -> List[str]:
        """Get recommendations based on service validation results"""
        recommendations = []
        
        for service, result in validation_results.items():
            if result['status'] != 'success':
                recommendations.append(f"Fix {service} connection: {result.get('message', 'Unknown error')}")
        
        if not recommendations:
            recommendations.append("All services are available. Ready to migrate APIs.")
        
        return recommendations
    
    def get_migration_statistics(self) -> Dict[str, Any]:
        """Get overall migration statistics"""
        # In a real application, calculate from database
        return {
            'total_migrations': 0,
            'successful_migrations': 0,
            'failed_migrations': 0,
            'total_apis_migrated': 0,
            'average_migration_time': 0,
            'most_recent_migration': None,
            'migration_success_rate': 0
        }