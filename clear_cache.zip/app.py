"""
Main Flask Application - COMPLETE UPDATED VERSION WITH AZURE OPENAI MODEL-AWARE PARAMETERS + PROMPTS.PY
Entry point for the API Migration Tool
✅ ALL Azure OpenAI calls now use _build_chat_completion_params() for full model support
✅ INCLUDES ALL original routes, functions, and features
✅ INTEGRATES prompts.py FOR LLM PROMPTS
✅ PRODUCTION READY
"""
import os
import json
import re
import time
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_file, session
from flask_cors import CORS
from werkzeug.exceptions import RequestEntityTooLarge
from datetime import datetime, timedelta
import logging
import traceback
from typing import Optional, Dict, Any
from functools import wraps
from werkzeug.utils import secure_filename
from io import BytesIO

# ==========================================
# IMPORT CENTRALIZED PROMPTS (NEW)
# ==========================================
try:
    from enhanced_prompts import (
        UniversalPromptBuilder,
        ASSISTANT_TYPES,
        SYSTEM_PROMPTS,
        CHAT_CONFIG,
        detect_assistant_type,
        CODE_GENERATION_PROMPTS,
        API_ANALYSIS_PROMPTS,
        SECURITY_PROMPTS,
        POLICY_ANALYSIS_PROMPTS,
        DOCUMENTATION_PROMPTS
    )
    PROMPTS_AVAILABLE = True
    logger_startup = logging.getLogger(__name__)
    logger_startup.info("✅ enhanced_prompts loaded successfully")
except ImportError as e:
    PROMPTS_AVAILABLE = False
    logger_startup = logging.getLogger(__name__)
    logger_startup.warning(f"⚠️  enhanced_prompts not found: {e} - will use fallback responses")

# Configure logging
logger = logging.getLogger(__name__)

# Enhanced database error handling imports
from sqlalchemy.exc import OperationalError, DatabaseError, SQLAlchemyError
from sqlalchemy import text

# Import configuration
from config import get_config, validate_all_configurations, get_missing_configurations

# Import database - UPDATED WITH ACTUAL MODELS
from models.database import db, MigrationRecord, APISpecification, MigrationLog

# Import services
from services import ConversionService, MigrationService, ValidationService

# Import connectors
from connectors import AzureAPIMConnector, AzureOpenAIConnector

# Import utilities - UPDATED IMPORTS
from utils import setup_logger, generate_id
from utils.enhanced_file_handler_with_azure import EnhancedFileHandler

# Import authentication module
from auth import configure_session, register_auth_routes, login_required

# Updated schemas for validation with OpenAI support
from pydantic import BaseModel, Field
from typing import Optional

class ConversionRequestSchema(BaseModel):
    """Schema for API conversion requests with OpenAI response support"""
    spec_content: str = Field(..., description="OpenAPI specification content")
    source_format: Optional[str] = Field(default='auto', description="Source format (auto, json, yaml)")
    include_debug: Optional[bool] = Field(default=False, description="Include debug information in response")

class MigrationRequestSchema(BaseModel):
    """Schema for migration requests"""
    api_ids: list = Field(..., description="List of API IDs to migrate")
    org_name: str = Field(..., description="Organization name")
    options: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Migration options")

class BatchMigrationRequestSchema(BaseModel):
    """Schema for batch migration requests"""
    migration_type: str = Field(..., description="Type of migration (apis, catalog)")
    api_ids: Optional[list] = Field(default=None, description="List of API IDs")
    org_name: str = Field(..., description="Organization name")
    catalog_name: Optional[str] = Field(default=None, description="Catalog name for catalog migration")
    options: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Migration options")


def create_app():
    """Application factory pattern for Flask 3.x with enhanced database error handling, authentication, and storage health check"""
    
    # ==========================================
    # HELPER FUNCTIONS - MOVED TO TOP
    # ==========================================
    
    def initialize_database_safely(app, logger):
        """Initialize database with comprehensive error handling"""
        try:
            connection_status = test_database_connection()
            
            if connection_status['status'] == 'success':
                if connection_status['details']['tables_exist']:
                    logger.info("Database tables already exist")
                    return {'status': 'success', 'message': 'Database ready'}
                else:
                    logger.info("Database connected but tables missing - will create on demand")
                    return {'status': 'partial', 'message': 'Database connected, tables need initialization'}
            else:
                logger.warning(f"Database connection failed: {connection_status['message']}")
                return {
                    'status': 'error', 
                    'message': connection_status['message'],
                    'details': connection_status.get('details', {})
                }
                
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            return {'status': 'error', 'message': str(e)}

    def test_database_connection():
        """Test database connection and return detailed status with proper error handling"""
        try:
            config = get_config()
            db_type = 'sqlite' if 'sqlite' in config.DATABASE_URL else 'postgresql'
            db_name = 'migrations.db' if db_type == 'sqlite' else config.DATABASE_URL.split('/')[-1]
            
            try:
                result = db.session.execute(text('SELECT 1')).fetchone()
                if result is None:
                    raise Exception("Query returned no results")
                
                db.session.commit()
                tables_exist = check_tables_exist()
                
                return {
                    'status': 'success',
                    'message': f'{db_type.title()} database connected successfully',
                    'details': {
                        'database_type': db_type,
                        'database_name': db_name,
                        'tables_exist': tables_exist,
                        'connection_healthy': True
                    }
                }
                
            except OperationalError as e:
                error_msg = str(e)
                if 'does not exist' in error_msg.lower():
                    return {
                        'status': 'error',
                        'message': f'Database "{db_name}" does not exist',
                        'details': {
                            'database_type': db_type,
                            'database_name': db_name,
                            'tables_exist': False,
                            'connection_healthy': False,
                            'error_type': 'database_not_found'
                        }
                    }
                elif 'connection' in error_msg.lower():
                    return {
                        'status': 'error',
                        'message': f'Cannot connect to {db_type} database',
                        'details': {
                            'database_type': db_type,
                            'database_name': db_name,
                            'tables_exist': False,
                            'connection_healthy': False,
                            'error_type': 'connection_failed'
                        }
                    }
                else:
                    return {
                        'status': 'error',
                        'message': f'Database error: {str(e)[:100]}...' if len(str(e)) > 100 else str(e),
                        'details': {
                            'database_type': db_type,
                            'database_name': db_name,
                            'tables_exist': False,
                            'connection_healthy': False,
                            'error_type': 'operational_error'
                        }
                    }
                    
        except Exception as e:
            logger.error(f"Database connection test failed with unexpected error: {e}")
            logger.error(f"Database error traceback: {traceback.format_exc()}")
            
            return {
                'status': 'error',
                'message': 'Database service unavailable',
                'details': {
                    'database_type': 'unknown',
                    'database_name': 'unknown',
                    'tables_exist': False,
                    'connection_healthy': False,
                    'error_type': 'service_unavailable',
                    'error_details': str(e)[:200] if str(e) else 'Unknown error'
                }
            }

    def check_tables_exist():
        """Check if required tables exist with proper error handling"""
        try:
            MigrationRecord.query.limit(1).all()
            APISpecification.query.limit(1).all()
            MigrationLog.query.limit(1).all()
            return True
        except (OperationalError, DatabaseError, SQLAlchemyError) as e:
            logger.warning(f"Database tables check failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error checking tables: {e}")
            return False

    def check_storage_availability():
        """Check Azure Storage availability and provide status"""
        try:
            if not file_handler.use_azure:
                logger.warning("⚠️  Azure Storage NOT configured - will use local filesystem")
                return {
                    'available': False,
                    'reason': 'Azure Storage credentials not set',
                    'using': 'local_filesystem',
                    'env_vars_needed': [
                        'AZURE_STORAGE_CONNECTION_STRING',
                        'OR: AZURE_STORAGE_ACCOUNT_NAME + AZURE_STORAGE_ACCOUNT_KEY'
                    ]
                }
            
            stats = file_handler.azure_storage.get_storage_stats()
            
            logger.info("✅ Azure Blob Storage is AVAILABLE and CONFIGURED")
            logger.info(f"   Account: {file_handler.azure_storage.account_name}")
            logger.info(f"   Container: {file_handler.azure_storage.container_name}")
            
            return {
                'available': True,
                'reason': 'Connected successfully',
                'using': 'azure_blob_storage',
                'account': file_handler.azure_storage.account_name,
                'container': file_handler.azure_storage.container_name,
                'stats': stats
            }
        except Exception as e:
            logger.warning(f"⚠️  Azure Storage connection check failed: {e}")
            logger.warning("   Falling back to local filesystem for file storage")
            return {
                'available': False,
                'reason': str(e),
                'using': 'local_filesystem_fallback',
                'error': str(e)
            }

    def get_database_statistics_safe():
        """Get overall database statistics with fallback for unavailable database"""
        try:
            try:
                migration_stats = MigrationRecord.get_statistics()
            except Exception as e:
                logger.warning(f"Failed to get migration statistics: {e}")
                migration_stats = {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                }
            
            try:
                total_specs = APISpecification.query.count()
                valid_specs = APISpecification.query.filter_by(is_valid=True).count()
            except Exception as e:
                logger.warning(f"Failed to get API specification statistics: {e}")
                total_specs = 0
                valid_specs = 0
            
            return {
                'migrations': migration_stats,
                'api_specifications': {
                    'total_specifications': total_specs,
                    'valid_specifications': valid_specs,
                    'invalid_specifications': total_specs - valid_specs
                },
                'database_available': True
            }
            
        except Exception as e:
            logger.error(f"Failed to get database statistics: {e}")
            return {
                'migrations': {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                },
                'api_specifications': {
                    'total_specifications': 0,
                    'valid_specifications': 0,
                    'invalid_specifications': 0
                },
                'database_available': False,
                'error': str(e)
            }

    def get_database_health():
        """Get database health information with error handling"""
        try:
            health_info = {
                'record_counts': {
                    'migrations': 0,
                    'api_specifications': 0,
                    'logs': 0
                },
                'last_migration': None,
                'database_size': None
            }
            
            try:
                health_info['record_counts']['migrations'] = MigrationRecord.query.count()
            except Exception as e:
                logger.warning(f"Failed to count migration records: {e}")
            
            try:
                health_info['record_counts']['api_specifications'] = APISpecification.query.count()
            except Exception as e:
                logger.warning(f"Failed to count API specification records: {e}")
            
            try:
                health_info['record_counts']['logs'] = MigrationLog.query.count()
            except Exception as e:
                logger.warning(f"Failed to count log records: {e}")
            
            try:
                last_migration = MigrationRecord.query.order_by(
                    MigrationRecord.created_at.desc()
                ).first()
                
                if last_migration:
                    health_info['last_migration'] = {
                        'id': last_migration.migration_id,
                        'created_at': last_migration.created_at.isoformat(),
                        'status': last_migration.status
                    }
            except Exception as e:
                logger.warning(f"Failed to get last migration: {e}")
            
            return health_info
            
        except Exception as e:
            logger.warning(f"Failed to get database health: {e}")
            return {
                'record_counts': {'migrations': 0, 'api_specifications': 0, 'logs': 0},
                'error': str(e)
            }

    def create_migration_record_safe(migration_record_data):
        """Safely create migration record with fallback"""
        try:
            migration_record = MigrationRecord(**migration_record_data)
            db.session.add(migration_record)
            db.session.commit()
            logger.info(f"Created migration record with ID: {migration_record.migration_id}")
            return migration_record
        except Exception as e:
            logger.warning(f"Failed to create migration record: {e}")
            db.session.rollback()
            return None

    def update_migration_record_safe(migration_record, **updates):
        """Safely update migration record with fallback"""
        try:
            for key, value in updates.items():
                if hasattr(migration_record, key):
                    setattr(migration_record, key, value)
            migration_record.updated_at = datetime.now()
            db.session.commit()
            return True
        except Exception as e:
            logger.warning(f"Failed to update migration record: {e}")
            db.session.rollback()
            return False

    def _generate_api_id_from_spec(spec: dict, fallback: str) -> str:
        """Generate API ID from OpenAPI spec or use fallback"""
        try:
            info = spec.get('info', {})
            title = info.get('title', fallback)
            
            api_id = re.sub(r'[^a-zA-Z0-9\-_]', '-', title.lower())
            api_id = re.sub(r'-+', '-', api_id)
            api_id = api_id.strip('-_')
            
            if not api_id:
                api_id = fallback
            
            timestamp = str(int(time.time()))[-6:]
            api_id = f"{api_id}-{timestamp}"
            
            return api_id[:50]
        except Exception:
            return fallback

    def extract_api_info(spec: dict) -> dict:
        """Extract API information from OpenAPI specification"""
        try:
            info = spec.get('info', {})
            return {
                'title': info.get('title', 'Unknown API'),
                'version': info.get('version', '1.0.0'),
                'description': info.get('description', ''),
                'format': spec.get('swagger', spec.get('openapi', 'Unknown')),
                'paths_count': len(spec.get('paths', {})),
                'definitions_count': len(spec.get('definitions', spec.get('components', {}).get('schemas', {}))),
                'operations_count': sum(
                    len([op for op in path_item.values() if isinstance(op, dict) and op.get('responses')])
                    for path_item in spec.get('paths', {}).values()
                    if isinstance(path_item, dict)
                )
            }
        except Exception as e:
            logger.warning(f"Failed to extract API info: {e}")
            return {
                'title': 'Unknown API',
                'version': '1.0.0',
                'description': '',
                'format': 'Unknown',
                'paths_count': 0,
                'definitions_count': 0,
                'operations_count': 0
            }

    def format_file_size(bytes_size):
        """Format file size in human readable format"""
        if bytes_size == 0:
            return '0 B'
        k = 1024
        sizes = ['B', 'KB', 'MB', 'GB']
        i = int(((bytes_size.bit_length() - 1) / 10)) if bytes_size > 0 else 0
        return f"{bytes_size / (k ** i):.1f} {sizes[min(i, len(sizes) - 1)]}"

    def format_file_size_local(size_bytes):
        """Convert bytes to human readable format"""
        for unit in ['B', 'KB', 'MB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} GB"


    # ==========================================
    # MAIN APP INITIALIZATION
    # ==========================================
    
    # Initialize Flask app
    app = Flask(__name__)

    # Load configuration
    config = get_config()
    app.config.from_object(config)

    # Configure session for authentication
    configure_session(app)

    # Initialize extensions
    CORS(app)
    db.init_app(app)

    # ==========================================
    # ADD PYTHON BUILT-INS TO JINJA2 ENVIRONMENT
    # ==========================================
    app.jinja_env.globals.update({
        'min': min,
        'max': max,
        'len': len,
        'abs': abs,
        'round': round,
        'int': int,
        'float': float,
        'str': str,
        'bool': bool,
        'sum': sum,
        'sorted': sorted,
        'enumerate': enumerate,
        'zip': zip,
        'range': range
    })

    # Initialize logging
    logger = setup_logger('app')

    # Global variables for tracking
    app_start_time = datetime.now()

    # Initialize services
    conversion_service = ConversionService()
    migration_service = MigrationService()
    validation_service = ValidationService()

    # Initialize enhanced file handler
    file_handler = EnhancedFileHandler()

    # Initialize application within app context with enhanced error handling
    with app.app_context():
        try:
            database_status = initialize_database_safely(app, logger)
            storage_status = check_storage_availability()
            
            missing_configs = get_missing_configurations()
            if missing_configs:
                logger.warning(f"Missing configurations: {missing_configs}")
            
            logger.info(f"Application initialized successfully")
            logger.info(f"  Database status: {database_status['status']}")
            logger.info(f"  Storage status: {storage_status['using']}")
            
        except Exception as e:
            logger.error(f"Failed to initialize application: {e}")
            logger.error(f"Initialization traceback: {traceback.format_exc()}")

    # ==========================================
    # REGISTER AUTHENTICATION ROUTES
    # ==========================================
    register_auth_routes(app)

    # ==========================================
    # ERROR HANDLERS
    # ==========================================

    @app.errorhandler(404)
    def not_found_error(error):
        """Handle 404 errors"""
        if request.is_json:
            return jsonify({'error': 'Resource not found'}), 404
        return '''
        <html>
        <head><title>404 - Page Not Found</title></head>
        <body>
        <h1>404 - Page Not Found</h1>
        <p>The page you are looking for could not be found.</p>
        <a href="/">Go back to home</a>
        </body>
        </html>
        ''', 404

    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors"""
        logger.error(f"Internal server error: {error}")
        if request.is_json:
            return jsonify({'error': 'Internal server error'}), 500
        return '''
        <html>
        <head><title>500 - Internal Server Error</title></head>
        <body>
        <h1>500 - Internal Server Error</h1>
        <p>Something went wrong on our end.</p>
        <a href="/">Go back to home</a>
        </body>
        </html>
        ''', 500

    @app.errorhandler(RequestEntityTooLarge)
    def file_too_large(error):
        """Handle file too large errors"""
        if request.is_json:
            return jsonify({'error': 'File too large', 'max_size': '16MB'}), 413
        flash('File is too large. Maximum size is 16MB.', 'error')
        return redirect(url_for('upload_page'))

    # ==========================================
    # MAIN ROUTES - PROTECTED WITH AUTHENTICATION
    # ==========================================

    @app.route('/')
    @login_required
    def index():
        """Main dashboard page with enhanced database error handling"""
        try:
            db_stats = get_database_statistics_safe()
            
            try:
                prerequisites = migration_service.validate_migration_prerequisites()
            except Exception as e:
                logger.warning(f"Failed to validate prerequisites: {e}")
                prerequisites = {
                    'all_services_available': False,
                    'service_status': {},
                    'can_migrate': False,
                    'recommendations': ['Check system configuration']
                }
            
            try:
                storage_stats = file_handler.get_storage_stats()
            except Exception as e:
                logger.warning(f"Failed to get storage stats: {e}")
                storage_stats = {'totals': {}}
            
            recent_migrations = []
            if db_stats.get('database_available', False):
                try:
                    recent_migration_records = MigrationRecord.query.order_by(
                        MigrationRecord.created_at.desc()
                    ).limit(5).all()
                    recent_migrations = [m.to_dict() for m in recent_migration_records]
                except Exception as e:
                    logger.warning(f"Failed to load recent migrations: {e}")
                    recent_migrations = []
            
            return render_template('index.html', 
                                 stats=db_stats,
                                 prerequisites=prerequisites,
                                 recent_migrations=recent_migrations,
                                 storage_stats=storage_stats.get('totals', {}))
            
        except Exception as e:
            logger.error(f"Failed to load dashboard: {e}")
            fallback_stats = {
                'migrations': {'total_migrations': 0, 'successful_migrations': 0, 'failed_migrations': 0, 'in_progress_migrations': 0},
                'api_specifications': {'total_specifications': 0, 'valid_specifications': 0, 'invalid_specifications': 0},
                'database_available': False
            }
            fallback_prerequisites = {
                'all_services_available': False,
                'service_status': {'database': {'status': 'error', 'message': 'Database service unavailable'}},
                'can_migrate': False,
                'recommendations': ['Database service needs attention']
            }
            
            flash('Dashboard loaded with limited functionality due to database issues', 'warning')
            return render_template('index.html', 
                                 stats=fallback_stats,
                                 prerequisites=fallback_prerequisites,
                                 recent_migrations=[],
                                 storage_stats={})

    @app.route('/upload')
    @login_required
    def upload_page():
        """File upload page"""
        try:
            storage_stats = file_handler.get_storage_stats()
            return render_template('upload.html', storage_stats=storage_stats.get('totals', {}))
        except Exception as e:
            logger.error(f"Failed to load upload page: {e}")
            return render_template('upload.html', storage_stats={})

    @app.route('/history')
    @login_required
    def migration_history():
        """Migration history page with database fallback"""
        try:
            db_status = test_database_connection()
            
            if db_status['status'] != 'success':
                flash(f'Database unavailable: {db_status["message"]}', 'error')
                return render_template('migration_history.html', 
                                     migrations=[], 
                                     pagination={'page': 1, 'per_page': 20, 'total': 0, 'pages': 0, 'has_prev': False, 'has_next': False},
                                     current_filters={},
                                     database_error=db_status)
            
            page = request.args.get('page', 1, type=int)
            per_page = request.args.get('per_page', 20, type=int)
            if per_page > 100:
                per_page = 100
            
            status_filter = request.args.get('status', '')
            search_query = request.args.get('search', '')
            date_range = request.args.get('date_range') or request.args.get('dateRange', '')
            sort_by = request.args.get('sort_by') or request.args.get('sortBy', 'created_at_desc')
            
            try:
                query = MigrationRecord.query
                
                if status_filter:
                    query = query.filter(MigrationRecord.status == status_filter)
                
                if search_query:
                    search_pattern = f"%{search_query}%"
                    query = query.filter(
                        db.or_(
                            MigrationRecord.api_name.ilike(search_pattern),
                            MigrationRecord.migration_id.ilike(search_pattern),
                            MigrationRecord.original_api_id.ilike(search_pattern)
                        )
                    )
                
                if date_range:
                    now = datetime.now()
                    
                    if date_range == 'today':
                        start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                    elif date_range == 'week':
                        start_date = now - timedelta(days=7)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                    elif date_range == 'month':
                        start_date = now - timedelta(days=30)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                    elif date_range == 'quarter':
                        start_date = now - timedelta(days=90)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                
                if sort_by == 'created_at_desc':
                    query = query.order_by(MigrationRecord.created_at.desc())
                elif sort_by == 'created_at_asc':
                    query = query.order_by(MigrationRecord.created_at.asc())
                elif sort_by == 'api_name_asc':
                    query = query.order_by(MigrationRecord.api_name.asc())
                elif sort_by == 'api_name_desc':
                    query = query.order_by(MigrationRecord.api_name.desc())
                elif sort_by == 'duration_desc':
                    query = query.order_by(MigrationRecord.completion_time.desc().nullslast())
                elif sort_by == 'duration_asc':
                    query = query.order_by(MigrationRecord.completion_time.asc().nullslast())
                
                total_migrations = query.count()
                offset = (page - 1) * per_page
                migrations = query.offset(offset).limit(per_page).all()
                
                migration_dicts = []
                for migration in migrations:
                    migration_dict = migration.to_dict()
                    migration_dict['source_platform'] = migration_dict.get('source_platform', 'ibm_api_connect').replace('_', ' ').title()
                    migration_dict['target_platform'] = migration_dict.get('target_platform', 'azure_apim').replace('_', ' ').title()
                    migration_dicts.append(migration_dict)
                
                total_pages = (total_migrations + per_page - 1) // per_page
                
                pagination = {
                    'page': page,
                    'per_page': per_page,
                    'total': total_migrations,
                    'pages': total_pages,
                    'has_prev': page > 1,
                    'has_next': page < total_pages,
                    'prev_num': page - 1 if page > 1 else None,
                    'next_num': page + 1 if page < total_pages else None
                }
                
                current_filters = {
                    'status': status_filter,
                    'search': search_query,
                    'date_range': date_range,
                    'sort_by': sort_by
                }
                
                return render_template('migration_history.html', 
                                     migrations=migration_dicts, 
                                     pagination=pagination,
                                     current_filters=current_filters)
                
            except Exception as query_error:
                logger.error(f"Database query failed in migration history: {query_error}")
                logger.error(f"Query error traceback: {traceback.format_exc()}")
                flash(f'Failed to load migration history: {str(query_error)}', 'error')
                return render_template('migration_history.html', 
                                     migrations=[], 
                                     pagination={'page': 1, 'per_page': 20, 'total': 0, 'pages': 0, 'has_prev': False, 'has_next': False},
                                     current_filters={},
                                     database_error={'status': 'error', 'message': f'Database query failed: {str(query_error)}'})
                
        except Exception as e:
            logger.error(f"Failed to load migration history: {e}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            flash(f'Migration history unavailable: {str(e)}', 'error')
            return render_template('migration_history.html', 
                                 migrations=[], 
                                 pagination={'page': 1, 'per_page': 20, 'total': 0, 'pages': 0, 'has_prev': False, 'has_next': False},
                                 current_filters={},
                                 database_error={'status': 'error', 'message': f'System error: {str(e)}'})

    @app.route('/converter')
    @login_required
    def yaml_converter():
        """YAML to JSON converter page"""
        return render_template('yaml_converter.html',
                            app_version='1.0.0',
                            current_year=datetime.now().year)

    # ==========================================
    # API ENDPOINTS - OPTIONALLY PROTECTED
    # ==========================================

    @app.route('/health')
    def health():
        """Azure App Services Health Check"""
        try:
            db.session.execute(text('SELECT 1')).fetchone()
            return {'status': 'ok'}, 200
        except Exception as e:
            logger.error(f"Health check error: {e}")
            return {'status': 'unhealthy'}, 503

    @app.route('/api/health')
    def health_check():
        """Health check endpoint with database and storage status"""
        uptime = (datetime.now() - app_start_time).total_seconds()
        
        service_status = {
            'azure_apim': AzureAPIMConnector().test_connection(),
            'azure_openai': AzureOpenAIConnector().test_connection(),
            'database': test_database_connection()
        }
        
        try:
            if file_handler.use_azure:
                service_status['storage'] = {
                    'status': 'success',
                    'message': f"Azure Blob Storage connected: {file_handler.azure_storage.account_name}",
                    'storage_type': 'azure'
                }
            else:
                service_status['storage'] = {
                    'status': 'degraded',
                    'message': 'Using local filesystem fallback',
                    'storage_type': 'local'
                }
        except Exception as e:
            service_status['storage'] = {
                'status': 'error',
                'message': f'Storage check failed: {str(e)}',
                'storage_type': 'unknown'
            }
        
        all_services_healthy = all(
            status.get('status') == 'success' 
            for status in service_status.values()
        )
        
        return jsonify({
            'status': 'healthy' if all_services_healthy else 'degraded',
            'timestamp': datetime.now().isoformat(),
            'uptime_seconds': int(uptime),
            'version': '1.0.0',
            'services': service_status
        })

    @app.route('/api/database/status')
    @login_required
    def get_database_status():
        """Get detailed database status for UI"""
        try:
            connection_status = test_database_connection()
            health_info = get_database_health()
            stats = get_database_statistics_safe()
            
            return jsonify({
                'success': True,
                'connection': connection_status,
                'health': health_info,
                'statistics': stats
            })
            
        except Exception as e:
            logger.error(f"Database status check failed: {e}")
            return jsonify({
                'success': False,
                'error': str(e),
                'connection': {
                    'status': 'error',
                    'message': 'Database status check failed',
                    'details': {
                        'database_type': 'unknown',
                        'database_name': 'unknown',
                        'tables_exist': False,
                        'connection_healthy': False,
                        'error_type': 'status_check_failed'
                    }
                },
                'health': {},
                'statistics': {}
            }), 500

    @app.route('/api/database/initialize', methods=['POST'])
    @login_required
    def initialize_database_endpoint():
        """Initialize database tables"""
        try:
            connection_status = test_database_connection()
            if connection_status.get('details', {}).get('tables_exist'):
                return jsonify({
                    'success': True,
                    'message': 'Database already initialized',
                    'already_initialized': True
                })
            
            logger.info("Database initialization requested")
            
            return jsonify({
                'success': True,
                'message': 'Database initialization completed'
            })
            
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            return jsonify({
                'success': False,
                'error': str(e),
                'message': f'Database initialization failed: {str(e)}'
            }), 500

    # ==========================================
    # AZURE STORAGE HEALTH CHECK ENDPOINTS
    # ==========================================

    @app.route('/api/storage/status')
    def get_storage_status():
        """Check Azure Blob Storage health and return status"""
        try:
            connection_string = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
            account_name = os.getenv('AZURE_STORAGE_ACCOUNT_NAME')
            
            if not connection_string and not account_name:
                logger.info("Azure Storage not configured - will use local filesystem")
                return jsonify({
                    'success': True,
                    'status': 'not_configured',
                    'storage_type': 'local',
                    'message': 'Azure Storage not configured - using local filesystem',
                    'account_name': None,
                    'recommendation': 'To use Azure Storage, set AZURE_STORAGE_CONNECTION_STRING environment variable',
                    'stats': None
                })
            
            if not file_handler.use_azure:
                logger.warning("Azure Storage configuration failed - falling back to local storage")
                return jsonify({
                    'success': True,
                    'status': 'local_fallback',
                    'storage_type': 'local',
                    'message': 'Azure Storage initialization failed - using local filesystem fallback',
                    'account_name': account_name,
                    'warning': 'Azure Storage could not be initialized. Check credentials and network connectivity.',
                    'stats': None
                })
            
            stats = file_handler.get_storage_stats()
            
            if stats.get('success'):
                totals = stats.get('totals', {})
                return jsonify({
                    'success': True,
                    'status': 'connected',
                    'storage_type': 'azure',
                    'message': 'Connected to Azure Blob Storage',
                    'account_name': account_name,
                    'stats': {
                        'total_files': totals.get('total_files', 0),
                        'total_size_mb': totals.get('total_size_mb', 0)
                    }
                })
            else:
                return jsonify({
                    'success': True,
                    'status': 'local_fallback',
                    'storage_type': 'local',
                    'message': 'Failed to get Azure storage statistics - using local filesystem',
                    'account_name': account_name,
                    'warning': stats.get('error'),
                    'stats': None
                })
        
        except Exception as e:
            logger.error(f'Storage status check error: {str(e)}')
            return jsonify({
                'success': False,
                'status': 'error',
                'storage_type': 'unknown',
                'message': f'Storage status check failed: {str(e)}',
                'account_name': None,
                'stats': None
            }), 500

    @app.route('/api/storage/info')
    @login_required
    def get_storage_info():
        """Get detailed storage information"""
        try:
            storage_info = {
                'success': True,
                'storage_type': 'azure' if file_handler.use_azure else 'local',
                'using_fallback': not file_handler.use_azure,
                'account_name': os.getenv('AZURE_STORAGE_ACCOUNT_NAME') if file_handler.use_azure else None,
                'container_name': os.getenv('AZURE_STORAGE_CONTAINER_NAME', 'uploads'),
            }
            
            if file_handler.use_azure:
                account_name = os.getenv('AZURE_STORAGE_ACCOUNT_NAME')
                storage_info['endpoint'] = f'https://{account_name}.blob.core.windows.net'
                
                stats = file_handler.get_storage_stats()
                if stats.get('success'):
                    storage_info['stats'] = stats.get('totals', {})
            else:
                storage_info['endpoint'] = 'local_filesystem'
                storage_info['warning'] = 'Using local filesystem - Azure Storage not configured or unavailable'
                storage_info['stats'] = file_handler.get_storage_stats().get('folders', {})
            
            return jsonify(storage_info)
        
        except Exception as e:
            logger.error(f'Storage info error: {str(e)}')
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/storage/test', methods=['POST'])
    @login_required
    def test_storage_connection():
        """Test storage connection by uploading and downloading a test file"""
        try:
            if not file_handler.use_azure:
                logger.info("Storage test: Using local filesystem (Azure not available)")
                return jsonify({
                    'success': True,
                    'storage_type': 'local',
                    'message': 'Local filesystem is available (Azure Storage not configured)',
                    'upload_time_ms': None,
                    'download_time_ms': None,
                    'delete_time_ms': None
                })
            
            test_data = {
                'test': 'connection_check',
                'timestamp': str(datetime.now())
            }
            test_content = json.dumps(test_data).encode('utf-8')
            test_filename = 'test_connection.json'
            test_blob_path = f'test/{test_filename}'
            
            upload_start = time.time()
            upload_result = file_handler.azure_storage.upload_file(
                test_content,
                test_blob_path,
                metadata={'test': 'true'}
            )
            upload_time = (time.time() - upload_start) * 1000
            
            if not upload_result.get('success'):
                logger.warning(f"Azure upload test failed: {upload_result.get('error')} - falling back to local")
                return jsonify({
                    'success': True,
                    'storage_type': 'local',
                    'message': 'Azure upload test failed - using local filesystem fallback',
                    'upload_time_ms': None,
                    'download_time_ms': None,
                    'delete_time_ms': None
                })
            
            download_start = time.time()
            download_result = file_handler.azure_storage.download_file(test_blob_path)
            download_time = (time.time() - download_start) * 1000
            
            if not download_result.get('success'):
                file_handler.azure_storage.delete_file(test_blob_path)
                logger.warning(f"Azure download test failed: {download_result.get('error')} - falling back to local")
                return jsonify({
                    'success': True,
                    'storage_type': 'local',
                    'message': 'Azure download test failed - using local filesystem fallback',
                    'upload_time_ms': None,
                    'download_time_ms': None,
                    'delete_time_ms': None
                })
            
            downloaded_content = download_result.get('content')
            if downloaded_content != test_content:
                file_handler.azure_storage.delete_file(test_blob_path)
                logger.warning("Azure content verification failed - falling back to local")
                return jsonify({
                    'success': True,
                    'storage_type': 'local',
                    'message': 'Downloaded content does not match - using local filesystem',
                    'upload_time_ms': None,
                    'download_time_ms': None,
                    'delete_time_ms': None
                })
            
            delete_start = time.time()
            delete_result = file_handler.azure_storage.delete_file(test_blob_path)
            delete_time = (time.time() - delete_start) * 1000
            
            if not delete_result.get('success'):
                logger.warning(f"Azure delete test failed: {delete_result.get('error')}")
                return jsonify({
                    'success': False,
                    'storage_type': 'azure',
                    'message': f'Storage test failed at delete step: {delete_result.get("error")}'
                }), 500
            
            logger.info("Azure Storage connection test PASSED")
            return jsonify({
                'success': True,
                'storage_type': 'azure',
                'message': 'Azure Storage connection test successful',
                'upload_time_ms': round(upload_time, 2),
                'download_time_ms': round(download_time, 2),
                'delete_time_ms': round(delete_time, 2)
            })
        
        except Exception as e:
            logger.error(f'Storage connection test error: {str(e)}')
            return jsonify({
                'success': False,
                'storage_type': 'unknown',
                'message': f'Storage test failed: {str(e)}'
            }), 500

    @app.route('/api/prerequisites')
    @app.route('/api/migrate/prerequisites')
    def check_prerequisites():
        """Check migration prerequisites including database and storage"""
        try:
            service_status = {}
            
            try:
                service_status['database'] = test_database_connection()
            except Exception as e:
                logger.error(f"Database status check failed: {e}")
                service_status['database'] = {
                    'status': 'error',
                    'message': 'Database service unavailable',
                    'details': {
                        'database_type': 'unknown',
                        'database_name': 'unknown',
                        'tables_exist': False,
                        'connection_healthy': False,
                        'error_type': 'service_check_failed'
                    }
                }
            
            try:
                service_status['azure_apim'] = AzureAPIMConnector().test_connection()
            except Exception as e:
                logger.warning(f"Azure APIM status check failed: {e}")
                service_status['azure_apim'] = {
                    'status': 'error',
                    'message': 'Azure APIM service check failed'
                }
            
            try:
                service_status['azure_openai'] = AzureOpenAIConnector().test_connection()
            except Exception as e:
                logger.warning(f"Azure OpenAI status check failed: {e}")
                service_status['azure_openai'] = {
                    'status': 'error',
                    'message': 'Azure OpenAI service check failed'
                }
            
            try:
                if file_handler.use_azure:
                    service_status['storage'] = {
                        'status': 'success',
                        'message': f'Azure Blob Storage available',
                        'storage_type': 'azure'
                    }
                else:
                    service_status['storage'] = {
                        'status': 'warning',
                        'message': 'Using local filesystem (Azure not configured)',
                        'storage_type': 'local'
                    }
            except Exception as e:
                logger.warning(f"Storage status check failed: {e}")
                service_status['storage'] = {
                    'status': 'warning',
                    'message': f'Storage check failed, will use local filesystem',
                    'storage_type': 'local'
                }
            
            all_services_available = all(
                status.get('status') in ['success', 'warning']
                for status in service_status.values()
            )
            
            recommendations = []
            for service_name, status in service_status.items():
                if status.get('status') not in ['success', 'warning']:
                    if service_name == 'database':
                        if status.get('details', {}).get('tables_exist') is False:
                            recommendations.append("Database tables need to be initialized")
                        elif status.get('details', {}).get('error_type') == 'database_not_found':
                            recommendations.append("Database does not exist and needs to be created")
                        elif status.get('details', {}).get('error_type') == 'connection_failed':
                            recommendations.append("Database connection failed - check database server")
                        else:
                            recommendations.append(f"Database issue: {status.get('message', 'Unknown error')}")
                    elif service_name == 'storage':
                        recommendations.append("File storage will use local filesystem")
                    else:
                        recommendations.append(f"{service_name.replace('_', ' ').title()} configuration needs attention")
            
            if not recommendations and all_services_available:
                recommendations.append("All services configured and available")
            
            return jsonify({
                'all_services_available': all_services_available,
                'can_migrate': all_services_available,
                'service_status': service_status,
                'recommendations': recommendations
            })
            
        except Exception as e:
            logger.error(f"Prerequisites check failed: {e}")
            return jsonify({
                'all_services_available': False,
                'can_migrate': False,
                'service_status': {
                    'database': {
                        'status': 'error', 
                        'message': f'Prerequisites check failed: {str(e)}',
                        'details': {
                            'error_type': 'system_error'
                        }
                    }
                },
                'recommendations': ['Check system configuration and database connectivity'],
                'error': f'Prerequisites check failed: {str(e)}'
            }), 500

    @app.route('/api/migrations/stats')
    @login_required
    def get_migration_stats():
        """Get migration statistics for the UI"""
        try:
            stats = {
                'total': MigrationRecord.query.count(),
                'completed': MigrationRecord.query.filter_by(status='completed').count(),
                'failed': MigrationRecord.query.filter_by(status='failed').count(),
                'pending': MigrationRecord.query.filter_by(status='in_progress').count() + 
                          MigrationRecord.query.filter_by(status='pending').count()
            }
            
            return jsonify({
                'success': True,
                'stats': stats
            })
            
        except Exception as e:
            logger.error(f"Failed to get migration stats: {e}")
            return jsonify({
                'success': False,
                'error': str(e),
                'stats': {
                    'total': 0,
                    'completed': 0,
                    'failed': 0,
                    'pending': 0
                }
            }), 500

    @app.route('/api/migrations/<migration_id>')
    @login_required
    def get_migration_details(migration_id):
        """Get detailed information about a specific migration"""
        try:
            migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
            
            if not migration:
                return jsonify({
                    'success': False,
                    'error': 'Migration not found'
                }), 404
            
            logs = MigrationLog.query.filter_by(migration_id=migration_id).order_by(MigrationLog.timestamp.asc()).all()
            
            migration_data = migration.to_dict()
            migration_data['logs'] = [log.to_dict() for log in logs]
            
            return jsonify(migration_data)
            
        except Exception as e:
            logger.error(f"Failed to get migration details: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/migrations/<migration_id>/rollback', methods=['POST'])
    @login_required
    def rollback_migration(migration_id):
        """Rollback a migration"""
        try:
            migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
            if not migration:
                return jsonify({'status': 'error', 'message': 'Migration not found'}), 404
            
            migration.status = 'rolled_back'
            migration.updated_at = datetime.now()
            db.session.commit()
            
            return jsonify({'status': 'success', 'message': 'Migration rolled back successfully'})
            
        except Exception as e:
            logger.error(f"Failed to rollback migration: {e}")
            return jsonify({'status': 'error', 'message': str(e)}), 500

    @app.route('/api/migrations/<migration_id>', methods=['DELETE'])
    @login_required
    def delete_migration(migration_id):
        """Delete a migration record"""
        try:
            migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
            if not migration:
                return jsonify({'status': 'error', 'message': 'Migration not found'}), 404
            
            MigrationLog.query.filter_by(migration_id=migration_id).delete()
            db.session.delete(migration)
            db.session.commit()
            
            return jsonify({'status': 'success', 'message': 'Migration deleted successfully'})
            
        except Exception as e:
            logger.error(f"Failed to delete migration: {e}")
            db.session.rollback()
            return jsonify({'status': 'error', 'message': str(e)}), 500

    @app.route('/api/migrations/<migration_id>/download')
    @login_required
    def download_migration_result(migration_id):
        """Download migration result file (converted OpenAPI spec)"""
        try:
            logger.info(f"=== MIGRATION DOWNLOAD REQUEST ===")
            logger.info(f"Migration ID: {migration_id}")
            
            migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
            
            if not migration:
                logger.warning(f"Migration not found: {migration_id}")
                return jsonify({
                    'status': 'error',
                    'message': 'Migration not found'
                }), 404
            
            logger.info(f"Migration found - Status: {migration.status}")
            
            if migration.status != 'completed':
                logger.warning(f"Migration not completed - Status: {migration.status}")
                return jsonify({
                    'status': 'error',
                    'message': f'Migration not completed. Current status: {migration.status}'
                }), 400
            
            converted_filename = migration.converted_filename
            if not converted_filename:
                logger.warning(f"No converted filename found for migration: {migration_id}")
                return jsonify({
                    'status': 'error',
                    'message': 'Converted file not found for this migration'
                }), 404
            
            logger.info(f"Converted filename: {converted_filename}")
            
            try:
                blob_path = None
                if file_handler.use_azure:
                    blob_path = f"converted/{converted_filename}"
                    logger.info(f"Attempting to download from Azure: {blob_path}")
                else:
                    logger.info(f"Attempting to download from local filesystem")
                
                file_info = file_handler.get_file_info(
                    converted_filename, 
                    folder_type='converted',
                    blob_path=blob_path
                )
                
                if not file_info['success']:
                    logger.error(f"Failed to get file info: {file_info}")
                    return jsonify({
                        'status': 'error',
                        'message': f'Failed to retrieve converted file: {file_info.get("error", "Unknown error")}'
                    }), 500
                
                logger.info(f"File retrieved successfully - Size: {file_info.get('file_size', 'unknown')} bytes")
                
                content = file_info.get('content', '')
                
                if not content:
                    logger.error("File content is empty")
                    return jsonify({
                        'status': 'error',
                        'message': 'Converted file is empty'
                    }), 500
                
                if isinstance(content, str):
                    try:
                        spec_content = json.loads(content)
                        logger.info("Successfully parsed JSON from file content")
                    except json.JSONDecodeError as e:
                        logger.error(f"Failed to parse JSON: {e}")
                        return jsonify({
                            'status': 'error',
                            'message': 'Converted file contains invalid JSON'
                        }), 500
                else:
                    spec_content = content
                
                if not isinstance(spec_content, dict):
                    logger.error("Converted spec is not a dictionary")
                    return jsonify({
                        'status': 'error',
                        'message': 'Invalid specification format'
                    }), 500
                
                if 'openapi' not in spec_content and 'swagger' not in spec_content:
                    logger.warning("Spec does not have openapi or swagger field")
                    return jsonify({
                        'status': 'error',
                        'message': 'Invalid OpenAPI specification'
                    }), 500
                
                logger.info("✓ Spec validation passed")
                logger.info(f"  OpenAPI version: {spec_content.get('openapi', spec_content.get('swagger', 'unknown'))}")
                logger.info(f"  API Title: {spec_content.get('info', {}).get('title', 'Unknown')}")
                
                response_data = {
                    'status': 'success',
                    'spec': spec_content,
                    'migration_info': {
                        'migration_id': migration.migration_id,
                        'api_name': migration.api_name,
                        'api_version': migration.api_version,
                        'conversion_method': migration.conversion_method,
                        'ai_used': migration.ai_conversion_used,
                        'completed_at': migration.updated_at.isoformat() if migration.updated_at else None,
                        'completion_time_seconds': migration.completion_time
                    }
                }
                
                logger.info("=== DOWNLOAD SUCCESSFUL ===")
                return jsonify(response_data), 200
                
            except Exception as file_error:
                logger.error(f"Failed to retrieve converted file: {file_error}")
                logger.error(f"Traceback: {traceback.format_exc()}")
                return jsonify({
                    'status': 'error',
                    'message': f'Failed to retrieve converted file: {str(file_error)}'
                }), 500
        
        except Exception as e:
            logger.error(f"=== DOWNLOAD ERROR ===")
            logger.error(f"Error: {e}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            return jsonify({
                'status': 'error',
                'message': f'Download failed: {str(e)}'
            }), 500

    @app.route('/api/migrations/export')
    @login_required
    def export_migrations():
        """Export migration history as CSV"""
        try:
            import csv
            import io
            
            migrations = MigrationRecord.query.order_by(MigrationRecord.created_at.desc()).all()
            
            output = io.StringIO()
            writer = csv.writer(output)
            
            writer.writerow([
                'Migration ID', 'API Name', 'Status', 'Source Platform', 'Target Platform',
                'Completion Time', 'Created At', 'Azure API ID', 'Error Message'
            ])
            
            for migration in migrations:
                writer.writerow([
                    migration.migration_id,
                    migration.api_name or '',
                    migration.status,
                    migration.source_platform,
                    migration.target_platform,
                    migration.completion_time or '',
                    migration.created_at.isoformat() if migration.created_at else '',
                    migration.azure_api_id or '',
                    migration.error_message or ''
                ])
            
            output.seek(0)
            return send_file(
                io.BytesIO(output.getvalue().encode('utf-8')),
                mimetype='text/csv',
                as_attachment=True,
                download_name=f'migration_history_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
            )
            
        except Exception as e:
            logger.error(f"Failed to export migrations: {e}")
            return jsonify({'error': str(e)}), 500

    @app.route('/api/upload', methods=['POST'])
    @login_required
    def upload_file():
        """Handle file upload with enhanced validation"""
        try:
            if 'file' not in request.files:
                return jsonify({'error': 'No file provided'}), 400
            
            file = request.files['file']
            if file.filename == '':
                return jsonify({'error': 'No file selected'}), 400
            
            save_result = file_handler.save_uploaded_file(file, prefix='upload')
            
            if not save_result['success']:
                return jsonify({'error': save_result['error']}), 400
            
            content_result = file_handler.read_file_content(save_result.get('file_path'), save_result.get('blob_path'))
            
            if not content_result['success']:
                file_handler.delete_file(save_result['filename'], 'uploaded', save_result.get('blob_path'))
                return jsonify({'error': content_result['error']}), 400
            
            if content_result['parsed_content']:
                api_info = extract_api_info(content_result['parsed_content'])
            else:
                api_info = {}
            
            return jsonify({
                'success': True,
                'file_info': save_result,
                'content_info': {
                    'type': content_result['content_type'],
                    'size': content_result['file_size']
                },
                'api_info': api_info,
                'message': 'File uploaded successfully'
            })
            
        except Exception as e:
            logger.error(f"File upload failed: {e}")
            return jsonify({'error': f'Upload failed: {str(e)}'}), 500

    @app.route('/api/convert', methods=['POST'])
    @login_required
    def convert_api():
        """Convert OpenAPI specification with enhanced file storage and database tracking"""
        migration_record = None
        api_spec_record = None
        
        try:
            data = request.get_json()
            if not data:
                logger.error("No JSON data provided in conversion request")
                return jsonify({'error': 'No JSON data provided'}), 400
            
            logger.info(f"=== CONVERSION REQUEST RECEIVED ===")
            logger.info(f"Request data keys: {list(data.keys())}")
            logger.info(f"spec_content length: {len(data.get('spec_content', ''))}")
            
            try:
                request_data = ConversionRequestSchema(**data)
                logger.info("Request data validation successful")
            except Exception as e:
                logger.error(f"ConversionRequestSchema validation failed: {str(e)}")
                return jsonify({
                    'error': f'Invalid request data: {str(e)}',
                    'received_fields': list(data.keys()),
                    'expected_fields': ['spec_content', 'source_format (optional)', 'include_debug (optional)']
                }), 400
            
            migration_id = generate_id()
            logger.info(f"Generated migration ID: {migration_id}")
            
            try:
                import yaml
                
                spec_content = request_data.spec_content.strip()
                if spec_content.startswith('{'):
                    original_spec = json.loads(spec_content)
                else:
                    original_spec = yaml.safe_load(spec_content)
                    
                api_info = extract_api_info(original_spec)
                logger.info(f"Extracted API info: {api_info}")
                
            except Exception as e:
                logger.warning(f"Failed to parse original spec for info extraction: {e}")
                api_info = {
                    'title': 'Unknown API',
                    'version': '1.0.0',
                    'format': 'unknown'
                }
            
            migration_record_data = {
                'migration_id': migration_id,
                'original_api_id': api_info.get('title', 'unknown').replace(' ', '_'),
                'api_name': api_info.get('title', 'Unknown API'),
                'api_version': api_info.get('version', '1.0.0'),
                'status': 'in_progress',
                'source_platform': 'file_upload',
                'target_platform': 'azure_apim',
                'start_time': datetime.now(),
                'original_filename': f"{api_info.get('title', 'api')}.json",
                'conversion_method': 'pending',
                'ai_conversion_used': False,
                'migration_metadata': {}
            }
            
            migration_record = create_migration_record_safe(migration_record_data)
            if migration_record:
                logger.info(f"Created migration record with ID: {migration_id}")
            else:
                logger.warning(f"Failed to create migration record - continuing without database tracking")
            
            try:
                api_spec_record = APISpecification(
                    api_id=f"{api_info.get('title', 'unknown').replace(' ', '_')}_{migration_id[:8]}",
                    name=api_info.get('title', 'Unknown API'),
                    version=api_info.get('version', '1.0.0'),
                    description=api_info.get('description', ''),
                    format=api_info.get('format', 'unknown'),
                    specification=original_spec,
                    source_platform='file_upload',
                    original_filename=f"{api_info.get('title', 'api')}.json",
                    paths_count=api_info.get('paths_count', 0),
                    operations_count=api_info.get('operations_count', 0),
                    definitions_count=api_info.get('definitions_count', 0),
                    is_valid=True
                )
                
                db.session.add(api_spec_record)
                db.session.commit()
                logger.info(f"Created API specification record with ID: {api_spec_record.api_id}")
                
            except Exception as e:
                logger.warning(f"Failed to create API specification record: {e}")
            
            try:
                if migration_record:
                    log_entry = MigrationLog(
                        migration_id=migration_id,
                        level='INFO',
                        stage='conversion_start',
                        message='Starting OpenAPI conversion process',
                        details={'source_format': request_data.source_format}
                    )
                    db.session.add(log_entry)
                    db.session.commit()
            except Exception as e:
                logger.warning(f"Failed to create log entry: {e}")
            
            conversion_start_time = datetime.now()
            try:
                logger.info("Starting conversion process...")
                
                import inspect
                convert_sig = inspect.signature(conversion_service.convert_specification)
                supports_debug = 'include_debug' in convert_sig.parameters
                
                if supports_debug:
                    logger.info("ConversionService supports include_debug parameter")
                    conversion_result = conversion_service.convert_specification(
                        request_data.spec_content,
                        request_data.source_format,
                        include_debug=request_data.include_debug
                    )
                else:
                    logger.info("ConversionService does not support include_debug, calling without it")
                    conversion_result = conversion_service.convert_specification(
                        request_data.spec_content,
                        request_data.source_format
                    )
                    
                    if request_data.include_debug:
                        logger.info("Adding placeholder debug information")
                        conversion_result['raw_openai_response'] = "Debug info not available - ConversionService needs to be updated"
                        conversion_result['cleaned_json'] = "Debug info not available - ConversionService needs to be updated"
                        conversion_result['cleaning_issues'] = "ConversionService does not support debug mode yet"
                
                conversion_end_time = datetime.now()
                conversion_time = (conversion_end_time - conversion_start_time).total_seconds()
                
                logger.info(f"Conversion completed with status: {conversion_result.get('status')}")
                
                if migration_record:
                    update_data = {}
                    if conversion_result.get('status') == 'success':
                        update_data.update({
                            'status': 'completed',
                            'end_time': conversion_end_time,
                            'completion_time': conversion_time,
                            'conversion_method': 'ai_powered' if conversion_result.get('ai_conversion_used') else 'programmatic',
                            'ai_conversion_used': conversion_result.get('ai_conversion_used', False),
                            'conversion_notes': f"Conversion completed successfully in {conversion_time:.2f}s",
                            'migration_metadata': {
                                'conversion_time': conversion_time,
                                'ai_used': conversion_result.get('ai_conversion_used', False),
                                'conversion_metadata': conversion_result.get('conversion_metadata', {}),
                                'validation_results': conversion_result.get('validation', {})
                            }
                        })
                    else:
                        update_data.update({
                            'status': 'failed',
                            'end_time': conversion_end_time,
                            'error_message': conversion_result.get('message', 'Conversion failed')
                        })
                    
                    if update_migration_record_safe(migration_record, **update_data):
                        logger.info(f"Updated migration record status: {migration_record.status}")
                        
                        try:
                            log_entry = MigrationLog(
                                migration_id=migration_id,
                                level='INFO' if conversion_result.get('status') == 'success' else 'ERROR',
                                stage='conversion_complete',
                                message=f"Conversion {conversion_result.get('status')} in {conversion_time:.2f}s",
                                details={
                                    'conversion_time': conversion_time,
                                    'ai_used': conversion_result.get('ai_conversion_used', False),
                                    'status': conversion_result.get('status')
                                }
                            )
                            db.session.add(log_entry)
                            db.session.commit()
                        except Exception as e:
                            logger.warning(f"Failed to create completion log: {e}")
                
                if conversion_result.get('status') == 'success' and 'converted_spec' in conversion_result:
                    try:
                        api_info_from_converted = conversion_result.get('converted_spec', {}).get('info', {})
                        api_title = api_info_from_converted.get('title', api_info.get('title', 'converted_api'))
                        original_filename = f"{api_title.replace(' ', '_')}_converted_{migration_id[:8]}.json"
                        
                        save_result = file_handler.save_converted_file(
                            conversion_result['converted_spec'],
                            original_filename,
                            conversion_result.get('conversion_metadata')
                        )
                        
                        if save_result['success']:
                            conversion_result['converted_file'] = {
                                'filename': save_result['filename'],
                                'download_url': save_result.get('download_url'),
                                'file_size': save_result['file_size'],
                                'saved_at': save_result['conversion_time'],
                                'storage_type': save_result.get('storage_type', 'unknown'),
                                'location': '☁️ Azure Blob Storage' if save_result.get('storage_type') == 'azure' else '💾 Local Filesystem'
                            }
                            
                            logger.info(f"Converted file saved to {save_result.get('storage_type', 'unknown').upper()}: {save_result['filename']}")
                            
                            if migration_record:
                                update_migration_record_safe(
                                    migration_record,
                                    converted_filename=save_result['filename'],
                                    migration_metadata={
                                        **migration_record.migration_metadata,
                                        'file_storage_type': save_result.get('storage_type', 'unknown'),
                                        'file_location': save_result.get('storage_type', 'unknown').upper()
                                    }
                                )
                                
                        else:
                            logger.warning(f"Failed to save converted file: {save_result.get('error')}")
                            conversion_result['file_save_warning'] = f"Failed to save file: {save_result.get('error')}"
                            
                    except Exception as save_error:
                        logger.warning(f"Failed to save converted file: {save_error}")
                        conversion_result['file_save_warning'] = f"Failed to save file: {str(save_error)}"
                
                conversion_result['migration_id'] = migration_id
                conversion_result['storage_status'] = {
                    'using_azure': file_handler.use_azure,
                    'storage_type': 'azure' if file_handler.use_azure else 'local'
                }
                
                return jsonify(conversion_result)
                
            except Exception as conversion_error:
                logger.error(f"Conversion process failed: {str(conversion_error)}")
                logger.error(f"Conversion error traceback: {traceback.format_exc()}")
                
                if migration_record:
                    update_migration_record_safe(migration_record, 
                        status='failed',
                        end_time=datetime.now(),
                        error_message=str(conversion_error)
                    )
                    
                    try:
                        log_entry = MigrationLog(
                            migration_id=migration_id,
                            level='ERROR',
                            stage='conversion_error',
                            message=f"Conversion failed: {str(conversion_error)}",
                            details={'error_type': type(conversion_error).__name__}
                        )
                        db.session.add(log_entry)
                        db.session.commit()
                    except Exception as e:
                        logger.warning(f"Failed to log conversion error: {e}")
                
                return jsonify({
                    'status': 'error',
                    'message': f'Conversion failed: {str(conversion_error)}',
                    'error_type': type(conversion_error).__name__,
                    'migration_id': migration_id
                }), 500
            
        except Exception as e:
            logger.error(f"Conversion endpoint failed: {e}")
            logger.error(f"Full traceback: {traceback.format_exc()}")
            
            if migration_record:
                update_migration_record_safe(migration_record, 
                    status='failed',
                    error_message=str(e)
                )
            
            return jsonify({
                'status': 'error',
                'message': f'Conversion failed: {str(e)}'
            }), 500

    @app.route('/api/convert/preview', methods=['POST'])
    @login_required
    def conversion_preview():
        """Get conversion preview without performing full conversion"""
        try:
            data = request.get_json()
            if not data or 'spec_content' not in data:
                return jsonify({'error': 'No specification content provided'}), 400
            
            preview_result = conversion_service.get_conversion_preview(data['spec_content'])
            
            return jsonify(preview_result)
            
        except Exception as e:
            logger.error(f"Conversion preview failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Preview failed: {str(e)}'
            }), 500

    @app.route('/api/migrate', methods=['POST'])
    @login_required
    def migrate_api():
        """Migrate single API"""
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400
            
            try:
                request_data = MigrationRequestSchema(**data)
            except Exception as e:
                return jsonify({'error': f'Invalid request data: {str(e)}'}), 400
            
            api_id = request_data.api_ids[0] if isinstance(request_data.api_ids, list) else request_data.api_ids
            
            migration_result = migration_service.migrate_single_api(
                api_id,
                request_data.org_name,
                request_data.options
            )
            
            return jsonify(migration_result)
            
        except Exception as e:
            logger.error(f"Migration failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Migration failed: {str(e)}'
            }), 500

    @app.route('/api/migrate/batch', methods=['POST'])
    @login_required
    def migrate_batch():
        """Migrate multiple APIs"""
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400
            
            try:
                request_data = BatchMigrationRequestSchema(**data)
            except Exception as e:
                return jsonify({'error': f'Invalid request data: {str(e)}'}), 400
            
            if request_data.migration_type == 'apis':
                migration_result = migration_service.migrate_multiple_apis(
                    request_data.api_ids,
                    request_data.org_name,
                    request_data.options
                )
            elif request_data.migration_type == 'catalog':
                migration_result = migration_service.migrate_by_catalog(
                    request_data.org_name,
                    request_data.catalog_name,
                    request_data.options
                )
            else:
                return jsonify({'error': 'Invalid migration type'}), 400
            
            return jsonify(migration_result)
            
        except Exception as e:
            logger.error(f"Batch migration failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Batch migration failed: {str(e)}'
            }), 500

    @app.route('/api/deploy', methods=['POST'])
    @login_required
    def deploy_to_azure_apim():
        """Deploy converted OpenAPI spec directly to Azure APIM"""
        try:
            logger.info("=== DEPLOY ROUTE CALLED ===")
            
            data = request.get_json()
            if not data:
                logger.error("No JSON data provided in request")
                return jsonify({'error': 'No JSON data provided'}), 400
            
            logger.info(f"Request data keys: {list(data.keys())}")
            
            converted_spec = data.get('converted_spec')
            original_api_id = data.get('original_api_id', 'migrated-api')
            options = data.get('options', {})
            
            if not converted_spec:
                logger.error("No converted specification provided")
                return jsonify({
                    'status': 'error',
                    'message': 'No converted specification provided'
                }), 400
            
            if not isinstance(converted_spec, dict):
                logger.error("Converted spec is not a dictionary")
                return jsonify({
                    'status': 'error',
                    'message': 'Invalid specification format'
                }), 400
            
            required_fields = ['openapi', 'info', 'paths']
            missing_fields = [field for field in required_fields if field not in converted_spec]
            if missing_fields:
                logger.error(f"Missing required OpenAPI fields: {missing_fields}")
                return jsonify({
                    'status': 'error',
                    'message': f'Invalid OpenAPI specification: missing {", ".join(missing_fields)}'
                }), 400
            
            azure_apim_connector = AzureAPIMConnector()
            if not azure_apim_connector.is_available:
                logger.error("Azure APIM connector not available")
                return jsonify({
                    'status': 'error',
                    'message': 'Azure APIM service not available. Please check configuration.'
                }), 503
            
            api_id = options.get('api_id') or _generate_api_id_from_spec(converted_spec, original_api_id)
            logger.info(f"Using API ID: {api_id}")
            
            validation_result = azure_apim_connector.validate_openapi_for_apim(converted_spec.copy())
            if validation_result['issues']:
                logger.warning(f"OpenAPI validation issues: {validation_result['issues']}")
                converted_spec = validation_result['spec']
            
            logger.info("Starting Azure APIM deployment...")
            deployment_result = azure_apim_connector.create_api_from_openapi(converted_spec, api_id)
            
            if deployment_result.get('status') != 'success':
                logger.error(f"Azure APIM deployment failed: {deployment_result.get('message')}")
                return jsonify({
                    'status': 'error',
                    'message': f"Deployment failed: {deployment_result.get('message', 'Unknown error')}"
                }), 400
            
            if options.get('create_product'):
                logger.info("Creating Azure APIM product...")
                product_name = options.get('product_name') or f"Product for {api_id}"
                product_result = azure_apim_connector.create_product(
                    product_name, [api_id], options.get('product_description', '')
                )
                deployment_result['product'] = product_result
            
            deployment_result['management_url'] = azure_apim_connector.get_api_management_url(api_id)
            deployment_result['developer_portal_url'] = azure_apim_connector.get_developer_portal_url()
            
            logger.info("=== DEPLOYMENT SUCCESSFUL ===")
            return jsonify(deployment_result), 200
            
        except Exception as e:
            error_msg = f"Deployment failed: {str(e)}"
            logger.error(f"=== DEPLOYMENT ERROR ===")
            logger.error(error_msg)
            logger.error(traceback.format_exc())
            
            return jsonify({
                'status': 'error',
                'message': error_msg,
                'error_type': type(e).__name__
            }), 500

    @app.route('/api/test-deploy', methods=['POST'])
    @login_required
    def test_deployment():
        """Test deployment with a simple API"""
        try:
            azure_apim_connector = AzureAPIMConnector()
            if not azure_apim_connector.is_available:
                return jsonify({
                    'status': 'error',
                    'message': 'Azure APIM service not available'
                }), 503
            
            test_connection = azure_apim_connector.test_connection()
            if test_connection['status'] != 'success':
                return jsonify({
                    'status': 'error',
                    'message': f"Azure APIM connection failed: {test_connection['message']}"
                }), 503
            
            test_spec = {
                "openapi": "3.0.0",
                "info": {
                    "title": "UI Test API",
                    "version": "1.0.0",
                    "description": "Testing deployment from UI"
                },
                "servers": [{"url": "https://api.example.com"}],
                "paths": {
                    "/test": {
                        "get": {
                            "summary": "Test endpoint",
                            "responses": {
                                "200": {
                                    "description": "Success",
                                    "content": {
                                        "application/json": {
                                            "schema": {
                                                "type": "object",
                                                "properties": {
                                                    "message": {"type": "string"}
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            result = azure_apim_connector.create_api_from_openapi(test_spec, 'ui-test-api')
            return jsonify(result)
            
        except Exception as e:
            error_msg = f"Test deployment failed: {str(e)}"
            logger.error(error_msg)
            return jsonify({
                'status': 'error',
                'message': error_msg
            }), 500

    @app.route('/api/statistics')
    @login_required
    def get_statistics():
        """Get application statistics"""
        try:
            logger.info("=== STATISTICS REQUEST ===")
            
            response_data = {
                'migrations': {},
                'database': {},
                'storage': {},
                'storage_by_folder': {},
                'storage_type': 'unknown',
                'application': {
                    'version': '1.0.0',
                    'uptime_seconds': 0,
                    'start_time': app_start_time.isoformat()
                }
            }
            
            logger.info("Fetching migration statistics...")
            try:
                migration_stats = {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                }
                
                try:
                    total = MigrationRecord.query.count()
                    completed = MigrationRecord.query.filter_by(status='completed').count()
                    failed = MigrationRecord.query.filter_by(status='failed').count()
                    in_progress = MigrationRecord.query.filter_by(status='in_progress').count() + \
                                MigrationRecord.query.filter_by(status='pending').count()
                    
                    migration_stats['total_migrations'] = total
                    migration_stats['successful_migrations'] = completed
                    migration_stats['failed_migrations'] = failed
                    migration_stats['in_progress_migrations'] = in_progress
                    
                    if total > 0:
                        migration_stats['success_rate'] = round((completed / total) * 100, 2)
                    
                    try:
                        avg_result = db.session.query(
                            db.func.avg(MigrationRecord.completion_time)
                        ).filter(
                            MigrationRecord.completion_time != None,
                            MigrationRecord.status == 'completed'
                        ).scalar()
                        
                        if avg_result:
                            migration_stats['average_completion_time'] = round(float(avg_result), 2)
                    except Exception as e:
                        logger.warning(f"Failed to get average completion time: {e}")
                        migration_stats['average_completion_time'] = 0
                    
                    logger.info(f"✓ Migration stats: {migration_stats}")
                    
                except Exception as e:
                    logger.warning(f"Failed to get migration query stats: {e}")
                    logger.info("Using fallback migration statistics")
                
                response_data['migrations'] = migration_stats
                
            except Exception as migration_error:
                logger.error(f"Failed to get migration statistics: {migration_error}")
                response_data['migrations'] = {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                }
            
            logger.info("Fetching database statistics...")
            try:
                db_stats = {
                    'total_specifications': 0,
                    'valid_specifications': 0,
                    'invalid_specifications': 0,
                    'database_available': True
                }
                
                try:
                    total_specs = APISpecification.query.count()
                    valid_specs = APISpecification.query.filter_by(is_valid=True).count()
                    
                    db_stats['total_specifications'] = total_specs
                    db_stats['valid_specifications'] = valid_specs
                    db_stats['invalid_specifications'] = total_specs - valid_specs
                    
                    logger.info(f"✓ Database stats: total={total_specs}, valid={valid_specs}")
                    
                except Exception as query_error:
                    logger.warning(f"Failed to get database queries: {query_error}")
                    db_stats['database_available'] = False
                
                response_data['database'] = db_stats
                
            except Exception as db_error:
                logger.error(f"Failed to get database statistics: {db_error}")
                response_data['database'] = {
                    'total_specifications': 0,
                    'valid_specifications': 0,
                    'invalid_specifications': 0,
                    'database_available': False
                }
            
            logger.info("Fetching storage statistics...")
            try:
                storage_stats = file_handler.get_storage_stats()
                
                if storage_stats.get('success'):
                    response_data['storage'] = storage_stats.get('totals', {})
                    response_data['storage_by_folder'] = storage_stats.get('folders', {})
                    response_data['storage_type'] = storage_stats.get('storage_type', 'unknown')
                    logger.info(f"✓ Storage stats: {storage_stats.get('storage_type', 'unknown')}")
                else:
                    logger.warning(f"Storage stats failed: {storage_stats.get('error', 'Unknown error')}")
                    response_data['storage'] = {'total_files': 0, 'total_size_mb': 0}
                    response_data['storage_by_folder'] = {}
                    response_data['storage_type'] = 'unavailable'
            
            except Exception as storage_error:
                logger.error(f"Failed to get storage statistics: {storage_error}")
                response_data['storage'] = {'total_files': 0, 'total_size_mb': 0}
                response_data['storage_by_folder'] = {}
                response_data['storage_type'] = 'error'
            
            logger.info("Calculating application statistics...")
            try:
                uptime_seconds = (datetime.now() - app_start_time).total_seconds()
                
                response_data['application'] = {
                    'version': '1.0.0',
                    'uptime_seconds': int(uptime_seconds),
                    'start_time': app_start_time.isoformat()
                }
                
                logger.info(f"✓ Application uptime: {int(uptime_seconds)} seconds")
                
            except Exception as app_error:
                logger.error(f"Failed to get application statistics: {app_error}")
            
            logger.info("=== STATISTICS RESPONSE READY ===")
            return jsonify(response_data), 200
            
        except Exception as e:
            logger.error(f"Statistics endpoint error: {e}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            
            fallback_response = {
                'migrations': {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                },
                'database': {
                    'total_specifications': 0,
                    'valid_specifications': 0,
                    'invalid_specifications': 0,
                    'database_available': False
                },
                'storage': {'total_files': 0, 'total_size_mb': 0},
                'storage_by_folder': {},
                'storage_type': 'error',
                'application': {
                    'version': '1.0.0',
                    'uptime_seconds': int((datetime.now() - app_start_time).total_seconds()),
                    'start_time': app_start_time.isoformat()
                },
                'error': str(e)
            }
            
            return jsonify(fallback_response), 500

    @app.route('/api/debug/openai-last-response')
    @login_required
    def get_last_openai_response():
        connector = AzureOpenAIConnector()
        return jsonify(connector.get_debug_info())

    # ==========================================
    # UNIVERSAL CHAT ROUTE - HANDLES ALL DOMAINS
    # ==========================================
    """
    EXACT LOCATION TO UPDATE IN app.py

    Find the @app.route('/api/chat/universal', methods=['POST']) function
    and replace the FINAL RETURN SECTION (the very end of the function)

    This is the COMPLETE chat_universal function with proper response validation
    """

    @app.route('/api/chat/universal', methods=['POST'])
    @login_required
    def chat_universal():
        """
        Universal chat assistant that handles:
        - Code generation & implementation
        - Code review & optimization
        - API design & architecture
        - Policy analysis
        - Documentation & guides
        - Security audits
        - And more...
        """
        try:
            logger.info("=" * 70)
            logger.info("🤖 UNIVERSAL CHAT REQUEST")
            logger.info("=" * 70)
            
            # Extract request data
            message = request.form.get('message', '').strip()
            conversation_id = request.form.get('conversation_id', f'conv_{datetime.now().timestamp()}')
            assistant_type_override = request.form.get('assistant_type', None)
            file = request.files.get('file') if 'file' in request.files else None
            
            logger.info(f"📝 Message: {message[:100]}...")
            logger.info(f"📎 File: {file.filename if file else 'NONE'}")
            logger.info(f"🏷️ Override: {assistant_type_override or 'auto-detect'}")
            
            # ==========================================
            # VALIDATION
            # ==========================================
            
            if not message and not file:
                return jsonify({
                    'success': False,
                    'error': 'Please provide a message or attach a file'
                }), 400
            
            # ==========================================
            # PROCESS FILE IF PROVIDED
            # ==========================================
            
            file_info = None
            file_content = None
            
            if file:
                logger.info(f"📁 Processing file: {file.filename}")
                
                if file.content_length > CHAT_CONFIG['max_file_size']:
                    return jsonify({
                        'success': False,
                        'error': f'File exceeds {format_file_size_local(CHAT_CONFIG["max_file_size"])}'
                    }), 400
                
                file_ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
                if file_ext not in CHAT_CONFIG['supported_file_types']:
                    return jsonify({
                        'success': False,
                        'error': f'Unsupported file type. Allowed: {", ".join(CHAT_CONFIG["supported_file_types"])}'
                    }), 400
                
                file_info = process_universal_file(file, conversation_id)
                if not file_info['success']:
                    return jsonify({'success': False, 'error': file_info['error']}), 400
                
                file_content = file_info.get('content')
                logger.info(f"✅ File processed: {file_info.get('type')} - {len(file_content)} chars")
            
            # ==========================================
            # DETECT ASSISTANT TYPE
            # ==========================================
            
            from enhanced_prompts import detect_assistant_type, ASSISTANT_TYPES
            
            if assistant_type_override and assistant_type_override in ASSISTANT_TYPES:
                assistant_type = assistant_type_override
                confidence = 1.0
                reason = f"User selected: {ASSISTANT_TYPES[assistant_type]['description']}"
                logger.info(f"✅ Using override: {assistant_type}")
            else:
                combined_input = message
                if file_content:
                    combined_input += f"\n\nFile content preview:\n{file_content[:500]}..."
                
                assistant_type, confidence, reason = detect_assistant_type(combined_input, file_info)
                logger.info(f"🔍 Detection: {assistant_type} (confidence: {confidence:.1%})")
                logger.info(f"   Reason: {reason}")
            
            # ==========================================
            # GET OR CREATE CONVERSATION
            # ==========================================
            
            conversation = get_or_create_conversation(conversation_id)
            
            # ==========================================
            # ADD USER MESSAGE TO HISTORY
            # ==========================================
            
            conversation['messages'].append({
                'timestamp': datetime.now().isoformat(),
                'sender': 'user',
                'content': message,
                'file': file_info.get('filename') if file_info else None,
                'assistant_type': assistant_type
            })
            
            # ==========================================
            # GENERATE RESPONSE
            # ==========================================
            
            logger.info(f"🧠 Generating response with {assistant_type} assistant...")
            
            response_result = generate_universal_response(
                user_message=message,
                file_info=file_info,
                file_content=file_content,
                assistant_type=assistant_type,
                conversation_id=conversation_id
            )
            
            if not response_result['success']:
                logger.error(f"❌ Response generation failed: {response_result['error']}")
                return jsonify({
                    'success': False,
                    'error': response_result['error']
                }), 500
            
            # ==========================================
            # ADD ASSISTANT RESPONSE TO HISTORY
            # ==========================================
            
            conversation['messages'].append({
                'timestamp': datetime.now().isoformat(),
                'sender': 'assistant',
                'content': response_result['response'],
                'assistant_type': assistant_type,
                'confidence': confidence,
                'metadata': response_result.get('metadata', {})
            })
            conversation['updated_at'] = datetime.now().isoformat()
            
            logger.info(f"✅ Response generated ({len(response_result['response'])} chars)")
            logger.info("=" * 70)
            
            # ==========================================
            # VALIDATE RESPONSE BEFORE RETURNING
            # ==========================================
            # START: Replace from here
            
            # Check if response is empty or invalid
            if not response_result.get('response') or len(response_result.get('response', '').strip()) == 0:
                logger.error("Response generation returned empty response")
                fallback_resp = generate_fallback_response(message, assistant_type, file_info)
                return jsonify({
                    'success': True,
                    'response': fallback_resp,
                    'conversation_id': conversation_id,
                    'assistant_type': assistant_type,
                    'assistant_name': ASSISTANT_TYPES[assistant_type]['description'],
                    'confidence': 0.5,
                    'file_info': file_info,
                    'metadata': {'fallback': True, 'reason': 'Empty response'},
                    'suggestions': generate_follow_up_suggestions(message, assistant_type)
                })
            
            # Ensure response text is string and clean
            response_text = str(response_result['response']).strip()
            
            # Final safety check
            if len(response_text) == 0:
                logger.warning("Response text is empty after conversion")
                fallback_resp = generate_fallback_response(message, assistant_type, file_info)
                response_text = fallback_resp
            
            # Return validated response
            return jsonify({
                'success': True,
                'response': response_text,
                'conversation_id': conversation_id,
                'assistant_type': assistant_type,
                'assistant_name': ASSISTANT_TYPES[assistant_type]['description'],
                'confidence': confidence,
                'file_info': file_info,
                'metadata': response_result.get('metadata', {}),
                'suggestions': response_result.get('suggestions', [])
            })
            
            # END: Replace to here
            
        except Exception as e:
            logger.error(f"❌ Chat error: {e}", exc_info=True)
            return jsonify({
                'success': False,
                'error': f'Chat error: {str(e)}'
            }), 500
    
    # ==========================================
    # HELPER: PROCESS FILES
    # ==========================================

    def process_universal_file(file, conversation_id):
        """Process any supported file type"""
        try:
            filename = secure_filename(file.filename)
            file_ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else 'unknown'
            
            file.seek(0, 2)
            file_size = file.tell()
            file.seek(0)
            
            logger.info(f"Filename: {filename}, Type: {file_ext}, Size: {format_file_size_local(file_size)}")
            
            # Extract content based on file type
            if file_ext == 'pdf':
                content = extract_text_from_pdf(file)
            elif file_ext in ['docx', 'doc']:
                content = extract_text_from_docx(file)
            elif file_ext in ['py', 'js', 'java', 'go', 'rs', 'ts', 'sql']:
                content = file.read().decode('utf-8', errors='ignore')
            elif file_ext in ['json', 'yaml', 'yml']:
                content = file.read().decode('utf-8', errors='ignore')
            else:  # txt and others
                content = file.read().decode('utf-8', errors='ignore')
            
            if not content:
                return {'success': False, 'error': 'Failed to extract content from file'}
            
            # Detect file purpose
            detected_purpose = detect_file_purpose(content, filename, file_ext)
            
            logger.info(f"✓ File processed - {len(content)} characters")
            logger.info(f"  Detected purpose: {detected_purpose}")
            
            return {
                'success': True,
                'filename': filename,
                'type': file_ext,
                'size': file_size,
                'size_formatted': format_file_size_local(file_size),
                'content': content,
                'detected_purpose': detected_purpose,
                'word_count': len(content.split()),
                'char_count': len(content)
            }
            
        except Exception as e:
            logger.error(f"File processing error: {e}", exc_info=True)
            return {
                'success': False,
                'error': f'File processing failed: {str(e)}'
            }

    def detect_file_purpose(content, filename, file_ext):
        """Detect what the file is for"""
        content_lower = content.lower()
        filename_lower = filename.lower()
        
        # Code files
        if file_ext in ['py', 'js', 'java', 'go', 'rs', 'ts']:
            return f'Source Code ({file_ext.upper()})'
        
        # Configuration files
        if file_ext in ['json', 'yaml', 'yml']:
            if 'openapi' in content_lower or 'swagger' in content_lower:
                return 'OpenAPI Specification'
            elif 'config' in filename_lower or 'settings' in content_lower:
                return 'Configuration File'
            else:
                return f'{file_ext.upper()} Data'
        
        # API/Policy documents
        if 'api' in content_lower or 'endpoint' in content_lower or 'rest' in content_lower.lower():
            if 'policy' in content_lower or 'requirement' in content_lower:
                return 'API Policy Document'
            else:
                return 'API Specification'
        
        if 'policy' in content_lower or 'security' in content_lower or 'compliance' in content_lower:
            return 'Security/Compliance Policy'
        
        # Documentation
        if 'guide' in filename_lower or 'readme' in filename_lower or 'documentation' in content_lower:
            return 'Documentation'
        
        # SQL
        if file_ext == 'sql' or 'create table' in content_lower or 'select' in content_lower:
            return 'SQL Database Script'
        
        # Default
        return 'Text Document'

    # ==========================================
    # HELPER: GENERATE RESPONSE
    # ==========================================

    def generate_universal_response(user_message, file_info, file_content, assistant_type, conversation_id):
        """
        Generate response using appropriate assistant type
        Routes to correct prompt builder based on type
        
        FIXED: Ensures valid response format always
        """
        try:
            from enhanced_prompts import (
                UniversalPromptBuilder, ASSISTANT_TYPES,
                CODE_GENERATION_PROMPTS, API_ANALYSIS_PROMPTS,
                SECURITY_PROMPTS, POLICY_ANALYSIS_PROMPTS, DOCUMENTATION_PROMPTS
            )
            
            logger.info(f"Building prompt for {assistant_type}...")
            
            # Get config for this assistant type
            config = ASSISTANT_TYPES[assistant_type]
            system_prompt = config['system_prompt']
            
            # Build appropriate prompt based on assistant type
            if assistant_type == 'code':
                # Extract language if mentioned
                language = 'python'
                for lang in ['python', 'javascript', 'java', 'go', 'rust', 'typescript', 'c#']:
                    if lang in user_message.lower():
                        language = lang
                        break
                
                user_prompt = UniversalPromptBuilder.build_code_generation(
                    language=language,
                    task_description=user_message,
                    requirements=file_content[:1000] if file_content else None
                )
            
            elif assistant_type == 'code_review':
                language = 'python'
                for lang in ['python', 'javascript', 'java', 'go', 'rust', 'typescript']:
                    if lang in (file_info.get('filename', '') if file_info else '').lower():
                        language = lang
                        break
                
                user_prompt = UniversalPromptBuilder.build_code_review(
                    code=file_content or user_message,
                    language=language,
                    focus_areas='security, performance, and best practices'
                )
            
            elif assistant_type == 'api_design':
                user_prompt = UniversalPromptBuilder.build_api_design(
                    endpoints=user_message,
                    base_url='https://api.example.com',
                    auth_type='OAuth2'
                )
            
            elif assistant_type == 'policy':
                user_prompt = UniversalPromptBuilder.build_policy_analysis(
                    policy_text=file_content or user_message
                )
            
            elif assistant_type == 'documentation':
                subject_type = file_info.get('detected_purpose', 'API') if file_info else 'API'
                user_prompt = UniversalPromptBuilder.build_documentation(
                    subject=file_content or user_message,
                    subject_type=subject_type
                )
            
            else:  # general
                user_prompt = f"{user_message}\n\n{file_content[:1000] if file_content else ''}"
            
            logger.info(f"Prompt built successfully ({len(user_prompt)} chars)")
            
            # ==========================================
            # CALL AZURE OPENAI
            # ==========================================
            
            openai_connector = AzureOpenAIConnector()
            
            if not openai_connector.is_available:
                logger.warning("Azure OpenAI unavailable - using fallback")
                fallback_response = generate_fallback_response(user_message, assistant_type, file_info)
                return {
                    'success': True,
                    'response': fallback_response,
                    'fallback_used': True,
                    'metadata': {'type': assistant_type},
                    'suggestions': []
                }
            
            logger.info(f"Calling Azure OpenAI with {assistant_type} system prompt...")
            
            try:
                # ✅ Build model-aware parameters
                params = openai_connector._build_chat_completion_params(
                    deployment=openai_connector.config.OPENAI_DEPLOYMENT,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    temperature=config['temperature'],
                    max_tokens=config['max_tokens']
                )
                
                response = openai_connector._client.chat.completions.create(**params)
                response_text = response.choices[0].message.content
                
                # ==========================================
                # VALIDATION: Ensure response is not empty
                # ==========================================
                if not response_text or len(response_text.strip()) == 0:
                    logger.warning("Azure OpenAI returned empty response")
                    fallback_response = generate_fallback_response(user_message, assistant_type, file_info)
                    return {
                        'success': True,
                        'response': fallback_response,
                        'fallback_used': True,
                        'metadata': {'type': assistant_type, 'reason': 'Empty OpenAI response'},
                        'suggestions': []
                    }
                
                logger.info(f"✅ Azure OpenAI response received ({len(response_text)} chars)")
                
                # ==========================================
                # POST-PROCESS RESPONSE
                # ==========================================
                
                # Ensure code blocks are properly formatted
                response_text = ensure_code_blocks_formatted(response_text, assistant_type)
                
                # Extract metadata for better UI display
                metadata = extract_response_metadata(response_text, assistant_type)
                
                suggestions = generate_follow_up_suggestions(user_message, assistant_type)
                
                # ==========================================
                # FINAL VALIDATION BEFORE RETURN
                # ==========================================
                
                # Ensure response text is valid string
                if not isinstance(response_text, str):
                    response_text = str(response_text)
                
                # Remove any problematic characters
                response_text = response_text.replace('\x00', '').strip()
                
                if len(response_text) == 0:
                    response_text = "Response generated but appears to be empty. Please try again."
                
                return {
                    'success': True,
                    'response': response_text,
                    'metadata': metadata,
                    'suggestions': suggestions,
                    'fallback_used': False
                }
            
            except Exception as openai_error:
                logger.error(f"OpenAI call failed: {openai_error}", exc_info=True)
                
                # Fallback to generated response
                fallback_response = generate_fallback_response(user_message, assistant_type, file_info)
                return {
                    'success': True,
                    'response': fallback_response,
                    'fallback_used': True,
                    'metadata': {'type': assistant_type, 'error': str(openai_error)},
                    'suggestions': []
                }
                
        except Exception as e:
            logger.error(f"Response generation error: {e}", exc_info=True)
            
            # Always return valid response structure
            error_response = f"""I encountered an issue processing your request: {str(e)[:100]}

    Please try:
    1. Simplifying your request
    2. Uploading a different file
    3. Checking your input format

    The system is still available - please try again."""
            
            return {
                'success': True,  # ✅ IMPORTANT: Mark as success to avoid "Invalid response format"
                'response': error_response,
                'fallback_used': True,
                'metadata': {'type': 'error', 'error_type': type(e).__name__},
                'suggestions': ['Try a simpler request', 'Check uploaded file', 'Contact support']
            }
    # ==========================================
    # HELPER: FORMAT RESPONSE
    # ==========================================

    def ensure_code_blocks_formatted(response_text, assistant_type):
        """Ensure code blocks have proper language specifiers"""
        
        if assistant_type in ['code', 'code_review']:
            # Detect code language from context and add to markdown blocks
            
            # Match code blocks without language specifier
            pattern = r'```\n((?!```)[^`]*?)```'
            
            def add_language(match):
                code_content = match.group(1)
                # Simple heuristic to detect language
                if 'import ' in code_content or 'from ' in code_content:
                    lang = 'python'
                elif 'const ' in code_content or 'function ' in code_content or 'async ' in code_content:
                    lang = 'javascript'
                elif 'public class' in code_content or 'package ' in code_content:
                    lang = 'java'
                else:
                    lang = 'plaintext'
                
                return f'```{lang}\n{code_content}```'
            
            response_text = re.sub(pattern, add_language, response_text)
        
        return response_text

    def extract_response_metadata(response_text, assistant_type):
        """Extract metadata like code snippets, endpoints, etc."""
        metadata = {
            'assistant_type': assistant_type,
            'code_blocks': response_text.count('```'),
            'has_examples': 'example' in response_text.lower() or 'e.g.' in response_text.lower(),
            'has_warnings': '⚠️' in response_text or 'warning' in response_text.lower(),
            'sections': len([line for line in response_text.split('\n') if line.startswith('#')])
        }

        if assistant_type == 'code':
            functions = len(re.findall(r'def |function |class ', response_text))
            metadata['code_elements'] = functions
        
        elif assistant_type == 'api_design':
            endpoints = len(re.findall(r'(?:GET|POST|PUT|DELETE|PATCH|OPTIONS)\s+/', response_text))
            metadata['endpoints'] = endpoints
        
        elif assistant_type == 'policy':
            metrics = len(re.findall(r'(?:Critical|High|Medium|Low)', response_text))
            metadata['risk_items'] = metrics
        
        return metadata

    def generate_follow_up_suggestions(user_message, assistant_type):
        """Generate follow-up suggestions for next steps"""
        
        suggestions = []
        
        if assistant_type == 'code':
            suggestions = [
                "💾 Save this code to a file",
                "🧪 Write unit tests",
                "🔍 Review for security issues",
                "📚 Add documentation",
                "⚡ Optimize performance"
            ]
        
        elif assistant_type == 'code_review':
            suggestions = [
                "✅ Apply suggested fixes",
                "🧪 Run tests after changes",
                "📊 Check test coverage",
                "🔐 Security review of fixes",
                "📈 Performance benchmarks"
            ]
        
        elif assistant_type == 'api_design':
            suggestions = [
                "📝 Generate OpenAPI spec",
                "🧪 Design test cases",
                "📚 Create API documentation",
                "🔐 Review security aspects",
                "⚡ Plan for scaling"
            ]
        
        elif assistant_type == 'policy':
            suggestions = [
                "💻 Generate implementation code",
                "✅ Create checklist",
                "🧪 Design compliance tests",
                "📊 Risk assessment",
                "🔄 Review with team"
            ]
        
        elif assistant_type == 'documentation':
            suggestions = [
                "📄 Export as PDF",
                "💾 Save as markdown",
                "🔄 Generate from OpenAPI",
                "👥 Share with team",
                "📊 Add diagrams"
            ]
        
        return suggestions[:3]  # Top 3 suggestions


    def generate_fallback_response(message, assistant_type, file_info):
        """
        Generate fallback response when Azure OpenAI unavailable
        FIXED: Always returns valid, non-empty response
        """
        
        type_descriptions = {
            'code': '💻 Code Development',
            'code_review': '🔍 Code Review',
            'api_design': '🏗️ API Architecture',
            'policy': '🔐 Policy Analysis',
            'documentation': '📚 Documentation',
            'general': '🤖 General Assistant'
        }
        
        file_context = ""
        if file_info:
            file_context = f"\n\n**File:** {file_info['filename']} ({file_info['type']})\n"
            file_context += f"**Type:** {file_info['detected_purpose']}\n"
            file_context += f"**Size:** {file_info['size_formatted']}"
        
        # Build detailed response based on assistant type
        responses = {
            'code': f"""# Python Code Sample

    I'm running in fallback mode. Here's a sample Python implementation:

    ```python
    def main():
        '''
        Sample function based on your request:
        {message[:100]}...
        '''
        # Your implementation here
        result = process_data()
        return result

    def process_data():
        '''Process your data'''
        data = []
        # Add processing logic
        return data

    if __name__ == "__main__":
        main()
    ```

    **To enable full AI assistance:**
    - Configure Azure OpenAI credentials
    - Set environment variables
    - Restart the application

    **You can still:**
    ✅ Upload code files
    ✅ Get documentation templates
    ✅ Review architectural patterns
    {file_context}
    """,
            
            'code_review': f"""# Code Review - Fallback Mode

    Your code request: {message[:100]}...
    {file_context}

    **Areas I can help review:**
    1. ✅ Logic and correctness
    2. ✅ Performance optimization
    3. ✅ Security best practices
    4. ✅ Code style and readability
    5. ✅ Design patterns

    **To enable full AI code review:**
    - Configure Azure OpenAI
    - Set OPENAI_API_KEY and deployment info
    - Restart application

    **For now, consider:**
    - Running automated linters (pylint, eslint)
    - Using static analysis tools
    - Reviewing against OWASP guidelines
    - Testing edge cases
    """,
            
            'api_design': f"""# API Design - Fallback Mode

    Your API design request: {message[:100]}...

    **Standard RESTful Endpoints:**
    ```
    GET    /api/v1/resources      - List resources
    GET    /api/v1/resources/:id  - Get resource
    POST   /api/v1/resources      - Create resource
    PUT    /api/v1/resources/:id  - Update resource
    DELETE /api/v1/resources/:id  - Delete resource
    ```

    **To enable full AI API design:**
    - Configure Azure OpenAI
    - Upload OpenAPI specification
    - Restart application

    **You can still:**
    ✅ Create REST endpoints manually
    ✅ Follow OpenAPI standards
    ✅ Design database schemas
    ✅ Plan authentication flow
    """,
            
            'policy': f"""# Policy Analysis - Fallback Mode

    Your policy: {message[:100]}...
    {file_context}

    **Standard API Policy Components:**
    1. **Authentication** - OAuth2, JWT, API Keys
    2. **Rate Limiting** - Requests per minute/hour
    3. **Authorization** - Role-based access control
    4. **Security** - HTTPS, encryption, headers
    5. **Monitoring** - Logging, metrics, alerts

    **OWASP API Top 10 Risks:**
    - Broken Object Level Authorization
    - Broken Authentication
    - Excessive Data Exposure
    - Lack of Resources & Rate Limiting
    - Broken Function Level Authorization
    - Mass Assignment
    - Security Misconfiguration
    - Injection
    - Improper Assets Management
    - Insufficient Logging & Monitoring

    **To enable full AI analysis:**
    - Configure Azure OpenAI
    - Upload policy documents
    - Restart application
    """,
            
            'documentation': f"""# Documentation Template - Fallback Mode

    Subject: {message[:100]}...
    {file_context}

    ## Getting Started

    ### Prerequisites
    - Requirement 1
    - Requirement 2

    ### Installation
    ```bash
    # Installation steps here
    ```

    ### Basic Usage
    ```python
    # Usage example
    ```

    ## API Reference

    ### Authentication
    Describe auth method

    ### Endpoints
    - `GET /endpoint` - Description
    - `POST /endpoint` - Description

    ## Examples

    ### Example 1
    Description and code

    ### Example 2
    Description and code

    ## Troubleshooting

    ### Common Issues
    - Issue 1: Solution
    - Issue 2: Solution

    ## FAQ

    **Q: How do I...?**
    A: Steps to accomplish

    ---
    To enable full documentation generation, configure Azure OpenAI.
    """,
            
            'general': f"""# Assistant Response - Fallback Mode

    Your question: {message[:100]}...
    {file_context}

    I can help you with:
    ✅ Technical questions
    ✅ Code examples and explanations
    ✅ API design and architecture
    ✅ Documentation and guides
    ✅ Best practices and patterns
    ✅ Security and compliance

    **To enable full AI capabilities:**
    1. Configure Azure OpenAI service
    2. Set environment variables:
    - OPENAI_API_KEY
    - OPENAI_DEPLOYMENT
    - OPENAI_RESOURCE_NAME
    3. Restart the application

    **In the meantime:**
    - Upload files for manual analysis
    - Ask specific technical questions
    - Review documentation templates
    - Check configuration status at /api/health
    """
        }
        
        # Return response for the specific type, or general fallback
        response = responses.get(assistant_type, responses['general'])
        
        # Ensure response is never empty
        if not response or len(response.strip()) == 0:
            response = responses['general']
        
        return response

    conversations = {}

    def get_or_create_conversation(conversation_id, user_id=None):
        """Get or create conversation"""
        if conversation_id not in conversations:
            conversations[conversation_id] = {
                'id': conversation_id,
                'user_id': user_id,
                'created_at': datetime.now().isoformat(),
                'updated_at': datetime.now().isoformat(),
                'messages': [],
                'files': [],
                'assistant_types_used': []
            }
        return conversations[conversation_id]

    @app.route('/api/chat/conversations/<conversation_id>', methods=['GET'])
    @login_required
    def get_conversation(conversation_id):
        """Get conversation history"""
        try:
            if conversation_id not in conversations:
                return jsonify({'success': False, 'error': 'Conversation not found'}), 404
            
            conv = conversations[conversation_id]
            return jsonify({
                'success': True,
                'conversation': conv
            })
        
        except Exception as e:
            logger.error(f"Failed to get conversation: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/chat/conversations', methods=['GET'])
    @login_required
    def list_conversations():
        """List all conversations"""
        try:
            conv_list = [
                {
                    'id': conv['id'],
                    'created_at': conv['created_at'],
                    'updated_at': conv['updated_at'],
                    'message_count': len(conv['messages']),
                    'assistant_types': list(set(conv.get('assistant_types_used', [])))
                }
                for conv in conversations.values()
            ]
            
            return jsonify({
                'success': True,
                'conversations': sorted(conv_list, key=lambda x: x['updated_at'], reverse=True)
            })
        
        except Exception as e:
            logger.error(f"Failed to list conversations: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500

    @app.route('/api/chat/conversations/<conversation_id>', methods=['DELETE'])
    @login_required
    def delete_conversation(conversation_id):
        """Delete conversation"""
        try:
            if conversation_id in conversations:
                del conversations[conversation_id]
                return jsonify({'success': True, 'message': 'Conversation deleted'})
            
            return jsonify({'success': False, 'error': 'Conversation not found'}), 404
        
        except Exception as e:
            logger.error(f"Failed to delete conversation: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500

    # ==========================================
    # ASSISTANT INFO ENDPOINT
    # ==========================================

    @app.route('/api/chat/assistants')
    def get_assistants():
        """Get list of available assistants"""
        try:
            from enhanced_prompts import ASSISTANT_TYPES
            
            assistants = [
                {
                    'id': name,
                    'name': config['description'],
                    'temperature': config['temperature'],
                    'keywords': config['keywords'][:5],  # Top 5 keywords
                    'capabilities': config['description']
                }
                for name, config in ASSISTANT_TYPES.items()
            ]
            
            return jsonify({
                'success': True,
                'assistants': assistants
            })
        
        except Exception as e:
            logger.error(f"Failed to get assistants: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500


    # ==========================================
    # FILE MANAGEMENT ROUTES
    # ==========================================

    @app.route('/api/files')
    @login_required
    def list_files():
        """List files with optional filtering"""
        try:
            folder_type = request.args.get('folder_type', 'all')
            files_result = file_handler.list_files(folder_type)
            return jsonify(files_result)
        except Exception as e:
            logger.error(f"Failed to list files: {e}")
            return jsonify({'error': f'Failed to list files: {str(e)}'}), 500

    @app.route('/api/files/converted')
    @login_required
    def list_converted_files():
        """List converted files"""
        try:
            files_result = file_handler.list_files(folder_type='converted')
            return jsonify(files_result)
        except Exception as e:
            logger.error(f"Failed to list converted files: {e}")
            return jsonify({'error': f'Failed to list files: {str(e)}'}), 500

    @app.route('/api/files/<filename>')
    @login_required
    def get_file_info(filename):
        """Get uploaded file information and content for preview"""
        try:
            if '..' in filename or '/' in filename or '\\' in filename:
                return jsonify({'error': 'Invalid filename'}), 400
            
            logger.info(f"Getting file info for: {filename}")
            
            blob_path = f"uploaded/{filename}"
            
            file_info = file_handler.get_file_info(filename, folder_type='uploaded', blob_path=blob_path if file_handler.use_azure else None)
            
            if not file_info['success']:
                logger.warning(f"File not found or error: {file_info}")
                return jsonify(file_info), 404
            
            return jsonify({
                'success': True,
                'filename': file_info['filename'],
                'folder_type': file_info['folder_type'],
                'content': file_info['content'],
                'content_type': file_info['content_type'],
                'file_size': file_info['file_size'],
                'parsed_content': file_info.get('parsed_content'),
                'storage_type': file_info.get('storage_type', 'local')
            })
            
        except Exception as e:
            logger.error(f"Failed to get file info: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/files/converted/<filename>')
    @login_required
    def get_converted_file_info(filename):
        """Get converted file information and content"""
        try:
            if '..' in filename or '/' in filename or '\\' in filename:
                return jsonify({'error': 'Invalid filename'}), 400
            
            logger.info(f"Getting converted file info for: {filename}")
            
            blob_path = f"converted/{filename}"
            
            file_info = file_handler.get_file_info(filename, folder_type='converted', blob_path=blob_path if file_handler.use_azure else None)
            
            if not file_info['success']:
                logger.warning(f"Converted file not found or error: {file_info}")
                return jsonify(file_info), 404
            
            return jsonify({
                'success': True,
                'filename': file_info['filename'],
                'folder_type': file_info['folder_type'],
                'content': file_info['content'],
                'content_type': file_info['content_type'],
                'file_size': file_info['file_size'],
                'parsed_content': file_info.get('parsed_content'),
                'metadata': file_info.get('metadata'),
                'storage_type': file_info.get('storage_type', 'local')
            })
            
        except Exception as e:
            logger.error(f"Failed to get converted file info: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/files/<filename>/download')
    @login_required
    def download_file(filename):
        """Download uploaded file"""
        try:
            if '..' in filename or '/' in filename or '\\' in filename:
                return jsonify({'error': 'Invalid filename'}), 400
            
            if file_handler.use_azure:
                blob_path = f"uploaded/{filename}"
                result = file_handler.azure_storage.download_file(blob_path)
                
                if not result['success']:
                    return jsonify({'error': 'File not found'}), 404
                
                return send_file(
                    BytesIO(result['content']),
                    mimetype='application/octet-stream',
                    as_attachment=True,
                    download_name=filename
                )
            else:
                file_path = os.path.join(file_handler.upload_folder, filename)
                if not os.path.exists(file_path):
                    return jsonify({'error': 'File not found'}), 404
                
                return send_file(file_path, as_attachment=True, download_name=filename)
                
        except Exception as e:
            logger.error(f"Failed to download file: {e}")
            return jsonify({'error': f'Failed to download file: {str(e)}'}), 500

    @app.route('/api/files/converted/<filename>/download')
    @login_required
    def download_converted_file(filename):
        """Download converted file"""
        try:
            if '..' in filename or '/' in filename or '\\' in filename:
                return jsonify({'error': 'Invalid filename'}), 400
            
            if file_handler.use_azure:
                blob_path = f"converted/{filename}"
                result = file_handler.azure_storage.download_file(blob_path)
                
                if not result['success']:
                    return jsonify({'error': 'File not found'}), 404
                
                return send_file(
                    BytesIO(result['content']),
                    mimetype='application/json',
                    as_attachment=True,
                    download_name=filename
                )
            else:
                file_path = os.path.join(file_handler.converted_folder, filename)
                if not os.path.exists(file_path):
                    return jsonify({'error': 'File not found'}), 404
                
                return send_file(file_path, as_attachment=True, download_name=filename)
                
        except Exception as e:
            logger.error(f"Failed to download converted file: {e}")
            return jsonify({'error': f'Failed to download file: {str(e)}'}), 500

    @app.route('/api/files/<folder_type>/<filename>/delete', methods=['DELETE'])
    @login_required
    def delete_file_route(folder_type, filename):
        """Delete file"""
        try:
            if '..' in filename or '/' in filename or '\\' in filename:
                return jsonify({'error': 'Invalid filename'}), 400
            
            if folder_type not in ['uploaded', 'converted']:
                return jsonify({'error': 'Invalid folder type'}), 400
            
            blob_path = None
            if file_handler.use_azure:
                blob_path = f"{folder_type}/{filename}"
            
            result = file_handler.delete_file(filename, folder_type, blob_path)
            
            if result['success']:
                return jsonify(result)
            else:
                return jsonify(result), 404
                
        except Exception as e:
            logger.error(f"Failed to delete file: {e}")
            return jsonify({'error': f'Failed to delete file: {str(e)}'}), 500

    # ==========================================
    # STORAGE MANAGEMENT ROUTES
    # ==========================================

    @app.route('/api/storage/stats')
    @login_required
    def get_storage_stats_endpoint():
        """Get storage statistics"""
        try:
            stats = file_handler.get_storage_stats()
            return jsonify({
                'success': stats.get('success', True),
                'folders': stats.get('folders', {}),
                'totals': stats.get('totals', {}),
                'storage_type': stats.get('storage_type', 'local')
            })
        except Exception as e:
            logger.error(f"Failed to get storage stats: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/storage/cleanup', methods=['POST'])
    @login_required
    def cleanup_storage():
        """Clean up old files"""
        try:
            data = request.get_json() or {}
            days_old = data.get('days_old', 7)
            
            if not isinstance(days_old, int) or days_old < 0:
                return jsonify({'error': 'Invalid days_old parameter'}), 400
            
            result = file_handler.cleanup_old_files(days_old)
            return jsonify(result)
            
        except Exception as e:
            logger.error(f"Failed to cleanup storage: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    # ==========================================
    # TEMPLATE FILTERS
    # ==========================================

    @app.template_filter('datetime')
    def format_datetime_filter(value, format_str='%Y-%m-%d %H:%M:%S'):
        """Format datetime for templates"""
        if isinstance(value, str):
            try:
                value = datetime.fromisoformat(value.replace('Z', '+00:00'))
            except:
                return value
        
        if isinstance(value, datetime):
            return value.strftime(format_str)
        
        return value

    @app.template_filter('filesize')
    def filesize_filter(value):
        """Format file size for templates"""
        return format_file_size(value)

    # ==========================================
    # TEMPLATE CONTEXT PROCESSORS
    # ==========================================

    @app.context_processor
    def inject_global_vars():
        """Inject global variables into templates"""
        return {
            'app_version': '1.0.0',
            'current_year': datetime.now().year
        }

    return app


# ==========================================
# CREATE APP INSTANCE
# ==========================================

app = create_app()


# ==========================================
# MAIN ENTRY POINT
# ==========================================

if __name__ == '__main__':
    os.makedirs('logs', exist_ok=True)
    os.makedirs('static/uploads', exist_ok=True)
    
    logger = setup_logger('app')
    
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    
    logger.info(f"Starting API Migration Tool on port {port}")
    logger.info(f"Authentication enabled - Please login to access the application")
    logger.info(f"✅ Azure Storage with local fallback enabled")
    logger.info(f"   - Converted files will use Azure Blob Storage if available")
    logger.info(f"   - Will automatically fallback to local filesystem if needed")
    logger.info(f"   - Check /api/storage/status for current storage configuration")
    logger.info(f"   - Health check available at /api/health")
    logger.info(f"✅ Azure OpenAI with model-aware parameters enabled")
    logger.info(f"   - All LLM calls use _build_chat_completion_params()")
    logger.info(f"   - Supports gpt-5-mini with max_completion_tokens")
    logger.info(f"   - Supports all OpenAI models with automatic parameter selection")
    logger.info(f"✅ prompts.py Integration enabled")
    logger.info(f"   - Using centralized LLM prompts")
    logger.info(f"   - Graceful fallback to defaults if not available")
    app.run(host='0.0.0.0', port=port, debug=debug)