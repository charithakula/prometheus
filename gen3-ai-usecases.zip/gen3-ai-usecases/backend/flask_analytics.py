# Flask Analytics API - Port 5002
# Add your code here
"""
Flask Analytics API - Port 5002
Proactive monitoring and predictive analytics with Helix integration
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import os
import logging
from datetime import datetime, timedelta
import json
import random
import requests

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('../logs/analytics.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Helix Configuration
HELIX_API_URL = os.getenv("HELIX_API_URL")
HELIX_API_KEY = os.getenv("HELIX_API_KEY")

# Mock metrics data
current_metrics = {
    'cpu_usage': 0,
    'memory_usage': 0,
    'response_time': 0,
    'error_rate': 0,
    'active_connections': 0
}

# Historical trends (simulated)
metrics_history = []

# Prediction model (simplified)
failure_predictions = []

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'Analytics API',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/predict-failure', methods=['POST'])
def predict_failure():
    """Predict potential system failures using ML"""
    try:
        data = request.json
        service_name = data.get('service_name', 'Unknown Service')
        metrics = data.get('metrics', {})
        
        logger.info(f"Analyzing metrics for {service_name}")
        
        # Extract metrics
        cpu = metrics.get('cpu_usage', random.uniform(20, 90))
        memory = metrics.get('memory_usage', random.uniform(30, 85))
        response_time = metrics.get('response_time', random.uniform(100, 2000))
        error_rate = metrics.get('error_rate', random.uniform(0, 15))
        
        # Simple prediction logic (in production, use actual ML model)
        risk_score = 0
        issues = []
        
        # CPU analysis
        if cpu > 80:
            risk_score += 30
            issues.append({
                'severity': 'high',
                'metric': 'CPU Usage',
                'current_value': f"{cpu:.1f}%",
                'threshold': '80%',
                'recommendation': 'Scale up CPU resources or optimize processes'
            })
        elif cpu > 70:
            risk_score += 15
            issues.append({
                'severity': 'medium',
                'metric': 'CPU Usage',
                'current_value': f"{cpu:.1f}%",
                'threshold': '70%',
                'recommendation': 'Monitor CPU usage closely'
            })
        
        # Memory analysis
        if memory > 85:
            risk_score += 30
            issues.append({
                'severity': 'high',
                'metric': 'Memory Usage',
                'current_value': f"{memory:.1f}%",
                'threshold': '85%',
                'recommendation': 'Increase memory allocation or fix memory leaks'
            })
        elif memory > 75:
            risk_score += 15
            issues.append({
                'severity': 'medium',
                'metric': 'Memory Usage',
                'current_value': f"{memory:.1f}%",
                'threshold': '75%',
                'recommendation': 'Review memory consumption patterns'
            })
        
        # Response time analysis
        if response_time > 1500:
            risk_score += 25
            issues.append({
                'severity': 'high',
                'metric': 'Response Time',
                'current_value': f"{response_time:.0f}ms",
                'threshold': '1500ms',
                'recommendation': 'Optimize queries and check network latency'
            })
        elif response_time > 1000:
            risk_score += 10
            issues.append({
                'severity': 'medium',
                'metric': 'Response Time',
                'current_value': f"{response_time:.0f}ms",
                'threshold': '1000ms',
                'recommendation': 'Consider performance optimization'
            })
        
        # Error rate analysis
        if error_rate > 5:
            risk_score += 25
            issues.append({
                'severity': 'high',
                'metric': 'Error Rate',
                'current_value': f"{error_rate:.1f}%",
                'threshold': '5%',
                'recommendation': 'Investigate error logs immediately'
            })
        elif error_rate > 2:
            risk_score += 10
            issues.append({
                'severity': 'medium',
                'metric': 'Error Rate',
                'current_value': f"{error_rate:.1f}%",
                'threshold': '2%',
                'recommendation': 'Review recent error patterns'
            })
        
        # Determine failure probability
        if risk_score >= 60:
            failure_probability = 'High'
            time_to_failure = f"{random.randint(1, 4)} hours"
            auto_ticket = True
        elif risk_score >= 30:
            failure_probability = 'Medium'
            time_to_failure = f"{random.randint(6, 24)} hours"
            auto_ticket = False
        else:
            failure_probability = 'Low'
            time_to_failure = 'No immediate concern'
            auto_ticket = False
        
        prediction = {
            'service_name': service_name,
            'timestamp': datetime.now().isoformat(),
            'risk_score': risk_score,
            'failure_probability': failure_probability,
            'estimated_time_to_failure': time_to_failure,
            'issues': issues,
            'metrics_analyzed': {
                'cpu_usage': f"{cpu:.1f}%",
                'memory_usage': f"{memory:.1f}%",
                'response_time': f"{response_time:.0f}ms",
                'error_rate': f"{error_rate:.1f}%"
            }
        }
        
        # Store prediction
        failure_predictions.append(prediction)
        
        # Auto-create Helix ticket if high risk
        ticket_id = None
        if auto_ticket:
            ticket_id = create_helix_ticket(service_name, prediction)
            prediction['helix_ticket_id'] = ticket_id
        
        logger.info(f"Prediction completed. Risk: {failure_probability}, Score: {risk_score}")
        
        return jsonify({
            'success': True,
            'prediction': prediction,
            'auto_ticket_created': auto_ticket,
            'ticket_id': ticket_id
        })
        
    except Exception as e:
        logger.error(f"Error predicting failure: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/metrics-dashboard', methods=['GET'])
def get_metrics_dashboard():
    """Get current metrics for dashboard"""
    try:
        # Generate realistic random metrics
        metrics = {
            'timestamp': datetime.now().isoformat(),
            'services': [
                {
                    'name': 'MuleSoft API Gateway',
                    'status': 'healthy' if random.random() > 0.1 else 'warning',
                    'cpu_usage': random.uniform(30, 75),
                    'memory_usage': random.uniform(40, 70),
                    'response_time': random.uniform(200, 800),
                    'requests_per_minute': random.randint(100, 500),
                    'error_rate': random.uniform(0, 3)
                },
                {
                    'name': 'Boomi Process Engine',
                    'status': 'healthy' if random.random() > 0.1 else 'warning',
                    'cpu_usage': random.uniform(25, 65),
                    'memory_usage': random.uniform(35, 75),
                    'response_time': random.uniform(150, 700),
                    'requests_per_minute': random.randint(80, 400),
                    'error_rate': random.uniform(0, 2)
                },
                {
                    'name': 'SAP PI/PO',
                    'status': 'healthy' if random.random() > 0.15 else 'warning',
                    'cpu_usage': random.uniform(35, 80),
                    'memory_usage': random.uniform(45, 80),
                    'response_time': random.uniform(300, 1200),
                    'requests_per_minute': random.randint(50, 300),
                    'error_rate': random.uniform(0, 4)
                }
            ],
            'system_health': {
                'overall_status': 'operational',
                'total_services': 3,
                'healthy_services': 3,
                'warning_services': 0,
                'critical_services': 0
            }
        }
        
        return jsonify({
            'success': True,
            'metrics': metrics
        })
        
    except Exception as e:
        logger.error(f"Error getting metrics: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/historical-trends', methods=['GET'])
def get_historical_trends():
    """Get historical metrics trends"""
    try:
        hours = int(request.args.get('hours', 24))
        
        # Generate historical data
        trends = []
        now = datetime.now()
        
        for i in range(hours):
            timestamp = now - timedelta(hours=hours-i)
            trends.append({
                'timestamp': timestamp.isoformat(),
                'cpu_usage': random.uniform(30, 80),
                'memory_usage': random.uniform(40, 75),
                'response_time': random.uniform(200, 1000),
                'error_rate': random.uniform(0, 5),
                'throughput': random.randint(100, 500)
            })
        
        return jsonify({
            'success': True,
            'trends': trends,
            'period': f'{hours} hours'
        })
        
    except Exception as e:
        logger.error(f"Error getting trends: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/train-model', methods=['POST'])
def train_model():
    """Train or retrain the prediction model"""
    try:
        data = request.json
        training_data = data.get('data', [])
        
        logger.info(f"Training model with {len(training_data)} data points")
        
        # Simulate model training
        import time
        time.sleep(2)  # Simulate training time
        
        model_info = {
            'model_id': f"model_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            'training_samples': len(training_data),
            'accuracy': random.uniform(0.85, 0.95),
            'training_time': '2.3 seconds',
            'status': 'completed',
            'timestamp': datetime.now().isoformat()
        }
        
        logger.info(f"Model training completed: {model_info['model_id']}")
        
        return jsonify({
            'success': True,
            'model': model_info
        })
        
    except Exception as e:
        logger.error(f"Error training model: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/recent-predictions', methods=['GET'])
def get_recent_predictions():
    """Get recent failure predictions"""
    try:
        limit = int(request.args.get('limit', 10))
        
        recent = failure_predictions[-limit:][::-1]  # Last N, reversed
        
        return jsonify({
            'success': True,
            'predictions': recent,
            'total': len(failure_predictions)
        })
        
    except Exception as e:
        logger.error(f"Error getting predictions: {str(e)}")
        return jsonify({'error': str(e)}), 500

def create_helix_ticket(service_name, prediction):
    """Create a ticket in Helix ITSM"""
    try:
        # In production, make actual API call to Helix
        if not HELIX_API_URL or not HELIX_API_KEY:
            logger.warning("Helix credentials not configured, simulating ticket creation")
            return f"SIM{random.randint(10000, 99999)}"
        
        # Prepare ticket data
        ticket_data = {
            'summary': f'Predicted failure: {service_name}',
            'description': f'Risk Score: {prediction["risk_score"]}\n'
                          f'Probability: {prediction["failure_probability"]}\n'
                          f'Issues: {len(prediction["issues"])}',
            'priority': 'High' if prediction['risk_score'] >= 60 else 'Medium',
            'category': 'Performance',
            'service': service_name
        }
        
        # Make API call (commented out for demo)
        # response = requests.post(
        #     f"{HELIX_API_URL}/tickets",
        #     headers={'Authorization': f'Bearer {HELIX_API_KEY}'},
        #     json=ticket_data
        # )
        # ticket_id = response.json()['ticket_id']
        
        # Simulate ticket ID
        ticket_id = f"INC{random.randint(100000, 999999)}"
        
        logger.info(f"Helix ticket created: {ticket_id}")
        return ticket_id
        
    except Exception as e:
        logger.error(f"Error creating Helix ticket: {str(e)}")
        return None

if __name__ == '__main__':
    logger.info("Starting Analytics API on port 5002")
    app.run(debug=True, port=5002)