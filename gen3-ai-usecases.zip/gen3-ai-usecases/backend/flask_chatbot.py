# Flask Chatbot API - Port 5001
# Add your code here
"""
Flask Chatbot API - Port 5001
AI Knowledge Assistant trained on historical tickets
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from openai import AzureOpenAI
from dotenv import load_dotenv
import os
import logging
from datetime import datetime
import json
import random

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('../logs/chatbot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Azure OpenAI Configuration
client = AzureOpenAI(
    api_key=os.getenv("OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
)

# Conversation history (in-memory)
conversations = {}

# Mock historical tickets database
historical_tickets = [
    {
        "ticket_id": "INC0012345",
        "title": "MuleSoft API Gateway timeout",
        "category": "Performance",
        "description": "API Gateway experiencing timeout after 30 seconds",
        "resolution": "Increased timeout value in gateway configuration and optimized backend query",
        "resolution_time": "2 hours"
    },
    {
        "ticket_id": "INC0012346",
        "title": "Boomi process deployment failed",
        "category": "Deployment",
        "description": "Process deployment fails with authentication error",
        "resolution": "Updated deployment credentials and verified firewall rules",
        "resolution_time": "1 hour"
    },
    {
        "ticket_id": "INC0012347",
        "title": "SAP PI mapping error",
        "category": "Integration",
        "description": "XML mapping transformation failing for certain field types",
        "resolution": "Fixed mapping logic for date fields and added error handling",
        "resolution_time": "3 hours"
    },
    {
        "ticket_id": "INC0012348",
        "title": "Database connection pool exhausted",
        "category": "Database",
        "description": "Application unable to get database connections",
        "resolution": "Increased connection pool size and fixed connection leaks",
        "resolution_time": "4 hours"
    },
    {
        "ticket_id": "INC0012349",
        "title": "SSL certificate expired",
        "category": "Security",
        "description": "API calls failing due to expired SSL certificate",
        "resolution": "Renewed SSL certificate and updated trust store",
        "resolution_time": "1 hour"
    }
]

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'Chatbot API',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/chat', methods=['POST'])
def chat():
    """Handle chat messages"""
    try:
        data = request.json
        message = data.get('message', '')
        session_id = data.get('session_id', 'default')
        
        if not message:
            return jsonify({'error': 'No message provided'}), 400
        
        logger.info(f"Chat request from session {session_id}: {message[:50]}...")
        
        # Initialize conversation history for session
        if session_id not in conversations:
            conversations[session_id] = []
        
        # Add user message to history
        conversations[session_id].append({
            "role": "user",
            "content": message
        })
        
        # Create system prompt with ticket knowledge
        system_prompt = """You are an AI assistant specializing in integration platform support. 
You have access to historical ticket resolutions and can help troubleshoot issues.

When answering:
1. Be specific and technical
2. Reference similar past tickets if relevant
3. Provide step-by-step solutions
4. Suggest preventive measures
5. Mention if the issue requires escalation

Keep responses concise but informative."""
        
        # Search for relevant tickets
        relevant_tickets = search_similar_tickets(message)
        
        # Add context from relevant tickets
        context = ""
        if relevant_tickets:
            context = "\n\nRelevant historical tickets:\n"
            for ticket in relevant_tickets[:3]:
                context += f"\n- {ticket['title']}: {ticket['resolution']}"
        
        # Build messages for API call
        messages = [{"role": "system", "content": system_prompt + context}]
        messages.extend(conversations[session_id][-5:])  # Last 5 messages for context
        
        # Call Azure OpenAI
        response = client.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
            messages=messages,
            temperature=0.7,
            max_tokens=1000
        )
        
        assistant_message = response.choices[0].message.content
        
        # Add assistant response to history
        conversations[session_id].append({
            "role": "assistant",
            "content": assistant_message
        })
        
        # Extract suggested actions
        suggested_actions = extract_actions(assistant_message)
        
        logger.info(f"Chat response generated for session {session_id}")
        
        return jsonify({
            'success': True,
            'response': assistant_message,
            'suggested_actions': suggested_actions,
            'related_tickets': [t['ticket_id'] for t in relevant_tickets[:3]],
            'session_id': session_id
        })
        
    except Exception as e:
        logger.error(f"Error in chat: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/search-tickets', methods=['POST'])
def search_tickets():
    """Search historical tickets"""
    try:
        data = request.json
        query = data.get('query', '')
        category = data.get('category', 'all')
        
        if not query:
            return jsonify({'error': 'No query provided'}), 400
        
        logger.info(f"Searching tickets: {query}")
        
        # Search tickets
        results = search_similar_tickets(query, category)
        
        return jsonify({
            'success': True,
            'results': results,
            'total': len(results)
        })
        
    except Exception as e:
        logger.error(f"Error searching tickets: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/ticket-stats', methods=['GET'])
def ticket_stats():
    """Get ticket statistics"""
    try:
        # Calculate statistics
        categories = {}
        total_resolution_time = 0
        
        for ticket in historical_tickets:
            category = ticket['category']
            categories[category] = categories.get(category, 0) + 1
            
            # Extract hours from resolution time
            time_str = ticket['resolution_time']
            hours = int(time_str.split()[0])
            total_resolution_time += hours
        
        avg_resolution_time = total_resolution_time / len(historical_tickets) if historical_tickets else 0
        
        stats = {
            'total_tickets': len(historical_tickets),
            'categories': categories,
            'avg_resolution_time': f"{avg_resolution_time:.1f} hours",
            'most_common_category': max(categories.items(), key=lambda x: x[1])[0] if categories else None
        }
        
        return jsonify({
            'success': True,
            'stats': stats
        })
        
    except Exception as e:
        logger.error(f"Error getting stats: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/clear-session', methods=['POST'])
def clear_session():
    """Clear chat session"""
    try:
        data = request.json
        session_id = data.get('session_id', 'default')
        
        if session_id in conversations:
            del conversations[session_id]
        
        return jsonify({
            'success': True,
            'message': 'Session cleared'
        })
        
    except Exception as e:
        logger.error(f"Error clearing session: {str(e)}")
        return jsonify({'error': str(e)}), 500

def search_similar_tickets(query, category='all'):
    """Search for similar tickets using keyword matching"""
    query_lower = query.lower()
    results = []
    
    for ticket in historical_tickets:
        if category != 'all' and ticket['category'].lower() != category.lower():
            continue
        
        # Simple keyword matching
        score = 0
        if query_lower in ticket['title'].lower():
            score += 3
        if query_lower in ticket['description'].lower():
            score += 2
        
        # Check for individual words
        words = query_lower.split()
        for word in words:
            if len(word) > 3:  # Skip short words
                if word in ticket['title'].lower():
                    score += 1
                if word in ticket['description'].lower():
                    score += 1
        
        if score > 0:
            ticket_copy = ticket.copy()
            ticket_copy['relevance_score'] = score
            results.append(ticket_copy)
    
    # Sort by relevance
    results.sort(key=lambda x: x['relevance_score'], reverse=True)
    return results

def extract_actions(message):
    """Extract suggested actions from message"""
    actions = []
    
    # Simple keyword-based action extraction
    action_keywords = {
        'check': 'Check configuration',
        'restart': 'Restart service',
        'verify': 'Verify settings',
        'update': 'Update configuration',
        'review': 'Review logs',
        'contact': 'Contact support',
        'increase': 'Increase resources',
        'monitor': 'Monitor metrics'
    }
    
    message_lower = message.lower()
    for keyword, action in action_keywords.items():
        if keyword in message_lower:
            actions.append(action)
    
    return list(set(actions))[:4]  # Return unique actions, max 4

if __name__ == '__main__':
    logger.info("Starting Chatbot API on port 5001")
    app.run(debug=True, port=5001)