# Gen 3.0 AI Use Cases

AI-powered tools for integration development and operations, featuring code review, knowledge assistance, and predictive analytics.

## 🚀 Features

### 1. **AI Code Review & Unit Test Generator**
- Analyzes integration code for bugs, security issues, and performance problems
- Auto-generates unit test scripts
- Supports MuleSoft, Boomi, SAP, TIBCO, and other platforms

### 2. **AI Knowledge Assistant (Chatbot)**
- Trained on historical ticket data
- Provides intelligent troubleshooting suggestions
- Searches similar past issues for faster resolution

### 3. **Proactive Analytics & Helix Integration**
- Predicts system failures using ML
- Auto-creates Helix ITSM tickets for high-risk issues
- Real-time service health monitoring

---

## 📁 Project Structure

```
gen3-ai-usecases/
├── backend/
│   ├── flask_code_review.py      (Port 5000)
│   ├── flask_chatbot.py           (Port 5001)
│   ├── flask_analytics.py         (Port 5002)
│   ├── requirements.txt
│   ├── .env
│   └── models/
├── frontend/
│   ├── code-review.html
│   ├── chatbot.html
│   ├── analytics.html
│   └── assets/
├── data/
│   ├── reviews/
│   ├── tickets/
│   └── metrics/
├── logs/
├── tests/
├── docs/
├── README.md
├── .gitignore
└── docker-compose.yml
```

---

## 🔧 Installation & Setup

### Prerequisites
- Python 3.8 or higher
- Azure OpenAI API access
- (Optional) Helix ITSM API credentials

### Step 1: Clone or Create Project Structure

```bash
# Run the Python script to create folder structure
python create_structure.py
```

### Step 2: Set Up Virtual Environment

```bash
cd gen3-ai-usecases/backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate

#if you use git bash 
source venv/Scripts/activate

# Mac/Linux:
source venv/bin/activate
```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 4: Configure Environment Variables

1. Copy the `.env` template to `.env` in the backend folder
2. Update the following required values:

```env
OPENAI_API_KEY=your_actual_api_key
AZURE_OPENAI_ENDPOINT=https://your-instance.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4
HELIX_API_URL=https://your-helix-instance.com/api
HELIX_API_KEY=your_helix_key
```

### Step 5: Start Backend Services

Open **3 separate terminals** and run:

```bash
# Terminal 1 - Code Review API
cd backend
python flask_code_review.py

# Terminal 2 - Chatbot API
cd backend
python flask_chatbot.py

# Terminal 3 - Analytics API
cd backend
python flask_analytics.py
```

### Step 6: Open Frontend Applications

Open the HTML files in your browser:
- `frontend/code-review.html` - Code review interface
- `frontend/chatbot.html` - Chat interface
- `frontend/analytics.html` - Analytics dashboard

---

## 📡 API Endpoints

### Code Review Service (Port 5000)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| POST | `/api/analyze-code` | Analyze code quality |
| POST | `/api/generate-tests` | Generate unit tests |
| GET | `/api/review-history` | Get review history |
| GET | `/api/platforms` | Get supported platforms |

**Example Request:**
```json
POST /api/analyze-code
{
  "code": "public class Example { ... }",
  "platform": "MuleSoft",
  "language": "Java"
}
```

### Chatbot Service (Port 5001)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| POST | `/api/chat` | Send chat message |
| POST | `/api/search-tickets` | Search historical tickets |
| GET | `/api/ticket-stats` | Get ticket statistics |
| POST | `/api/clear-session` | Clear chat session |

**Example Request:**
```json
POST /api/chat
{
  "message": "How do I fix a timeout error?",
  "session_id": "session_123"
}
```

### Analytics Service (Port 5002)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| POST | `/api/predict-failure` | Predict system failure |
| GET | `/api/metrics-dashboard` | Get dashboard metrics |
| GET | `/api/historical-trends` | Get historical trends |
| POST | `/api/train-model` | Train ML model |
| GET | `/api/recent-predictions` | Get recent predictions |

**Example Request:**
```json
POST /api/predict-failure
{
  "service_name": "MuleSoft API Gateway",
  "metrics": {
    "cpu_usage": 85,
    "memory_usage": 80,
    "response_time": 1500,
    "error_rate": 5
  }
}
```

---

## 🧪 Testing

### Test Backend APIs

```bash
# Test Code Review API
curl http://localhost:5000/api/health

# Test Chatbot API
curl http://localhost:5001/api/health

# Test Analytics API
curl http://localhost:5002/api/health
```

### Run Unit Tests

```bash
cd tests
pytest
```

---

## 🎨 Customization

### Change SCE Brand Colors

Edit the CSS in HTML files:
```css
/* Primary Orange */
#FF6B35

/* Navy Blue */
#003A70
```

### Add New Platforms

Update `flask_code_review.py`:
```python
platforms = [
    'MuleSoft',
    'Boomi',
    # Add your platform here
    'Your Platform'
]
```

### Modify Prediction Thresholds

Update `flask_analytics.py`:
```python
# CPU threshold
if cpu > 80:  # Change this value
    risk_score += 30
```

---

## 🐳 Docker Deployment (Optional)

### Build and Run with Docker Compose

```bash
docker-compose up -d
```

This will start all three services in containers.

---

## 📊 Monitoring & Logs

### View Logs

```bash
# Code review logs
tail -f logs/code_review.log

# Chatbot logs
tail -f logs/chatbot.log

# Analytics logs
tail -f logs/analytics.log
```

### Log Levels

Adjust in `.env`:
```env
LOG_LEVEL=INFO  # Options: DEBUG, INFO, WARNING, ERROR
```

---

## 🔒 Security Best Practices

1. **Never commit `.env` files** - Contains sensitive API keys
2. **Use HTTPS in production** - Don't expose HTTP endpoints
3. **Implement rate limiting** - Prevent API abuse
4. **Regular updates** - Keep dependencies updated
5. **API key rotation** - Change keys periodically

---

## 🐛 Troubleshooting

### Issue: "Connection refused" error

**Solution:** Ensure backend services are running
```bash
# Check if services are running
lsof -i :5000
lsof -i :5001
lsof -i :5002
```

### Issue: "Module not found" error

**Solution:** Install dependencies
```bash
pip install -r requirements.txt
```

### Issue: Azure OpenAI authentication failed

**Solution:** Verify your credentials in `.env`
```bash
# Test API key
curl https://your-instance.openai.azure.com/ \
  -H "api-key: YOUR_API_KEY"
```

### Issue: CORS errors in browser

**Solution:** Enable CORS in Flask apps (already configured)

---

## 📚 Additional Resources

- [Azure OpenAI Documentation](https://learn.microsoft.com/en-us/azure/ai-services/openai/)
- [Flask Documentation](https://flask.palletsprojects.com/)
- [Helix ITSM API Guide](https://docs.bmc.com/docs/helixitsm)

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📝 License

Proprietary - Gen 3.0 Program

---

## 👥 Support

For questions or issues:
- Email: support@yourcompany.com
- Internal Teams Channel: #gen3-support

---

## 🎯 Roadmap

- [ ] Add more integration platforms
- [ ] Implement user authentication
- [ ] Create admin dashboard
- [ ] Add API documentation (Swagger)
- [ ] Implement caching with Redis
- [ ] Add email notifications
- [ ] Create mobile app
- [ ] Advanced ML model training

---

**Built with ❤️ for Gen 3.0 Program**