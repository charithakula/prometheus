const API_BASE_URL = 'http://localhost:5000/api';
let currentResults = null;
let currentSource = 'paste';
let uploadedFileContent = null;
let isUsingRealAI = false;
let currentTestCases = [];
let currentIssues = [];
let selectedIssues = [];
let originalCode = '';
let manualPlatformOverride = null;

const fileUploadArea = document.getElementById('fileUploadArea');
const fileInput = document.getElementById('fileInput');

fileUploadArea.addEventListener('dragover', (e) => { e.preventDefault(); fileUploadArea.classList.add('dragover'); });
fileUploadArea.addEventListener('dragleave', () => { fileUploadArea.classList.remove('dragover'); });
fileUploadArea.addEventListener('drop', (e) => { e.preventDefault(); fileUploadArea.classList.remove('dragover'); if (e.dataTransfer.files.length > 0) handleFile(e.dataTransfer.files[0]); });
fileInput.addEventListener('change', (e) => { if (e.target.files[0]) handleFile(e.target.files[0]); });

function handleFile(file) {
    if (file.size > 5 * 1024 * 1024) { showToast('File size exceeds 5MB limit', 'error'); return; }
    const reader = new FileReader();
    reader.onload = (e) => {
        uploadedFileContent = e.target.result;
        document.getElementById('fileName').textContent = file.name;
        document.getElementById('fileSize').textContent = formatFileSize(file.size);
        document.getElementById('uploadedFile').classList.add('show');
        fileUploadArea.style.display = 'none';
        showToast('File uploaded successfully!', 'success');
    };
    reader.readAsText(file);
}

function removeFile() {
    uploadedFileContent = null;
    document.getElementById('uploadedFile').classList.remove('show');
    fileUploadArea.style.display = 'block';
    fileInput.value = '';
}

function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function switchSource(source) {
    currentSource = source;
    document.querySelectorAll('.source-tab').forEach(tab => tab.classList.remove('active'));
    
    const buttons = document.querySelectorAll('.source-tab');
    buttons.forEach(btn => {
        if (btn.textContent.toLowerCase().includes(source.toLowerCase()) || 
            (source === 'paste' && btn.textContent.includes('Paste')) ||
            (source === 'file' && btn.textContent.includes('Upload')) ||
            (source === 'git' && btn.textContent.includes('Git'))) {
            btn.classList.add('active');
        }
    });
    
    document.querySelectorAll('.input-source-content').forEach(content => content.classList.remove('active'));
    document.getElementById(source + 'Source').classList.add('active');
}

function setupPlatformSelector() {
    const platformBadge = document.getElementById('platformBadge');
    
    if (document.getElementById('platformOverride')) return;
    
    const platformSelector = document.createElement('select');
    platformSelector.id = 'platformOverride';
    platformSelector.className = 'form-input';
    platformSelector.style.marginTop = '10px';
    platformSelector.innerHTML = `
        <option value="">-- Auto-Detect Platform --</option>
        <option value="python-flask">Python Flask</option>
        <option value="python-django">Python Django</option>
        <option value="java-spring-boot">Java Spring Boot</option>
        <option value="node-express">Node.js Express</option>
        <option value="javascript">JavaScript</option>
        <option value="java">Java</option>
        <option value="python">Python</option>
        <option value="php">PHP</option>
        <option value="dotnet-csharp">.NET/C#</option>
        <option value="golang">Go/Golang</option>
        <option value="rust">Rust</option>
        <option value="kotlin">Kotlin</option>
        <option value="swift">Swift</option>
        <option value="mulesoft">MuleSoft</option>
        <option value="boomi">Dell Boomi</option>
        <option value="sap">SAP PI/PO</option>
        <option value="tibco">TIBCO</option>
        <option value="informatica">Informatica</option>
        <option value="talend">Talend</option>
        <option value="kafka">Apache Kafka</option>
        <option value="xml">XML</option>
        <option value="json">JSON</option>
        <option value="generic">Generic</option>
    `;
    
    platformSelector.addEventListener('change', (e) => {
        manualPlatformOverride = e.target.value || null;
        if (manualPlatformOverride) {
            platformBadge.innerHTML = `✓ Manual: ${platformSelector.options[platformSelector.selectedIndex].text}`;
            platformBadge.style.color = 'var(--success)';
        } else {
            platformBadge.innerHTML = 'Auto-Detection Enabled';
            platformBadge.style.color = 'var(--primary-green)';
        }
    });
    
    platformBadge.parentElement.appendChild(platformSelector);
}

function updateAIStatus(usingRealAI) {
    isUsingRealAI = usingRealAI;
    const badge = document.getElementById('aiModeBadge');
    const indicator = document.getElementById('resultAiIndicator');
    
    if (usingRealAI) {
        badge.className = 'ai-status-badge real-ai';
        badge.innerHTML = '<span>Real AI Active</span>';
        badge.style.display = 'flex';
        indicator.className = 'live-ai-indicator ai show';
        indicator.textContent = 'AI Generated';
    } else {
        badge.innerHTML = '<span>Mock Mode</span>';
        badge.style.display = 'none';
        indicator.className = 'live-ai-indicator mock show';
        indicator.textContent = 'Mock Data';
    }
}

async function analyzeCode() {
    let code = '';
    
    if (currentSource === 'paste') {
        code = document.getElementById('codeInput').value.trim();
        if (!code) { showToast('Please enter code to analyze', 'error'); return; }
    } else if (currentSource === 'file') {
        if (!uploadedFileContent) { showToast('Please upload a file first', 'error'); return; }
        code = uploadedFileContent;
    } else if (currentSource === 'git') {
        const repoUrl = document.getElementById('gitRepoUrl').value.trim();
        const filePath = document.getElementById('gitFilePath').value.trim();
        if (!repoUrl || !filePath) { showToast('Please provide repository URL and file path', 'error'); return; }
        try {
            code = await fetchFromGit(repoUrl, document.getElementById('gitBranch').value.trim(), filePath, '');
            if (!code) { showToast('Failed to fetch code from Git repository', 'error'); return; }
            showToast('Code fetched from GitHub successfully!', 'success');
        } catch (error) { showToast('Error fetching from Git: ' + error.message, 'error'); return; }
    }

    originalCode = code;
    
    // Use manual override if set, otherwise auto-detect
    let platform = manualPlatformOverride || detectPlatform(code);
    
    if (manualPlatformOverride) {
        console.log(`Using manual platform override: ${platform}`);
    }
    
    displayDetectedPlatform(platform);

    const btn = document.getElementById('analyzeBtn');
    btn.disabled = true;
    btn.innerHTML = '<div class="spinner"></div><span>Analyzing Code...</span>';
    document.getElementById('aiProcessingOverlay').classList.add('show');

    try {
        const analyzeResponse = await fetch(`${API_BASE_URL}/analyze-code`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code, platform })
        });

        if (!analyzeResponse.ok) throw new Error('Analysis failed');
        const analyzeData = await analyzeResponse.json();
        const usingAI = analyzeData.source === 'ai';
        
        let analysisData;
        try { analysisData = JSON.parse(analyzeData.analysis); } catch (e) { analysisData = analyzeData.analysis; }

        const testsResponse = await fetch(`${API_BASE_URL}/generate-tests`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code, platform })
        });

        if (testsResponse.ok) {
            const testsData = await testsResponse.json();
            analysisData.tests = testsData.tests;
            analysisData.test_cases = testsData.test_cases;
        }

        currentResults = analysisData;
        displayResults(analysisData);
        updateAIStatus(usingAI);
        
        const message = usingAI ? 'Analysis completed with Real AI!' : 'Using mock data - AI unavailable';
        showToast(message, usingAI ? 'success' : 'warning');

    } catch (error) {
        showToast('API error. Using demo mode.', 'warning');
        const demoResults = generateDemoResults();
        currentResults = demoResults;
        displayResults(demoResults);
        updateAIStatus(false);
    } finally {
        document.getElementById('aiProcessingOverlay').classList.remove('show');
        btn.disabled = false;
        btn.innerHTML = '<span>🔍</span><span>Analyze Code & Generate Tests</span>';
    }
}

async function fetchFromGit(repoUrl, branch, filePath, token) {
    const githubMatch = repoUrl.match(/github\.com\/([^\/]+)\/([^\/\.]+)/);
    if (!githubMatch) throw new Error('Invalid GitHub URL');
    const owner = githubMatch[1];
    const repo = githubMatch[2];
    const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}?ref=${branch}`;
    const headers = { 'Accept': 'application/vnd.github.v3.raw' };
    if (token) headers['Authorization'] = `token ${token}`;
    const response = await fetch(apiUrl, { headers });
    if (!response.ok) throw new Error(`GitHub API error: ${response.statusText}`);
    return await response.text();
}

function detectPlatform(code) {
    const lowerCode = code.toLowerCase();
    
    // Check for specific integration platforms FIRST (most specific)
    if (lowerCode.includes('mulesoft') || lowerCode.includes('mule esb') || 
        (lowerCode.includes('mule') && lowerCode.includes('flow')) || 
        lowerCode.includes('dataweave')) {
        return 'mulesoft';
    }
    
    if (lowerCode.includes('boomi') || lowerCode.includes('dell boomi')) {
        return 'boomi';
    }
    
    if (lowerCode.includes('sap pi') || lowerCode.includes('sap po') || 
        lowerCode.includes('sap hana') || lowerCode.includes('odata') ||
        (lowerCode.includes('sap') && lowerCode.includes('interface'))) {
        return 'sap';
    }
    
    if (lowerCode.includes('tibco') || lowerCode.includes('businessworks')) {
        return 'tibco';
    }
    
    if (lowerCode.includes('informatica')) {
        return 'informatica';
    }
    
    if (lowerCode.includes('talend')) {
        return 'talend';
    }
    
    if (lowerCode.includes('apache kafka') || lowerCode.includes('kafka')) {
        return 'kafka';
    }
    
    // Check for REST API patterns
    if ((lowerCode.includes('@restcontroller') || lowerCode.includes('@getmapping') || 
         lowerCode.includes('@postmapping') || lowerCode.includes('restcontroller')) &&
        (lowerCode.includes('class ') || lowerCode.includes('public '))) {
        return 'java-rest-api';
    }
    
    // Check for specific framework patterns (more specific first)
    if (lowerCode.includes('from flask import') || 
        (lowerCode.includes('flask') && lowerCode.includes('@app.route'))) {
        return 'python-flask';
    }
    
    if (lowerCode.includes('from django') || lowerCode.includes('django.') ||
        (lowerCode.includes('django') && lowerCode.includes('models'))) {
        return 'python-django';
    }
    
    if (lowerCode.includes('spring boot') || lowerCode.includes('springbootapplication') ||
        (lowerCode.includes('spring') && (lowerCode.includes('@autowired') || 
         lowerCode.includes('@component') || lowerCode.includes('@service')))) {
        return 'java-spring-boot';
    }
    
    if (lowerCode.includes('express') || 
        ((lowerCode.includes('app.get') || lowerCode.includes('app.post')) &&
        lowerCode.includes('require'))) {
        return 'node-express';
    }
    
    if (lowerCode.includes('async function') || lowerCode.includes('await ') ||
        (lowerCode.includes('promise') && lowerCode.includes('fetch'))) {
        return 'javascript';
    }
    
    if (lowerCode.includes('.net') || lowerCode.includes('using system') ||
        (lowerCode.includes('namespace ') && lowerCode.includes('public class'))) {
        return 'dotnet-csharp';
    }
    
    if (lowerCode.includes('using http') || lowerCode.includes('gomod') ||
        lowerCode.includes('package main')) {
        return 'golang';
    }
    
    if (lowerCode.includes('public class') || 
        (lowerCode.includes('package ') && lowerCode.includes('class '))) {
        return 'java';
    }
    
    if (lowerCode.includes('<?php') || lowerCode.includes('<?=')) {
        return 'php';
    }
    
    if (lowerCode.includes('<?xml') || 
        (lowerCode.includes('<') && lowerCode.includes('xmlns'))) {
        return 'xml';
    }
    
    if (lowerCode.includes('from ') && lowerCode.includes('import ') &&
        (lowerCode.includes('def ') || lowerCode.includes('class ') ||
         lowerCode.includes('import os') || lowerCode.includes('import sys'))) {
        return 'python';
    }
    
    if (lowerCode.includes('def ') && 
        !(lowerCode.includes('function ') || lowerCode.includes('const '))) {
        return 'python';
    }
    
    if (lowerCode.includes('async fn') || lowerCode.includes('fn main()')) {
        return 'rust';
    }
    
    if (lowerCode.includes('fun ') && 
        (lowerCode.includes('class ') || lowerCode.includes('data class'))) {
        return 'kotlin';
    }
    
    if (lowerCode.includes('interface ') && 
        lowerCode.includes('implementation ') &&
        (lowerCode.includes('func ') || lowerCode.includes('var '))) {
        return 'swift';
    }
    
    if (lowerCode.includes('function ') || lowerCode.includes('const ') ||
        lowerCode.includes('let ') || lowerCode.includes('=>') ||
        lowerCode.includes('require(') || lowerCode.includes('module.exports')) {
        return 'javascript';
    }
    
    if ((lowerCode.startsWith('{') || lowerCode.includes('":'))) {
        return 'json';
    }
    
    return 'generic';
}

function displayDetectedPlatform(platform) {
    const platformNames = { 
        'java-rest-api': 'Java REST API',
        'python-flask': 'Python (Flask)',
        'python-django': 'Python (Django)',
        'java-spring-boot': 'Java (Spring Boot)',
        'node-express': 'Node.js (Express)',
        'dotnet-csharp': '.NET/C#',
        'golang': 'Go/Golang',
        'python': 'Python',
        'java': 'Java',
        'javascript': 'JavaScript/Node.js',
        'php': 'PHP',
        'rust': 'Rust',
        'kotlin': 'Kotlin',
        'swift': 'Swift',
        'boomi': 'Dell Boomi',
        'sap': 'SAP PI/PO',
        'tibco': 'TIBCO',
        'informatica': 'Informatica',
        'talend': 'Talend',
        'kafka': 'Apache Kafka',
        'xml': 'XML',
        'json': 'JSON',
        'generic': 'Generic'
    };
    document.getElementById('platformBadge').innerHTML = `Detected: ${platformNames[platform] || 'Generic'}`;
}

function displayResults(data) {
    document.getElementById('emptyState').style.display = 'none';
    document.getElementById('resultsContent').classList.add('active');
    displayIssues(data.issues || []);
    document.getElementById('testCode').textContent = data.tests || 'No tests generated';
    
    let testCases = data.test_cases || parseTestCases(data.tests || '');
    displayTestCases(testCases);
    displayMetrics(data.metrics || {});
}

function displayIssues(issues) {
    const container = document.getElementById('issuesContainer');
    if (issues.length === 0) { 
        container.innerHTML = '<p style="text-align: center; color: var(--text-gray); padding: 40px; font-size: 13px;">No issues found!</p>'; 
        return; 
    }
    
    currentIssues = issues;
    selectedIssues = [];
    
    const high = issues.filter(i => i.severity === 'high').length;
    const medium = issues.filter(i => i.severity === 'medium').length;
    const low = issues.filter(i => i.severity === 'low').length;
    
    let html = `<div style="padding: 12px; background: var(--light-gray); border-radius: 8px; margin-bottom: 16px; font-size: 12px;">Found ${issues.length} issues: ${high} High, ${medium} Medium, ${low} Low</div>`;
    
    html += `<div class="fix-actions-bar">
        <div class="fix-counter">Selected:  <strong id="selectedCount">0</strong>  issues</div>
        <button class="btn-action" onclick="selectAllIssues()">✓ Select All</button>
        <button class="btn-action" onclick="deselectAllIssues()">✗ Clear</button>
        <button class="btn-action" style="background: var(--primary-green-dark);" id="generateFixBtn" onclick="generateFixedCode()" disabled>⚡ Generate Fixed Code</button>
    </div>`;
    
    issues.forEach((issue, idx) => {
        html += `<div class="issue-wrapper">
            <input type="checkbox" class="issue-checkbox" id="issue_${idx}" onchange="toggleIssue(${idx})">
            <div class="issue-card ${issue.severity}">
                <div class="issue-header">
                    <span class="severity-badge ${issue.severity}">${issue.severity}</span>
                    <span>Line ${issue.line}</span>
                </div>
                <div class="issue-message">${issue.message}</div>
                <div class="issue-suggestion">${issue.suggestion}</div>
            </div>
        </div>`;
    });
    
    container.innerHTML = html;
}

function toggleIssue(idx) {
    const checkbox = document.getElementById(`issue_${idx}`);
    if (checkbox.checked) {
        if (!selectedIssues.includes(idx)) selectedIssues.push(idx);
    } else {
        selectedIssues = selectedIssues.filter(i => i !== idx);
    }
    updateFixCounter();
}

function selectAllIssues() {
    selectedIssues = currentIssues.map((_, idx) => idx);
    currentIssues.forEach((_, idx) => {
        const checkbox = document.getElementById(`issue_${idx}`);
        if (checkbox) checkbox.checked = true;
    });
    updateFixCounter();
}

function deselectAllIssues() {
    selectedIssues = [];
    currentIssues.forEach((_, idx) => {
        const checkbox = document.getElementById(`issue_${idx}`);
        if (checkbox) checkbox.checked = false;
    });
    updateFixCounter();
}

function updateFixCounter() {
    document.getElementById('selectedCount').textContent = selectedIssues.length;
    document.getElementById('generateFixBtn').disabled = selectedIssues.length === 0;
}

async function generateFixedCode() {
    if (selectedIssues.length === 0) {
        showToast('Please select at least one issue to fix', 'error');
        return;
    }

    const btn = document.getElementById('generateFixBtn');
    btn.disabled = true;
    btn.innerHTML = '<span>⏳</span><span>Generating...</span>';

    try {
        const selectedIssuesList = selectedIssues.map(idx => currentIssues[idx]);
        
        const response = await fetch(`${API_BASE_URL}/generate-fixed-code`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                code: originalCode,
                selected_issues: selectedIssuesList
            })
        });

        if (response.ok) {
            const data = await response.json();
            document.getElementById('fixedCode').textContent = data.fixed_code;
            document.getElementById('downloadFixedBtn').disabled = false;
            showToast('Fixed code generated successfully!', 'success');
            switchTab('fixed');
        } else {
            throw new Error('Failed to generate fixed code');
        }
    } catch (error) {
        showToast('Error generating fixed code: ' + error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '⚡ Generate Fixed Code';
    }
}

function copyFixedCode() {
    const code = document.getElementById('fixedCode').textContent;
    navigator.clipboard.writeText(code).then(() => {
        showToast('Fixed code copied to clipboard!', 'success');
    });
}

function downloadFixedCode() {
    const code = document.getElementById('fixedCode').textContent;
    const element = document.createElement('a');
    const file = new Blob([code], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `fixed-code-${Date.now()}.py`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    showToast('Fixed code downloaded!', 'success');
}

function parseTestCases(testCode) {
    const testCases = [];
    if (!testCode || testCode.trim().length === 0) return [];
    
    const patterns = [
        { regex: /(test|it)\s*\(\s*['"`](.*?)['"`]\s*,/gi, name: 2 },
        { regex: /(test|it)\s*\(\s*['"`](.*?)['"`]\s*\)\s*=>/gi, name: 2 }
    ];
    
    for (const pattern of patterns) {
        let match;
        const regex = new RegExp(pattern.regex);
        while ((match = regex.exec(testCode)) !== null) {
            const testName = match[pattern.name].trim();
            if (testName && testName.length > 0) {
                if (!testCases.find(tc => tc.name === testName)) {
                    testCases.push({
                        name: testName,
                        type: 'Unit Test',
                        priority: 'Medium',
                        assertions: 1,
                        id: `TC_${String(testCases.length + 1).padStart(3, '0')}`
                    });
                }
            }
        }
        if (testCases.length > 0) break;
    }
    
    return testCases;
}

function displayTestCases(testCases) {
    currentTestCases = testCases;
    const container = document.getElementById('testCasesContainer');
    if (testCases.length === 0) { 
        container.innerHTML = '<p style="text-align: center; color: var(--text-gray); padding: 40px; font-size: 13px;">No test cases found</p>'; 
        return; 
    }
    let html = `<div style="padding: 15px; background: var(--light-gray); border-radius: 8px; margin-bottom: 20px; text-align: center;">Found ${testCases.length} test cases</div>`;
    testCases.forEach((tc, index) => {
        html += `<div style="background: var(--light-gray); padding: 14px; border-radius: 8px; margin-bottom: 12px; border-left: 3px solid var(--primary-green);">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div><strong>${tc.id} - ${tc.name}</strong></div>
                <button class="btn-action" onclick="openTestCaseModal(${index})" style="padding: 6px 12px; font-size: 0.75rem;">View</button>
            </div>
            <div style="color: var(--text-gray); font-size: 0.8rem; margin-top: 8px;">${tc.type} with ${tc.assertions} assertions</div>
        </div>`;
    });
    container.innerHTML = html;
}

function openTestCaseModal(index) {
    const tc = currentTestCases[index];
    if (!tc) return;
    
    document.getElementById('modalTestId').textContent = tc.id;
    document.getElementById('modalTestName').textContent = tc.name;
    document.getElementById('modalTestType').textContent = tc.type;
    document.getElementById('modalTestPriority').textContent = tc.priority;
    document.getElementById('modalTestAssertions').textContent = tc.assertions;
    
    document.getElementById('modalTestDescription').textContent = tc.description || `Test: ${tc.name}`;
    document.getElementById('modalTestPreconditions').textContent = tc.preconditions || 'System initialized and ready.';
    
    if (typeof tc.test_steps === 'string') {
        const steps = tc.test_steps.split(' | ');
        const stepsHtml = '<ol>' + steps.map(step => `<li>${step.trim()}</li>`).join('') + '</ol>';
        document.getElementById('modalTestSteps').innerHTML = stepsHtml;
    } else if (Array.isArray(tc.test_steps)) {
        const stepsHtml = '<ol>' + tc.test_steps.map(step => `<li>${step}</li>`).join('') + '</ol>';
        document.getElementById('modalTestSteps').innerHTML = stepsHtml;
    } else {
        document.getElementById('modalTestSteps').innerHTML = '<ol><li>Execute test</li></ol>';
    }
    
    document.getElementById('modalTestExpected').textContent = tc.expected_result || 'Test should pass.';
    document.getElementById('modalTestPostconditions').textContent = tc.post_conditions || 'Test cleanup completed.';
    
    document.getElementById('testCaseModal').classList.add('show');
}

function closeTestCaseModal() {
    document.getElementById('testCaseModal').classList.remove('show');
}

       function displayMetrics(metrics) {
            const container = document.getElementById('metricsGrid');
            
            const high = metrics.complexity?.high || 2;
            const medium = metrics.complexity?.medium || 3;
            const low = metrics.complexity?.low || 4;
            const total = high + medium + low;
            
            const codeQuality = metrics.code_quality || 92;
            const codeReview = metrics.code_review_percentage || 94;
            
            const highPercent = Math.round((high / total) * 100);
            const mediumPercent = Math.round((medium / total) * 100);
            const lowPercent = Math.round((low / total) * 100);
            
            // Determine dominant complexity level and colors
            let complexityBgGradient, complexityBorder, complexityLabel;
            if (high > medium && high > low) {
                complexityBgGradient = 'linear-gradient(135deg, #7f1d1d, #dc2626)';
                complexityBorder = 'rgba(239, 68, 68, 0.5)';
                complexityLabel = 'High Complexity';
            } else if (medium > low && medium > high) {
                complexityBgGradient = 'linear-gradient(135deg, #78350f, #f59e0b)';
                complexityBorder = 'rgba(245, 158, 11, 0.5)';
                complexityLabel = 'Medium Complexity';
            } else {
                complexityBgGradient = 'linear-gradient(135deg, #15803d, #10b981)';
                complexityBorder = 'rgba(16, 185, 129, 0.5)';
                complexityLabel = 'Low Complexity';
            }
            
            container.innerHTML = `
                <div style="background: white; padding: 28px; border-radius: 14px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); border: 1px solid rgba(0, 88, 65, 0.2);">
                    <div style="font-size: 1rem; font-weight: 700; color: #005841; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px;">Complexity Breakdown</div>
                    <div style="font-size: 0.8rem; font-weight: 600; color: #005841; margin-bottom: 6px;">${complexityLabel}</div>
                    <div style="font-size: 0.8rem; color: #636568; margin-bottom: 20px;">Distribution of ${total} issues found</div>
                    
                    <div style="display: flex; gap: 8px; margin-bottom: 18px; height: 8px; border-radius: 10px; background: rgba(255, 255, 255, 0.2); overflow: hidden;">
                        <div style="flex: ${highPercent}%; background: #ef4444; transition: flex 0.3s;"></div>
                        <div style="flex: ${mediumPercent}%; background: #f59e0b; transition: flex 0.3s;"></div>
                        <div style="flex: ${lowPercent}%; background: #10b981; transition: flex 0.3s;"></div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;">
                        <div style="background: rgba(0, 88, 65, 0.08); padding: 14px; border-radius: 10px; border-left: 4px solid #ef4444;">
                            <div style="font-size: 0.75rem; color: #636568; font-weight: 600; text-transform: uppercase; margin-bottom: 6px;">High</div>
                            <div style="font-size: 1.8rem; font-weight: 800; color: #005841;">${high}</div>
                            <div style="font-size: 0.75rem; color: #636568; margin-top: 6px;">${highPercent}%</div>
                        </div>
                        <div style="background: rgba(0, 88, 65, 0.08); padding: 14px; border-radius: 10px; border-left: 4px solid #f59e0b;">
                            <div style="font-size: 0.75rem; color: #636568; font-weight: 600; text-transform: uppercase; margin-bottom: 6px;">Medium</div>
                            <div style="font-size: 1.8rem; font-weight: 800; color: #005841;">${medium}</div>
                            <div style="font-size: 0.75rem; color: #636568; margin-top: 6px;">${mediumPercent}%</div>
                        </div>
                        <div style="background: rgba(0, 88, 65, 0.08); padding: 14px; border-radius: 10px; border-left: 4px solid #10b981;">
                            <div style="font-size: 0.75rem; color: #636568; font-weight: 600; text-transform: uppercase; margin-bottom: 6px;">Low</div>
                            <div style="font-size: 1.8rem; font-weight: 800; color: #005841;">${low}</div>
                            <div style="font-size: 0.75rem; color: #636568; margin-top: 6px;">${lowPercent}%</div>
                        </div>
                    </div>
                </div>
                
                <div style="background: white; padding: 28px; border-radius: 14px; box-shadow: 0 4px 12px rgba(0, 88, 65, 0.15); border: 1px solid rgba(0, 88, 65, 0.2);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 18px;">
                        <div>
                            <div style="font-size: 0.8rem; color: #636568; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Code Quality Score</div>
                            <div style="font-size: 2.8rem; font-weight: 900; color: #005841;">${codeQuality}%</div>
                        </div>
                        <span style="background: linear-gradient(135deg, #ffc32e, #f59e0b); color: #005841; padding: 8px 16px; border-radius: 8px; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px;">${codeQuality >= 90 ? 'Excellent' : codeQuality >= 75 ? 'Good' : 'Fair'}</span>
                    </div>
                    <div style="width: 100%; height: 10px; background: rgba(0, 88, 65, 0.1); border-radius: 10px; overflow: hidden; margin-bottom: 14px;">
                        <div style="width: ${codeQuality}%; height: 100%; background: linear-gradient(90deg, #ffc32e, #f59e0b); box-shadow: 0 0 15px rgba(255, 195, 46, 0.4);"></div>
                    </div>
                    <div style="font-size: 0.85rem; color: #636568;">${codeQuality >= 90 ? '✓ Excellent code quality with minimal issues' : codeQuality >= 75 ? '✓ Good code quality, some improvements needed' : '⚠ Code quality needs improvement'}</div>
                </div>
                
                <div style="background: white; padding: 28px; border-radius: 14px; box-shadow: 0 4px 12px rgba(0, 88, 65, 0.15); border: 1px solid rgba(0, 88, 65, 0.2);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 18px;">
                        <div>
                            <div style="font-size: 0.8rem; color: #636568; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Code Review Coverage</div>
                            <div style="font-size: 2.8rem; font-weight: 900; color: #005841;">${codeReview}%</div>
                        </div>
                        <span style="background: linear-gradient(135deg, #ffc32e, #f59e0b); color: #005841; padding: 8px 16px; border-radius: 8px; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px;">${codeReview >= 90 ? 'Comprehensive' : codeReview >= 75 ? 'Adequate' : 'Basic'}</span>
                    </div>
                    <div style="width: 100%; height: 10px; background: rgba(0, 88, 65, 0.1); border-radius: 10px; overflow: hidden; margin-bottom: 14px;">
                        <div style="width: ${codeReview}%; height: 100%; background: linear-gradient(90deg, #ffc32e, #f59e0b); box-shadow: 0 0 15px rgba(255, 195, 46, 0.4);"></div>
                    </div>
                    <div style="font-size: 0.85rem; color: #636568;">✓ ${codeReview >= 90 ? 'Comprehensive review coverage achieved' : codeReview >= 75 ? 'Adequate review coverage' : 'Basic review coverage'}</div>
                </div>
            `;
        }

function switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        if (tab.textContent.toLowerCase().includes(tabName.toLowerCase()) ||
            (tabName === 'issues' && tab.textContent.includes('Issues')) ||
            (tabName === 'fixed' && tab.textContent.includes('Fixed')) ||
            (tabName === 'tests' && tab.textContent.includes('Unit Tests')) ||
            (tabName === 'testcases' && tab.textContent.includes('Test Cases')) ||
            (tabName === 'metrics' && tab.textContent.includes('Metrics'))) {
            tab.classList.add('active');
        }
    });
    
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    document.getElementById(`${tabName}Tab`).classList.add('active');
}

function copyTests() {
    const code = document.getElementById('testCode').textContent;
    navigator.clipboard.writeText(code).then(() => {
        showToast('Test code copied!', 'success');
    });
}

// ============================================
// CSV DOWNLOAD - TEST CASE DEFINITIONS
// ============================================
function downloadTestsAsCSV() {
    if (!currentTestCases || currentTestCases.length === 0) { 
        showToast('No test cases available', 'error'); 
        return; 
    }
    
    let csv = 'Test Case ID,Test Name,Type,Priority,Assertions,Description,Preconditions,Test Steps,Expected Result,Post Conditions,Notes\n';
    
    currentTestCases.forEach(tc => {
        const description = (tc.description || '').replace(/"/g, '""');
        const preconditions = (tc.preconditions || '').replace(/"/g, '""');
        const steps = (tc.test_steps || '').replace(/"/g, '""');
        const expected = (tc.expected_result || '').replace(/"/g, '""');
        const postconditions = (tc.post_conditions || '').replace(/"/g, '""');
        
        csv += `"${tc.id}","${tc.name}","${tc.type}","${tc.priority}",${tc.assertions},"${description}","${preconditions}","${steps}","${expected}","${postconditions}","${tc.notes || ''}"\n`;
    });
    
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `test-case-definitions-${Date.now()}.csv`;
    link.click();
    
    showToast(`Downloaded ${currentTestCases.length} test case definitions as CSV!`, 'success');
}

// ============================================
// EXCEL DOWNLOAD - TEST DEFINITIONS + EXECUTION TEMPLATE
// ============================================
function downloadTestsAsExcel() {
    if (!currentTestCases || currentTestCases.length === 0) { 
        showToast('No test cases available', 'error'); 
        return; 
    }
    
    // ===== SHEET 1: TEST CASE DEFINITIONS =====
    let definitionsHtml = `<table border="1" cellpadding="12" cellspacing="0" style="border-collapse: collapse; width: 100%; font-family: Arial; font-size: 11px;">
        <thead style="background-color: #005841; color: white; font-weight: bold;">
            <tr>
                <th>Test Case ID</th>
                <th>Test Name</th>
                <th>Type</th>
                <th>Priority</th>
                <th>Assertions</th>
                <th>Description</th>
                <th>Preconditions</th>
                <th>Test Steps</th>
                <th>Expected Result</th>
                <th>Post Conditions</th>
                <th>Notes</th>
            </tr>
        </thead>
        <tbody>`;
    
    currentTestCases.forEach((tc, index) => {
        const bgColor = index % 2 === 0 ? '#ffffff' : '#f8fafc';
        
        const description = tc.description || '';
        const preconditions = tc.preconditions || '';
        const steps = Array.isArray(tc.test_steps) 
            ? tc.test_steps.join('<br/>') 
            : (tc.test_steps || '');
        const expected = tc.expected_result || '';
        const postconditions = tc.post_conditions || '';
        
        definitionsHtml += `<tr style="background-color: ${bgColor};">
            <td style="font-weight: bold; color: #005841;">${tc.id}</td>
            <td>${tc.name}</td>
            <td>${tc.type}</td>
            <td>${tc.priority}</td>
            <td style="text-align: center;">${tc.assertions || 0}</td>
            <td style="word-wrap: break-word; white-space: pre-wrap; max-width: 300px;">${description}</td>
            <td style="word-wrap: break-word; white-space: pre-wrap; max-width: 250px;">${preconditions}</td>
            <td style="word-wrap: break-word; white-space: pre-wrap; max-width: 300px;">${steps}</td>
            <td style="word-wrap: break-word; white-space: pre-wrap; max-width: 300px;">${expected}</td>
            <td style="word-wrap: break-word; white-space: pre-wrap; max-width: 250px;">${postconditions}</td>
            <td>${tc.notes || ''}</td>
        </tr>`;
    });
    
    definitionsHtml += `</tbody></table>`;
    
    // ===== SHEET 2: EXECUTION RESULTS TEMPLATE =====
    let executionHtml = `<table border="1" cellpadding="12" cellspacing="0" style="border-collapse: collapse; width: 100%; font-family: Arial; font-size: 11px;">
        <thead style="background-color: #1e40af; color: white; font-weight: bold;">
            <tr>
                <th>Test Case ID</th>
                <th>Test Name</th>
                <th>Status</th>
                <th>Duration (ms)</th>
                <th>Executed Date</th>
                <th>Executed By</th>
                <th>Code Coverage</th>
                <th>Defects Found</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>`;
    
    currentTestCases.forEach((tc, index) => {
        const bgColor = index % 2 === 0 ? '#ffffff' : '#f8fafc';
        
        executionHtml += `<tr style="background-color: ${bgColor};">
            <td style="font-weight: bold; color: #1e40af;">${tc.id}</td>
            <td>${tc.name}</td>
            <td style="text-align: center; color: #6b7280;">[Pending/Passed/Failed]</td>
            <td style="text-align: center;"></td>
            <td style="text-align: center;"></td>
            <td></td>
            <td style="text-align: center;"></td>
            <td></td>
            <td></td>
        </tr>`;
    });
    
    executionHtml += `</tbody></table>`;
    
    // Combine both sheets into single HTML
    const combinedHtml = `
        <html>
            <head>
                <meta charset="UTF-8">
            </head>
            <body>
                <h2 style="color: #005841; margin: 20px 0 10px 0;">TEST CASE DEFINITIONS</h2>
                ${definitionsHtml}
                
                <h2 style="color: #1e40af; margin: 30px 0 10px 0;">EXECUTION RESULTS (Template)</h2>
                ${executionHtml}
            </body>
        </html>
    `;
    
    const blob = new Blob([combinedHtml], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `test-cases-${Date.now()}.xls`;
    link.click();
    
    showToast(`Downloaded ${currentTestCases.length} test cases with execution template!`, 'success');
}

// ============================================
// HELPER FUNCTION - Calculate Average Coverage
// ============================================
function calculateAverageCoverage() {
    if (!currentTestCases || currentTestCases.length === 0) return 0;
    
    const coverages = currentTestCases
        .map(tc => {
            if (tc.code_coverage) {
                const num = parseInt(tc.code_coverage.toString().replace('%', ''));
                return isNaN(num) ? 0 : num;
            }
            return 0;
        })
        .filter(num => num > 0);
    
    if (coverages.length === 0) return 0;
    return (coverages.reduce((a, b) => a + b, 0) / coverages.length).toFixed(2);
}

function downloadTestsAsExcelBasic() {
    let html = `<table border="1"><tr><th>ID</th><th>Name</th><th>Type</th><th>Priority</th><th>Assertions</th></tr>`;
    currentTestCases.forEach(tc => {
        html += `<tr><td>${tc.id}</td><td>${tc.name}</td><td>${tc.type}</td><td>${tc.priority}</td><td>${tc.assertions}</td></tr>`;
    });
    html += `</table>`;
    const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `test-cases-${Date.now()}.xls`;
    link.click();
    showToast(`Downloaded ${currentTestCases.length} test cases!`, 'success');
}

function showToast(message, type) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    toastMessage.textContent = message;
    toast.style.borderLeftColor = type === 'success' ? 'var(--success)' : 'var(--danger)';
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

function generateDemoResults() {
    return {
        issues: [
            {
                severity: 'high',
                line: 5,
                message: 'Missing null checks for input validation',
                suggestion: 'Add proper null/undefined checks before processing'
            },
            {
                severity: 'medium',
                line: 12,
                message: 'No error handling in try-catch block',
                suggestion: 'Implement comprehensive exception handling'
            },
            {
                severity: 'medium',
                line: 18,
                message: 'Hardcoded credentials detected',
                suggestion: 'Use environment variables for sensitive data'
            },
            {
                severity: 'low',
                line: 25,
                message: 'Missing function documentation',
                suggestion: 'Add JSDoc comments for better code clarity'
            }
        ],
        tests: `
// Sample Unit Tests
test('should validate input correctly', () => {
    expect(true).toBe(true);
});

test('should handle null input gracefully', () => {
    expect(handleNull(null)).toBe(null);
});

test('should throw error on invalid data', () => {
    expect(() => validateData({})).toThrow();
});

test('should process valid input successfully', () => {
    const result = processData({ id: 1, name: 'test' });
    expect(result).toBeDefined();
});
        `,
        test_cases: [
            {
                id: 'TC_001',
                name: 'Validate OpenAPI Schema Definition',
                type: 'Integration Test',
                priority: 'High',
                assertions: 4,
                duration: '250ms',
                code_coverage: '90%',
                executed_by: 'Automated',
                executed_date: new Date().toLocaleDateString(),
                description: 'Verify OpenAPI schema is valid and conforms to v3.0 specification',
                preconditions: 'OpenAPI definition file loaded',
                test_steps: [
                    'Load OpenAPI specification',
                    'Validate against JSON Schema',
                    'Check required fields (info, paths, components)',
                    'Verify all endpoints are documented'
                ],
                expected_result: 'OpenAPI definition passes schema validation without errors',
                post_conditions: 'API definition ready for deployment',
                notes: 'Critical for API contract integrity'
            },
            {
                id: 'TC_002',
                name: 'Test API Endpoint Registration',
                type: 'Integration Test',
                priority: 'High',
                assertions: 5,
                duration: '350ms',
                code_coverage: '87%',
                executed_by: 'Automated',
                executed_date: new Date().toLocaleDateString(),
                description: 'Verify all OpenAPI endpoints are correctly registered',
                preconditions: 'API Management service provisioned and configured',
                test_steps: [
                    'Import OpenAPI definition',
                    'Verify all paths are registered',
                    'Check HTTP methods (GET, POST, PUT, DELETE)',
                    'Validate operation IDs match specification',
                    'Confirm authentication policies applied'
                ],
                expected_result: 'All endpoints available with correct methods and policies',
                post_conditions: 'API operations accessible through gateway',
                notes: 'Core API management functionality'
            },
            {
                id: 'TC_003',
                name: 'Validate Security Schemes and Authentication',
                type: 'Security Test',
                priority: 'High',
                assertions: 4,
                duration: '280ms',
                code_coverage: '92%',
                executed_by: 'Automated',
                executed_date: new Date().toLocaleDateString(),
                description: 'Verify security schemes (OAuth2, JWT, API Key) are properly configured',
                preconditions: 'Security policies configured in OpenAPI definition',
                test_steps: [
                    'Verify security schemes defined in components',
                    'Check OAuth2 endpoints and scopes',
                    'Validate JWT configuration',
                    'Confirm API Key header requirements'
                ],
                expected_result: 'All security schemes properly configured and enforced',
                post_conditions: 'API secured with appropriate authentication mechanisms',
                notes: 'Security-critical for production deployment'
            },
            {
                id: 'TC_004',
                name: 'Test Request/Response Schema Validation',
                type: 'Functional Test',
                priority: 'High',
                assertions: 6,
                duration: '320ms',
                code_coverage: '85%',
                executed_by: 'Automated',
                executed_date: new Date().toLocaleDateString(),
                description: 'Verify request and response bodies match OpenAPI schema definitions',
                preconditions: 'OpenAPI schemas defined for all endpoints',
                test_steps: [
                    'Extract request schema from OpenAPI',
                    'Validate incoming request payload',
                    'Check required fields presence',
                    'Verify data types and formats',
                    'Validate response schema against definition',
                    'Check response status codes'
                ],
                expected_result: 'All requests and responses conform to OpenAPI schema',
                post_conditions: 'API contract enforced at gateway level',
                notes: 'Ensures API consistency and prevents invalid payloads'
            },
            {
                id: 'TC_005',
                name: 'Validate API Versioning Strategy',
                type: 'Integration Test',
                priority: 'Medium',
                assertions: 3,
                duration: '200ms',
                code_coverage: '80%',
                executed_by: 'Automated',
                executed_date: new Date().toLocaleDateString(),
                description: 'Verify API versioning configured correctly (URL or header-based)',
                preconditions: 'Multiple API versions defined in OpenAPI',
                test_steps: [
                    'Check version parameter in OpenAPI (x-version)',
                    'Verify version routing policies',
                    'Test request routing to correct backend version',
                    'Validate version deprecation policies'
                ],
                expected_result: 'Requests routed to correct API version with proper versioning strategy',
                post_conditions: 'API versioning operational and manageable',
                notes: 'Important for maintaining backward compatibility'
            },
            {
                id: 'TC_006',
                name: 'Test Rate Limiting and Quota Policies',
                type: 'Performance Test',
                priority: 'High',
                assertions: 4,
                duration: '400ms',
                code_coverage: '88%',
                executed_by: 'Automated',
                executed_date: new Date().toLocaleDateString(),
                description: 'Verify rate limiting and quota policies are enforced',
                preconditions: 'Rate-limit policies configured',
                test_steps: [
                    'Define rate limit thresholds',
                    'Send requests exceeding quota',
                    'Verify 429 (Too Many Requests) response',
                    'Check rate limit headers in response'
                ],
                expected_result: 'Rate limiting enforced with correct throttling behavior',
                post_conditions: 'API protected from abuse with quota management',
                notes: 'Critical for API stability and fair usage'
            },
            {
                id: 'TC_007',
                name: 'Validate CORS Configuration',
                type: 'Functional Test',
                priority: 'Medium',
                assertions: 3,
                duration: '180ms',
                code_coverage: '83%',
                executed_by: 'Automated',
                executed_date: new Date().toLocaleDateString(),
                description: 'Verify CORS headers are correctly configured for cross-origin requests',
                preconditions: 'CORS policy applied',
                test_steps: [
                    'Send preflight OPTIONS request',
                    'Verify Access-Control-Allow-Origin header',
                    'Check allowed methods and headers',
                    'Validate credentials policy'
                ],
                expected_result: 'CORS headers present and correctly configured for allowed origins',
                post_conditions: 'Cross-origin requests handled securely',
                notes: 'Required for client-side browser applications'
            },
            {
                id: 'TC_008',
                name: 'Test Backend Service Integration',
                type: 'Integration Test',
                priority: 'High',
                assertions: 4,
                duration: '450ms',
                code_coverage: '91%',
                executed_by: 'Automated',
                executed_date: new Date().toLocaleDateString(),
                description: 'Verify backend service URLs and policies are correctly configured',
                preconditions: 'Backend endpoints configured in OpenAPI',
                test_steps: [
                    'Verify backend service URLs match OpenAPI servers',
                    'Test request forwarding to backend',
                    'Validate response handling from backend',
                    'Check timeout and retry policies'
                ],
                expected_result: 'Requests successfully proxied to backend with correct routing',
                post_conditions: 'API gateway properly forwarding to backend services',
                notes: 'Essential for end-to-end API functionality'
            }
        ],
        metrics: {
            complexity: { high: 2, medium: 1, low: 1 },
            code_quality: 87,
            code_review_percentage: 91
        }
    };
}

async function checkAPIConnection() {
    try {
        const response = await fetch(`${API_BASE_URL}/health`);
        if (response.ok) {
            document.getElementById('apiStatus').innerHTML = '<span class="status-dot"></span><span>API Connected</span>';
            document.getElementById('apiStatus').className = 'api-status';
        } else throw new Error('Not responding');
    } catch (error) {
        document.getElementById('apiStatus').innerHTML = '<span class="status-dot"></span><span>Demo Mode</span>';
        document.getElementById('apiStatus').className = 'api-status';
    }
}

window.addEventListener('DOMContentLoaded', () => {
    setupPlatformSelector();
    checkAPIConnection();
});

window.addEventListener('load', checkAPIConnection);