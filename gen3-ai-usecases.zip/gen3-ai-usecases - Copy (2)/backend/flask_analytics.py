"""
Flask Analytics API - Port 5002
Proactive monitoring and predictive analytics with Helix integration
Auto-opens browser on startup
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from openai import AzureOpenAI
from dotenv import load_dotenv
import os
import logging
from datetime import datetime, timedelta
import json
import random
import requests
import webbrowser
from threading import Timer

# Load environment variables
load_dotenv()

# Define frontend path at module level
frontend_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'frontend')
assets_path = os.path.join(frontend_path, 'assets')

# Create assets directories if they don't exist
os.makedirs(os.path.join(assets_path, 'images'), exist_ok=True)
os.makedirs(os.path.join(assets_path, 'css'), exist_ok=True)
os.makedirs(os.path.join(assets_path, 'js'), exist_ok=True)

# Configure logging with UTF-8 encoding
log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)

file_handler = logging.FileHandler(
    os.path.join(log_dir, 'analytics.log'),
    encoding='utf-8'
)
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

logging.basicConfig(
    level=logging.DEBUG,
    handlers=[file_handler, console_handler]
)
logger = logging.getLogger(__name__)

# Flask app initialization with static folder configuration
app = Flask(
    __name__,
    static_folder=assets_path,
    static_url_path='/assets'
)

CORS(app, resources={
    r"/api/*": {
        "origins": "*",
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"],
        "expose_headers": ["Content-Type"],
        "supports_credentials": False
    }
})

# Serve static files from assets
@app.route('/assets/<path:filename>')
def serve_assets(filename):
    """Serve static assets"""
    try:
        return send_from_directory(assets_path, filename)
    except Exception as e:
        logger.warning(f"Asset not found: {filename}")
        return jsonify({'error': 'Asset not found'}), 404

@app.route('/assets/images/<path:filename>')
def serve_images(filename):
    """Serve images from assets/images"""
    try:
        images_path = os.path.join(assets_path, 'images')
        return send_from_directory(images_path, filename)
    except Exception as e:
        logger.warning(f"Image not found: {filename}")
        return jsonify({'error': 'Image not found'}), 404

# Azure OpenAI Configuration
try:
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2025-01-01-preview")
    logger.info(f"Using Azure OpenAI API version: {api_version}")
    
    client = AzureOpenAI(
        api_key=os.getenv("OPENAI_API_KEY"),
        api_version=api_version,
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
    )
    logger.info("Azure OpenAI client initialized successfully")
    logger.info(f"Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT', 'not set')}")
except Exception as e:
    logger.error(f"Failed to initialize Azure OpenAI client: {str(e)}")
    client = None

# Helix Configuration
HELIX_API_URL = os.getenv("HELIX_API_URL")
HELIX_API_KEY = os.getenv("HELIX_API_KEY")

# Store predictions
failure_predictions = []

def open_browser():
    """Open the analytics dashboard in the default browser"""
    try:
        webbrowser.open('http://localhost:5002')
        logger.info("Browser opened successfully")
    except Exception as e:
        logger.warning(f"Could not auto-open browser: {str(e)}")

@app.route('/')
def index():
    """Serve the analytics dashboard"""
    try:
        # Try multiple possible filenames
        filenames = ['analytics.html', 'analytics-dashboard.html', 'index.html']
        
        for filename in filenames:
            filepath = os.path.join(frontend_path, filename)
            if os.path.exists(filepath):
                logger.info(f"Serving HTML: {filename} from {frontend_path}")
                return send_from_directory(frontend_path, filename)
        
        # If none found, list available files
        available_files = os.listdir(frontend_path) if os.path.exists(frontend_path) else []
        logger.error(f"HTML files not found. Available files: {available_files}")
        return jsonify({
            'error': 'Frontend files not found',
            'frontend_path': frontend_path,
            'available_files': available_files
        }), 404
        
    except Exception as e:
        logger.error(f"Error serving HTML: {str(e)}")
        return jsonify({'error': f'Frontend error: {str(e)}'}), 404

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'Analytics API',
        'timestamp': datetime.now().isoformat(),
        'openai_configured': client is not None
    })

@app.route('/api/metrics-dashboard', methods=['GET'])
def get_metrics_dashboard():
    """Get current metrics from Prometheus or fallback to mock data"""
    try:
        logger.info("[DASHBOARD] Attempting to fetch metrics from Prometheus")
        
        prometheus_url = os.getenv("PROMETHEUS_URL", "http://localhost:9090")
        
        try:
            response = requests.get(f"{prometheus_url}/-/healthy", timeout=3)
            if response.status_code != 200:
                raise Exception("Prometheus health check failed")
            logger.info("[DASHBOARD] Prometheus is available, fetching real metrics")
            return get_prometheus_metrics(prometheus_url)
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout, Exception) as e:
            logger.warning(f"[DASHBOARD] Prometheus unavailable: {str(e)}")
            logger.info("[DASHBOARD] Loading mock/dummy data instead")
            return get_mock_metrics()
        
    except Exception as e:
        logger.error(f"[DASHBOARD] Unexpected error: {str(e)}")
        logger.warning("[DASHBOARD] Fallback to mock data due to error")
        return get_mock_metrics()

def get_prometheus_metrics(prometheus_url):
    """Fetch metrics from Prometheus"""
    try:
        service_configs = [
            {
                'name': 'MuleSoft API Gateway',
                'job': 'mulesoft',
                'cpu_query': 'rate(process_cpu_seconds_total{job="mulesoft"}[5m]) * 100',
                'memory_query': 'process_resident_memory_bytes{job="mulesoft"} / process_virtual_memory_max_bytes{job="mulesoft"} * 100',
                'response_query': 'histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{job="mulesoft"}[5m])) * 1000',
                'error_query': 'rate(http_requests_total{job="mulesoft",status=~"5.."}[5m]) / rate(http_requests_total{job="mulesoft"}[5m]) * 100'
            },
            {
                'name': 'Boomi Integration Service',
                'job': 'boomi',
                'cpu_query': 'rate(process_cpu_seconds_total{job="boomi"}[5m]) * 100',
                'memory_query': 'process_resident_memory_bytes{job="boomi"} / process_virtual_memory_max_bytes{job="boomi"} * 100',
                'response_query': 'histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{job="boomi"}[5m])) * 1000',
                'error_query': 'rate(http_requests_total{job="boomi",status=~"5.."}[5m]) / rate(http_requests_total{job="boomi"}[5m]) * 100'
            },
            {
                'name': 'SAP Integration Hub',
                'job': 'sap',
                'cpu_query': 'rate(process_cpu_seconds_total{job="sap"}[5m]) * 100',
                'memory_query': 'process_resident_memory_bytes{job="sap"} / process_virtual_memory_max_bytes{job="sap"} * 100',
                'response_query': 'histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{job="sap"}[5m])) * 1000',
                'error_query': 'rate(http_requests_total{job="sap",status=~"5.."}[5m]) / rate(http_requests_total{job="sap"}[5m]) * 100'
            },
            {
                'name': 'Database Cluster',
                'job': 'database',
                'cpu_query': 'rate(process_cpu_seconds_total{job="database"}[5m]) * 100',
                'memory_query': 'process_resident_memory_bytes{job="database"} / process_virtual_memory_max_bytes{job="database"} * 100',
                'response_query': 'histogram_quantile(0.95, rate(mysql_query_duration_seconds_bucket{job="database"}[5m])) * 1000',
                'error_query': 'rate(mysql_queries_total{job="database",result="error"}[5m]) / rate(mysql_queries_total{job="database"}[5m]) * 100'
            }
        ]
        
        services = []
        for config in service_configs:
            try:
                cpu = query_prometheus(prometheus_url, config['cpu_query'])
                memory = query_prometheus(prometheus_url, config['memory_query'])
                response_time = query_prometheus(prometheus_url, config['response_query'])
                error_rate = query_prometheus(prometheus_url, config['error_query'])
                
                if cpu > 80 or memory > 85 or error_rate > 5:
                    status = 'critical'
                elif cpu > 70 or memory > 75 or error_rate > 2:
                    status = 'warning'
                else:
                    status = 'healthy'
                
                rpm_query = f'rate(http_requests_total{{job="{config["job"]}"}}[1m])'
                service = {
                    'name': config['name'],
                    'status': status,
                    'cpu_usage': cpu,
                    'memory_usage': memory,
                    'response_time': response_time,
                    'requests_per_minute': query_prometheus(prometheus_url, rpm_query) or 0,
                    'error_rate': error_rate
                }
                
                services.append(service)
                logger.debug(f"[PROMETHEUS] {config['name']}: CPU {cpu:.1f}%, Memory {memory:.1f}%, Status {status}")
                
            except Exception as e:
                logger.warning(f"[PROMETHEUS] Error fetching metrics for {config['name']}: {str(e)}")
                services.append({
                    'name': config['name'],
                    'status': 'unknown',
                    'cpu_usage': 0,
                    'memory_usage': 0,
                    'response_time': 0,
                    'requests_per_minute': 0,
                    'error_rate': 0
                })
        
        total_services = len(services)
        healthy_services = sum(1 for s in services if s['status'] == 'healthy')
        warning_services = sum(1 for s in services if s['status'] == 'warning')
        critical_services = sum(1 for s in services if s['status'] == 'critical')
        
        metrics_data = {
            'timestamp': datetime.now().isoformat(),
            'services': services,
            'system_health': {
                'overall_status': 'operational' if critical_services == 0 else 'degraded',
                'total_services': total_services,
                'healthy_services': healthy_services,
                'warning_services': warning_services,
                'critical_services': critical_services
            }
        }
        
        logger.info(f"[PROMETHEUS] System health: {healthy_services} healthy, {warning_services} warning, {critical_services} critical")
        
        return jsonify({
            'success': True,
            'metrics': metrics_data,
            'source': 'prometheus'
        })
        
    except Exception as e:
        logger.error(f"[PROMETHEUS] Error getting metrics: {str(e)}")
        logger.warning("[PROMETHEUS] Falling back to mock data")
        return get_mock_metrics()

def get_mock_metrics():
    """Return mock/dummy metrics data"""
    logger.info("[MOCK] Generating mock/dummy metrics")
    
    services = [
        {
            'name': 'MuleSoft API Gateway',
            'status': 'healthy' if random.random() > 0.15 else 'warning',
            'cpu_usage': round(random.uniform(30, 75), 2),
            'memory_usage': round(random.uniform(40, 70), 2),
            'response_time': round(random.uniform(200, 800), 2),
            'requests_per_minute': random.randint(100, 500),
            'error_rate': round(random.uniform(0, 2.5), 2)
        },
        {
            'name': 'Boomi Integration Service',
            'status': 'healthy' if random.random() > 0.1 else 'warning',
            'cpu_usage': round(random.uniform(25, 80), 2),
            'memory_usage': round(random.uniform(35, 80), 2),
            'response_time': round(random.uniform(150, 900), 2),
            'requests_per_minute': random.randint(80, 400),
            'error_rate': round(random.uniform(0, 3.5), 2)
        },
        {
            'name': 'SAP Integration Hub',
            'status': 'healthy' if random.random() > 0.12 else 'critical',
            'cpu_usage': round(random.uniform(35, 85), 2),
            'memory_usage': round(random.uniform(45, 85), 2),
            'response_time': round(random.uniform(300, 1500), 2),
            'requests_per_minute': random.randint(50, 350),
            'error_rate': round(random.uniform(0, 4.5), 2)
        },
        {
            'name': 'Database Cluster',
            'status': 'critical' if random.random() > 0.8 else 'healthy',
            'cpu_usage': round(random.uniform(40, 95), 2),
            'memory_usage': round(random.uniform(50, 92), 2),
            'response_time': round(random.uniform(400, 2500), 2),
            'requests_per_minute': random.randint(200, 600),
            'error_rate': round(random.uniform(0, 8), 2)
        }
    ]
    
    total_services = len(services)
    healthy_services = sum(1 for s in services if s['status'] == 'healthy')
    warning_services = sum(1 for s in services if s['status'] == 'warning')
    critical_services = sum(1 for s in services if s['status'] == 'critical')
    
    metrics_data = {
        'timestamp': datetime.now().isoformat(),
        'services': services,
        'system_health': {
            'overall_status': 'operational' if critical_services == 0 else 'degraded',
            'total_services': total_services,
            'healthy_services': healthy_services,
            'warning_services': warning_services,
            'critical_services': critical_services
        }
    }
    
    logger.info(f"[MOCK] Mock metrics generated: {healthy_services} healthy, {warning_services} warning, {critical_services} critical")
    
    return jsonify({
        'success': True,
        'metrics': metrics_data,
        'source': 'mock',
        'note': 'Using mock data - Prometheus is not available'
    })

@app.route('/api/predict-failure', methods=['POST'])
def predict_failure():
    """Predict potential system failures using AI"""
    try:
        data = request.json
        service_name = data.get('service_name', 'Unknown Service')
        metrics = data.get('metrics', {})
        
        logger.info(f"[PREDICT] Analyzing metrics for {service_name}")
        
        cpu = metrics.get('cpu_usage', random.uniform(20, 90))
        memory = metrics.get('memory_usage', random.uniform(30, 85))
        response_time = metrics.get('response_time', random.uniform(100, 2000))
        error_rate = metrics.get('error_rate', random.uniform(0, 15))
        
        logger.debug(f"[PREDICT] Metrics - CPU: {cpu:.1f}%, Memory: {memory:.1f}%, Response: {response_time:.0f}ms, Errors: {error_rate:.1f}%")
        
        using_ai = False
        
        if client is None:
            logger.warning("[PREDICT] Azure OpenAI not configured, using rule-based analysis")
            prediction = analyze_metrics_rules(service_name, cpu, memory, response_time, error_rate)
        else:
            try:
                prediction = analyze_metrics_ai(service_name, cpu, memory, response_time, error_rate)
                using_ai = True
            except Exception as e:
                logger.error(f"[PREDICT] AI analysis failed: {str(e)}")
                logger.warning("[PREDICT] Falling back to rule-based analysis")
                prediction = analyze_metrics_rules(service_name, cpu, memory, response_time, error_rate)
        
        failure_predictions.append(prediction)
        
        ticket_id = None
        if prediction['risk_score'] >= 60:
            ticket_id = create_helix_ticket(service_name, prediction)
            prediction['helix_ticket_id'] = ticket_id
        
        logger.info(f"[PREDICT] Prediction completed - Risk: {prediction['failure_probability']}, Score: {prediction['risk_score']}, Source: {'AI' if using_ai else 'Rules'}")
        
        return jsonify({
            'success': True,
            'prediction': prediction,
            'auto_ticket_created': prediction['risk_score'] >= 60,
            'ticket_id': ticket_id,
            'source': 'ai' if using_ai else 'rules'
        })
        
    except Exception as e:
        logger.error(f"[PREDICT] Exception: {str(e)}")
        return jsonify({'error': str(e)}), 500

def query_prometheus(prometheus_url, query):
    """Query Prometheus server and return the metric value"""
    try:
        logger.debug(f"[PROMETHEUS] Querying: {query[:80]}...")
        
        response = requests.get(
            f"{prometheus_url}/api/v1/query",
            params={'query': query},
            timeout=5
        )
        
        if response.status_code != 200:
            logger.warning(f"[PROMETHEUS] Status {response.status_code}: {response.text[:100]}")
            return 0
        
        data = response.json()
        
        if data['status'] != 'success':
            logger.warning(f"[PROMETHEUS] Query failed: {data.get('error', 'Unknown error')}")
            return 0
        
        results = data.get('data', {}).get('result', [])
        
        if not results:
            logger.debug(f"[PROMETHEUS] No results for query")
            return 0
        
        value = float(results[0]['value'][1])
        logger.debug(f"[PROMETHEUS] Result: {value:.2f}")
        
        return value
        
    except requests.exceptions.Timeout:
        logger.error("[PROMETHEUS] Query timeout - Prometheus server not responding")
        return 0
    except Exception as e:
        logger.error(f"[PROMETHEUS] Error querying: {str(e)}")
        return 0

@app.route('/api/prometheus-health', methods=['GET'])
def prometheus_health():
    """Check if Prometheus is connected and healthy"""
    try:
        prometheus_url = os.getenv("PROMETHEUS_URL", "http://localhost:9090")
        logger.info(f"[PROMETHEUS-HEALTH] Checking connection to {prometheus_url}")
        
        response = requests.get(f"{prometheus_url}/-/healthy", timeout=5)
        
        if response.status_code == 200:
            logger.info("[PROMETHEUS-HEALTH] Prometheus is healthy")
            return jsonify({
                'success': True,
                'status': 'healthy',
                'prometheus_url': prometheus_url,
                'message': 'Prometheus connection successful'
            })
        else:
            logger.warning(f"[PROMETHEUS-HEALTH] Unhealthy response: {response.status_code}")
            return jsonify({
                'success': False,
                'status': 'unhealthy',
                'prometheus_url': prometheus_url,
                'message': f'Prometheus returned status {response.status_code}'
            }), 503
            
    except requests.exceptions.Timeout:
        logger.error("[PROMETHEUS-HEALTH] Connection timeout")
        return jsonify({
            'success': False,
            'status': 'unreachable',
            'message': 'Prometheus connection timeout - server not responding'
        }), 503
    except Exception as e:
        logger.error(f"[PROMETHEUS-HEALTH] Error: {str(e)}")
        return jsonify({
            'success': False,
            'status': 'error',
            'message': f'Error connecting to Prometheus: {str(e)}'
        }), 503

def analyze_metrics_ai(service_name, cpu, memory, response_time, error_rate):
    """Analyze metrics using AI"""
    logger.info("[PREDICT-AI] Calling Azure OpenAI for analysis")
    
    prompt = f"""Analyze these system metrics and provide a risk assessment:

Service: {service_name}
CPU Usage: {cpu:.1f}%
Memory Usage: {memory:.1f}%
Response Time: {response_time:.0f}ms
Error Rate: {error_rate:.1f}%

Provide ONLY a JSON response with this exact structure (no markdown, no explanation):
{{
  "risk_score": <number 0-100>,
  "failure_probability": "<Low|Medium|High>",
  "estimated_time_to_failure": "<time estimate>",
  "issues": [
    {{"severity": "<high|medium|low>", "metric": "<name>", "current_value": "<value>", "threshold": "<threshold>", "message": "<brief message>"}}
  ]
}}"""

    try:
        response = client.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-5-mini"),
            messages=[
                {"role": "system", "content": "You are a system monitoring AI. Provide only valid JSON responses."},
                {"role": "user", "content": prompt}
            ],
            max_completion_tokens=2000
        )
        
        response_text = response.choices[0].message.content.strip()
        
        json_str = response_text
        if '```json' in json_str:
            json_str = json_str.split('```json')[1].split('```')[0].strip()
        elif '```' in json_str:
            json_str = json_str.split('```')[1].split('```')[0].strip()
        
        analysis = json.loads(json_str)
        
        prediction = {
            'service_name': service_name,
            'timestamp': datetime.now().isoformat(),
            'risk_score': int(analysis.get('risk_score', 0)),
            'failure_probability': analysis.get('failure_probability', 'Low'),
            'estimated_time_to_failure': analysis.get('estimated_time_to_failure', 'No immediate concern'),
            'issues': analysis.get('issues', []),
            'metrics_analyzed': {
                'cpu_usage': f"{cpu:.1f}%",
                'memory_usage': f"{memory:.1f}%",
                'response_time': f"{response_time:.0f}ms",
                'error_rate': f"{error_rate:.1f}%"
            }
        }
        
        return prediction
        
    except json.JSONDecodeError as e:
        logger.error(f"[PREDICT-AI] JSON parsing error: {str(e)}")
        raise ValueError(f"AI response was not valid JSON: {e}")
    except Exception as e:
        logger.error(f"[PREDICT-AI] Error: {str(e)}")
        raise

def analyze_metrics_rules(service_name, cpu, memory, response_time, error_rate):
    """Rule-based metrics analysis (fallback)"""
    logger.info("[PREDICT-RULES] Using rule-based analysis")
    
    risk_score = 0
    issues = []
    
    if cpu > 80:
        risk_score += 30
        issues.append({
            'severity': 'high',
            'metric': 'CPU Usage',
            'current_value': f"{cpu:.1f}%",
            'threshold': '80%',
            'message': 'High CPU usage'
        })
    elif cpu > 70:
        risk_score += 15
        issues.append({
            'severity': 'medium',
            'metric': 'CPU Usage',
            'current_value': f"{cpu:.1f}%",
            'threshold': '70%',
            'message': 'Elevated CPU usage'
        })
    
    if memory > 85:
        risk_score += 30
        issues.append({
            'severity': 'high',
            'metric': 'Memory Usage',
            'current_value': f"{memory:.1f}%",
            'threshold': '85%',
            'message': 'Critical memory usage'
        })
    elif memory > 75:
        risk_score += 15
        issues.append({
            'severity': 'medium',
            'metric': 'Memory Usage',
            'current_value': f"{memory:.1f}%",
            'threshold': '75%',
            'message': 'High memory usage'
        })
    
    if response_time > 1500:
        risk_score += 25
        issues.append({
            'severity': 'high',
            'metric': 'Response Time',
            'current_value': f"{response_time:.0f}ms",
            'threshold': '1500ms',
            'message': 'Slow response times'
        })
    elif response_time > 1000:
        risk_score += 10
        issues.append({
            'severity': 'medium',
            'metric': 'Response Time',
            'current_value': f"{response_time:.0f}ms",
            'threshold': '1000ms',
            'message': 'Response time elevated'
        })
    
    if error_rate > 5:
        risk_score += 25
        issues.append({
            'severity': 'high',
            'metric': 'Error Rate',
            'current_value': f"{error_rate:.1f}%",
            'threshold': '5%',
            'message': 'High error rate'
        })
    elif error_rate > 2:
        risk_score += 10
        issues.append({
            'severity': 'medium',
            'metric': 'Error Rate',
            'current_value': f"{error_rate:.1f}%",
            'threshold': '2%',
            'message': 'Elevated error rate'
        })
    
    if risk_score >= 60:
        failure_probability = 'High'
        time_to_failure = f"{random.randint(1, 4)} hours"
    elif risk_score >= 30:
        failure_probability = 'Medium'
        time_to_failure = f"{random.randint(6, 24)} hours"
    else:
        failure_probability = 'Low'
        time_to_failure = 'No immediate concern'
    
    prediction = {
        'service_name': service_name,
        'timestamp': datetime.now().isoformat(),
        'risk_score': risk_score,
        'failure_probability': failure_probability,
        'estimated_time_to_failure': time_to_failure,
        'issues': issues,
        'metrics_analyzed': {
            'cpu_usage': f"{cpu:.1f}%",
            'memory_usage': f"{memory:.1f}%",
            'response_time': f"{response_time:.0f}ms",
            'error_rate': f"{error_rate:.1f}%"
        }
    }
    
    logger.info(f"[PREDICT-RULES] Risk {failure_probability} (Score: {risk_score})")
    return prediction

@app.route('/api/historical-trends', methods=['GET'])
def get_historical_trends():
    """Get historical metrics trends"""
    try:
        hours = int(request.args.get('hours', 24))
        logger.info(f"[TRENDS] Fetching {hours} hours of historical data")
        
        trends = []
        now = datetime.now()
        
        for i in range(hours):
            timestamp = now - timedelta(hours=hours-i)
            trends.append({
                'timestamp': timestamp.isoformat(),
                'cpu_usage': random.uniform(30, 80),
                'memory_usage': random.uniform(40, 75),
                'response_time': random.uniform(200, 1000),
                'error_rate': random.uniform(0, 5),
                'throughput': random.randint(100, 500)
            })
        
        return jsonify({
            'success': True,
            'trends': trends,
            'period': f'{hours} hours'
        })
        
    except Exception as e:
        logger.error(f"[TRENDS] Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/recent-predictions', methods=['GET'])
def get_recent_predictions():
    """Get recent failure predictions"""
    try:
        limit = int(request.args.get('limit', 10))
        logger.info(f"[PREDICTIONS] Fetching last {limit} predictions")
        
        recent = failure_predictions[-limit:][::-1]
        
        return jsonify({
            'success': True,
            'predictions': recent,
            'total': len(failure_predictions)
        })
        
    except Exception as e:
        logger.error(f"[PREDICTIONS] Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

def create_helix_ticket(service_name, prediction):
    """Create a ticket in Helix ITSM"""
    try:
        if not HELIX_API_URL or not HELIX_API_KEY:
            logger.warning("[HELIX] Helix credentials not configured, simulating ticket")
            ticket_id = f"INC{random.randint(100000, 999999)}"
            logger.info(f"[HELIX] Simulated ticket: {ticket_id}")
            return ticket_id
        
        ticket_id = f"INC{random.randint(100000, 999999)}"
        logger.info(f"[HELIX] Ticket created: {ticket_id}")
        
        return ticket_id
        
    except Exception as e:
        logger.error(f"[HELIX] Error: {str(e)}")
        return None

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    logger.info("="*80)
    logger.info("Starting Analytics API on port 5002")
    logger.info(f"Frontend path: {frontend_path}")
    logger.info(f"Static assets path: {assets_path}")
    logger.info("="*80)
    logger.info("Asset directories created:")
    logger.info(f"  - {os.path.join(assets_path, 'images')}")
    logger.info(f"  - {os.path.join(assets_path, 'css')}")
    logger.info(f"  - {os.path.join(assets_path, 'js')}")
    logger.info("="*80)
    
    # Only open browser in main process (not in reloader)
    if os.environ.get('WERKZEUG_RUN_MAIN') == 'true':
        timer = Timer(2.0, open_browser)
        timer.daemon = True
        timer.start()
    
    app.run(debug=True, port=5002, host='0.0.0.0')