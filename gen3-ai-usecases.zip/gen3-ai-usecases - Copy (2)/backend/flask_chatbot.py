"""
Flask Chatbot API - Port 5001
AI Knowledge Assistant trained on historical tickets
Optimized for GPT-5-mini with enhanced logging and error handling
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from openai import AzureOpenAI
from dotenv import load_dotenv
import os
import logging
from datetime import datetime
import json
import webbrowser
from threading import Timer
from collections import defaultdict
import uuid

# Load environment variables
load_dotenv()

# Configure logging with UTF-8 encoding
log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)

file_handler = logging.FileHandler(
    os.path.join(log_dir, 'chatbot.log'),
    encoding='utf-8'
)
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

logging.basicConfig(
    level=logging.DEBUG,
    handlers=[file_handler, console_handler]
)
logger = logging.getLogger(__name__)

# Setup Flask with correct template folder
template_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../frontend'))
app = Flask(__name__, static_folder=os.path.join(template_dir, 'assets'), static_url_path='/assets')

CORS(app, resources={
    r"/api/*": {
        "origins": "*",
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type"],
        "expose_headers": ["Content-Type"],
        "supports_credentials": False
    }
})

logger.info(f"Template directory: {template_dir}")

# Azure OpenAI Configuration
try:
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2025-01-01-preview")
    logger.info(f"Using Azure OpenAI API version: {api_version}")
    
    client = AzureOpenAI(
        api_key=os.getenv("OPENAI_API_KEY"),
        api_version=api_version,
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
    )
    logger.info("Azure OpenAI client initialized successfully")
    logger.info(f"Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT', 'not set')}")
except Exception as e:
    logger.error(f"Failed to initialize Azure OpenAI client: {str(e)}")
    client = None

# Conversation history (in-memory)
conversations = {}

# Raised tickets storage (in-memory)
raised_tickets = []

# Mock historical tickets database
historical_tickets = [
    {
        "ticket_id": "INC0012345",
        "title": "Azure APIM timeout on Developer Portal",
        "category": "Performance",
        "description": "API Management gateway experiencing timeout after 30 seconds on Developer Portal",
        "resolution": "Increased timeout value in Azure APIM configuration and optimized backend query",
        "resolution_time": "2 hours",
        "created_date": "2025-01-15",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012346",
        "title": "MFT file transfer deployment failed",
        "category": "Deployment",
        "description": "MFT process deployment fails with authentication error",
        "resolution": "Updated deployment credentials and verified firewall rules",
        "resolution_time": "1 hour",
        "created_date": "2025-01-20",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012347",
        "title": "SAP CPI mapping error",
        "category": "Integration",
        "description": "XML mapping transformation failing for certain field types in SAP CPI",
        "resolution": "Fixed mapping logic for date fields and added error handling",
        "resolution_time": "3 hours",
        "created_date": "2025-01-22",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012348",
        "title": "Azure APIM connection pool exhausted",
        "category": "Database",
        "description": "Azure API Management unable to get database connections",
        "resolution": "Increased connection pool size and fixed connection leaks in APIM",
        "resolution_time": "4 hours",
        "created_date": "2025-01-25",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012349",
        "title": "SSL certificate expired - Developer Portal",
        "category": "Security",
        "description": "API calls failing due to expired SSL certificate on Developer Portal",
        "resolution": "Renewed SSL certificate and updated trust store",
        "resolution_time": "1 hour",
        "created_date": "2025-01-28",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012358",
        "title": "SAP CPI SSL certificate expired",
        "category": "Security",
        "description": "API calls failing due to expired SSL certificate in SAP CPI",
        "resolution": "Renewed SSL certificate and updated trust store",
        "resolution_time": "1 hour",
        "created_date": "2025-01-30",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012359",
        "title": "Azure APIM policy validation error",
        "category": "Integration",
        "description": "API policy validation failing for custom headers in Azure APIM",
        "resolution": "Updated policy XML schema and added proper namespace declarations",
        "resolution_time": "1.5 hours",
        "created_date": "2025-02-01",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012360",
        "title": "MFT encryption key rotation failed",
        "category": "Security",
        "description": "MFT system unable to complete encryption key rotation process",
        "resolution": "Restarted MFT service and manually triggered key rotation with proper permissions",
        "resolution_time": "2.5 hours",
        "created_date": "2025-02-02",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012361",
        "title": "SAP CPI adapter connection refused",
        "category": "Integration",
        "description": "SAP CPI unable to connect to backend system - connection refused on port 5432",
        "resolution": "Verified network connectivity and restarted SAP CPI integration adapter",
        "resolution_time": "45 minutes",
        "created_date": "2025-02-03",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012362",
        "title": "Developer Portal high memory consumption",
        "category": "Performance",
        "description": "Developer Portal consuming excessive memory - memory usage at 92%",
        "resolution": "Optimized caching strategy and cleared outdated API metadata",
        "resolution_time": "1 hour",
        "created_date": "2025-02-04",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012363",
        "title": "MFT scheduled job not executing",
        "category": "Deployment",
        "description": "Scheduled MFT batch job failing to execute at designated time",
        "resolution": "Fixed cron job configuration and updated system clock synchronization",
        "resolution_time": "1.5 hours",
        "created_date": "2025-02-05",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012364",
        "title": "Azure APIM rate limiting not working",
        "category": "Performance",
        "description": "Rate limiting policies in Azure APIM not enforcing throttling correctly",
        "resolution": "Updated rate limit configuration and cleared policy cache",
        "resolution_time": "2 hours",
        "created_date": "2025-02-06",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012365",
        "title": "SAP CPI interface monitoring alert",
        "category": "Performance",
        "description": "SAP CPI interface average response time exceeding 5 seconds threshold",
        "resolution": "Optimized data transformation logic and added database indexes",
        "resolution_time": "3 hours",
        "created_date": "2025-02-07",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012366",
        "title": "Developer Portal API documentation not loading",
        "category": "Integration",
        "description": "API documentation endpoints returning 404 errors in Developer Portal",
        "resolution": "Restored missing documentation files and rebuilt search indexes",
        "resolution_time": "1 hour",
        "created_date": "2025-02-08",
        "status": "Resolved"
    },
    {
        "ticket_id": "INC0012367",
        "title": "MFT file permission denied error",
        "category": "Security",
        "description": "MFT unable to write files to shared directory due to permission restrictions",
        "resolution": "Updated file system permissions and added MFT service account to proper groups",
        "resolution_time": "30 minutes",
        "created_date": "2025-02-09",
        "status": "Resolved"
    }
]

def open_browser():
    """Open browser after a delay"""
    webbrowser.open('http://localhost:5001/')

@app.route('/')
def index():
    """Serve the HTML UI from frontend/chatbot.html"""
    try:
        logger.info(f"Serving chatbot.html from {template_dir}")
        return send_from_directory(template_dir, 'chatbot.html')
    except Exception as e:
        logger.error(f"Error serving HTML: {str(e)}")
        return jsonify({'error': 'Frontend files not found. Place chatbot.html in frontend/ folder'}), 404

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'Chatbot API',
        'timestamp': datetime.now().isoformat(),
        'openai_configured': client is not None
    })

@app.route('/api/chat', methods=['POST'])
def chat():
    """Handle chat messages - Optimized for GPT-5-mini"""
    try:
        data = request.json
        message = data.get('message', '')
        session_id = data.get('session_id', 'default')
        
        if not message:
            return jsonify({'error': 'No message provided'}), 400
        
        logger.info(f"[CHAT] Message received: {message[:50]}...")
        
        if session_id not in conversations:
            conversations[session_id] = []
            logger.info(f"[CHAT] New session created: {session_id}")
        
        conversations[session_id].append({
            "role": "user",
            "content": message
        })
        
        # Find relevant tickets
        relevant_tickets = search_similar_tickets(message)
        logger.info(f"[CHAT] Found {len(relevant_tickets)} relevant tickets")
        
        if client is None:
            logger.warning("[CHAT] Azure OpenAI not configured, using mock response")
            assistant_message = generate_mock_response(message, relevant_tickets)
            suggested_actions = extract_actions(assistant_message)
            using_ai = False
        else:
            # Build concise context for GPT-5-mini (keep it simple)
            context = ""
            if relevant_tickets:
                context = "\nTicket Database (use this information ONLY):\n"
                for ticket in relevant_tickets[:3]:  # Include top 3 tickets
                    context += f"\nTicket: {ticket['ticket_id']}\n"
                    context += f"Title: {ticket['title']}\n"
                    context += f"Category: {ticket['category']}\n"
                    context += f"Description: {ticket['description']}\n"
                    context += f"Resolution: {ticket['resolution']}\n"
                    context += f"Time to resolve: {ticket['resolution_time']}\n"
            
            # Direct prompt using only the provided ticket data with structured format
            system_prompt = f"""You are a support assistant with access to a ticket database.
{context}

Format your response EXACTLY in this structure using plain text headers:

Brief summary of the issue
[Ticket ID] — [Title]

Description
[Ticket description]

Resolution (from ticket)
[What was done to fix it]

Root cause (from the ticket)
[Why did this happen - explain based on description and resolution]

Recommended resolution steps (actionable)
1. [First actionable step]
2. [Second actionable step]
3. [Third actionable step]
4. [Fourth actionable step]
5. [Fifth actionable step]

Preventive measures
- [First preventive measure]
- [Second preventive measure]
- [Third preventive measure]
- [Fourth preventive measure]

RULES:
1. Use ONLY the ticket information provided
2. Do not generate new information
3. Reference the specific ticket ID and title
4. Keep steps concise and actionable
5. Do NOT use asterisks, markdown, or bold formatting
6. Use plain text with clear section headers"""
            
            try:
                model_name = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-5-mini").lower()
                logger.info(f"[CHAT] Calling Azure OpenAI with model: {model_name}")
                
                if 'gpt-5' in model_name:
                    max_tokens = 6000
                else:
                    max_tokens = 1000
                
                messages = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": message}
                ]
                
                completion_params = {
                    'model': os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-5-mini"),
                    'messages': messages,
                    'max_completion_tokens': max_tokens
                }
                logger.info(f"[CHAT] Max tokens set to: {max_tokens}")
                
                if 'gpt-5' not in model_name:
                    completion_params['temperature'] = 0.5
                
                response = client.chat.completions.create(**completion_params)
                
                assistant_message = response.choices[0].message.content.strip()
                
                if not assistant_message:
                    logger.warning(f"[CHAT] Empty response. Finish reason: {response.choices[0].finish_reason}")
                    assistant_message = "I processed your request but received an empty response. Please try again or rephrase your question."
                
                # Extract suggested actions from AI response
                suggested_actions = extract_actions(assistant_message)
                using_ai = True
                
            except Exception as e:
                logger.error(f"[CHAT] Error calling API: {str(e)}")
                logger.warning("[CHAT] Falling back to mock response")
                assistant_message = generate_mock_response(message, relevant_tickets)
                suggested_actions = extract_actions(assistant_message)
                using_ai = False
        
        # Add to conversation
        conversations[session_id].append({
            "role": "assistant",
            "content": assistant_message
        })
        
        logger.info(f"[CHAT] Response generated - Source: {'AI' if using_ai else 'Mock'}, Actions: {len(suggested_actions)}")
        
        return jsonify({
            'success': True,
            'response': assistant_message,
            'suggested_actions': suggested_actions,
            'related_tickets': [t['ticket_id'] for t in relevant_tickets[:3]],
            'session_id': session_id,
            'source': 'ai' if using_ai else 'mock'
        })
        
    except Exception as e:
        logger.error(f"[CHAT] Exception: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/search-tickets', methods=['POST'])
def search_tickets():
    """Search historical tickets"""
    try:
        data = request.json
        query = data.get('query', '')
        category = data.get('category', 'all')
        
        logger.info(f"[SEARCH] Query: {query if query else '(empty - returning all)'}, Category: {category}")
        
        results = search_similar_tickets(query, category)
        logger.info(f"[SEARCH] Found {len(results)} results")
        
        return jsonify({
            'success': True,
            'results': results,
            'total': len(results)
        })
        
    except Exception as e:
        logger.error(f"[SEARCH] Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/ticket/<ticket_id>', methods=['GET'])
def get_ticket_details(ticket_id):
    """Get detailed ticket information"""
    try:
        logger.info(f"[TICKET] Fetching details for: {ticket_id}")
        
        ticket = None
        for t in historical_tickets:
            if t['ticket_id'] == ticket_id:
                ticket = t
                break
        
        if not ticket:
            logger.warning(f"[TICKET] Ticket not found: {ticket_id}")
            return jsonify({'error': 'Ticket not found'}), 404
        
        logger.info(f"[TICKET] Found ticket: {ticket_id}")
        
        return jsonify({
            'success': True,
            'ticket': ticket
        })
        
    except Exception as e:
        logger.error(f"[TICKET] Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/ticket-frequency', methods=['GET'])
def ticket_frequency():
    """Get ticket frequency grouped by similarity"""
    try:
        logger.info("[FREQUENCY] Calculating ticket frequency")
        
        frequency_data = get_ticket_frequency()
        
        logger.info(f"[FREQUENCY] Generated {len(frequency_data)} groups")
        
        return jsonify({
            'success': True,
            'frequency': frequency_data,
            'total_groups': len(frequency_data),
            'total_tickets': len(historical_tickets)
        })
        
    except Exception as e:
        logger.error(f"[FREQUENCY] Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/ticket-stats', methods=['GET'])
def ticket_stats():
    """Get ticket statistics"""
    try:
        logger.info("[STATS] Calculating ticket statistics")
        
        categories = {}
        total_resolution_time = 0
        
        for ticket in historical_tickets:
            category = ticket['category']
            categories[category] = categories.get(category, 0) + 1
            
            time_str = ticket['resolution_time']
            
            # Handle different time formats: "1 hour", "1.5 hours", "45 minutes", "30 minutes"
            try:
                if 'hour' in time_str.lower():
                    # Extract the number part (handles both "1" and "1.5")
                    hours = float(time_str.split()[0])
                    total_resolution_time += hours
                elif 'minute' in time_str.lower():
                    # Convert minutes to hours
                    minutes = float(time_str.split()[0])
                    hours = minutes / 60
                    total_resolution_time += hours
                else:
                    # Fallback: try to parse as number
                    hours = float(time_str.split()[0])
                    total_resolution_time += hours
            except (ValueError, IndexError) as e:
                logger.warning(f"[STATS] Could not parse time_str: {time_str} - {str(e)}")
                continue
        
        avg_resolution_time = total_resolution_time / len(historical_tickets) if historical_tickets else 0
        
        stats = {
            'total_tickets': len(historical_tickets),
            'categories': categories,
            'avg_resolution_time': f"{avg_resolution_time:.1f} hours",
            'most_common_category': max(categories.items(), key=lambda x: x[1])[0] if categories else None
        }
        
        logger.info(f"[STATS] Generated stats: {len(historical_tickets)} tickets, {len(categories)} categories")
        
        return jsonify({
            'success': True,
            'stats': stats
        })
        
    except Exception as e:
        logger.error(f"[STATS] Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/raise-ticket', methods=['POST'])
def raise_ticket():
    """Submit a new ticket"""
    try:
        data = request.json
        title = data.get('title', '')
        category = data.get('category', '')
        description = data.get('description', '')
        priority = data.get('priority', 'Medium')
        
        if not title or not category or not description:
            return jsonify({'error': 'Missing required fields: title, category, description'}), 400
        
        # Generate ticket ID
        ticket_id = f"INC{str(uuid.uuid4().int)[:7]}"
        
        new_ticket = {
            'ticket_id': ticket_id,
            'title': title,
            'category': category,
            'description': description,
            'priority': priority,
            'status': 'Open',
            'created_date': datetime.now().strftime('%Y-%m-%d'),
            'created_time': datetime.now().strftime('%H:%M:%S'),
            'resolution': 'Pending',
            'resolution_time': 'TBD'
        }
        
        raised_tickets.append(new_ticket)
        
        logger.info(f"[RAISE] New ticket created: {ticket_id}")
        logger.info(f"[RAISE] Title: {title}, Category: {category}, Priority: {priority}")
        
        return jsonify({
            'success': True,
            'ticket_id': ticket_id,
            'message': f'Ticket {ticket_id} has been successfully created',
            'ticket': new_ticket
        })
        
    except Exception as e:
        logger.error(f"[RAISE] Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/raised-tickets', methods=['GET'])
def get_raised_tickets():
    """Get all raised tickets"""
    try:
        logger.info(f"[RAISED] Fetching all raised tickets. Total: {len(raised_tickets)}")
        
        return jsonify({
            'success': True,
            'tickets': raised_tickets,
            'total': len(raised_tickets)
        })
        
    except Exception as e:
        logger.error(f"[RAISED] Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/clear-session', methods=['POST'])
def clear_session():
    """Clear chat session"""
    try:
        data = request.json
        session_id = data.get('session_id', 'default')
        
        if session_id in conversations:
            msg_count = len(conversations[session_id])
            del conversations[session_id]
            logger.info(f"[SESSION] Cleared session {session_id} ({msg_count} messages)")
        else:
            logger.info(f"[SESSION] Session {session_id} not found")
        
        return jsonify({
            'success': True,
            'message': 'Session cleared'
        })
        
    except Exception as e:
        logger.error(f"[SESSION] Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

def search_similar_tickets(query, category='all'):
    """Search for similar tickets using keyword matching"""
    query_lower = query.lower()
    results = []
    
    for ticket in historical_tickets:
        if category != 'all' and ticket['category'].lower() != category.lower():
            continue
        
        # If no query, return all tickets with equal score
        if not query_lower:
            ticket_copy = ticket.copy()
            ticket_copy['relevance_score'] = 0
            results.append(ticket_copy)
            continue
        
        score = 0
        
        # Search in ticket ID (high priority)
        if query_lower in ticket['ticket_id'].lower():
            score += 10
        
        # Search in title
        if query_lower in ticket['title'].lower():
            score += 3
        
        # Search in description
        if query_lower in ticket['description'].lower():
            score += 2
        
        # Search individual words (longer than 3 chars)
        words = query_lower.split()
        for word in words:
            if len(word) > 3:
                if word in ticket['ticket_id'].lower():
                    score += 5
                if word in ticket['title'].lower():
                    score += 1
                if word in ticket['description'].lower():
                    score += 1
        
        if score > 0:
            ticket_copy = ticket.copy()
            ticket_copy['relevance_score'] = score
            results.append(ticket_copy)
    
    results.sort(key=lambda x: x['relevance_score'], reverse=True)
    return results

def get_ticket_frequency():
    """Group similar tickets and return frequency count"""
    frequency_map = defaultdict(list)
    
    for ticket in historical_tickets:
        # Create a key based on category and title
        key = (ticket['category'], ticket['title'])
        frequency_map[key].append(ticket)
    
    # Create frequency results
    results = []
    for (category, title), tickets in frequency_map.items():
        representative_ticket = tickets[0]
        
        result = {
            'ticket_id': representative_ticket['ticket_id'],
            'title': title,
            'category': category,
            'description': representative_ticket['description'],
            'resolution': representative_ticket['resolution'],
            'resolution_time': representative_ticket['resolution_time'],
            'frequency': len(tickets),
            'ticket_ids': [t['ticket_id'] for t in tickets]
        }
        results.append(result)
    
    # Sort by frequency (most common first)
    results.sort(key=lambda x: x['frequency'], reverse=True)
    return results

def format_response(text):
    """Convert markdown bold (**text**) to HTML strong tags"""
    import re
    # Replace **text** with <strong>text</strong>
    text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
    return text

def extract_actions(message):
    """Extract suggested actions from message"""
    actions = []
    
    action_keywords = {
        'check': 'Check configuration',
        'restart': 'Restart service',
        'verify': 'Verify settings',
        'update': 'Update configuration',
        'review': 'Review logs',
        'contact': 'Contact support',
        'increase': 'Increase resources',
        'monitor': 'Monitor metrics',
        'clear': 'Clear cache',
        'test': 'Run tests'
    }
    
    message_lower = message.lower()
    for keyword, action in action_keywords.items():
        if keyword in message_lower:
            actions.append(action)
    
    return list(set(actions))[:4]

def generate_mock_response(query, relevant_tickets=None):
    """Generate mock response when OpenAI is not available with structured format"""
    logger.info("[MOCK] Generating mock response with structured format")
    
    # If we have relevant tickets from search, format them as structured response
    if relevant_tickets and len(relevant_tickets) > 0:
        ticket = relevant_tickets[0]
        logger.info(f"[MOCK] Using ticket data: {ticket['ticket_id']}")
        
        # Structured response format
        mock_response = f"""<strong>Brief summary of the issue</strong>
Ticket {ticket['ticket_id']} — {ticket['title']}

<strong>Description</strong>
{ticket['description']}

<strong>Resolution (from ticket)</strong>
{ticket['resolution']}

<strong>Root cause (from the ticket)</strong>
The issue occurred due to factors addressed in the resolution. Review the ticket description and resolution steps to understand the root cause and how it was fixed.

<strong>Recommended resolution steps (actionable)</strong>
1. {ticket['resolution']}
2. Verify the fix has been applied to your environment
3. Monitor system behavior and performance after applying the fix
4. Run tests to confirm the issue is resolved
5. Document the changes and monitor for any regressions

<strong>Preventive measures</strong>
- Establish monitoring and alerts for early detection of similar issues
- Periodically review and optimize configurations based on performance metrics
- Maintain documentation of known issues and their resolutions
- Schedule regular reviews of system health and performance
- Implement preventive maintenance schedules"""
        
        return mock_response
    
    # Generic fallback responses with structure
    responses = {
        'timeout': """**Brief summary of the issue**
Timeout issues detected in the system

**Description**
The system is experiencing timeout errors, indicating that operations are taking longer than the configured timeout threshold allows.

**Root cause**
Timeouts typically occur when backend services are slow, network latency is high, or timeout configurations are too aggressive.

**Recommended resolution steps (actionable)**
1. Increase timeout value in configuration to accommodate current response times
2. Optimize backend queries and services for better performance
3. Check network connectivity and latency
4. Review application logs for errors or slow operations
5. Monitor performance metrics before and after changes

**Preventive measures**
- Set up monitoring and alerts for response time metrics
- Perform load testing to determine appropriate timeout values
- Regularly review and optimize queries and services
- Document timeout configuration decisions and rationale""",
        
        'deployment': """**Brief summary of the issue**
Process deployment failure detected

**Description**
A deployment process has failed, preventing changes from being applied to the environment.

**Root cause**
Deployment failures often result from authentication issues, configuration problems, or firewall restrictions.

**Recommended resolution steps (actionable)**
1. Verify deployment credentials and permissions
2. Check firewall rules and network connectivity
3. Validate deployment configuration files
4. Review deployment logs for specific error messages
5. Test deployment in a staging environment first

**Preventive measures**
- Maintain updated deployment documentation
- Set up pre-deployment validation checks
- Use staging environment for testing before production
- Monitor deployment process logs
- Regularly review and update security policies""",
        
        'database': """**Brief summary of the issue**
Database connectivity or performance issue

**Description**
The application is experiencing problems connecting to or querying the database.

**Root cause**
Database issues can stem from connection pool exhaustion, credential problems, or slow queries.

**Recommended resolution steps (actionable)**
1. Check database connection pool settings and current usage
2. Verify database credentials and permissions
3. Review and optimize slow queries
4. Check available disk space and resources
5. Restart database services if necessary

**Preventive measures**
- Monitor connection pool usage and set up alerts
- Regularly review and optimize database queries
- Implement connection pooling and caching strategies
- Schedule regular database maintenance
- Set up monitoring for disk space and system resources""",
        
        'ssl': """**Brief summary of the issue**
SSL/TLS certificate issue detected

**Description**
API calls are failing due to SSL/TLS certificate problems or expiration.

**Root cause**
SSL issues typically result from expired certificates, invalid certificate chains, or misconfigured trust stores.

**Recommended resolution steps (actionable)**
1. Check certificate expiration dates
2. Verify the certificate chain is complete and valid
3. Renew or update the certificate if expired
4. Update the trust store with the new certificate
5. Test SSL/TLS connections after updates

**Preventive measures**
- Set up monitoring and alerts for certificate expiration dates
- Implement automated certificate renewal processes
- Maintain updated documentation of all certificates
- Regularly test SSL/TLS connections
- Schedule certificate renewal 30 days before expiration"""
    }
    
    for key, response in responses.items():
        if key in query.lower():
            logger.info(f"[MOCK] Matched key: {key}")
            return response
    
    logger.info("[MOCK] Using default response")
    return """**Brief summary of the issue**
Help needed with troubleshooting

**Description**
To provide better assistance, please provide more details about the issue.

**Root cause**
Unable to determine without more information.

**Recommended resolution steps (actionable)**
1. What is the exact error message or behavior?
2. When did this issue start occurring?
3. What changes were made recently?
4. What troubleshooting steps have already been tried?
5. What is the business impact of this issue?

**Preventive measures**
- Gather detailed error logs and system information
- Document the issue and steps to reproduce it
- Review recent changes or deployments
- Test changes in a staging environment first
- Monitor system health regularly"""

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    logger.info("="*80)
    logger.info("Starting Chatbot API on port 5001")
    logger.info("="*80)
    
    if not os.getenv("OPENAI_API_KEY"):
        logger.warning("⚠️ OPENAI_API_KEY not found in .env file!")
    if not os.getenv("AZURE_OPENAI_ENDPOINT"):
        logger.warning("⚠️ AZURE_OPENAI_ENDPOINT not found in .env file!")
    
    logger.info("="*80)
    
    # Open browser (no reloader, so no need to check WERKZEUG_RUN_MAIN)
    timer = Timer(1.0, open_browser)
    timer.daemon = True
    timer.start()
    
    app.run(debug=False, port=5001, host='0.0.0.0', use_reloader=False)