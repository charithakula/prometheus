import requests
import time
from datetime import datetime

SERVICES = [
    ("Code Review", "http://localhost:5000/api/health"),
    ("Chatbot", "http://localhost:5001/api/health"),
    ("Analytics", "http://localhost:5002/api/health"),
]

def check_health():
    print(f"\n{'='*60}")
    print(f"Service Health Check - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}")
    
    all_healthy = True
    for name, url in SERVICES:
        try:
            response = requests.get(url, timeout=2)
            if response.status_code == 200:
                data = response.json()
                print(f"✓ {name:20} - {data.get('status', 'unknown')}")
            else:
                print(f"✗ {name:20} - HTTP {response.status_code}")
                all_healthy = False
        except Exception as e:
            print(f"✗ {name:20} - {str(e)}")
            all_healthy = False
    
    print(f"{'='*60}")
    return all_healthy

if __name__ == "__main__":
    print("Starting service monitor... (Press Ctrl+C to stop)")
    
    try:
        while True:
            check_health()
            time.sleep(10)  # Check every 10 seconds
    except KeyboardInterrupt:
        print("\nMonitor stopped.")