import subprocess
import sys
import signal
import os
import time
from pathlib import Path

processes = []

def signal_handler(sig, frame):
    print("\nShutting down all services...")
    for p in processes:
        try:
            p.terminate()
        except:
            pass
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

# Define absolute paths
BASE_DIR = Path("A:/code-review-backend/gen3-ai-usecases").resolve()
backend_dir = BASE_DIR / "backend"

print(f"Base directory: {BASE_DIR}")
print(f"Backend directory: {backend_dir}\n")

apps = [
    ("Code Review", backend_dir / "flask_code_review.py", 5000),
    ("Chatbot", backend_dir / "flask_chatbot.py", 5001),
    ("Analytics", backend_dir / "flask_analytics.py", 5002),
]

# Start Flask apps
print("=" * 60)
print("STARTING FLASK SERVICES")
print("=" * 60)

for name, script, port in apps:
    if not script.exists():
        print(f"✗ {name} API - Script not found: {script}")
        continue
    
    try:
        p = subprocess.Popen([sys.executable, str(script)], cwd=str(BASE_DIR))
        processes.append(p)
        print(f"✓ {name} API (port {port}) started - PID: {p.pid}")
    except Exception as e:
        print(f"✗ {name} API - Error: {e}")

if not processes:
    print("No services started!")
    sys.exit(1)

# Wait a bit for services to start
print("\nWaiting 3 seconds for services to initialize...")
time.sleep(3)

# Start health check monitor
health_check_script = BASE_DIR / "health_check.py"
if health_check_script.exists():
    try:
        print("\n" + "=" * 60)
        print("STARTING HEALTH CHECK MONITOR")
        print("=" * 60)
        p = subprocess.Popen([sys.executable, str(health_check_script)], cwd=str(BASE_DIR))
        processes.append(p)
        print(f"✓ Health Check Monitor started - PID: {p.pid}\n")
    except Exception as e:
        print(f"✗ Health Check Monitor - Error: {e}\n")
else:
    print(f"\n⚠ Health check script not found at: {health_check_script}")
    print("Skipping health check monitor...\n")

print("=" * 60)
print("ALL SERVICES RUNNING")
print("=" * 60)
print("\nAccess the applications at:")
print("  • Code Review: http://localhost:5000")
print("  • Chatbot: http://localhost:5001")
print("  • Analytics: http://localhost:5002")
print("\nPress Ctrl+C to stop all services.\n")

try:
    for p in processes:
        p.wait()
except KeyboardInterrupt:
    signal_handler(None, None)