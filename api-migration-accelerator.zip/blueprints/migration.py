"""
Migration Blueprint - All migration-related routes
File: blueprints/migration.py

Routes:
- GET /api/migrations/stats - Get migration statistics - CACHED 60 seconds
- GET /api/migrations/<migration_id> - Get migration details - CACHED 300 seconds per ID
- POST /api/migrations/<migration_id>/rollback - Rollback migration
- DELETE /api/migrations/<migration_id> - Delete migration
- GET /api/migrations/<migration_id>/download - Download migration result
- GET /api/migrations/export - Export migration history
"""

from flask import Blueprint, request, jsonify, send_file
import json
import csv
import io
import traceback
from datetime import datetime
import logging
from models.database import db, MigrationRecord, APISpecification, MigrationLog
from auth import login_required
from utils.enhanced_file_handler_with_azure import EnhancedFileHandler

logger = logging.getLogger(__name__)

# Create blueprint
migration_bp = Blueprint('migration', __name__, url_prefix='/api/migrations')

# Initialize file handler
file_handler = EnhancedFileHandler()

# ✅ NEW: Global cache reference
_cache = None


def set_migration_cache(cache):
    """Set cache reference for migration routes"""
    global _cache
    _cache = cache
    logger.info("✅ Migration blueprint: cache reference set")


@migration_bp.route('/stats')
@login_required
def get_migration_stats():
    """Get migration statistics for the UI - CACHED for 60 seconds"""
    try:
        # ✅ NEW: Check cache first
        if _cache:
            cached_stats = _cache.get('migration_stats')
            if cached_stats:
                logger.debug("migration_stats: returning cached result")
                return cached_stats
        
        stats = {
            'total': MigrationRecord.query.count(),
            'completed': MigrationRecord.query.filter_by(status='completed').count(),
            'failed': MigrationRecord.query.filter_by(status='failed').count(),
            'pending': MigrationRecord.query.filter_by(status='in_progress').count() + 
                      MigrationRecord.query.filter_by(status='pending').count()
        }
        
        logger.info(f"✅ Migration stats retrieved: {stats}")
        
        response = jsonify({
            'success': True,
            'stats': stats
        })
        
        # ✅ NEW: Cache the response for 60 seconds
        if _cache:
            _cache.set('migration_stats', response, timeout=60)
            logger.debug("migration_stats: cached for 60 seconds")
        
        return response
        
    except Exception as e:
        logger.error(f"Failed to get migration stats: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'stats': {
                'total': 0,
                'completed': 0,
                'failed': 0,
                'pending': 0
            }
        }), 500


@migration_bp.route('/<migration_id>')
@login_required
def get_migration_details(migration_id):
    """Get detailed information about a specific migration - CACHED for 300 seconds per ID"""
    try:
        logger.info(f"Getting migration details: {migration_id}")
        
        # ✅ NEW: Check cache first with unique key per migration
        cache_key = f'migration_details_{migration_id}'
        if _cache:
            cached_details = _cache.get(cache_key)
            if cached_details:
                logger.debug(f"migration_details: returning cached result for {migration_id}")
                return cached_details
        
        migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
        
        if not migration:
            logger.warning(f"Migration not found: {migration_id}")
            return jsonify({
                'success': False,
                'error': 'Migration not found'
            }), 404
        
        logs = MigrationLog.query.filter_by(migration_id=migration_id).order_by(MigrationLog.timestamp.asc()).all()
        
        migration_data = migration.to_dict()
        migration_data['logs'] = [log.to_dict() for log in logs]
        
        logger.info(f"✅ Migration details retrieved: {migration_id}")
        
        response = jsonify(migration_data)
        
        # ✅ NEW: Cache the response for 300 seconds (5 minutes)
        if _cache:
            _cache.set(cache_key, response, timeout=300)
            logger.debug(f"migration_details: cached for 300 seconds - {migration_id}")
        
        return response
        
    except Exception as e:
        logger.error(f"Failed to get migration details: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@migration_bp.route('/<migration_id>/rollback', methods=['POST'])
@login_required
def rollback_migration(migration_id):
    """Rollback a migration"""
    try:
        logger.info(f"↩️  Rolling back migration: {migration_id}")
        
        migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
        if not migration:
            logger.warning(f"Migration not found: {migration_id}")
            return jsonify({'status': 'error', 'message': 'Migration not found'}), 404
        
        migration.status = 'rolled_back'
        migration.updated_at = datetime.now()
        db.session.commit()
        
        # ✅ NEW: Invalidate caches after mutation
        if _cache:
            _cache.delete('migration_stats')
            _cache.delete(f'migration_details_{migration_id}')
            logger.debug("rollback_migration: cleared cache")
        
        logger.info(f"✅ Migration rolled back: {migration_id}")
        
        return jsonify({'status': 'success', 'message': 'Migration rolled back successfully'})
        
    except Exception as e:
        logger.error(f"Failed to rollback migration: {e}")
        db.session.rollback()
        return jsonify({'status': 'error', 'message': str(e)}), 500


@migration_bp.route('/<migration_id>', methods=['DELETE'])
@login_required
def delete_migration(migration_id):
    """Delete a migration record"""
    try:
        logger.info(f"🗑️  Deleting migration: {migration_id}")
        
        migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
        if not migration:
            logger.warning(f"Migration not found: {migration_id}")
            return jsonify({'status': 'error', 'message': 'Migration not found'}), 404
        
        MigrationLog.query.filter_by(migration_id=migration_id).delete()
        db.session.delete(migration)
        db.session.commit()
        
        # ✅ NEW: Invalidate caches after mutation
        if _cache:
            _cache.delete('migration_stats')
            _cache.delete(f'migration_details_{migration_id}')
            logger.debug("delete_migration: cleared cache")
        
        logger.info(f"✅ Migration deleted: {migration_id}")
        
        return jsonify({'status': 'success', 'message': 'Migration deleted successfully'})
        
    except Exception as e:
        logger.error(f"Failed to delete migration: {e}")
        db.session.rollback()
        return jsonify({'status': 'error', 'message': str(e)}), 500


@migration_bp.route('/<migration_id>/download')
@login_required
def download_migration_result(migration_id):
    """Download migration result file (converted OpenAPI spec)"""
    try:
        logger.info(f"=== MIGRATION DOWNLOAD REQUEST ===")
        logger.info(f"Migration ID: {migration_id}")
        
        migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
        
        if not migration:
            logger.warning(f"Migration not found: {migration_id}")
            return jsonify({
                'status': 'error',
                'message': 'Migration not found'
            }), 404
        
        logger.info(f"Migration found - Status: {migration.status}")
        
        if migration.status != 'completed':
            logger.warning(f"Migration not completed - Status: {migration.status}")
            return jsonify({
                'status': 'error',
                'message': f'Migration not completed. Current status: {migration.status}'
            }), 400
        
        converted_filename = migration.converted_filename
        if not converted_filename:
            logger.warning(f"No converted filename found for migration: {migration_id}")
            return jsonify({
                'status': 'error',
                'message': 'Converted file not found for this migration'
            }), 404
        
        logger.info(f"Converted filename: {converted_filename}")
        
        try:
            blob_path = None
            if file_handler.use_azure:
                blob_path = f"converted/{converted_filename}"
                logger.info(f"Attempting to download from Azure: {blob_path}")
            else:
                logger.info(f"Attempting to download from local filesystem")
            
            file_info = file_handler.get_file_info(
                converted_filename, 
                folder_type='converted',
                blob_path=blob_path
            )
            
            if not file_info['success']:
                logger.error(f"Failed to get file info: {file_info}")
                return jsonify({
                    'status': 'error',
                    'message': f'Failed to retrieve converted file: {file_info.get("error", "Unknown error")}'
                }), 500
            
            logger.info(f"File retrieved successfully - Size: {file_info.get('file_size', 'unknown')} bytes")
            
            content = file_info.get('content', '')
            
            if not content:
                logger.error("File content is empty")
                return jsonify({
                    'status': 'error',
                    'message': 'Converted file is empty'
                }), 500
            
            # Parse content if string
            if isinstance(content, str):
                try:
                    spec_content = json.loads(content)
                    logger.info("Successfully parsed JSON from file content")
                except json.JSONDecodeError as e:
                    logger.error(f"Failed to parse JSON: {e}")
                    return jsonify({
                        'status': 'error',
                        'message': 'Converted file contains invalid JSON'
                    }), 500
            else:
                spec_content = content
            
            # Validate spec
            if not isinstance(spec_content, dict):
                logger.error("Converted spec is not a dictionary")
                return jsonify({
                    'status': 'error',
                    'message': 'Invalid specification format'
                }), 500
            
            if 'openapi' not in spec_content and 'swagger' not in spec_content:
                logger.warning("Spec does not have openapi or swagger field")
                return jsonify({
                    'status': 'error',
                    'message': 'Invalid OpenAPI specification'
                }), 500
            
            logger.info("✓ Spec validation passed")
            logger.info(f"  OpenAPI version: {spec_content.get('openapi', spec_content.get('swagger', 'unknown'))}")
            logger.info(f"  API Title: {spec_content.get('info', {}).get('title', 'Unknown')}")
            
            response_data = {
                'status': 'success',
                'spec': spec_content,
                'migration_info': {
                    'migration_id': migration.migration_id,
                    'api_name': migration.api_name,
                    'api_version': migration.api_version,
                    'conversion_method': migration.conversion_method,
                    'ai_used': migration.ai_conversion_used,
                    'completed_at': migration.updated_at.isoformat() if migration.updated_at else None,
                    'completion_time_seconds': migration.completion_time
                }
            }
            
            logger.info("=== DOWNLOAD SUCCESSFUL ===")
            return jsonify(response_data), 200
            
        except Exception as file_error:
            logger.error(f"Failed to retrieve converted file: {file_error}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            return jsonify({
                'status': 'error',
                'message': f'Failed to retrieve converted file: {str(file_error)}'
            }), 500
    
    except Exception as e:
        logger.error(f"=== DOWNLOAD ERROR ===")
        logger.error(f"Error: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({
            'status': 'error',
            'message': f'Download failed: {str(e)}'
        }), 500


@migration_bp.route('/export')
@login_required
def export_migrations():
    """Export migration history as CSV"""
    try:
        logger.info("📤 Exporting migrations")
        
        migrations = MigrationRecord.query.order_by(MigrationRecord.created_at.desc()).all()
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        writer.writerow([
            'Migration ID', 'API Name', 'Status', 'Source Platform', 'Target Platform',
            'Completion Time', 'Created At', 'Azure API ID', 'Error Message'
        ])
        
        for migration in migrations:
            writer.writerow([
                migration.migration_id,
                migration.api_name or '',
                migration.status,
                migration.source_platform,
                migration.target_platform,
                migration.completion_time or '',
                migration.created_at.isoformat() if migration.created_at else '',
                migration.azure_api_id or '',
                migration.error_message or ''
            ])
        
        output.seek(0)
        
        logger.info(f"✅ Migrations exported: {len(migrations)} items")
        
        return send_file(
            io.BytesIO(output.getvalue().encode('utf-8')),
            mimetype='text/csv',
            as_attachment=True,
            download_name=f'migration_history_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        )
        
    except Exception as e:
        logger.error(f"Failed to export migrations: {e}")
        return jsonify({'error': str(e)}), 500