"""
Health Blueprint - Health check and monitoring routes
File: blueprints/health.py

Routes:
- GET /health - Simple health check (no auth) - CACHED 10 seconds
- GET /api/health - Detailed health check (requires auth) - CACHED 10 seconds
"""

from flask import Blueprint, jsonify
import logging
import time
import threading
from datetime import datetime
from auth import login_required
from connectors import AzureAPIMConnector, AzureOpenAIConnector
from models.database import db
from sqlalchemy import text

logger = logging.getLogger(__name__)

# Create blueprint
health_bp = Blueprint('health', __name__)

# Global app reference (set by create_app)
_app = None
_app_start_time = None
_file_handler = None
_cache = None  # ✅ NEW: Reference to cache instance


def set_health_context(app, app_start_time, file_handler, cache=None):
    """Set global context for health checks"""
    global _app, _app_start_time, _file_handler, _cache
    _app = app
    _app_start_time = app_start_time
    _file_handler = file_handler
    _cache = cache  # ✅ NEW: Store cache reference


def test_database_connection():
    """Test database connection and return detailed status"""
    try:
        from config import get_config
        from models.database import MigrationRecord, APISpecification, MigrationLog
        from sqlalchemy.exc import OperationalError, DatabaseError, SQLAlchemyError
        
        config = get_config()
        db_type = 'sqlite' if 'sqlite' in config.DATABASE_URL else 'postgresql'
        db_name = 'migrations.db' if db_type == 'sqlite' else config.DATABASE_URL.split('/')[-1]
        
        try:
            result = db.session.execute(text('SELECT 1')).fetchone()
            if result is None:
                raise Exception("Query returned no results")
            
            db.session.commit()
            
            # Check tables
            try:
                MigrationRecord.query.limit(1).all()
                APISpecification.query.limit(1).all()
                MigrationLog.query.limit(1).all()
                tables_exist = True
            except (OperationalError, DatabaseError, SQLAlchemyError):
                tables_exist = False
            
            return {
                'status': 'success',
                'message': f'{db_type.title()} database connected successfully',
                'details': {
                    'database_type': db_type,
                    'database_name': db_name,
                    'tables_exist': tables_exist,
                    'connection_healthy': True
                }
            }
            
        except OperationalError as e:
            error_msg = str(e)
            if 'does not exist' in error_msg.lower():
                return {
                    'status': 'error',
                    'message': f'Database "{db_name}" does not exist',
                    'details': {
                        'database_type': db_type,
                        'database_name': db_name,
                        'tables_exist': False,
                        'connection_healthy': False,
                        'error_type': 'database_not_found'
                    }
                }
            elif 'connection' in error_msg.lower():
                return {
                    'status': 'error',
                    'message': f'Cannot connect to {db_type} database',
                    'details': {
                        'database_type': db_type,
                        'database_name': db_name,
                        'tables_exist': False,
                        'connection_healthy': False,
                        'error_type': 'connection_failed'
                    }
                }
            else:
                return {
                    'status': 'error',
                    'message': f'Database error: {str(e)[:100]}',
                    'details': {
                        'database_type': db_type,
                        'database_name': db_name,
                        'tables_exist': False,
                        'connection_healthy': False,
                        'error_type': 'operational_error'
                    }
                }
    
    except Exception as e:
        logger.error(f"Database connection test failed: {e}")
        return {
            'status': 'error',
            'message': 'Database service unavailable',
            'details': {
                'database_type': 'unknown',
                'database_name': 'unknown',
                'tables_exist': False,
                'connection_healthy': False,
                'error_type': 'service_unavailable'
            }
        }


def test_with_timeout(name, test_func, timeout=3):
    """Test service with timeout - returns proper status"""
    result = {
        'status': 'warning',
        'message': f'{name} check timed out',
        'response_time_ms': None
    }
    
    start_time = time.time()
    test_complete = threading.Event()
    result_holder = {'result': None}
    
    def do_test():
        try:
            # Push app context in thread
            if _app:
                with _app.app_context():
                    result_holder['result'] = test_func()
            else:
                result_holder['result'] = test_func()
        except Exception as e:
            logger.warning(f"{name} test error: {str(e)[:100]}")
            result_holder['result'] = {
                'status': 'error',
                'message': str(e)[:100]
            }
        finally:
            test_complete.set()
    
    thread = threading.Thread(target=do_test, daemon=True)
    thread.start()
    
    # Wait for test to complete or timeout
    if test_complete.wait(timeout=timeout):
        elapsed = (time.time() - start_time) * 1000
        if result_holder['result']:
            result = result_holder['result']
            result['response_time_ms'] = round(elapsed, 2)
            logger.info(f"  {name}: {result.get('status', 'unknown')} ({elapsed:.0f}ms)")
        else:
            logger.warning(f"  {name}: no result but completed")
    else:
        elapsed = (time.time() - start_time) * 1000
        result['response_time_ms'] = round(elapsed, 2)
        logger.warning(f"  {name}: timed out after {elapsed:.0f}ms")
    
    return result


@health_bp.route('/health')
def simple_health():
    """
    Simple quick health check (no auth required)
    Just checks database availability
    ✅ CACHED for 10 seconds
    """
    try:
        # ✅ NEW: Try to get from cache first (if cache is enabled)
        if _cache:
            cached_result = _cache.get('simple_health_check')
            if cached_result:
                logger.debug("simple_health: returning cached result")
                return cached_result
        
        db.session.execute(text('SELECT 1')).fetchone()
        response = jsonify({
            'status': 'ok',
            'timestamp': datetime.now().isoformat()
        }), 200
        
        # ✅ NEW: Cache the successful response
        if _cache:
            _cache.set('simple_health_check', response, timeout=10)
            logger.debug("simple_health: cached result for 10 seconds")
        
        return response
    
    except Exception as e:
        logger.warning(f"Simple health check failed: {e}")
        # Don't cache errors
        return jsonify({
            'status': 'unhealthy',
            'error': str(e)[:100]
        }), 503


@health_bp.route('/api/health')
@login_required
def health_check():
    """
    Detailed health check with actual service testing
    Tests all services and returns comprehensive status
    ✅ CACHED for 10 seconds
    """
    try:
        # ✅ NEW: Try to get from cache first (if cache is enabled)
        if _cache:
            cached_result = _cache.get('detailed_health_check')
            if cached_result:
                logger.debug("health_check: returning cached result")
                return cached_result
        
        uptime = (datetime.now() - _app_start_time).total_seconds()
        
        service_status = {}
        
        # ==========================================
        # TEST AZURE APIM
        # ==========================================
        
        logger.info("Testing Azure APIM...")
        try:
            apim_connector = AzureAPIMConnector()
            
            if not apim_connector.is_available:
                service_status['azure_apim'] = {
                    'status': 'warning',
                    'message': 'Azure APIM not configured',
                    'details': 'Set AZURE_APIM_SERVICE_NAME and AZURE_APIM_API_KEY'
                }
            else:
                def test_apim():
                    return apim_connector.test_connection()
                
                result = test_with_timeout('Azure APIM', test_apim, timeout=5)
                
                if result.get('status') == 'success':
                    service_status['azure_apim'] = {
                        'status': 'success',
                        'message': f"Connected to {result.get('api_management_name', 'Azure APIM')}",
                        'details': result.get('message'),
                        'response_time_ms': result.get('response_time_ms')
                    }
                else:
                    service_status['azure_apim'] = result
        
        except Exception as e:
            logger.error(f"APIM test error: {e}")
            service_status['azure_apim'] = {
                'status': 'error',
                'message': f'APIM connection failed: {str(e)[:80]}'
            }
        
        # ==========================================
        # TEST AZURE OPENAI
        # ==========================================
        
        logger.info("Testing Azure OpenAI...")
        try:
            openai_connector = AzureOpenAIConnector()
            
            if not openai_connector.is_available:
                service_status['azure_openai'] = {
                    'status': 'warning',
                    'message': 'Azure OpenAI not configured',
                    'details': 'Set OPENAI_API_KEY and OPENAI_RESOURCE_NAME'
                }
            else:
                def test_openai():
                    return openai_connector.test_connection()
                
                result = test_with_timeout('Azure OpenAI', test_openai, timeout=5)
                
                if result.get('status') == 'success':
                    service_status['azure_openai'] = {
                        'status': 'success',
                        'message': f"Connected to {result.get('deployment', 'Azure OpenAI')}",
                        'details': f"Model: {result.get('model_name', 'Unknown')}",
                        'response_time_ms': result.get('response_time_ms')
                    }
                else:
                    service_status['azure_openai'] = result
        
        except Exception as e:
            logger.error(f"OpenAI test error: {e}")
            service_status['azure_openai'] = {
                'status': 'error',
                'message': f'OpenAI connection failed: {str(e)[:80]}'
            }
        
        # ==========================================
        # TEST DATABASE
        # ==========================================
        
        logger.info("Testing Database...")
        try:
            def test_db():
                return test_database_connection()
            
            result = test_with_timeout('Database', test_db, timeout=5)
            
            if result.get('status') == 'success':
                details = result.get('details', {})
                tables_exist = details.get('tables_exist', False)
                
                if tables_exist:
                    service_status['database'] = {
                        'status': 'success',
                        'message': f"{details.get('database_type', 'Database').title()} connected",
                        'details': f"DB: {details.get('database_name', 'unknown')}",
                        'response_time_ms': result.get('response_time_ms')
                    }
                else:
                    service_status['database'] = {
                        'status': 'warning',
                        'message': 'Database connected but tables need initialization',
                        'details': f"DB: {details.get('database_name', 'unknown')} - run /api/database/initialize",
                        'response_time_ms': result.get('response_time_ms')
                    }
            else:
                service_status['database'] = result
        
        except Exception as e:
            logger.error(f"Database test error: {e}")
            service_status['database'] = {
                'status': 'error',
                'message': f'Database connection failed: {str(e)[:80]}'
            }
        
        # ==========================================
        # TEST STORAGE
        # ==========================================
        
        logger.info("Testing Storage...")
        try:
            def test_storage():
                if _file_handler and _file_handler.use_azure:
                    return {
                        'status': 'success',
                        'message': 'Connected to Azure Blob Storage',
                        'account': _file_handler.azure_storage.account_name,
                        'storage_type': 'azure'
                    }
                else:
                    return {
                        'status': 'success',
                        'message': 'Using local filesystem storage',
                        'storage_type': 'local'
                    }
            
            result = test_with_timeout('Storage', test_storage, timeout=3)
            
            if result.get('status') == 'success':
                storage_type = result.get('storage_type', 'local')
                service_status['storage'] = {
                    'status': 'success',
                    'message': result.get('message'),
                    'storage_type': storage_type,
                    'details': result.get('account') or 'Local filesystem',
                    'response_time_ms': result.get('response_time_ms')
                }
            else:
                service_status['storage'] = result
        
        except Exception as e:
            logger.error(f"Storage test error: {e}")
            service_status['storage'] = {
                'status': 'warning',
                'message': 'Storage check failed, will use local filesystem',
                'storage_type': 'local'
            }
        
        # ==========================================
        # CALCULATE OVERALL HEALTH STATUS
        # ==========================================
        
        success_count = sum(1 for s in service_status.values() if s.get('status') == 'success')
        warning_count = sum(1 for s in service_status.values() if s.get('status') == 'warning')
        error_count = sum(1 for s in service_status.values() if s.get('status') == 'error')
        total_count = len(service_status)
        
        logger.info(f"Service Summary: {success_count} success, {warning_count} warning, {error_count} error")
        
        if error_count > 0 and success_count == 0:
            overall_status = 'unhealthy'
        elif error_count > 0 or warning_count > 0:
            overall_status = 'degraded'
        else:
            overall_status = 'healthy'
        
        logger.info(f"Overall Health: {overall_status}")
        
        response = jsonify({
            'status': overall_status,
            'timestamp': datetime.now().isoformat(),
            'uptime_seconds': int(uptime),
            'version': '1.0.0',
            'services': service_status,
            'summary': {
                'total_services': total_count,
                'healthy': success_count,
                'degraded': warning_count,
                'unhealthy': error_count
            }
        }), 200
        
        # ✅ NEW: Cache the successful response for 10 seconds
        if _cache:
            _cache.set('detailed_health_check', response, timeout=10)
            logger.debug("health_check: cached result for 10 seconds")
        
        return response
    
    except Exception as e:
        logger.error(f"Health check error: {e}")
        # Don't cache errors
        return jsonify({
            'status': 'error',
            'message': f'Health check failed: {str(e)}',
            'timestamp': datetime.now().isoformat()
        }), 500