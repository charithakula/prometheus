"""
Conversion Blueprint - Minimal separation of just 2 routes
File: blueprints/conversion.py

Routes:
- POST /api/convert - Convert OpenAPI specification (NOT cached, mutates data)
- POST /api/convert/preview - Get conversion preview (CACHED 120 seconds per spec)
"""

from flask import Blueprint, request, jsonify
import logging
import json
import yaml
import traceback
from datetime import datetime
from auth import login_required
from models.database import db, MigrationRecord, MigrationLog, APISpecification
from services.conversion_service import ConversionService
from utils import generate_id
from pydantic import BaseModel, Field
from typing import Optional

logger = logging.getLogger(__name__)

# Create blueprint
conversion_bp = Blueprint('conversion', __name__, url_prefix='/api/convert')

# Initialize conversion service
conversion_service = ConversionService()

# ✅ NEW: Global cache reference
_cache = None

# Schema for validation
class ConversionRequestSchema(BaseModel):
    """Schema for API conversion requests"""
    spec_content: str = Field(..., description="OpenAPI specification content")
    source_format: Optional[str] = Field(default='auto', description="Source format (auto, json, yaml)")
    include_debug: Optional[bool] = Field(default=False, description="Include debug information in response")


def set_conversion_cache(cache):
    """Set cache reference for conversion routes"""
    global _cache
    _cache = cache
    logger.info("✅ Conversion blueprint: cache reference set")


def create_migration_record_safe(migration_record_data):
    """Safely create migration record with fallback"""
    try:
        migration_record = MigrationRecord(**migration_record_data)
        db.session.add(migration_record)
        db.session.commit()
        logger.info(f"Created migration record with ID: {migration_record.migration_id}")
        return migration_record
    except Exception as e:
        logger.warning(f"Failed to create migration record: {e}")
        db.session.rollback()
        return None


def update_migration_record_safe(migration_record, **updates):
    """Safely update migration record with fallback"""
    try:
        for key, value in updates.items():
            if hasattr(migration_record, key):
                setattr(migration_record, key, value)
        migration_record.updated_at = datetime.now()
        db.session.commit()
        return True
    except Exception as e:
        logger.warning(f"Failed to update migration record: {e}")
        db.session.rollback()
        return False


def extract_api_info(spec: dict) -> dict:
    """Extract API information from OpenAPI specification"""
    try:
        info = spec.get('info', {})
        return {
            'title': info.get('title', 'Unknown API'),
            'version': info.get('version', '1.0.0'),
            'description': info.get('description', ''),
            'format': spec.get('swagger', spec.get('openapi', 'Unknown')),
            'paths_count': len(spec.get('paths', {})),
            'definitions_count': len(spec.get('definitions', spec.get('components', {}).get('schemas', {}))),
            'operations_count': sum(
                len([op for op in path_item.values() if isinstance(op, dict) and op.get('responses')])
                for path_item in spec.get('paths', {}).values()
                if isinstance(path_item, dict)
            )
        }
    except Exception as e:
        logger.warning(f"Failed to extract API info: {e}")
        return {
            'title': 'Unknown API',
            'version': '1.0.0',
            'description': '',
            'format': 'Unknown',
            'paths_count': 0,
            'definitions_count': 0,
            'operations_count': 0
        }


@conversion_bp.route('', methods=['POST'])
@login_required
def convert_api():
    """Convert OpenAPI specification with enhanced file storage and database tracking
    ❌ NOT CACHED (performs conversion, mutates data)
    """
    migration_record = None
    api_spec_record = None
    
    try:
        data = request.get_json()
        if not data:
            logger.error("No JSON data provided in conversion request")
            return jsonify({'error': 'No JSON data provided'}), 400
        
        logger.info(f"=== CONVERSION REQUEST RECEIVED ===")
        logger.info(f"Request data keys: {list(data.keys())}")
        logger.info(f"spec_content length: {len(data.get('spec_content', ''))}")
        
        try:
            request_data = ConversionRequestSchema(**data)
            logger.info("Request data validation successful")
        except Exception as e:
            logger.error(f"ConversionRequestSchema validation failed: {str(e)}")
            return jsonify({
                'error': f'Invalid request data: {str(e)}',
                'received_fields': list(data.keys()),
                'expected_fields': ['spec_content', 'source_format (optional)', 'include_debug (optional)']
            }), 400
        
        migration_id = generate_id()
        logger.info(f"Generated migration ID: {migration_id}")
        
        try:
            spec_content = request_data.spec_content.strip()
            if spec_content.startswith('{'):
                original_spec = json.loads(spec_content)
            else:
                original_spec = yaml.safe_load(spec_content)
                
            api_info = extract_api_info(original_spec)
            logger.info(f"Extracted API info: {api_info}")
            
        except Exception as e:
            logger.warning(f"Failed to parse original spec for info extraction: {e}")
            api_info = {
                'title': 'Unknown API',
                'version': '1.0.0',
                'format': 'unknown'
            }
        
        migration_record_data = {
            'migration_id': migration_id,
            'original_api_id': api_info.get('title', 'unknown').replace(' ', '_'),
            'api_name': api_info.get('title', 'Unknown API'),
            'api_version': api_info.get('version', '1.0.0'),
            'status': 'in_progress',
            'source_platform': 'file_upload',
            'target_platform': 'azure_apim',
            'start_time': datetime.now(),
            'original_filename': f"{api_info.get('title', 'api')}.json",
            'conversion_method': 'pending',
            'ai_conversion_used': False,
            'migration_metadata': {}
        }
        
        migration_record = create_migration_record_safe(migration_record_data)
        if migration_record:
            logger.info(f"Created migration record with ID: {migration_id}")
        else:
            logger.warning(f"Failed to create migration record - continuing without database tracking")
        
        try:
            api_spec_record = APISpecification(
                api_id=f"{api_info.get('title', 'unknown').replace(' ', '_')}_{migration_id[:8]}",
                name=api_info.get('title', 'Unknown API'),
                version=api_info.get('version', '1.0.0'),
                description=api_info.get('description', ''),
                format=api_info.get('format', 'unknown'),
                specification=original_spec,
                source_platform='file_upload',
                original_filename=f"{api_info.get('title', 'api')}.json",
                paths_count=api_info.get('paths_count', 0),
                operations_count=api_info.get('operations_count', 0),
                definitions_count=api_info.get('definitions_count', 0),
                is_valid=True
            )
            
            db.session.add(api_spec_record)
            db.session.commit()
            logger.info(f"Created API specification record with ID: {api_spec_record.api_id}")
            
        except Exception as e:
            logger.warning(f"Failed to create API specification record: {e}")
        
        try:
            if migration_record:
                log_entry = MigrationLog(
                    migration_id=migration_id,
                    level='INFO',
                    stage='conversion_start',
                    message='Starting OpenAPI conversion process',
                    details={'source_format': request_data.source_format}
                )
                db.session.add(log_entry)
                db.session.commit()
        except Exception as e:
            logger.warning(f"Failed to create log entry: {e}")
        
        conversion_start_time = datetime.now()
        try:
            logger.info("Starting conversion process...")
            
            import inspect
            convert_sig = inspect.signature(conversion_service.convert_specification)
            supports_debug = 'include_debug' in convert_sig.parameters
            
            if supports_debug:
                logger.info("ConversionService supports include_debug parameter")
                conversion_result = conversion_service.convert_specification(
                    request_data.spec_content,
                    request_data.source_format,
                    include_debug=request_data.include_debug
                )
            else:
                logger.info("ConversionService does not support include_debug, calling without it")
                conversion_result = conversion_service.convert_specification(
                    request_data.spec_content,
                    request_data.source_format
                )
                
                if request_data.include_debug:
                    logger.info("Adding placeholder debug information")
                    conversion_result['raw_openai_response'] = "Debug info not available - ConversionService needs to be updated"
                    conversion_result['cleaned_json'] = "Debug info not available - ConversionService needs to be updated"
                    conversion_result['cleaning_issues'] = "ConversionService does not support debug mode yet"
            
            conversion_end_time = datetime.now()
            conversion_time = (conversion_end_time - conversion_start_time).total_seconds()
            
            logger.info(f"Conversion completed with status: {conversion_result.get('status')}")
            
            if migration_record:
                update_data = {}
                if conversion_result.get('status') == 'success':
                    update_data.update({
                        'status': 'completed',
                        'end_time': conversion_end_time,
                        'completion_time': conversion_time,
                        'conversion_method': 'ai_powered' if conversion_result.get('ai_conversion_used') else 'programmatic',
                        'ai_conversion_used': conversion_result.get('ai_conversion_used', False),
                        'conversion_notes': f"Conversion completed successfully in {conversion_time:.2f}s",
                        'migration_metadata': {
                            'conversion_time': conversion_time,
                            'ai_used': conversion_result.get('ai_conversion_used', False),
                            'conversion_metadata': conversion_result.get('conversion_metadata', {}),
                            'validation_results': conversion_result.get('validation', {})
                        }
                    })
                else:
                    update_data.update({
                        'status': 'failed',
                        'end_time': conversion_end_time,
                        'error_message': conversion_result.get('message', 'Conversion failed')
                    })
                
                if update_migration_record_safe(migration_record, **update_data):
                    logger.info(f"Updated migration record status: {migration_record.status}")
                    
                    try:
                        log_entry = MigrationLog(
                            migration_id=migration_id,
                            level='INFO' if conversion_result.get('status') == 'success' else 'ERROR',
                            stage='conversion_complete',
                            message=f"Conversion {conversion_result.get('status')} in {conversion_time:.2f}s",
                            details={
                                'conversion_time': conversion_time,
                                'ai_used': conversion_result.get('ai_conversion_used', False),
                                'status': conversion_result.get('status')
                            }
                        )
                        db.session.add(log_entry)
                        db.session.commit()
                    except Exception as e:
                        logger.warning(f"Failed to create completion log: {e}")
            
            if conversion_result.get('status') == 'success' and 'converted_spec' in conversion_result:
                try:
                    api_info_from_converted = conversion_result.get('converted_spec', {}).get('info', {})
                    api_title = api_info_from_converted.get('title', api_info.get('title', 'converted_api'))
                    original_filename = f"{api_title.replace(' ', '_')}_converted_{migration_id[:8]}.json"
                    
                    # Note: file_handler would need to be imported if file saving is required
                    # save_result = file_handler.save_converted_file(...)
                    
                except Exception as save_error:
                    logger.warning(f"Failed to save converted file: {save_error}")
            
            # ✅ NEW: Invalidate preview cache after conversion
            if _cache:
                _cache.delete('conversion_preview_cache')
                logger.debug("convert_api: cleared preview cache after conversion")
            
            conversion_result['migration_id'] = migration_id
            
            return jsonify(conversion_result)
            
        except Exception as conversion_error:
            logger.error(f"Conversion process failed: {str(conversion_error)}")
            logger.error(f"Conversion error traceback: {traceback.format_exc()}")
            
            if migration_record:
                update_migration_record_safe(migration_record, 
                    status='failed',
                    end_time=datetime.now(),
                    error_message=str(conversion_error)
                )
                
                try:
                    log_entry = MigrationLog(
                        migration_id=migration_id,
                        level='ERROR',
                        stage='conversion_error',
                        message=f"Conversion failed: {str(conversion_error)}",
                        details={'error_type': type(conversion_error).__name__}
                    )
                    db.session.add(log_entry)
                    db.session.commit()
                except Exception as e:
                    logger.warning(f"Failed to log conversion error: {e}")
            
            return jsonify({
                'status': 'error',
                'message': f'Conversion failed: {str(conversion_error)}',
                'error_type': type(conversion_error).__name__,
                'migration_id': migration_id
            }), 500
        
    except Exception as e:
        logger.error(f"Conversion endpoint failed: {e}")
        logger.error(f"Full traceback: {traceback.format_exc()}")
        
        if migration_record:
            update_migration_record_safe(migration_record, 
                status='failed',
                error_message=str(e)
            )
        
        return jsonify({
            'status': 'error',
            'message': f'Conversion failed: {str(e)}'
        }), 500


@conversion_bp.route('/preview', methods=['POST'])
@login_required
def conversion_preview():
    """Get conversion preview without performing full conversion
    ✅ CACHED for 120 seconds per spec
    """
    try:
        data = request.get_json()
        if not data or 'spec_content' not in data:
            return jsonify({'error': 'No specification content provided'}), 400
        
        # ✅ NEW: Create cache key based on spec content hash
        import hashlib
        spec_hash = hashlib.md5(data['spec_content'].encode()).hexdigest()
        cache_key = f'conversion_preview_{spec_hash}'
        
        # ✅ NEW: Check cache first
        if _cache:
            cached_result = _cache.get(cache_key)
            if cached_result:
                logger.debug(f"conversion_preview: returning cached result for {spec_hash[:8]}")
                return cached_result
        
        logger.info("🔍 Getting conversion preview")
        preview_result = conversion_service.get_conversion_preview(data['spec_content'])
        
        response = jsonify(preview_result)
        
        # ✅ NEW: Cache successful response for 120 seconds (2 minutes)
        if _cache:
            _cache.set(cache_key, response, timeout=120)
            logger.debug(f"conversion_preview: cached for 120 seconds - {spec_hash[:8]}")
        
        return response
        
    except Exception as e:
        logger.error(f"Conversion preview failed: {e}")
        return jsonify({
            'status': 'error',
            'message': f'Preview failed: {str(e)}'
        }), 500