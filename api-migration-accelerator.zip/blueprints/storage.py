"""
Storage Blueprint - All storage-related routes
File: blueprints/storage.py

Routes:
- GET /api/storage/status - Check storage status - CACHED 30 seconds
- GET /api/storage/info - Get storage info - CACHED 60 seconds
- GET /api/storage/stats - Get storage statistics - CACHED 60 seconds
- POST /api/storage/test - Test storage connection (NOT cached)
- POST /api/storage/cleanup - Cleanup old files (NOT cached, invalidates cache)
- GET /api/storage/quota - Get storage quota - CACHED 60 seconds
- GET /api/storage/config - Get storage config - CACHED 300 seconds
- GET /api/storage/debug/details - Get debug details - CACHED 30 seconds
"""

from flask import Blueprint, request, jsonify, current_app
from datetime import datetime
from functools import wraps
import logging

# Import services
from services.storage_service import StorageService
from auth import login_required

logger = logging.getLogger(__name__)

# Create blueprint
storage_bp = Blueprint('storage', __name__, url_prefix='/api/storage')

# Initialize storage service (lazy loaded)
_storage_service = None
_cache = None  # ✅ NEW: Global cache reference


def get_storage_service():
    """Lazy load storage service"""
    global _storage_service
    if _storage_service is None:
        _storage_service = StorageService()
        logger.info("✅ StorageService initialized")
    return _storage_service


def set_storage_cache(cache):
    """Set cache reference for storage routes"""
    global _cache
    _cache = cache
    logger.info("✅ Storage blueprint: cache reference set")


# ==========================================
# STORAGE STATUS ROUTES
# ==========================================

@storage_bp.route('/status', methods=['GET'])
def get_status():
    """
    Check Azure Blob Storage health and return status
    ✅ CACHED for 30 seconds
    
    Returns:
    {
        'success': bool,
        'status': str (not_configured|local_fallback|connected|error),
        'storage_type': str (local|azure),
        'message': str,
        'account_name': str (if azure),
        'stats': dict (if connected)
    }
    """
    try:
        logger.info("🔍 Storage status check requested")
        
        # ✅ NEW: Check cache first
        if _cache:
            cached_status = _cache.get('storage_status')
            if cached_status:
                logger.debug("storage_status: returning cached result")
                return cached_status
        
        storage_service = get_storage_service()
        status_result = storage_service.check_status()
        
        if not status_result['success']:
            logger.warning(f"Storage status check failed: {status_result.get('message')}")
            return jsonify(status_result), 500
        
        logger.info(f"✅ Storage status: {status_result.get('status')}")
        response = jsonify(status_result), 200
        
        # ✅ NEW: Cache successful response for 30 seconds
        if _cache:
            _cache.set('storage_status', response, timeout=30)
            logger.debug("storage_status: cached for 30 seconds")
        
        return response
    
    except Exception as e:
        logger.error(f"Storage status check error: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'status': 'error',
            'storage_type': 'unknown',
            'message': f'Storage status check failed: {str(e)[:100]}',
            'error': str(e)
        }), 500


@storage_bp.route('/info', methods=['GET'])
@login_required
def get_info():
    """
    Get detailed storage information
    ✅ CACHED for 60 seconds
    
    Returns:
    {
        'success': bool,
        'storage_type': str (local|azure),
        'using_fallback': bool,
        'account_name': str,
        'container_name': str,
        'endpoint': str,
        'stats': dict
    }
    """
    try:
        logger.info("📊 Storage info requested")
        
        # ✅ NEW: Check cache first
        if _cache:
            cached_info = _cache.get('storage_info')
            if cached_info:
                logger.debug("storage_info: returning cached result")
                return cached_info
        
        storage_service = get_storage_service()
        info_result = storage_service.get_info()
        
        if not info_result['success']:
            logger.warning(f"Failed to get storage info: {info_result.get('message')}")
            return jsonify(info_result), 500
        
        logger.info(f"✅ Storage info retrieved: {info_result.get('storage_type')}")
        response = jsonify(info_result), 200
        
        # ✅ NEW: Cache successful response for 60 seconds
        if _cache:
            _cache.set('storage_info', response, timeout=60)
            logger.debug("storage_info: cached for 60 seconds")
        
        return response
    
    except Exception as e:
        logger.error(f"Storage info error: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@storage_bp.route('/stats', methods=['GET'])
@login_required
def get_stats():
    """
    Get storage statistics
    ✅ CACHED for 60 seconds
    
    Returns:
    {
        'success': bool,
        'folders': dict (stats per folder),
        'totals': dict (overall stats),
        'storage_type': str
    }
    """
    try:
        logger.info("📈 Storage stats requested")
        
        # ✅ NEW: Check cache first
        if _cache:
            cached_stats = _cache.get('storage_stats')
            if cached_stats:
                logger.debug("storage_stats: returning cached result")
                return cached_stats
        
        storage_service = get_storage_service()
        stats_result = storage_service.get_stats()
        
        if not stats_result['success']:
            logger.warning(f"Failed to get storage stats: {stats_result.get('error')}")
            return jsonify(stats_result), 500
        
        logger.info(f"✅ Storage stats retrieved")
        response = jsonify(stats_result), 200
        
        # ✅ NEW: Cache successful response for 60 seconds
        if _cache:
            _cache.set('storage_stats', response, timeout=60)
            logger.debug("storage_stats: cached for 60 seconds")
        
        return response
    
    except Exception as e:
        logger.error(f"Storage stats error: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# STORAGE TEST ROUTES
# ==========================================

@storage_bp.route('/test', methods=['POST'])
@login_required
def test_connection():
    """
    Test storage connection by uploading, downloading, and deleting a test file
    ❌ NOT CACHED (real-time test)
    
    Returns:
    {
        'success': bool,
        'storage_type': str,
        'message': str,
        'upload_time_ms': float,
        'download_time_ms': float,
        'delete_time_ms': float
    }
    """
    try:
        logger.info("🧪 Storage connection test starting")
        
        storage_service = get_storage_service()
        test_result = storage_service.test_connection()
        
        if not test_result['success']:
            logger.error(f"Storage test failed: {test_result.get('message')}")
            return jsonify(test_result), 500
        
        logger.info(f"✅ Storage test passed: {test_result.get('storage_type')}")
        logger.info(f"   Upload: {test_result.get('upload_time_ms')}ms")
        logger.info(f"   Download: {test_result.get('download_time_ms')}ms")
        logger.info(f"   Delete: {test_result.get('delete_time_ms')}ms")
        
        return jsonify(test_result), 200
    
    except Exception as e:
        logger.error(f"Storage test error: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'storage_type': 'unknown',
            'message': f'Storage test failed: {str(e)[:100]}'
        }), 500


# ==========================================
# STORAGE CLEANUP ROUTES
# ==========================================

@storage_bp.route('/cleanup', methods=['POST'])
@login_required
def cleanup():
    """
    Clean up old files from storage
    ❌ NOT CACHED (mutates data, invalidates cache)
    
    Request:
    {
        'days_old': int (default: 7)
    }
    
    Returns:
    {
        'success': bool,
        'files_deleted': int,
        'space_freed_mb': float,
        'message': str
    }
    """
    try:
        logger.info("🧹 Storage cleanup requested")
        
        data = request.get_json() or {}
        days_old = data.get('days_old', 7)
        
        # Validate input
        if not isinstance(days_old, int) or days_old < 0:
            logger.warning(f"Invalid days_old parameter: {days_old}")
            return jsonify({
                'success': False,
                'error': 'Invalid days_old parameter. Must be a non-negative integer.'
            }), 400
        
        logger.info(f"Cleaning files older than {days_old} days")
        
        storage_service = get_storage_service()
        cleanup_result = storage_service.cleanup_old_files(days_old)
        
        if not cleanup_result['success']:
            logger.warning(f"Storage cleanup had issues: {cleanup_result.get('message')}")
            return jsonify(cleanup_result), 500
        
        # ✅ NEW: Invalidate cache after cleanup
        if _cache:
            _cache.delete('storage_stats')
            _cache.delete('storage_quota')
            logger.debug("cleanup: cleared storage cache")
        
        logger.info(f"✅ Storage cleanup completed")
        logger.info(f"   Files deleted: {cleanup_result.get('files_deleted', 0)}")
        logger.info(f"   Space freed: {cleanup_result.get('space_freed_mb', 0)}MB")
        
        return jsonify(cleanup_result), 200
    
    except Exception as e:
        logger.error(f"Storage cleanup error: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# STORAGE QUOTA ROUTES
# ==========================================

@storage_bp.route('/quota', methods=['GET'])
@login_required
def get_quota():
    """
    Get storage quota information
    ✅ CACHED for 60 seconds
    
    Returns:
    {
        'success': bool,
        'total_quota_mb': float,
        'used_mb': float,
        'available_mb': float,
        'usage_percent': float,
        'storage_type': str
    }
    """
    try:
        logger.info("💾 Storage quota requested")
        
        # ✅ NEW: Check cache first
        if _cache:
            cached_quota = _cache.get('storage_quota')
            if cached_quota:
                logger.debug("storage_quota: returning cached result")
                return cached_quota
        
        storage_service = get_storage_service()
        quota_result = storage_service.get_quota()
        
        if not quota_result['success']:
            logger.warning(f"Failed to get storage quota: {quota_result.get('error')}")
            return jsonify(quota_result), 500
        
        logger.info(f"✅ Storage quota retrieved")
        logger.info(f"   Usage: {quota_result.get('usage_percent', 0):.1f}%")
        
        response = jsonify(quota_result), 200
        
        # ✅ NEW: Cache successful response for 60 seconds
        if _cache:
            _cache.set('storage_quota', response, timeout=60)
            logger.debug("storage_quota: cached for 60 seconds")
        
        return response
    
    except Exception as e:
        logger.error(f"Storage quota error: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# STORAGE CONFIGURATION ROUTES
# ==========================================

@storage_bp.route('/config', methods=['GET'])
@login_required
def get_config():
    """
    Get storage configuration information (sanitized for security)
    ✅ CACHED for 300 seconds (config doesn't change often)
    
    Returns:
    {
        'success': bool,
        'storage_type': str,
        'account_name': str (masked),
        'container_name': str,
        'endpoint': str,
        'connection_status': str
    }
    """
    try:
        logger.info("⚙️  Storage config requested")
        
        # ✅ NEW: Check cache first
        if _cache:
            cached_config = _cache.get('storage_config')
            if cached_config:
                logger.debug("storage_config: returning cached result")
                return cached_config
        
        storage_service = get_storage_service()
        config_result = storage_service.get_config()
        
        if not config_result['success']:
            logger.warning(f"Failed to get storage config: {config_result.get('error')}")
            return jsonify(config_result), 500
        
        logger.info(f"✅ Storage config retrieved")
        response = jsonify(config_result), 200
        
        # ✅ NEW: Cache successful response for 300 seconds (5 minutes)
        if _cache:
            _cache.set('storage_config', response, timeout=300)
            logger.debug("storage_config: cached for 300 seconds")
        
        return response
    
    except Exception as e:
        logger.error(f"Storage config error: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# DEBUG ROUTES
# ==========================================

@storage_bp.route('/debug/details', methods=['GET'])
@login_required
def get_debug_details():
    """
    Get detailed debug information about storage
    ✅ CACHED for 30 seconds
    
    Returns comprehensive storage debugging info
    """
    try:
        logger.info("🐛 Storage debug details requested")
        
        # ✅ NEW: Check cache first
        if _cache:
            cached_debug = _cache.get('storage_debug_details')
            if cached_debug:
                logger.debug("storage_debug_details: returning cached result")
                return cached_debug
        
        storage_service = get_storage_service()
        debug_result = storage_service.get_debug_details()
        
        logger.info(f"✅ Storage debug details retrieved")
        response = jsonify(debug_result), 200
        
        # ✅ NEW: Cache successful response for 30 seconds
        if _cache:
            _cache.set('storage_debug_details', response, timeout=30)
            logger.debug("storage_debug_details: cached for 30 seconds")
        
        return response
    
    except Exception as e:
        logger.error(f"Storage debug error: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500