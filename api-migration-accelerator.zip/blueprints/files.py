"""
Files Blueprint - All file management routes
File: blueprints/files.py

Routes:
- GET /api/files - List files - CACHED 60 seconds
- GET /api/files/converted - List converted files - CACHED 60 seconds
- GET /api/files/<filename> - Get file info - CACHED 300 seconds per file
- GET /api/files/converted/<filename> - Get converted file info - CACHED 300 seconds per file
- GET /api/files/<filename>/download - Download file (NOT cached)
- GET /api/files/converted/<filename>/download - Download converted file (NOT cached)
- DELETE /api/files/<folder_type>/<filename>/delete - Delete file (NOT cached, invalidates cache)
- GET /api/files/search - Search files - CACHED 30 seconds
- GET /api/files/<filename>/validate - Validate file - CACHED 120 seconds
- POST /api/files/batch/delete - Batch delete (NOT cached, invalidates cache)
- GET /api/files/<filename>/details - Get details - CACHED 300 seconds
"""

from flask import Blueprint, request, jsonify, send_file
from datetime import datetime
from functools import wraps
import logging
from io import BytesIO
import os

# Import services
from services.files_service import FilesService
from auth import login_required

logger = logging.getLogger(__name__)

# Create blueprint
files_bp = Blueprint('files', __name__, url_prefix='/api/files')

# Initialize files service (lazy loaded)
_files_service = None
_cache = None  # ✅ NEW: Global cache reference


def get_files_service():
    """Lazy load files service"""
    global _files_service
    if _files_service is None:
        _files_service = FilesService()
        logger.info("✅ FilesService initialized")
    return _files_service


def set_files_cache(cache):
    """Set cache reference for files routes"""
    global _cache
    _cache = cache
    logger.info("✅ Files blueprint: cache reference set")


# ==========================================
# FILE LISTING ROUTES
# ==========================================

@files_bp.route('', methods=['GET'])
@login_required
def list_files():
    """
    List all files with optional filtering by folder type
    ✅ CACHED for 60 seconds
    
    Query Parameters:
    - folder_type: 'uploaded' | 'converted' | 'all' (default: 'all')
    
    Returns:
    {
        'success': bool,
        'files': list,
        'folder_type': str,
        'count': int,
        'total_size_mb': float
    }
    """
    try:
        logger.info("📁 Listing files")
        
        folder_type = request.args.get('folder_type', 'all')
        
        # ✅ NEW: Check cache first with key based on folder type
        cache_key = f'files_list_{folder_type}'
        if _cache:
            cached_result = _cache.get(cache_key)
            if cached_result:
                logger.debug(f"files_list: returning cached result for {folder_type}")
                return cached_result
        
        files_service = get_files_service()
        result = files_service.list_files(folder_type)
        
        if not result.get('success'):
            logger.warning(f"Failed to list files: {result.get('error')}")
            return jsonify(result), 500
        
        logger.info(f"✅ Listed {result.get('count', 0)} files")
        response = jsonify(result), 200
        
        # ✅ NEW: Cache successful response for 60 seconds
        if _cache:
            _cache.set(cache_key, response, timeout=60)
            logger.debug(f"files_list: cached for 60 seconds - {folder_type}")
        
        return response
    
    except Exception as e:
        logger.error(f"Failed to list files: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@files_bp.route('/converted', methods=['GET'])
@login_required
def list_converted_files():
    """
    List all converted files
    ✅ CACHED for 60 seconds
    
    Returns:
    {
        'success': bool,
        'files': list,
        'folder_type': str,
        'count': int,
        'total_size_mb': float
    }
    """
    try:
        logger.info("📁 Listing converted files")
        
        # ✅ NEW: Check cache first
        cache_key = 'files_list_converted'
        if _cache:
            cached_result = _cache.get(cache_key)
            if cached_result:
                logger.debug("files_list_converted: returning cached result")
                return cached_result
        
        files_service = get_files_service()
        result = files_service.list_files('converted')
        
        if not result.get('success'):
            logger.warning(f"Failed to list converted files: {result.get('error')}")
            return jsonify(result), 500
        
        logger.info(f"✅ Listed {result.get('count', 0)} converted files")
        response = jsonify(result), 200
        
        # ✅ NEW: Cache successful response for 60 seconds
        if _cache:
            _cache.set(cache_key, response, timeout=60)
            logger.debug("files_list_converted: cached for 60 seconds")
        
        return response
    
    except Exception as e:
        logger.error(f"Failed to list converted files: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# FILE INFO ROUTES
# ==========================================

@files_bp.route('/<filename>', methods=['GET'])
@login_required
def get_file_info(filename):
    """
    Get uploaded file information and content for preview
    ✅ CACHED for 300 seconds per file
    
    Path Parameters:
    - filename: Name of the file
    
    Returns:
    {
        'success': bool,
        'filename': str,
        'folder_type': str,
        'content': str,
        'content_type': str,
        'file_size': int,
        'parsed_content': dict,
        'storage_type': str
    }
    """
    try:
        logger.info(f"📄 Getting file info: {filename}")
        
        # Validate filename (prevent directory traversal)
        if '..' in filename or '/' in filename or '\\' in filename:
            logger.warning(f"Invalid filename attempt: {filename}")
            return jsonify({'error': 'Invalid filename'}), 400
        
        # ✅ NEW: Check cache first with unique key per file
        cache_key = f'file_info_uploaded_{filename}'
        if _cache:
            cached_result = _cache.get(cache_key)
            if cached_result:
                logger.debug(f"file_info: returning cached result for {filename}")
                return cached_result
        
        files_service = get_files_service()
        result = files_service.get_file_info(filename, 'uploaded')
        
        if not result.get('success'):
            logger.warning(f"File not found: {filename}")
            return jsonify(result), 404
        
        logger.info(f"✅ File info retrieved: {filename}")
        response = jsonify(result), 200
        
        # ✅ NEW: Cache successful response for 300 seconds (5 minutes)
        if _cache:
            _cache.set(cache_key, response, timeout=300)
            logger.debug(f"file_info: cached for 300 seconds - {filename}")
        
        return response
    
    except Exception as e:
        logger.error(f"Failed to get file info: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@files_bp.route('/converted/<filename>', methods=['GET'])
@login_required
def get_converted_file_info(filename):
    """
    Get converted file information and content
    ✅ CACHED for 300 seconds per file
    
    Path Parameters:
    - filename: Name of the converted file
    
    Returns:
    {
        'success': bool,
        'filename': str,
        'folder_type': str,
        'content': str,
        'content_type': str,
        'file_size': int,
        'parsed_content': dict,
        'metadata': dict,
        'storage_type': str
    }
    """
    try:
        logger.info(f"📄 Getting converted file info: {filename}")
        
        # Validate filename
        if '..' in filename or '/' in filename or '\\' in filename:
            logger.warning(f"Invalid filename attempt: {filename}")
            return jsonify({'error': 'Invalid filename'}), 400
        
        # ✅ NEW: Check cache first with unique key per file
        cache_key = f'file_info_converted_{filename}'
        if _cache:
            cached_result = _cache.get(cache_key)
            if cached_result:
                logger.debug(f"file_info_converted: returning cached result for {filename}")
                return cached_result
        
        files_service = get_files_service()
        result = files_service.get_file_info(filename, 'converted')
        
        if not result.get('success'):
            logger.warning(f"Converted file not found: {filename}")
            return jsonify(result), 404
        
        logger.info(f"✅ Converted file info retrieved: {filename}")
        response = jsonify(result), 200
        
        # ✅ NEW: Cache successful response for 300 seconds (5 minutes)
        if _cache:
            _cache.set(cache_key, response, timeout=300)
            logger.debug(f"file_info_converted: cached for 300 seconds - {filename}")
        
        return response
    
    except Exception as e:
        logger.error(f"Failed to get converted file info: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# FILE DOWNLOAD ROUTES
# ==========================================

@files_bp.route('/<filename>/download', methods=['GET'])
@login_required
def download_file(filename):
    """
    Download uploaded file
    ❌ NOT CACHED (binary file download)
    
    Path Parameters:
    - filename: Name of the file to download
    
    Returns:
    - File content (binary)
    """
    try:
        logger.info(f"⬇️  Downloading file: {filename}")
        
        # Validate filename
        if '..' in filename or '/' in filename or '\\' in filename:
            logger.warning(f"Invalid filename attempt: {filename}")
            return jsonify({'error': 'Invalid filename'}), 400
        
        files_service = get_files_service()
        result = files_service.download_file(filename, 'uploaded')
        
        if not result.get('success'):
            logger.warning(f"Failed to download file: {filename}")
            return jsonify({'error': result.get('error')}), 404
        
        logger.info(f"✅ File downloaded: {filename}")
        
        return send_file(
            BytesIO(result['content']),
            mimetype=result.get('mimetype', 'application/octet-stream'),
            as_attachment=True,
            download_name=filename
        )
    
    except Exception as e:
        logger.error(f"Failed to download file: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@files_bp.route('/converted/<filename>/download', methods=['GET'])
@login_required
def download_converted_file(filename):
    """
    Download converted file
    ❌ NOT CACHED (binary file download)
    
    Path Parameters:
    - filename: Name of the converted file to download
    
    Returns:
    - File content (binary)
    """
    try:
        logger.info(f"⬇️  Downloading converted file: {filename}")
        
        # Validate filename
        if '..' in filename or '/' in filename or '\\' in filename:
            logger.warning(f"Invalid filename attempt: {filename}")
            return jsonify({'error': 'Invalid filename'}), 400
        
        files_service = get_files_service()
        result = files_service.download_file(filename, 'converted')
        
        if not result.get('success'):
            logger.warning(f"Failed to download converted file: {filename}")
            return jsonify({'error': result.get('error')}), 404
        
        logger.info(f"✅ Converted file downloaded: {filename}")
        
        return send_file(
            BytesIO(result['content']),
            mimetype=result.get('mimetype', 'application/json'),
            as_attachment=True,
            download_name=filename
        )
    
    except Exception as e:
        logger.error(f"Failed to download converted file: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# FILE DELETE ROUTES
# ==========================================

@files_bp.route('/<folder_type>/<filename>/delete', methods=['DELETE'])
@login_required
def delete_file(folder_type, filename):
    """
    Delete a file from storage
    ❌ NOT CACHED (mutates data, invalidates cache)
    
    Path Parameters:
    - folder_type: 'uploaded' | 'converted'
    - filename: Name of the file to delete
    
    Returns:
    {
        'success': bool,
        'message': str,
        'filename': str,
        'folder_type': str
    }
    """
    try:
        logger.info(f"🗑️  Deleting file: {filename} from {folder_type}")
        
        # Validate inputs
        if '..' in filename or '/' in filename or '\\' in filename:
            logger.warning(f"Invalid filename attempt: {filename}")
            return jsonify({'error': 'Invalid filename'}), 400
        
        if folder_type not in ['uploaded', 'converted']:
            logger.warning(f"Invalid folder_type: {folder_type}")
            return jsonify({'error': 'Invalid folder type'}), 400
        
        files_service = get_files_service()
        result = files_service.delete_file(filename, folder_type)
        
        if not result.get('success'):
            logger.warning(f"Failed to delete file: {filename}")
            return jsonify(result), 404
        
        # ✅ NEW: Invalidate file caches after deletion
        if _cache:
            _cache.delete(f'file_info_uploaded_{filename}')
            _cache.delete(f'file_info_converted_{filename}')
            _cache.delete(f'file_details_{filename}')
            _cache.delete('files_list_uploaded')
            _cache.delete('files_list_converted')
            _cache.delete('files_list_all')
            logger.debug("delete_file: cleared file caches")
        
        logger.info(f"✅ File deleted: {filename}")
        return jsonify(result), 200
    
    except Exception as e:
        logger.error(f"Failed to delete file: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# FILE SEARCH ROUTES
# ==========================================

@files_bp.route('/search', methods=['GET'])
@login_required
def search_files():
    """
    Search for files by name or type
    ✅ CACHED for 30 seconds
    
    Query Parameters:
    - query: Search query (filename pattern)
    - folder_type: 'uploaded' | 'converted' | 'all' (default: 'all')
    - file_type: Filter by file extension (e.g., 'json', 'yaml')
    
    Returns:
    {
        'success': bool,
        'results': list,
        'count': int,
        'query': str
    }
    """
    try:
        logger.info("🔍 Searching files")
        
        query = request.args.get('query', '')
        folder_type = request.args.get('folder_type', 'all')
        file_type = request.args.get('file_type', '')
        
        if not query:
            return jsonify({
                'success': False,
                'error': 'Search query required'
            }), 400
        
        # ✅ NEW: Check cache first with key based on search params
        cache_key = f'files_search_{query}_{folder_type}_{file_type}'
        if _cache:
            cached_result = _cache.get(cache_key)
            if cached_result:
                logger.debug(f"files_search: returning cached result for {query}")
                return cached_result
        
        files_service = get_files_service()
        result = files_service.search_files(query, folder_type, file_type)
        
        if not result.get('success'):
            logger.warning(f"Search failed: {result.get('error')}")
            return jsonify(result), 500
        
        logger.info(f"✅ Found {result.get('count', 0)} files")
        response = jsonify(result), 200
        
        # ✅ NEW: Cache successful response for 30 seconds
        if _cache:
            _cache.set(cache_key, response, timeout=30)
            logger.debug(f"files_search: cached for 30 seconds - {query}")
        
        return response
    
    except Exception as e:
        logger.error(f"Failed to search files: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# FILE VALIDATION ROUTES
# ==========================================

@files_bp.route('/<filename>/validate', methods=['GET'])
@login_required
def validate_file(filename):
    """
    Validate a file (check if it's valid OpenAPI spec, etc.)
    ✅ CACHED for 120 seconds per file
    
    Path Parameters:
    - filename: Name of the file to validate
    
    Returns:
    {
        'success': bool,
        'is_valid': bool,
        'file_type': str,
        'issues': list,
        'warnings': list
    }
    """
    try:
        logger.info(f"✓ Validating file: {filename}")
        
        # Validate filename
        if '..' in filename or '/' in filename or '\\' in filename:
            logger.warning(f"Invalid filename attempt: {filename}")
            return jsonify({'error': 'Invalid filename'}), 400
        
        # ✅ NEW: Check cache first with unique key per file
        cache_key = f'file_validate_{filename}'
        if _cache:
            cached_result = _cache.get(cache_key)
            if cached_result:
                logger.debug(f"file_validate: returning cached result for {filename}")
                return cached_result
        
        files_service = get_files_service()
        result = files_service.validate_file(filename)
        
        if not result.get('success'):
            logger.warning(f"Validation failed: {filename}")
            return jsonify(result), 404
        
        logger.info(f"✅ File validation complete: {filename}")
        response = jsonify(result), 200
        
        # ✅ NEW: Cache successful response for 120 seconds (2 minutes)
        if _cache:
            _cache.set(cache_key, response, timeout=120)
            logger.debug(f"file_validate: cached for 120 seconds - {filename}")
        
        return response
    
    except Exception as e:
        logger.error(f"Failed to validate file: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# FILE BATCH OPERATIONS
# ==========================================

@files_bp.route('/batch/delete', methods=['POST'])
@login_required
def batch_delete_files():
    """
    Delete multiple files at once
    ❌ NOT CACHED (mutates data, invalidates cache)
    
    Request JSON:
    {
        'filenames': [str],
        'folder_type': str
    }
    
    Returns:
    {
        'success': bool,
        'deleted': int,
        'failed': int,
        'errors': list
    }
    """
    try:
        logger.info("🗑️  Batch deleting files")
        
        data = request.get_json() or {}
        filenames = data.get('filenames', [])
        folder_type = data.get('folder_type', 'uploaded')
        
        if not filenames:
            return jsonify({
                'success': False,
                'error': 'No filenames provided'
            }), 400
        
        if folder_type not in ['uploaded', 'converted']:
            return jsonify({
                'success': False,
                'error': 'Invalid folder type'
            }), 400
        
        files_service = get_files_service()
        result = files_service.batch_delete_files(filenames, folder_type)
        
        if not result.get('success'):
            logger.warning(f"Batch delete failed: {result.get('error')}")
            return jsonify(result), 500
        
        # ✅ NEW: Invalidate caches after batch deletion
        if _cache:
            # Clear all file-specific caches
            for filename in filenames:
                _cache.delete(f'file_info_uploaded_{filename}')
                _cache.delete(f'file_info_converted_{filename}')
                _cache.delete(f'file_details_{filename}')
            # Clear list caches
            _cache.delete('files_list_uploaded')
            _cache.delete('files_list_converted')
            _cache.delete('files_list_all')
            logger.debug("batch_delete_files: cleared file caches")
        
        logger.info(f"✅ Batch delete complete: {result.get('deleted', 0)} deleted")
        return jsonify(result), 200
    
    except Exception as e:
        logger.error(f"Failed to batch delete files: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# FILE DETAILS/METADATA ROUTES
# ==========================================

@files_bp.route('/<filename>/details', methods=['GET'])
@login_required
def get_file_details(filename):
    """
    Get detailed file information including metadata
    ✅ CACHED for 300 seconds per file
    
    Path Parameters:
    - filename: Name of the file
    
    Returns:
    {
        'success': bool,
        'filename': str,
        'file_size': int,
        'file_size_formatted': str,
        'created_at': str,
        'modified_at': str,
        'content_type': str,
        'storage_type': str,
        'metadata': dict,
        'folder_type': str
    }
    """
    try:
        logger.info(f"📋 Getting file details: {filename}")
        
        # Validate filename
        if '..' in filename or '/' in filename or '\\' in filename:
            logger.warning(f"Invalid filename attempt: {filename}")
            return jsonify({'error': 'Invalid filename'}), 400
        
        # ✅ NEW: Check cache first with unique key per file
        cache_key = f'file_details_{filename}'
        if _cache:
            cached_result = _cache.get(cache_key)
            if cached_result:
                logger.debug(f"file_details: returning cached result for {filename}")
                return cached_result
        
        files_service = get_files_service()
        result = files_service.get_file_details(filename)
        
        if not result.get('success'):
            logger.warning(f"Failed to get file details: {filename}")
            return jsonify(result), 404
        
        logger.info(f"✅ File details retrieved: {filename}")
        response = jsonify(result), 200
        
        # ✅ NEW: Cache successful response for 300 seconds (5 minutes)
        if _cache:
            _cache.set(cache_key, response, timeout=300)
            logger.debug(f"file_details: cached for 300 seconds - {filename}")
        
        return response
    
    except Exception as e:
        logger.error(f"Failed to get file details: {str(e)}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500