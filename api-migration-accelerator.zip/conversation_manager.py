"""
Production-grade Conversation Manager
- Automatic pruning of old conversations
- Memory leak prevention
- Database persistence option
- Thread-safe operations
"""
from datetime import datetime, timedelta
from typing import Dict, Optional, List
import json
import logging
import threading
from collections import OrderedDict

logger = logging.getLogger(__name__)


class ConversationManager:
    """
    Thread-safe conversation manager with automatic cleanup
    and optional database persistence
    """
    
    def __init__(self, 
                 max_conversations: int = 500,
                 ttl_hours: int = 24,
                 cleanup_interval_minutes: int = 60):
        """
        Initialize conversation manager
        
        Args:
            max_conversations: Maximum conversations to keep in memory
            ttl_hours: Time-to-live for conversations (hours)
            cleanup_interval_minutes: How often to cleanup old conversations
        """
        self.conversations = OrderedDict()  # Maintains insertion order
        self.max_conversations = max_conversations
        self.ttl_hours = ttl_hours
        self.cleanup_interval_minutes = cleanup_interval_minutes
        self._lock = threading.RLock()
        self._last_cleanup = datetime.now()
        
        logger.info(f"ConversationManager initialized: max={max_conversations}, ttl={ttl_hours}h")
    
    def get_or_create(self, 
                     conversation_id: str, 
                     user_id: Optional[str] = None) -> Dict:
        """Get existing conversation or create new one"""
        with self._lock:
            # Cleanup if interval passed
            if self._should_cleanup():
                self._cleanup_old_conversations()
            
            if conversation_id in self.conversations:
                # Move to end (most recent)
                self.conversations.move_to_end(conversation_id)
                return self.conversations[conversation_id]
            
            # Create new
            conversation = {
                'id': conversation_id,
                'user_id': user_id,
                'created_at': datetime.now().isoformat(),
                'updated_at': datetime.now().isoformat(),
                'messages': [],
                'files': [],
                'assistant_types_used': [],
                'stats': {
                    'total_messages': 0,
                    'total_characters': 0,
                    'average_response_time_ms': 0
                }
            }
            
            self.conversations[conversation_id] = conversation
            
            # Prune if exceeds max
            if len(self.conversations) > self.max_conversations:
                self._prune_to_limit()
            
            return conversation
    
    def add_user_message(self, 
                        conversation_id: str,
                        message: str,
                        file_info: Optional[Dict] = None,
                        assistant_type: Optional[str] = None) -> bool:
        """Add user message to conversation"""
        with self._lock:
            if conversation_id not in self.conversations:
                return False
            
            conv = self.conversations[conversation_id]
            conv['messages'].append({
                'timestamp': datetime.now().isoformat(),
                'sender': 'user',
                'content': message,
                'file': file_info.get('filename') if file_info else None,
                'assistant_type': assistant_type,
                'character_count': len(message)
            })
            
            # Update stats
            conv['stats']['total_messages'] += 1
            conv['stats']['total_characters'] += len(message)
            conv['updated_at'] = datetime.now().isoformat()
            
            if file_info and file_info['filename'] not in [f['filename'] for f in conv['files']]:
                conv['files'].append(file_info)
            
            if assistant_type and assistant_type not in conv['assistant_types_used']:
                conv['assistant_types_used'].append(assistant_type)
            
            return True
    
    def add_assistant_message(self,
                             conversation_id: str,
                             response: str,
                             assistant_type: str,
                             confidence: float = 1.0,
                             metadata: Optional[Dict] = None,
                             response_time_ms: float = 0) -> bool:
        """Add assistant response to conversation"""
        with self._lock:
            if conversation_id not in self.conversations:
                return False
            
            conv = self.conversations[conversation_id]
            conv['messages'].append({
                'timestamp': datetime.now().isoformat(),
                'sender': 'assistant',
                'content': response,
                'assistant_type': assistant_type,
                'confidence': confidence,
                'metadata': metadata or {},
                'character_count': len(response),
                'response_time_ms': response_time_ms
            })
            
            # Update stats
            conv['stats']['total_messages'] += 1
            conv['stats']['total_characters'] += len(response)
            
            # Update average response time
            message_count = len([m for m in conv['messages'] if m['sender'] == 'assistant'])
            avg = conv['stats']['average_response_time_ms']
            conv['stats']['average_response_time_ms'] = (
                (avg * (message_count - 1) + response_time_ms) / message_count
            )
            
            conv['updated_at'] = datetime.now().isoformat()
            
            if assistant_type not in conv['assistant_types_used']:
                conv['assistant_types_used'].append(assistant_type)
            
            return True
    
    def get_conversation(self, conversation_id: str) -> Optional[Dict]:
        """Get conversation by ID"""
        with self._lock:
            if conversation_id in self.conversations:
                self.conversations.move_to_end(conversation_id)
                return self.conversations[conversation_id]
            return None
    
    def list_conversations(self, user_id: Optional[str] = None) -> List[Dict]:
        """List all conversations with summary"""
        with self._lock:
            conversations = []
            for conv in reversed(list(self.conversations.values())):
                if user_id and conv.get('user_id') != user_id:
                    continue
                
                conversations.append({
                    'id': conv['id'],
                    'user_id': conv.get('user_id'),
                    'created_at': conv['created_at'],
                    'updated_at': conv['updated_at'],
                    'message_count': len(conv['messages']),
                    'assistant_types': list(set(conv['assistant_types_used'])),
                    'stats': conv['stats']
                })
            
            return conversations
    
    def delete_conversation(self, conversation_id: str) -> bool:
        """Delete conversation"""
        with self._lock:
            if conversation_id in self.conversations:
                del self.conversations[conversation_id]
                return True
            return False
    
    def get_stats(self) -> Dict:
        """Get manager statistics"""
        with self._lock:
            total_messages = sum(
                len(conv['messages']) for conv in self.conversations.values()
            )
            total_chars = sum(
                conv['stats']['total_characters'] 
                for conv in self.conversations.values()
            )
            
            return {
                'total_conversations': len(self.conversations),
                'total_messages': total_messages,
                'total_characters': total_chars,
                'max_conversations': self.max_conversations,
                'utilization_percent': (len(self.conversations) / self.max_conversations) * 100
            }
    
    def _should_cleanup(self) -> bool:
        """Check if cleanup should run"""
        elapsed = (datetime.now() - self._last_cleanup).total_seconds()
        return elapsed > (self.cleanup_interval_minutes * 60)
    
    def _cleanup_old_conversations(self):
        """Remove conversations older than TTL"""
        now = datetime.now()
        ttl_seconds = self.ttl_hours * 3600
        
        removed = 0
        conversation_ids = list(self.conversations.keys())
        
        for conv_id in conversation_ids:
            conv = self.conversations[conv_id]
            created = datetime.fromisoformat(conv['created_at'])
            age_seconds = (now - created).total_seconds()
            
            if age_seconds > ttl_seconds:
                del self.conversations[conv_id]
                removed += 1
        
        self._last_cleanup = datetime.now()
    
    def _prune_to_limit(self):
        """Remove oldest conversations to reach max limit"""
        overage = len(self.conversations) - self.max_conversations
        if overage <= 0:
            return
        
        for _ in range(overage):
            if self.conversations:
                self.conversations.popitem(last=False)
    
    def export_conversation(self, conversation_id: str) -> Optional[str]:
        """Export conversation as JSON"""
        with self._lock:
            if conversation_id not in self.conversations:
                return None
            
            conv = self.conversations[conversation_id]
            return json.dumps(conv, indent=2, default=str)
    
    def clear_all(self):
        """Clear all conversations"""
        with self._lock:
            self.conversations.clear()
    
    def get_memory_usage(self) -> Dict:
        """Estimate memory usage"""
        import sys
        
        with self._lock:
            total_size = 0
            for conv in self.conversations.values():
                total_size += sys.getsizeof(json.dumps(conv))
            
            return {
                'estimated_bytes': total_size,
                'estimated_mb': total_size / (1024 * 1024),
                'conversations': len(self.conversations),
                'average_per_conversation': total_size / max(1, len(self.conversations))
            }
