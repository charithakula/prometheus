"""
Azure API Management Connector - ENHANCED VERSION WITH SSL CERTIFICATE HANDLING
Handles CRUD operations for APIs in Azure API Management
Updated with comprehensive OpenAPI validation and SSL/TLS certificate support for private networks
"""
import json
import logging
import requests
import re
import os
from typing import Dict, Any, List, Optional
from azure.identity import ClientSecretCredential
from azure.mgmt.apimanagement import ApiManagementClient
from azure.mgmt.apimanagement.models import (
    ApiCreateOrUpdateParameter,
    ApiContract,
    ApiVersionSetContract,
    ApiVersionSetEntityBase
)
from config import BaseConfig
import urllib3

logger = logging.getLogger(__name__)

# ==========================================
# SSL CERTIFICATE CONFIGURATION
# ==========================================

class SSLConfig:
    """SSL Certificate configuration for private networks"""
    
    # Set to False to disable SSL verification (NOT RECOMMENDED FOR PRODUCTION)
    VERIFY_SSL = os.environ.get('VERIFY_SSL', 'True').lower() == 'true'
    
    # Path to custom CA certificate bundle
    CA_BUNDLE_PATH = os.environ.get('CA_BUNDLE_PATH', None)
    
    # Path to client certificate (if required)
    CLIENT_CERT_PATH = os.environ.get('CLIENT_CERT_PATH', None)
    
    # Path to client key (if required)
    CLIENT_KEY_PATH = os.environ.get('CLIENT_KEY_PATH', None)
    
    @staticmethod
    def get_cert_config() -> Dict[str, Any]:
        """Get certificate configuration for requests"""
        config = {}
        
        if not SSLConfig.VERIFY_SSL:
            config['verify'] = False
            logger.warning("⚠️  SSL verification DISABLED - for private network testing only!")
        elif SSLConfig.CA_BUNDLE_PATH and os.path.exists(SSLConfig.CA_BUNDLE_PATH):
            config['verify'] = SSLConfig.CA_BUNDLE_PATH
            logger.info(f"✓ Using custom CA certificate: {SSLConfig.CA_BUNDLE_PATH}")
        else:
            config['verify'] = True
            logger.info("✓ Using default SSL certificate verification")
        
        # Add client certificate if provided
        if SSLConfig.CLIENT_CERT_PATH and SSLConfig.CLIENT_KEY_PATH:
            if os.path.exists(SSLConfig.CLIENT_CERT_PATH) and os.path.exists(SSLConfig.CLIENT_KEY_PATH):
                config['cert'] = (SSLConfig.CLIENT_CERT_PATH, SSLConfig.CLIENT_KEY_PATH)
                logger.info(f"✓ Using client certificate: {SSLConfig.CLIENT_CERT_PATH}")
        
        return config
    
    @staticmethod
    def configure_environment():
        """Configure environment variables for SSL certificates"""
        try:
            # Suppress SSL warnings if verification is disabled
            if not SSLConfig.VERIFY_SSL:
                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
                logger.warning("SSL warnings suppressed - verification disabled")
            
            # Configure requests library for custom certificates
            if SSLConfig.CA_BUNDLE_PATH and os.path.exists(SSLConfig.CA_BUNDLE_PATH):
                os.environ['REQUESTS_CA_BUNDLE'] = SSLConfig.CA_BUNDLE_PATH
                os.environ['CURL_CA_BUNDLE'] = SSLConfig.CA_BUNDLE_PATH
                logger.info("✓ Configured custom CA certificate for requests")
            
            logger.info(f"SSL Configuration:")
            logger.info(f"  - VERIFY_SSL: {SSLConfig.VERIFY_SSL}")
            logger.info(f"  - CA_BUNDLE_PATH: {SSLConfig.CA_BUNDLE_PATH}")
            logger.info(f"  - CLIENT_CERT_PATH: {SSLConfig.CLIENT_CERT_PATH}")
            
        except Exception as e:
            logger.error(f"Failed to configure SSL: {e}")


class AzureAPIMConnector:
    """Azure API Management service connector with SSL certificate support"""
    
    def __init__(self):
        """Initialize Azure APIM client with SSL certificate handling"""
        self.config = BaseConfig
        self._credential = None
        self._client = None
        
        # Configure SSL handling
        SSLConfig.configure_environment()
        
        # Initialize client
        self._initialize_client()
    
    def _initialize_client(self) -> bool:
        """Initialize Azure APIM client with service principal authentication and SSL handling"""
        try:
            # Validate configuration
            missing_config = self.config.validate_azure_config() + self.config.validate_apim_config()
            if missing_config:
                logger.error(f"Missing Azure APIM configuration: {missing_config}")
                return False
            
            logger.info("Creating Azure credentials with SSL configuration...")
            
            # Create credential with SSL handling
            self._credential = ClientSecretCredential(
                tenant_id=self.config.AZURE_TENANT_ID ,
                client_id=self.config.AZURE_CLIENT_ID,
                client_secret=self.config.AZURE_CLIENT_SECRET,
            )
            
            logger.info("✓ Azure credentials created successfully")
            logger.info("Creating Azure APIM client...")
            
            # Initialize APIM client
            self._client = ApiManagementClient(
                credential=self._credential,
                subscription_id=self.config.AZURE_SUBSCRIPTION_ID
            )
            
            logger.info("✓ Azure APIM client initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"✗ Failed to initialize Azure APIM client: {e}")
            logger.error(f"  Error type: {type(e).__name__}")
            
            # Provide helpful debugging information for SSL errors
            if 'SSL' in str(e) or 'certificate' in str(e).lower() or 'CERTIFICATE_VERIFY_FAILED' in str(e):
                logger.error("\n  ✗ SSL Certificate Error Detected!")
                logger.error("  Possible solutions:")
                logger.error("  1. Set VERIFY_SSL=False for private network testing (NOT for production)")
                logger.error("  2. Provide CA_BUNDLE_PATH environment variable with certificate path")
                logger.error("  3. Check if your network requires a proxy or SSL inspection certificate")
                logger.error("  4. Verify Azure credentials are correct")
                logger.error("\n  Example setup:")
                logger.error("    export VERIFY_SSL=True")
                logger.error("    export CA_BUNDLE_PATH=/etc/ssl/certs/ca-bundle.crt")
                logger.error("    export AZURE_TENANT_ID=your-tenant-id")
                logger.error("    python app.py")
            
            self._client = None
            return False
    
    @property
    def is_available(self) -> bool:
        """Check if Azure APIM service is available"""
        return self._client is not None
    
    def test_connection(self) -> Dict[str, Any]:
        """Test connection to Azure APIM service with SSL error handling"""
        if not self.is_available:
            return {
                'status': 'error',
                'message': 'Azure APIM client not initialized - check SSL certificates',
                'ssl_config': {
                    'verify_ssl': SSLConfig.VERIFY_SSL,
                    'ca_bundle_path': SSLConfig.CA_BUNDLE_PATH,
                }
            }
        
        try:
            logger.info("Testing Azure APIM connection...")
            
            # Test by listing APIs (should return even if empty)
            apis = self._client.api.list_by_service(
                resource_group_name=self.config.AZURE_APIM_RESOURCE_GROUP,
                service_name=self.config.AZURE_APIM_SERVICE_NAME
            )
            
            api_count = sum(1 for _ in apis)
            
            logger.info(f"✓ Connection successful - {api_count} APIs found")
            
            return {
                'status': 'success',
                'message': 'Azure APIM connection successful',
                'service_name': self.config.AZURE_APIM_SERVICE_NAME,
                'api_count': api_count
            }
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"✗ Azure APIM connection failed: {error_msg}")
            
            # Check for SSL-related errors
            if 'SSL' in error_msg or 'certificate' in error_msg.lower() or 'CERTIFICATE_VERIFY_FAILED' in error_msg:
                logger.error("\n  ✗ SSL Certificate Error!")
                logger.error("  Current SSL Configuration:")
                logger.error(f"    - VERIFY_SSL: {SSLConfig.VERIFY_SSL}")
                logger.error(f"    - CA_BUNDLE_PATH: {SSLConfig.CA_BUNDLE_PATH}")
                logger.error(f"    - CLIENT_CERT_PATH: {SSLConfig.CLIENT_CERT_PATH}")
                logger.error("\n  To fix:")
                logger.error("  Option 1 (Testing only): export VERIFY_SSL=False")
                logger.error("  Option 2 (Recommended): export CA_BUNDLE_PATH=/path/to/ca-bundle.crt")
                logger.error("  Option 3: Update system certificates")
            
            return {
                'status': 'error',
                'message': f'Azure APIM connection failed: {error_msg}',
                'ssl_config': {
                    'verify_ssl': SSLConfig.VERIFY_SSL,
                    'ca_bundle_path': SSLConfig.CA_BUNDLE_PATH,
                    'client_cert_path': SSLConfig.CLIENT_CERT_PATH
                }
            }
    
    def validate_openapi_for_apim(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """
        ENHANCED: Validate and fix OpenAPI spec for Azure APIM compatibility
        Specifically addresses the $ref validation errors
        """
        issues = []
        
        # Check required fields
        if 'openapi' not in spec:
            issues.append("Missing 'openapi' version field")
            spec['openapi'] = '3.0.0'
        
        if 'info' not in spec or 'title' not in spec['info']:
            issues.append("Missing API title in info section")
            spec['info'] = spec.get('info', {})
            spec['info']['title'] = spec['info'].get('title', 'Migrated API')
        
        if 'paths' not in spec or not spec['paths']:
            issues.append("No paths defined")
        
        # CRITICAL FIX: Check and fix all $ref paths
        spec_str = json.dumps(spec)
        
        # Find all problematic $ref patterns
        problematic_patterns = [
            r'"\$ref":\s*"[^#][^"]*\/definitions\/',
            r'"\$ref":\s*"\/definitions\/',
            r'"\$ref":\s*"[^"]*\/definitions\/'
        ]
        
        has_ref_issues = False
        for pattern in problematic_patterns:
            if re.search(pattern, spec_str):
                has_ref_issues = True
                break
        
        if has_ref_issues:
            issues.append("Found invalid $ref paths - fixing automatically")
            
            # Fix all $ref paths comprehensively
            logger.info("Fixing $ref validation errors for Azure APIM")
            
            # Replace all variations of invalid $ref paths
            fixes = [
                ('"/definitions/', '"#/components/schemas/'),
                ('"#/definitions/', '"#/components/schemas/'),
                ('"/parameters/', '"#/components/parameters/'),
                ('"/responses/', '"#/components/responses/')
            ]
            
            for old_pattern, new_pattern in fixes:
                if old_pattern in spec_str:
                    spec_str = spec_str.replace(old_pattern, new_pattern)
                    logger.info(f"Fixed $ref pattern: {old_pattern} -> {new_pattern}")
            
            # Use regex to catch any remaining problematic references
            spec_str = re.sub(r'"(\$ref":\s*)"([^#][^"]*\/definitions\/[^"]*)"', r'"\1"#/components/schemas/\2"', spec_str)
            spec_str = re.sub(r'"(\$ref":\s*)"(\/definitions\/[^"]*)"', r'"\1"#/components/schemas/\2"', spec_str)
            
            try:
                spec = json.loads(spec_str)
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse JSON after $ref fixes: {e}")
                # Continue with original spec if fixing broke it
        
        # Ensure components section exists
        if 'components' not in spec:
            spec['components'] = {}
            issues.append("Added missing components section")
        
        if 'schemas' not in spec.get('components', {}):
            spec['components']['schemas'] = {}
        
        # Move any remaining definitions to components/schemas
        if 'definitions' in spec:
            spec['components']['schemas'].update(spec['definitions'])
            del spec['definitions']
            issues.append("Moved definitions to components/schemas")
        
        # Remove OpenAPI 2.0 specific fields that cause validation errors
        openapi_2_fields = ['swagger', 'host', 'basePath', 'schemes', 'consumes', 'produces', 'securityDefinitions']
        for field in openapi_2_fields:
            if field in spec:
                if field == 'securityDefinitions' and 'securitySchemes' not in spec['components']:
                    spec['components']['securitySchemes'] = spec[field]
                del spec[field]
                issues.append(f"Removed OpenAPI 2.0 field: {field}")
        
        # Check servers - add default if missing
        if 'servers' not in spec or not spec['servers']:
            issues.append("No servers defined - adding default")
            spec['servers'] = [{"url": "https://api.example.com", "description": "Default server"}]
        
        # Validate servers have URLs
        if 'servers' in spec:
            for i, server in enumerate(spec['servers']):
                if 'url' not in server or not server['url']:
                    issues.append(f"Server {i} missing URL - fixing")
                    spec['servers'][i]['url'] = 'https://api.example.com'
        
        # Validate no body parameters exist (OpenAPI 3.0 uses requestBody)
        for path, path_item in spec.get('paths', {}).items():
            for method, operation in path_item.items():
                if method.lower() in ['get', 'post', 'put', 'patch', 'delete', 'head', 'options']:
                    if isinstance(operation, dict) and 'parameters' in operation:
                        # Check for body parameters
                        body_params = [p for p in operation['parameters'] if isinstance(p, dict) and p.get('in') == 'body']
                        if body_params:
                            issues.append(f"Found body parameters in {method.upper()} {path} - should use requestBody")
                            # Remove body parameters (they should be converted to requestBody)
                            operation['parameters'] = [p for p in operation['parameters'] if not (isinstance(p, dict) and p.get('in') == 'body')]
        
        # Validate responses have content blocks instead of direct schema
        for path, path_item in spec.get('paths', {}).items():
            for method, operation in path_item.items():
                if method.lower() in ['get', 'post', 'put', 'patch', 'delete', 'head', 'options']:
                    if isinstance(operation, dict) and 'responses' in operation:
                        for status, response in operation['responses'].items():
                            if isinstance(response, dict) and 'schema' in response and 'content' not in response:
                                issues.append(f"Response {status} in {method.upper()} {path} uses schema instead of content")
                                # Convert schema to content
                                schema = response.pop('schema')
                                response['content'] = {
                                    'application/json': {
                                        'schema': schema
                                    }
                                }
        
        # Final validation - check for any remaining problematic $ref paths
        final_check = json.dumps(spec)
        remaining_bad_refs = re.findall(r'"\$ref":\s*"[^#][^"]*\/definitions\/[^"]*"', final_check)
        if remaining_bad_refs:
            issues.append(f"WARNING: Still found {len(remaining_bad_refs)} problematic $ref paths after fixes")
            for bad_ref in remaining_bad_refs[:5]:  # Show first 5
                logger.warning(f"Remaining bad $ref: {bad_ref}")
        
        logger.info(f"✓ Azure APIM validation completed. Found and fixed {len(issues)} issues")
        
        return {
            'valid': len([i for i in issues if 'WARNING' not in i]) == 0,
            'issues': issues,
            'spec': spec
        }
    
    def create_api_from_openapi(self, openapi_spec: Dict[str, Any], api_id: Optional[str] = None) -> Dict[str, Any]:
        """Create API in APIM from OpenAPI 3.0 specification"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            # First, validate and fix the spec for Azure APIM
            validation_result = self.validate_openapi_for_apim(openapi_spec.copy())
            if not validation_result['valid']:
                logger.warning(f"OpenAPI spec had issues: {validation_result['issues']}")
            
            # Use the fixed spec
            openapi_spec = validation_result['spec']
            
            # Extract API information from OpenAPI spec
            api_info = self._extract_api_info(openapi_spec)
            
            # Generate API ID if not provided
            if not api_id:
                api_id = self._generate_api_id(api_info['title'])
            
            logger.info(f"Creating API in Azure APIM: {api_id}")
            logger.info(f"API Info: {api_info['title']} v{api_info.get('version', 'Unknown')}")
            
            # Prepare API creation parameters
            api_params = ApiCreateOrUpdateParameter(
                display_name=api_info['title'],
                description=api_info.get('description', ''),
                service_url=api_info.get('service_url'),
                path=api_info.get('path', api_id),
                protocols=api_info.get('protocols', ['https']),
                format='openapi+json',
                value=json.dumps(openapi_spec)
            )
            
            # Create the API
            result = self._client.api.begin_create_or_update(
                resource_group_name=self.config.AZURE_APIM_RESOURCE_GROUP,
                service_name=self.config.AZURE_APIM_SERVICE_NAME,
                api_id=api_id,
                parameters=api_params
            ).result()
            
            logger.info(f"✓ Successfully created API: {api_id}")
            
            return {
                'status': 'success',
                'api_id': api_id,
                'display_name': result.display_name,
                'path': result.path,
                'service_url': result.service_url,
                'api_version': api_info.get('version'),
                'message': f'API {api_id} created successfully',
                'validation_issues_fixed': validation_result['issues']
            }
            
        except Exception as e:
            logger.error(f"✗ Failed to create API: {e}")
            logger.error(f"  Error type: {type(e).__name__}")
            
            if 'SSL' in str(e) or 'certificate' in str(e).lower():
                logger.error("  SSL Certificate Error - check your network configuration")
            
            return {
                'status': 'error',
                'message': f'Failed to create API: {str(e)}'
            }
    
    def list_apis(self) -> List[Dict[str, Any]]:
        """List all APIs in the APIM service"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            apis = self._client.api.list_by_service(
                resource_group_name=self.config.AZURE_APIM_RESOURCE_GROUP,
                service_name=self.config.AZURE_APIM_SERVICE_NAME
            )
            
            api_list = []
            for api in apis:
                api_info = {
                    'id': api.name,
                    'display_name': api.display_name,
                    'description': api.description,
                    'service_url': api.service_url,
                    'path': api.path,
                    'protocols': api.protocols,
                    'api_version': api.api_version,
                    'api_version_set_id': api.api_version_set_id,
                    'is_current': api.is_current,
                    'subscription_required': api.subscription_required
                }
                api_list.append(api_info)
            
            logger.info(f"✓ Retrieved {len(api_list)} APIs from Azure APIM")
            return api_list
            
        except Exception as e:
            logger.error(f"✗ Failed to list APIs: {e}")
            raise
    
    def get_api(self, api_id: str) -> Optional[Dict[str, Any]]:
        """Get specific API details"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            api = self._client.api.get(
                resource_group_name=self.config.AZURE_APIM_RESOURCE_GROUP,
                service_name=self.config.AZURE_APIM_SERVICE_NAME,
                api_id=api_id
            )
            
            return {
                'id': api.name,
                'display_name': api.display_name,
                'description': api.description,
                'service_url': api.service_url,
                'path': api.path,
                'protocols': api.protocols,
                'api_version': api.api_version,
                'api_version_set_id': api.api_version_set_id,
                'is_current': api.is_current,
                'subscription_required': api.subscription_required
            }
            
        except Exception as e:
            logger.error(f"✗ Failed to get API {api_id}: {e}")
            return None
    
    def update_api(self, api_id: str, openapi_spec: Dict[str, Any]) -> Dict[str, Any]:
        """Update existing API with new OpenAPI specification"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            # Validate and fix the spec first
            validation_result = self.validate_openapi_for_apim(openapi_spec.copy())
            openapi_spec = validation_result['spec']
            
            # Extract API information from OpenAPI spec
            api_info = self._extract_api_info(openapi_spec)
            
            # Prepare API update parameters
            api_params = ApiCreateOrUpdateParameter(
                display_name=api_info['title'],
                description=api_info.get('description', ''),
                service_url=api_info.get('service_url'),
                format='openapi+json',
                value=json.dumps(openapi_spec)
            )
            
            # Update the API
            result = self._client.api.begin_create_or_update(
                resource_group_name=self.config.AZURE_APIM_RESOURCE_GROUP,
                service_name=self.config.AZURE_APIM_SERVICE_NAME,
                api_id=api_id,
                parameters=api_params
            ).result()
            
            logger.info(f"✓ Successfully updated API: {api_id}")
            
            return {
                'status': 'success',
                'api_id': api_id,
                'display_name': result.display_name,
                'message': f'API {api_id} updated successfully'
            }
            
        except Exception as e:
            logger.error(f"✗ Failed to update API {api_id}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to update API: {str(e)}'
            }
    
    def delete_api(self, api_id: str) -> Dict[str, Any]:
        """Delete API from APIM"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            self._client.api.delete(
                resource_group_name=self.config.AZURE_APIM_RESOURCE_GROUP,
                service_name=self.config.AZURE_APIM_SERVICE_NAME,
                api_id=api_id,
                if_match='*'
            )
            
            logger.info(f"✓ Successfully deleted API: {api_id}")
            
            return {
                'status': 'success',
                'api_id': api_id,
                'message': f'API {api_id} deleted successfully'
            }
            
        except Exception as e:
            logger.error(f"✗ Failed to delete API {api_id}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to delete API: {str(e)}'
            }
    
    def create_product(self, product_name: str, api_ids: List[str], description: str = "") -> Dict[str, Any]:
        """Create a product and associate APIs with it"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            from azure.mgmt.apimanagement.models import ProductContract
            
            product_id = self._generate_api_id(product_name)
            
            # Create product parameters
            product_params = ProductContract(
                display_name=product_name,
                description=description or f"Product for {product_name}",
                subscription_required=True,
                approval_required=False,
                state='published'
            )
            
            # Create product
            product = self._client.product.create_or_update(
                resource_group_name=self.config.AZURE_APIM_RESOURCE_GROUP,
                service_name=self.config.AZURE_APIM_SERVICE_NAME,
                product_id=product_id,
                parameters=product_params
            )
            
            # Associate APIs with product
            for api_id in api_ids:
                try:
                    self._client.product_api.create_or_update(
                        resource_group_name=self.config.AZURE_APIM_RESOURCE_GROUP,
                        service_name=self.config.AZURE_APIM_SERVICE_NAME,
                        product_id=product_id,
                        api_id=api_id
                    )
                    logger.info(f"✓ Associated API {api_id} with product {product_id}")
                except Exception as e:
                    logger.warning(f"⚠️  Failed to associate API {api_id} with product {product_id}: {e}")
            
            logger.info(f"✓ Successfully created product: {product_name} with {len(api_ids)} APIs")
            
            return {
                'status': 'success',
                'product_id': product_id,
                'display_name': product.display_name,
                'api_count': len(api_ids),
                'message': f'Product {product_name} created successfully'
            }
            
        except Exception as e:
            logger.error(f"✗ Failed to create product {product_name}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to create product: {str(e)}'
            }
    
    def get_api_management_url(self, api_id: str) -> str:
        """Get the management URL for an API"""
        return f"https://portal.azure.com/#@{self.config.AZURE_TENANT_ID}/resource/subscriptions/{self.config.AZURE_SUBSCRIPTION_ID}/resourceGroups/{self.config.AZURE_APIM_RESOURCE_GROUP}/providers/Microsoft.ApiManagement/service/{self.config.AZURE_APIM_SERVICE_NAME}/apis/{api_id}"
    
    def get_developer_portal_url(self) -> str:
        """Get the developer portal URL"""
        return f"https://{self.config.AZURE_APIM_SERVICE_NAME}.developer.azure-api.net"
    
    def export_api(self, api_id: str, export_format: str = 'openapi+json') -> Dict[str, Any]:
        """Export API specification from APIM"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            # Export API
            export_result = self._client.api_export.get(
                resource_group_name=self.config.AZURE_APIM_RESOURCE_GROUP,
                service_name=self.config.AZURE_APIM_SERVICE_NAME,
                api_id=api_id,
                format=export_format
            )
            
            return {
                'status': 'success',
                'api_id': api_id,
                'format': export_format,
                'specification': export_result.value,
                'message': f'API {api_id} exported successfully'
            }
            
        except Exception as e:
            logger.error(f"✗ Failed to export API {api_id}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to export API: {str(e)}'
            }
    
    def _extract_api_info(self, openapi_spec: Dict[str, Any]) -> Dict[str, Any]:
        """Extract API information from OpenAPI specification"""
        info = openapi_spec.get('info', {})
        servers = openapi_spec.get('servers', [])
        
        # Extract service URL from servers
        service_url = None
        if servers:
            service_url = servers[0].get('url')
        
        # Extract path prefix
        title = info.get('title', 'migrated-api')
        path = self._generate_api_id(title)
        
        return {
            'title': info.get('title', 'Migrated API'),
            'description': info.get('description', 'API migrated from IBM API Connect'),
            'version': info.get('version', '1.0.0'),
            'service_url': service_url,
            'path': path,
            'protocols': ['https']
        }
    
    def _generate_api_id(self, title: str) -> str:
        """Generate API ID from title"""
        import time
        
        # Clean the title - remove special characters and replace with hyphens
        api_id = re.sub(r'[^a-zA-Z0-9\-_]', '-', title.lower())
        api_id = re.sub(r'-+', '-', api_id)
        api_id = api_id.strip('-_')
        
        # Ensure we have something
        if not api_id:
            api_id = 'migrated-api'
        
        # Add timestamp to make it unique
        timestamp = str(int(time.time()))[-6:]
        api_id = f"{api_id}-{timestamp}"
        
        # Azure APIM API ID length limit
        return api_id[:50]