"""
Production-grade Logging Configuration
- Structured logging
- Request tracking with IDs
- Proper log levels
- Performance metrics
"""
import logging
import logging.handlers
import os
import uuid
from datetime import datetime
from typing import Any
import json


class JSONFormatter(logging.Formatter):
    """Format logs as JSON for structured logging"""
    
    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
        }
        
        # Add request ID if available
        if hasattr(record, 'request_id'):
            log_data['request_id'] = record.request_id
        
        # Add extra fields
        if hasattr(record, 'extra'):
            log_data.update(record.extra)
        
        # Include exception if present
        if record.exc_info:
            log_data['exception'] = self.formatException(record.exc_info)
        
        return json.dumps(log_data)


class PlainFormatter(logging.Formatter):
    """Format logs as plain text for console"""
    
    COLORS = {
        'DEBUG': '\033[36m',      # Cyan
        'INFO': '\033[32m',       # Green
        'WARNING': '\033[33m',    # Yellow
        'ERROR': '\033[31m',      # Red
        'CRITICAL': '\033[35m',   # Magenta
        'RESET': '\033[0m'
    }
    
    def format(self, record: logging.LogRecord) -> str:
        if os.getenv('FLASK_ENV') == 'development':
            color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
            reset = self.COLORS['RESET']
            
            return (
                f"{color}[{record.levelname:8}]{reset} "
                f"{datetime.fromtimestamp(record.created).strftime('%H:%M:%S')} "
                f"{record.name}:{record.lineno} - {record.getMessage()}"
            )
        else:
            return (
                f"[{record.levelname:8}] "
                f"{datetime.fromtimestamp(record.created).strftime('%Y-%m-%d %H:%M:%S')} "
                f"{record.name} - {record.getMessage()}"
            )


def setup_logging(app=None):
    """
    Setup production-grade logging
    
    Args:
        app: Flask app instance (optional)
    """
    log_level = os.getenv('LOG_LEVEL', 'INFO').upper()
    
    # Create logs directory
    os.makedirs('logs', exist_ok=True)
    
    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    
    # Remove existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # ==========================================
    # CONSOLE HANDLER (STDOUT)
    # ==========================================
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    console_handler.setFormatter(PlainFormatter())
    root_logger.addHandler(console_handler)
    
    # ==========================================
    # FILE HANDLER (ROTATING)
    # ==========================================
    
    file_handler = logging.handlers.RotatingFileHandler(
        'logs/app.log',
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=10,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(PlainFormatter())
    root_logger.addHandler(file_handler)
    
    # ==========================================
    # JSON FILE HANDLER (STRUCTURED LOGGING)
    # ==========================================
    
    json_handler = logging.handlers.RotatingFileHandler(
        'logs/app.json',
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    json_handler.setLevel(logging.INFO)
    json_handler.setFormatter(JSONFormatter())
    root_logger.addHandler(json_handler)
    
    # ==========================================
    # ERROR FILE HANDLER
    # ==========================================
    
    error_handler = logging.handlers.RotatingFileHandler(
        'logs/errors.log',
        maxBytes=5 * 1024 * 1024,  # 5MB
        backupCount=5,
        encoding='utf-8'
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(PlainFormatter())
    root_logger.addHandler(error_handler)
    
    # ==========================================
    # CONFIGURE SPECIFIC LOGGERS
    # ==========================================
    
    # Reduce noise from libraries
    logging.getLogger('werkzeug').setLevel(logging.WARNING)
    logging.getLogger('sqlalchemy').setLevel(logging.WARNING)
    logging.getLogger('azure').setLevel(logging.WARNING)
    
    # Set up app logger if provided
    if app:
        app.logger.setLevel(log_level)
        app.logger.info(f"Logging configured: level={log_level}")
    
    root_logger.info(f"Logging initialized: {log_level}")
    root_logger.info(f"Log files: logs/app.log, logs/app.json, logs/errors.log")
    
    return root_logger


def get_request_logger(request_id: str = None) -> logging.LoggerAdapter:
    """
    Get a logger with request tracking
    
    Args:
        request_id: Request ID (auto-generated if not provided)
    
    Returns:
        LoggerAdapter with request ID
    """
    if not request_id:
        request_id = str(uuid.uuid4())[:8]
    
    logger = logging.getLogger(__name__)
    
    return logging.LoggerAdapter(
        logger,
        {'request_id': request_id}
    )


class PerformanceLogger:
    """Track performance metrics"""
    
    def __init__(self, operation_name: str):
        self.operation_name = operation_name
        self.logger = logging.getLogger(__name__)
        self.start_time = None
    
    def __enter__(self):
        self.start_time = datetime.now()
        self.logger.debug(f"Starting: {self.operation_name}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        elapsed = (datetime.now() - self.start_time).total_seconds() * 1000
        
        if exc_type:
            self.logger.error(
                f"Failed: {self.operation_name} ({elapsed:.0f}ms)",
                exc_info=(exc_type, exc_val, exc_tb)
            )
        else:
            level = logging.WARNING if elapsed > 5000 else logging.INFO
            self.logger.log(
                level,
                f"Completed: {self.operation_name} ({elapsed:.0f}ms)"
            )
