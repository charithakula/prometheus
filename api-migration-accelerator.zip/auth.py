"""
Complete Authentication Module for API Migration Tool
Includes: Login/Logout, Profile Management, Settings, Password Management, 
API Key Management, Statistics, Activity Tracking, and YAML Conversion
"""
import os
import yaml
import json
import secrets
import logging
from functools import wraps
from datetime import datetime, timedelta
from flask import session, redirect, url_for, flash, render_template, request, jsonify

logger = logging.getLogger('app')


# ==========================================
# AUTHENTICATION DECORATOR
# ==========================================

def login_required(f):
    """Decorator to require login for protected routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            # For API endpoints, return JSON error
            if request.is_json or request.path.startswith('/api/'):
                return jsonify({
                    'success': False,
                    'error': 'Authentication required',
                    'message': 'Please log in to access this resource'
                }), 401
            
            # For regular routes, redirect to login WITHOUT flash message
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


# ==========================================
# SESSION CONFIGURATION
# ==========================================

def configure_session(app):
    """Configure Flask session for authentication"""
    
    # Get SECRET_KEY from environment or use default (CHANGE IN PRODUCTION!)
    secret_key = os.environ.get('SECRET_KEY')
    if not secret_key:
        logger.warning("SECRET_KEY not set in environment! Using default development key.")
        logger.warning("[WARNING] SECURITY WARNING: Set SECRET_KEY environment variable in production!")
        secret_key = 'dev-secret-key-CHANGE-IN-PRODUCTION-' + os.urandom(24).hex()
    
    # Session configuration
    app.config['SECRET_KEY'] = secret_key
    app.config['SESSION_COOKIE_NAME'] = 'api_migration_session'
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    
    # Set secure cookies in production (not in debug mode)
    if not app.config.get('DEBUG'):
        app.config['SESSION_COOKIE_SECURE'] = True
        logger.info("Secure session cookies enabled (HTTPS required)")
    
    # Permanent session lifetime (for "remember me")
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)
    
    logger.info("[OK] Session configuration completed")
    logger.info(f"  - Cookie name: {app.config['SESSION_COOKIE_NAME']}")
    logger.info(f"  - Session lifetime: {app.config['PERMANENT_SESSION_LIFETIME']}")
    logger.info(f"  - Secure cookies: {app.config.get('SESSION_COOKIE_SECURE', False)}")


# ==========================================
# DEFAULT USER PROFILES AND SETTINGS
# ==========================================

def get_default_user_profile():
    """Get default user profile structure"""
    return {
        'first_name': '',
        'last_name': '',
        'email': '',
        'phone': '',
        'department': '',
        'location': '',
        'profile_picture': None,
        'bio': '',
        'account_status': 'active',
        'created_date': datetime.now().isoformat(),
        'last_updated': datetime.now().isoformat()
    }


def get_default_user_settings():
    """Get default user settings structure"""
    return {
        'general': {
            'language': 'en',
            'theme': 'light',
            'timezone': 'UTC',
            'date_format': 'YYYY-MM-DD'
        },
        'notifications': {
            'email_enabled': True,
            'migration_alerts': True,
            'migration_started': True,
            'migration_completed': True,
            'migration_failed': True,
            'weekly_summary': True,
            'service_status': True,
            'maintenance_alerts': True
        },
        'integrations': {
            'azure_apim': {'enabled': False, 'status': 'not_configured'},
            'github': {'enabled': False, 'status': 'not_configured'},
            'slack': {'enabled': False, 'status': 'not_configured'}
        },
        'security': {
            'rate_limiting': {'enabled': True, 'requests_per_minute': 60},
            'two_factor_enabled': False,
            'password_expiry_days': 90,
            'last_password_change': datetime.now().isoformat()
        },
        'advanced': {
            'debug_logging': False,
            'performance_metrics': False,
            'developer_mode': False
        }
    }


def get_current_user():
    """Get current logged-in user from session"""
    if 'user_id' not in session:
        return None
    
    return {
        'user_id': session.get('user_id'),
        'username': session.get('username'),
        'email': session.get('email'),
        'first_name': session.get('first_name', ''),
        'last_name': session.get('last_name', ''),
        'profile': session.get('profile', get_default_user_profile()),
        'settings': session.get('settings', get_default_user_settings()),
        'logged_in_at': session.get('logged_in_at'),
        'api_keys': session.get('api_keys', [])
    }


def is_authenticated():
    """Check if current user is authenticated"""
    return 'user_id' in session


def validate_password(password):
    """Validate password meets security requirements"""
    errors = []
    
    if len(password) < 8:
        errors.append("Password must be at least 8 characters long")
    
    if not any(c.isupper() for c in password):
        errors.append("Password must contain at least one uppercase letter")
    
    if not any(c.islower() for c in password):
        errors.append("Password must contain at least one lowercase letter")
    
    if not any(c.isdigit() for c in password):
        errors.append("Password must contain at least one number")
    
    return errors


# ==========================================
# AUTHENTICATION ROUTES
# ==========================================

def register_auth_routes(app):
    """Register authentication and user management routes with the Flask app"""
    
    # ==========================================
    # LOGIN & LOGOUT ROUTES - ✅ FIXED
    # ==========================================
    
    @app.route('/login', methods=['GET'])
    def login():
        """Login page route"""
        # If already logged in, redirect to dashboard
        if 'user_id' in session:
            logger.info(f"User {session.get('username')} already logged in, redirecting to dashboard")
            return redirect(url_for('index'))
        
        return render_template('login.html')
    
    
    @app.route('/logout', methods=['GET', 'POST'])
    def logout():
        """
        ✅ FIXED: Logout route - handles both GET and POST
        Clears session and redirects to login with success parameter
        """
        username = session.get('username', 'User')
        
        logger.info(f"[LOGOUT] User '{username}' initiated logout")
        
        # Clear session completely
        session.clear()
        
        logger.info(f"[LOGOUT] Session cleared for user '{username}'")
        
        # ✅ DON'T use flash - pass success via URL parameter instead
        # This prevents the message from persisting after next login
        return redirect(url_for('login') + '?logout=success')
    
    
    # ==========================================
    # AUTHENTICATION API ENDPOINTS
    # ==========================================
    
    @app.route('/api/auth/login', methods=['POST'])
    def api_login():
        """
        Handle login API request
        Expects JSON: { username, password, remember }
        Returns: { success, message, redirect_url, user }
        """
        try:
            data = request.get_json()
            username = data.get('username', '').strip()
            password = data.get('password', '')
            remember = data.get('remember', False)
            
            # Validate input
            if not username or not password:
                logger.warning("Login attempt with missing credentials")
                return jsonify({
                    'success': False,
                    'message': 'Username and password are required'
                }), 400
            
            # Test users for development (CHANGE IN PRODUCTION!)
            valid_users = {
                'admin': {'password': 'admin', 'email': 'admin@example.com', 'first_name': 'Admin', 'last_name': 'User'},
                'user': {'password': 'password', 'email': 'user@example.com', 'first_name': 'Regular', 'last_name': 'User'},
                'demo': {'password': 'demo123', 'email': 'demo@example.com', 'first_name': 'Demo', 'last_name': 'Account'}
            }
            
            if username in valid_users and valid_users[username]['password'] == password:
                # Successful authentication
                user_data = valid_users[username]
                
                # ✅ Clear any existing flash messages from previous session
                session.pop('_flashes', None)
                
                session['user_id'] = username
                session['username'] = username
                session['email'] = user_data['email']
                session['first_name'] = user_data['first_name']
                session['last_name'] = user_data['last_name']
                session['logged_in_at'] = datetime.now().isoformat()
                session['profile'] = get_default_user_profile()
                session['settings'] = get_default_user_settings()
                session['api_keys'] = []
                
                # Set session to permanent if remember me is checked
                if remember:
                    session.permanent = True
                
                logger.info(f"[OK] User '{username}' logged in successfully (remember_me: {remember})")
                
                return jsonify({
                    'success': True,
                    'message': 'Login successful',
                    'redirect_url': url_for('index'),
                    'user': {
                        'username': username,
                        'email': user_data['email'],
                        'first_name': user_data['first_name'],
                        'last_name': user_data['last_name'],
                        'logged_in_at': session['logged_in_at']
                    }
                })
            else:
                # Failed authentication
                logger.warning(f"[FAILED] Failed login attempt for username: '{username}'")
                return jsonify({
                    'success': False,
                    'message': 'Invalid username or password'
                }), 401
                
        except Exception as e:
            logger.error(f"Login error: {e}")
            return jsonify({
                'success': False,
                'message': f'Login error: {str(e)}'
            }), 500
    
    
    @app.route('/api/auth/verify', methods=['POST', 'GET'])
    def api_verify_token():
        """
        Verify authentication session
        Returns: { valid, user_id, username, logged_in_at }
        """
        try:
            # Check session-based auth
            if 'user_id' in session:
                return jsonify({
                    'valid': True,
                    'user_id': session.get('user_id'),
                    'username': session.get('username'),
                    'logged_in_at': session.get('logged_in_at')
                })
            
            return jsonify({'valid': False}), 401
            
        except Exception as e:
            logger.error(f"Token verification error: {e}")
            return jsonify({'valid': False, 'error': str(e)}), 500
    
    
    @app.route('/api/auth/session')
    def get_session_info():
        """Get current session information"""
        if 'user_id' not in session:
            return jsonify({
                'authenticated': False,
                'message': 'No active session'
            }), 401
        
        return jsonify({
            'authenticated': True,
            'user': {
                'user_id': session.get('user_id'),
                'username': session.get('username'),
                'email': session.get('email'),
                'first_name': session.get('first_name'),
                'last_name': session.get('last_name'),
                'logged_in_at': session.get('logged_in_at')
            },
            'session': {
                'permanent': session.permanent,
                'new': session.new
            }
        })
    
    
    # ==========================================
    # PROFILE MANAGEMENT ROUTES
    # ==========================================
    
    @app.route('/profile')
    @login_required
    def profile_page():
        """User profile page"""
        user = get_current_user()
        
        try:
            # Get user statistics
            from models.database import MigrationRecord
            
            total_migrations = MigrationRecord.query.count()
            successful_migrations = MigrationRecord.query.filter_by(status='completed').count()
            failed_migrations = MigrationRecord.query.filter_by(status='failed').count()
            
            success_rate = (successful_migrations / total_migrations * 100) if total_migrations > 0 else 0
            
            stats = {
                'total_migrations': total_migrations,
                'successful_migrations': successful_migrations,
                'failed_migrations': failed_migrations,
                'success_rate': round(success_rate, 2)
            }
        except Exception as e:
            logger.warning(f"Failed to get user statistics: {e}")
            stats = {
                'total_migrations': 0,
                'successful_migrations': 0,
                'failed_migrations': 0,
                'success_rate': 0
            }
        
        return render_template('profile.html', user=user, stats=stats)
    
    
    @app.route('/api/user/profile', methods=['GET', 'POST'])
    @login_required
    def api_user_profile():
        """Get or update user profile"""
        user = get_current_user()
        
        if request.method == 'GET':
            return jsonify({
                'success': True,
                'profile': user['profile'],
                'user_info': {
                    'username': user['username'],
                    'email': user['email'],
                    'user_id': user['user_id'],
                    'logged_in_at': user['logged_in_at']
                }
            })
        
        if request.method == 'POST':
            data = request.get_json()
            
            if not data:
                return jsonify({'error': 'No data provided'}), 400
            
            # Update profile in session
            profile = session.get('profile', get_default_user_profile())
            
            allowed_fields = ['first_name', 'last_name', 'email', 'phone', 'department', 'location', 'bio']
            
            for field in allowed_fields:
                if field in data:
                    profile[field] = str(data[field]).strip()
            
            profile['last_updated'] = datetime.now().isoformat()
            session['profile'] = profile
            session.modified = True
            
            # Update session user fields
            session['first_name'] = profile.get('first_name', '')
            session['last_name'] = profile.get('last_name', '')
            session['email'] = profile.get('email', user['email'])
            
            logger.info(f"User {user['username']} updated profile")
            
            return jsonify({
                'success': True,
                'message': 'Profile updated successfully',
                'profile': profile
            })
    
    
    # ==========================================
    # SETTINGS MANAGEMENT ROUTES
    # ==========================================
    
    @app.route('/settings')
    @login_required
    def settings_page():
        """User settings page"""
        user = get_current_user()
        return render_template('settings.html', user=user)
    
    
    @app.route('/api/user/settings', methods=['GET', 'POST'])
    @login_required
    def api_user_settings():
        """Get or update user settings"""
        user = get_current_user()
        
        if request.method == 'GET':
            return jsonify({
                'success': True,
                'settings': user['settings']
            })
        
        if request.method == 'POST':
            data = request.get_json()
            
            if not data:
                return jsonify({'error': 'No data provided'}), 400
            
            # Update settings in session
            settings = session.get('settings', get_default_user_settings())
            
            # Update general settings
            if 'general' in data and isinstance(data['general'], dict):
                settings['general'].update(data['general'])
            
            # Update notification settings
            if 'notifications' in data and isinstance(data['notifications'], dict):
                settings['notifications'].update(data['notifications'])
            
            # Update integration settings
            if 'integrations' in data and isinstance(data['integrations'], dict):
                settings['integrations'].update(data['integrations'])
            
            # Update security settings
            if 'security' in data and isinstance(data['security'], dict):
                # Don't allow direct password updates here
                safe_security_updates = {k: v for k, v in data['security'].items() if k != 'password'}
                settings['security'].update(safe_security_updates)
            
            # Update advanced settings
            if 'advanced' in data and isinstance(data['advanced'], dict):
                settings['advanced'].update(data['advanced'])
            
            session['settings'] = settings
            session.modified = True
            
            logger.info(f"User {user['username']} updated settings")
            
            return jsonify({
                'success': True,
                'message': 'Settings updated successfully',
                'settings': settings
            })
    
    
    # ==========================================
    # PASSWORD MANAGEMENT
    # ==========================================
    
    @app.route('/api/user/password', methods=['POST'])
    @login_required
    def api_change_password():
        """Change user password"""
        user = get_current_user()
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        current_password = data.get('currentPassword', '').strip()
        new_password = data.get('newPassword', '').strip()
        confirm_password = data.get('confirmPassword', '').strip()
        
        # Validate current password
        valid_users = {
            'admin': 'admin',
            'user': 'password',
            'demo': 'demo123'
        }
        
        if user['username'] not in valid_users or valid_users[user['username']] != current_password:
            return jsonify({
                'error': 'Current password is incorrect'
            }), 401
        
        # Validate new password matches confirm
        if new_password != confirm_password:
            return jsonify({
                'error': 'New password and confirmation do not match'
            }), 400
        
        # Validate new password strength
        validation_errors = validate_password(new_password)
        if validation_errors:
            return jsonify({
                'error': 'Password does not meet requirements',
                'requirements': validation_errors
            }), 400
        
        logger.info(f"User {user['username']} changed password")
        
        # Update security setting
        settings = session.get('settings', get_default_user_settings())
        settings['security']['last_password_change'] = datetime.now().isoformat()
        session['settings'] = settings
        session.modified = True
        
        return jsonify({
            'success': True,
            'message': 'Password changed successfully'
        })
    
    
    # ==========================================
    # USER STATISTICS & ACTIVITY
    # ==========================================
    
    @app.route('/api/user/stats')
    @login_required
    def api_user_stats():
        """Get user statistics"""
        user = get_current_user()
        
        try:
            from models.database import MigrationRecord
            
            total = MigrationRecord.query.count()
            completed = MigrationRecord.query.filter_by(status='completed').count()
            failed = MigrationRecord.query.filter_by(status='failed').count()
            pending = MigrationRecord.query.filter_by(status='in_progress').count() + \
                     MigrationRecord.query.filter_by(status='pending').count()
            
            success_rate = (completed / total * 100) if total > 0 else 0
            
            stats = {
                'total_migrations': total,
                'successful_migrations': completed,
                'failed_migrations': failed,
                'pending_migrations': pending,
                'success_rate': round(success_rate, 2),
                'account_logged_in': user['logged_in_at']
            }
            
        except Exception as e:
            logger.warning(f"Failed to get user stats: {e}")
            stats = {
                'total_migrations': 0,
                'successful_migrations': 0,
                'failed_migrations': 0,
                'pending_migrations': 0,
                'success_rate': 0,
                'account_logged_in': user['logged_in_at']
            }
        
        return jsonify({
            'success': True,
            'stats': stats
        })
    
    
    @app.route('/api/user/activity')
    @login_required
    def api_user_activity():
        """Get user activity log"""
        user = get_current_user()
        
        try:
            from models.database import MigrationLog
            
            # Get recent activities (last 7 days)
            seven_days_ago = datetime.now() - timedelta(days=7)
            
            logs = MigrationLog.query.filter(
                MigrationLog.timestamp >= seven_days_ago
            ).order_by(MigrationLog.timestamp.desc()).limit(50).all()
            
            activities = [
                {
                    'timestamp': log.timestamp.isoformat(),
                    'stage': log.stage,
                    'message': log.message,
                    'level': log.level,
                    'migration_id': log.migration_id
                }
                for log in logs
            ]
            
        except Exception as e:
            logger.warning(f"Failed to get user activity: {e}")
            activities = []
        
        return jsonify({
            'success': True,
            'activities': activities,
            'total_activities': len(activities)
        })
    
    
    # ==========================================
    # API KEY MANAGEMENT
    # ==========================================
    
    @app.route('/api/user/api-keys', methods=['GET', 'POST'])
    @login_required
    def api_user_api_keys():
        """List or create API keys"""
        user = get_current_user()
        
        # Initialize API keys in session if not present
        if 'api_keys' not in session:
            session['api_keys'] = []
        
        if request.method == 'GET':
            # Return masked API keys
            masked_keys = []
            for key in session['api_keys']:
                masked = {
                    'id': key['id'],
                    'name': key['name'],
                    'key': f"{key['key'][:8]}...{key['key'][-4:]}",  # Masked
                    'created_at': key['created_at'],
                    'last_used': key.get('last_used'),
                    'is_active': key.get('is_active', True)
                }
                masked_keys.append(masked)
            
            return jsonify({
                'success': True,
                'api_keys': masked_keys,
                'total': len(masked_keys)
            })
        
        if request.method == 'POST':
            data = request.get_json()
            name = data.get('name', 'Unnamed Key').strip()
            
            if not name:
                return jsonify({'error': 'Key name is required'}), 400
            
            # Generate new API key
            api_key = secrets.token_urlsafe(32)
            
            new_key = {
                'id': secrets.token_hex(8),
                'name': name,
                'key': api_key,
                'created_at': datetime.now().isoformat(),
                'last_used': None,
                'is_active': True
            }
            
            session['api_keys'].append(new_key)
            session.modified = True
            
            logger.info(f"User {user['username']} created new API key: {name}")
            
            return jsonify({
                'success': True,
                'message': 'API key created successfully',
                'api_key': {
                    'id': new_key['id'],
                    'name': new_key['name'],
                    'key': api_key,  # Only show full key once
                    'created_at': new_key['created_at'],
                    'warning': 'Save this key in a secure location. You will not see it again!'
                }
            })
    
    
    @app.route('/api/user/api-keys/<key_id>', methods=['DELETE'])
    @login_required
    def api_delete_api_key(key_id):
        """Delete API key"""
        user = get_current_user()
        
        if 'api_keys' not in session:
            return jsonify({'error': 'API key not found'}), 404
        
        # Find and delete key
        original_length = len(session['api_keys'])
        session['api_keys'] = [k for k in session['api_keys'] if k['id'] != key_id]
        session.modified = True
        
        if len(session['api_keys']) == original_length:
            return jsonify({'error': 'API key not found'}), 404
        
        logger.info(f"User {user['username']} deleted API key: {key_id}")
        
        return jsonify({
            'success': True,
            'message': 'API key deleted successfully'
        })
    
    
    # ==========================================
    # YAML CONVERTER API ENDPOINTS (PROTECTED)
    # ==========================================
    
    @app.route('/api/yaml/convert', methods=['POST'])
    @login_required
    def api_convert_yaml():
        """
        Convert YAML to JSON via API
        Expects JSON: { yaml_content, indent }
        Returns: { success, json_content, size, lines }
        """
        try:
            data = request.get_json()
            yaml_content = data.get('yaml_content', '')
            indent = data.get('indent', 2)
            
            if not yaml_content:
                return jsonify({
                    'success': False,
                    'error': 'No YAML content provided'
                }), 400
            
            # Parse YAML
            try:
                parsed_data = yaml.safe_load(yaml_content)
            except yaml.YAMLError as e:
                logger.warning(f"YAML parsing error: {str(e)}")
                return jsonify({
                    'success': False,
                    'error': f'YAML parsing error: {str(e)}'
                }), 400
            
            # Convert to JSON with specified indent
            if indent == 'tab':
                json_content = json.dumps(parsed_data, indent='\t')
            elif indent == '0':
                json_content = json.dumps(parsed_data)
            else:
                json_content = json.dumps(parsed_data, indent=int(indent))
            
            logger.info(f"YAML converted successfully by user {session.get('username')} - {len(json_content)} bytes")
            
            return jsonify({
                'success': True,
                'json_content': json_content,
                'size': len(json_content),
                'lines': len(json_content.split('\n'))
            })
            
        except Exception as e:
            logger.error(f"YAML conversion error: {e}")
            return jsonify({
                'success': False,
                'error': f'Conversion error: {str(e)}'
            }), 500
    
    
    @app.route('/api/yaml/validate', methods=['POST'])
    @login_required
    def api_validate_yaml():
        """
        Validate YAML syntax
        Expects JSON: { yaml_content }
        Returns: { valid, error, message }
        """
        try:
            data = request.get_json()
            yaml_content = data.get('yaml_content', '')
            
            if not yaml_content:
                return jsonify({
                    'valid': False,
                    'error': 'No YAML content provided'
                })
            
            try:
                yaml.safe_load(yaml_content)
                return jsonify({
                    'valid': True,
                    'message': 'YAML is valid'
                })
            except yaml.YAMLError as e:
                return jsonify({
                    'valid': False,
                    'error': str(e),
                    'message': f'YAML validation failed: {str(e)}'
                })
                
        except Exception as e:
            logger.error(f"YAML validation error: {e}")
            return jsonify({
                'valid': False,
                'error': str(e)
            }), 500
    
    
    logger.info("[OK] Authentication routes registered successfully")
    logger.info("  ✅ Login/Logout routes (FIXED!)")
    logger.info("  ✅ Profile management routes")
    logger.info("  ✅ Settings management routes")
    logger.info("  ✅ Password management routes")
    logger.info("  ✅ API key management routes")
    logger.info("  ✅ Statistics and activity routes")
    logger.info("  ✅ YAML conversion routes")


# ==========================================
# PASSWORD HASHING UTILITIES (FOR PRODUCTION)
# ==========================================

def hash_password(password: str) -> str:
    """
    Hash a password for storing in database
    Use this in production instead of plain text passwords!
    
    Example:
        hashed = hash_password('mypassword')
        # Store hashed in database
    """
    from werkzeug.security import generate_password_hash
    return generate_password_hash(password, method='pbkdf2:sha256')


def verify_password(stored_password_hash: str, provided_password: str) -> bool:
    """
    Verify a stored password hash against a provided password
    Use this in production for secure password verification!
    
    Example:
        if verify_password(user.password_hash, provided_password):
            # Password is correct
    """
    from werkzeug.security import check_password_hash
    return check_password_hash(stored_password_hash, provided_password)