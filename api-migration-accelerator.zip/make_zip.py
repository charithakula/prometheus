import zipfile
import os

def zip_project(folder_path, output_zip):
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            # Skip unnecessary directories
            dirs[:] = [d for d in dirs if d not in ('__pycache__', 'venv', '.venv')]
            for file in files:
                filepath = os.path.join(root, file)
                arcname = os.path.relpath(filepath, start=folder_path)
                zipf.write(filepath, arcname)

# 👇 Use the current project folder name here
folder_to_zip = os.getcwd()  # current directory (api-migration-accelerator)
output_zip = os.path.join(os.path.dirname(folder_to_zip), "api-migration-accelerator.zip")

zip_project(folder_to_zip, output_zip)
print(f"✅ Created ZIP: {output_zip}")
