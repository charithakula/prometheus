"""
Enhanced File Handler with Azure Blob Storage Support
Handles file operations for both uploaded and converted OpenAPI specifications
FEATURES: Separate folders, file validation, cleanup, conversion tracking, Azure Storage
"""
import os
import json
import yaml
import hashlib
import shutil
from typing import Dict, Any, Optional, List
from datetime import datetime
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename
import logging
from io import BytesIO

logger = logging.getLogger(__name__)


class AzureStorageAdapter:
    """Adapter for Azure Blob Storage operations"""
    
    def __init__(self):
        """Initialize Azure Storage adapter"""
        try:
            from azure.storage.blob import BlobServiceClient
            from azure.core.exceptions import AzureError
            
            self.connection_string = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
            self.account_name = os.getenv('AZURE_STORAGE_ACCOUNT_NAME')
            self.container_name = os.getenv('AZURE_STORAGE_CONTAINER_NAME', 'uploads')
            
            if self.connection_string:
                self.client = BlobServiceClient.from_connection_string(self.connection_string)
            elif self.account_name:
                account_key = os.getenv('AZURE_STORAGE_ACCOUNT_KEY')
                self.client = BlobServiceClient(
                    account_url=f"https://{self.account_name}.blob.core.windows.net",
                    credential=account_key
                )
            else:
                self.client = None
                logger.info("Azure Storage not configured - using local filesystem")
                return
            
            # Ensure container exists
            self.container_client = self._get_or_create_container()
            logger.info(f"✓ Azure Storage initialized - Container: {self.container_name}")
            
        except ImportError:
            logger.warning("azure-storage-blob not installed - falling back to local storage")
            self.client = None
        except Exception as e:
            logger.error(f"Failed to initialize Azure Storage: {e}")
            self.client = None
    
    def _get_or_create_container(self):
        """Get or create blob container"""
        try:
            container_client = self.client.get_container_client(self.container_name)
            try:
                container_client.get_container_properties()
                logger.info(f"Container '{self.container_name}' exists")
            except:
                logger.info(f"Creating container '{self.container_name}'")
                container_client = self.client.create_container(self.container_name)
            return container_client
        except Exception as e:
            logger.error(f"Failed to get/create container: {e}")
            raise
    
    @property
    def is_available(self) -> bool:
        """Check if Azure Storage is available"""
        return self.client is not None and hasattr(self, 'container_client') and self.container_client is not None
    
    def upload_file(self, content: bytes, blob_path: str, metadata: Optional[Dict] = None) -> Dict[str, Any]:
        """Upload file to Azure Blob Storage"""
        try:
            if not self.is_available:
                return {'success': False, 'error': 'Azure Storage not available'}
            
            blob_client = self.container_client.get_blob_client(blob_path)
            blob_client.upload_blob(content, overwrite=True)
            
            if metadata:
                blob_client.set_blob_metadata(metadata)
            
            properties = blob_client.get_blob_properties()
            
            return {
                'success': True,
                'blob_path': blob_path,
                'size': properties.size,
                'download_url': f"https://{self.account_name}.blob.core.windows.net/{self.container_name}/{blob_path}"
            }
            
        except Exception as e:
            logger.error(f"Azure upload failed: {e}")
            return {'success': False, 'error': str(e)}
    
    def download_file(self, blob_path: str) -> Dict[str, Any]:
        """Download file from Azure Blob Storage"""
        try:
            if not self.is_available:
                return {'success': False, 'error': 'Azure Storage not available'}
            
            blob_client = self.container_client.get_blob_client(blob_path)
            download_stream = blob_client.download_blob()
            content = download_stream.readall()
            
            properties = blob_client.get_blob_properties()
            
            return {
                'success': True,
                'blob_path': blob_path,
                'content': content,
                'size': properties.size
            }
            
        except Exception as e:
            logger.error(f"Azure download failed: {e}")
            return {'success': False, 'error': str(e)}
    
    def delete_file(self, blob_path: str) -> Dict[str, Any]:
        """Delete file from Azure Blob Storage"""
        try:
            if not self.is_available:
                return {'success': False, 'error': 'Azure Storage not available'}
            
            blob_client = self.container_client.get_blob_client(blob_path)
            blob_client.delete_blob()
            
            return {'success': True, 'blob_path': blob_path}
            
        except Exception as e:
            logger.error(f"Azure delete failed: {e}")
            return {'success': False, 'error': str(e)}
    
    def list_files(self, prefix: str = '') -> Dict[str, Any]:
        """List files in Azure Blob Storage"""
        try:
            if not self.is_available:
                return {'success': False, 'error': 'Azure Storage not available', 'files': []}
            
            files = []
            blobs = self.container_client.list_blobs(name_starts_with=prefix)
            
            for blob in blobs:
                files.append({
                    'name': blob.name,
                    'size': blob.size,
                    'modified_time': blob.last_modified.isoformat() if blob.last_modified else None
                })
            
            return {'success': True, 'files': files}
            
        except Exception as e:
            logger.error(f"Azure list failed: {e}")
            return {'success': False, 'error': str(e), 'files': []}
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get Azure storage statistics"""
        try:
            if not self.is_available:
                return {'total_size_mb': 0, 'total_files': 0}
            
            total_size = 0
            total_files = 0
            
            blobs = self.container_client.list_blobs()
            for blob in blobs:
                total_size += blob.size
                total_files += 1
            
            return {
                'total_size_mb': round(total_size / (1024 * 1024), 2),
                'total_files': total_files
            }
            
        except Exception as e:
            logger.error(f"Azure stats failed: {e}")
            return {'total_size_mb': 0, 'total_files': 0}


class EnhancedFileHandler:
    """Enhanced file handler with local filesystem and Azure Blob Storage support"""
    
    def __init__(self, base_folder: str = 'static/uploads'):
        """Initialize file handler with organized folder structure"""
        self.base_folder = base_folder
        self.upload_folder = os.path.join(base_folder, 'uploaded')
        self.converted_folder = os.path.join(base_folder, 'converted')
        self.temp_folder = os.path.join(base_folder, 'temp')
        
        # File size limits
        self.max_file_size = 16 * 1024 * 1024  # 16MB
        self.allowed_extensions = {'.json', '.yaml', '.yml', '.txt'}
        
        # Initialize Azure Storage adapter
        self.azure_storage = AzureStorageAdapter()
        self.use_azure = self.azure_storage.is_available
        
        # Create local folders (for fallback and metadata)
        self._create_folders()
        
        logger.info(f"EnhancedFileHandler initialized - Storage: {'Azure' if self.use_azure else 'Local'}")
    
    def _create_folders(self):
        """Create necessary local folder structure"""
        folders = [self.base_folder, self.upload_folder, self.converted_folder, self.temp_folder]
        for folder in folders:
            os.makedirs(folder, exist_ok=True)
            logger.info(f"Ensured folder exists: {folder}")
    
    def save_uploaded_file(self, file: FileStorage, prefix: str = 'upload') -> Dict[str, Any]:
        """Save uploaded file with validation (to Azure or local)"""
        try:
            # Validate file
            validation_result = self._validate_file(file)
            if not validation_result['valid']:
                return {
                    'success': False,
                    'error': validation_result['error']
                }
            
            # Generate secure filename
            original_filename = file.filename
            file_extension = os.path.splitext(original_filename)[1].lower()
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            secure_base = secure_filename(os.path.splitext(original_filename)[0])
            filename = f"{prefix}_{timestamp}_{secure_base}{file_extension}"
            
            # Read file content
            file_content = file.read()
            file_hash = self._calculate_hash(file_content)
            
            if self.use_azure:
                # Save to Azure Blob Storage
                blob_path = f"uploaded/{filename}"
                
                result = self.azure_storage.upload_file(
                    file_content,
                    blob_path,
                    metadata={
                        'original_filename': original_filename,
                        'upload_time': datetime.now().isoformat(),
                        'file_hash': file_hash
                    }
                )
                
                if not result['success']:
                    return {'success': False, 'error': result['error']}
                
                logger.info(f"Uploaded file saved to Azure: {filename}")
                
                return {
                    'success': True,
                    'filename': filename,
                    'blob_path': blob_path,
                    'file_path': blob_path,  # For compatibility
                    'original_filename': original_filename,
                    'file_size': len(file_content),
                    'file_hash': file_hash,
                    'upload_time': datetime.now().isoformat(),
                    'folder_type': 'uploaded',
                    'storage_type': 'azure',
                    'download_url': result['download_url']
                }
            
            else:
                # Save to local filesystem
                file_path = os.path.join(self.upload_folder, filename)
                with open(file_path, 'wb') as f:
                    f.write(file_content)
                
                file_stats = os.stat(file_path)
                
                logger.info(f"Uploaded file saved locally: {filename}")
                
                return {
                    'success': True,
                    'filename': filename,
                    'file_path': file_path,
                    'blob_path': None,
                    'original_filename': original_filename,
                    'file_size': file_stats.st_size,
                    'file_hash': file_hash,
                    'upload_time': datetime.now().isoformat(),
                    'folder_type': 'uploaded',
                    'storage_type': 'local'
                }
            
        except Exception as e:
            logger.error(f"Failed to save uploaded file: {e}")
            return {
                'success': False,
                'error': f'Failed to save file: {str(e)}'
            }
    
    def save_converted_file(self, converted_spec: Dict[str, Any], 
                           original_filename: str, 
                           conversion_metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Save converted OpenAPI specification (to Azure or local)"""
        try:
            # Generate filename for converted file
            base_name = os.path.splitext(original_filename)[0]
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            converted_filename = f"converted_{timestamp}_{secure_filename(base_name)}.json"
            metadata_filename = f"metadata_{timestamp}_{secure_filename(base_name)}.json"
            
            # Serialize converted spec
            converted_content = json.dumps(converted_spec, indent=2, ensure_ascii=False).encode('utf-8')
            
            # Prepare metadata
            metadata = {
                'original_filename': original_filename,
                'converted_filename': converted_filename,
                'conversion_timestamp': datetime.now().isoformat(),
                'openapi_version': converted_spec.get('openapi', 'Unknown'),
                'api_title': converted_spec.get('info', {}).get('title', 'Unknown'),
                'api_version': converted_spec.get('info', {}).get('version', 'Unknown'),
                'paths_count': len(converted_spec.get('paths', {})),
                'schemas_count': len(converted_spec.get('components', {}).get('schemas', {})),
                'conversion_metadata': conversion_metadata or {}
            }
            
            metadata_content = json.dumps(metadata, indent=2, ensure_ascii=False).encode('utf-8')
            
            if self.use_azure:
                # Save to Azure Blob Storage
                blob_path = f"converted/{converted_filename}"
                metadata_blob_path = f"converted/{metadata_filename}"
                
                # Upload converted spec
                result = self.azure_storage.upload_file(converted_content, blob_path)
                if not result['success']:
                    return {'success': False, 'error': result['error']}
                
                # Upload metadata
                self.azure_storage.upload_file(metadata_content, metadata_blob_path)
                
                logger.info(f"Converted file saved to Azure: {converted_filename}")
                
                return {
                    'success': True,
                    'filename': converted_filename,
                    'blob_path': blob_path,
                    'file_path': blob_path,  # For compatibility
                    'metadata_filename': metadata_filename,
                    'metadata_blob_path': metadata_blob_path,
                    'metadata_path': metadata_blob_path,  # For compatibility
                    'file_size': len(converted_content),
                    'conversion_time': datetime.now().isoformat(),
                    'folder_type': 'converted',
                    'storage_type': 'azure',
                    'download_url': result['download_url'],
                    'metadata': metadata
                }
            
            else:
                # Save to local filesystem
                converted_path = os.path.join(self.converted_folder, converted_filename)
                metadata_path = os.path.join(self.converted_folder, metadata_filename)
                
                with open(converted_path, 'wb') as f:
                    f.write(converted_content)
                
                with open(metadata_path, 'wb') as f:
                    f.write(metadata_content)
                
                file_stats = os.stat(converted_path)
                
                logger.info(f"Converted file saved locally: {converted_filename}")
                
                return {
                    'success': True,
                    'filename': converted_filename,
                    'file_path': converted_path,
                    'blob_path': None,
                    'metadata_filename': metadata_filename,
                    'metadata_path': metadata_path,
                    'metadata_blob_path': None,
                    'file_size': file_stats.st_size,
                    'conversion_time': datetime.now().isoformat(),
                    'folder_type': 'converted',
                    'storage_type': 'local',
                    'download_url': f'/api/files/converted/{converted_filename}',
                    'metadata': metadata
                }
            
        except Exception as e:
            logger.error(f"Failed to save converted file: {e}")
            return {
                'success': False,
                'error': f'Failed to save converted file: {str(e)}'
            }
    
    def read_file_content(self, file_path: str, blob_path: Optional[str] = None) -> Dict[str, Any]:
        """Read and parse file content (from Azure or local)"""
        try:
            content = None
            
            if self.use_azure and blob_path:
                # Read from Azure
                result = self.azure_storage.download_file(blob_path)
                if not result['success']:
                    return {'success': False, 'error': result['error']}
                
                content = result['content'].decode('utf-8')
            
            elif os.path.exists(file_path):
                # Read from local
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            
            else:
                return {'success': False, 'error': 'File not found'}
            
            # Determine content type and parse
            file_extension = os.path.splitext(file_path)[1].lower() if file_path else '.json'
            content_type = 'json' if file_extension == '.json' else 'yaml'
            
            parsed_content = None
            try:
                if content_type == 'json' or content.strip().startswith('{'):
                    parsed_content = json.loads(content)
                    content_type = 'json'
                else:
                    parsed_content = yaml.safe_load(content)
                    content_type = 'yaml'
            except Exception as parse_error:
                logger.warning(f"Failed to parse content as {content_type}: {parse_error}")
            
            return {
                'success': True,
                'content': content,
                'parsed_content': parsed_content,
                'content_type': content_type,
                'file_size': len(content.encode('utf-8')) if content else 0,
                'encoding': 'utf-8'
            }
            
        except Exception as e:
            logger.error(f"Failed to read file content: {e}")
            return {
                'success': False,
                'error': f'Failed to read file: {str(e)}'
            }
    
    def get_file_info(self, filename: str, folder_type: str = 'uploaded', blob_path: Optional[str] = None) -> Dict[str, Any]:
        """Get file information with content preview"""
        try:
            if self.use_azure and blob_path:
                # Get from Azure
                result = self.azure_storage.download_file(blob_path)
                if not result['success']:
                    return result
                
                content = result['content'].decode('utf-8')
                file_size = result['size']
                
                # Parse content
                try:
                    parsed_content = json.loads(content)
                    content_type = 'json'
                except:
                    try:
                        parsed_content = yaml.safe_load(content)
                        content_type = 'yaml'
                    except:
                        parsed_content = None
                        content_type = 'text'
                
                # Get metadata if it's converted
                metadata = None
                if folder_type == 'converted':
                    metadata = self._get_conversion_metadata(filename, blob_path)
                
                return {
                    'success': True,
                    'filename': filename,
                    'blob_path': blob_path,
                    'folder_type': folder_type,
                    'content': content,
                    'parsed_content': parsed_content,
                    'content_type': content_type,
                    'file_size': file_size,
                    'storage_type': 'azure',
                    'metadata': metadata
                }
            
            else:
                # Get from local filesystem
                folder = self.upload_folder if folder_type == 'uploaded' else self.converted_folder
                file_path = os.path.join(folder, filename)
                
                if not os.path.exists(file_path):
                    return {'success': False, 'error': 'File not found'}
                
                content_result = self.read_file_content(file_path)
                if not content_result['success']:
                    return content_result
                
                file_stats = os.stat(file_path)
                
                metadata = None
                if folder_type == 'converted':
                    metadata = self._get_conversion_metadata(filename)
                
                return {
                    'success': True,
                    'filename': filename,
                    'file_path': file_path,
                    'folder_type': folder_type,
                    'content': content_result['content'],
                    'parsed_content': content_result['parsed_content'],
                    'content_type': content_result['content_type'],
                    'file_size': file_stats.st_size,
                    'modified_time': datetime.fromtimestamp(file_stats.st_mtime).isoformat(),
                    'storage_type': 'local',
                    'metadata': metadata
                }
        
        except Exception as e:
            logger.error(f"Failed to get file info: {e}")
            return {'success': False, 'error': f'Failed to get file info: {str(e)}'}
    
    def list_files(self, folder_type: str = 'all') -> Dict[str, Any]:
        """List files in specified folder(s)"""
        try:
            files = []
            
            if self.use_azure:
                # List from Azure
                if folder_type in ['all', 'uploaded']:
                    result = self.azure_storage.list_files(prefix='uploaded/')
                    if result['success']:
                        for f in result['files']:
                            f['folder_type'] = 'uploaded'
                            f['storage_type'] = 'azure'
                            files.extend([f])
                
                if folder_type in ['all', 'converted']:
                    result = self.azure_storage.list_files(prefix='converted/')
                    if result['success']:
                        for f in result['files']:
                            f['folder_type'] = 'converted'
                            f['storage_type'] = 'azure'
                            files.extend([f])
            
            else:
                # List from local
                if folder_type in ['all', 'uploaded']:
                    uploaded_files = self._list_folder_files(self.upload_folder, 'uploaded')
                    files.extend(uploaded_files)
                
                if folder_type in ['all', 'converted']:
                    converted_files = self._list_folder_files(self.converted_folder, 'converted')
                    files.extend(converted_files)
            
            # Sort by modification time (newest first)
            files.sort(key=lambda x: x.get('modified_time', ''), reverse=True)
            
            return {
                'success': True,
                'files': files,
                'total_count': len(files),
                'folder_type': folder_type,
                'storage_type': 'azure' if self.use_azure else 'local'
            }
            
        except Exception as e:
            logger.error(f"Failed to list files: {e}")
            return {
                'success': False,
                'error': f'Failed to list files: {str(e)}',
                'files': []
            }
    
    def delete_file(self, filename: str, folder_type: str = 'uploaded', blob_path: Optional[str] = None) -> Dict[str, Any]:
        """Delete file and associated metadata"""
        try:
            if self.use_azure and blob_path:
                # Delete from Azure
                result = self.azure_storage.delete_file(blob_path)
                if not result['success']:
                    return result
                
                # Delete metadata if it's a converted file
                if folder_type == 'converted':
                    metadata_blob_path = blob_path.replace('converted_', 'metadata_')
                    self.azure_storage.delete_file(metadata_blob_path)
                
                logger.info(f"Deleted file from Azure: {filename}")
                
                return {
                    'success': True,
                    'message': f'File {filename} deleted successfully',
                    'storage_type': 'azure'
                }
            
            else:
                # Delete from local
                folder = self.upload_folder if folder_type == 'uploaded' else self.converted_folder
                file_path = os.path.join(folder, filename)
                
                if not os.path.exists(file_path):
                    return {'success': False, 'error': 'File not found'}
                
                os.remove(file_path)
                
                # Delete metadata file if it's a converted file
                if folder_type == 'converted':
                    metadata_filename = filename.replace('converted_', 'metadata_')
                    metadata_path = os.path.join(self.converted_folder, metadata_filename)
                    if os.path.exists(metadata_path):
                        os.remove(metadata_path)
                
                logger.info(f"Deleted file locally: {filename}")
                
                return {
                    'success': True,
                    'message': f'File {filename} deleted successfully',
                    'storage_type': 'local'
                }
        
        except Exception as e:
            logger.error(f"Failed to delete file: {e}")
            return {
                'success': False,
                'error': f'Failed to delete file: {str(e)}'
            }
    
    def cleanup_old_files(self, days_old: int = 7) -> Dict[str, Any]:
        """Clean up files older than specified days (local only)"""
        try:
            # Note: Azure Storage cleanup would need to iterate and delete
            # For now, we only clean local files
            
            if self.use_azure:
                logger.info("Cleanup requested for Azure Storage - manual cleanup recommended")
                return {
                    'success': True,
                    'message': 'Azure cleanup requires manual intervention',
                    'deleted_files': [],
                    'count': 0,
                    'storage_type': 'azure'
                }
            
            cutoff_time = datetime.now().timestamp() - (days_old * 24 * 60 * 60)
            deleted_files = []
            
            # Clean uploaded files
            for filename in os.listdir(self.upload_folder):
                file_path = os.path.join(self.upload_folder, filename)
                if os.path.isfile(file_path) and os.path.getmtime(file_path) < cutoff_time:
                    os.remove(file_path)
                    deleted_files.append(f"uploaded/{filename}")
            
            # Clean converted files
            for filename in os.listdir(self.converted_folder):
                file_path = os.path.join(self.converted_folder, filename)
                if os.path.isfile(file_path) and os.path.getmtime(file_path) < cutoff_time:
                    os.remove(file_path)
                    deleted_files.append(f"converted/{filename}")
            
            # Clean temp files
            for filename in os.listdir(self.temp_folder):
                file_path = os.path.join(self.temp_folder, filename)
                if os.path.isfile(file_path) and os.path.getmtime(file_path) < cutoff_time:
                    os.remove(file_path)
                    deleted_files.append(f"temp/{filename}")
            
            logger.info(f"Cleaned up {len(deleted_files)} old files")
            
            return {
                'success': True,
                'deleted_files': deleted_files,
                'count': len(deleted_files),
                'storage_type': 'local'
            }
        
        except Exception as e:
            logger.error(f"Failed to cleanup old files: {e}")
            return {
                'success': False,
                'error': f'Failed to cleanup: {str(e)}'
            }
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get storage statistics"""
        try:
            if self.use_azure:
                stats = self.azure_storage.get_storage_stats()
                return {
                    'success': True,
                    'folders': {
                        'total': stats
                    },
                    'totals': stats,
                    'storage_type': 'azure'
                }
            
            else:
                stats = {}
                
                for folder_name, folder_path in [
                    ('uploaded', self.upload_folder),
                    ('converted', self.converted_folder),
                    ('temp', self.temp_folder)
                ]:
                    if os.path.exists(folder_path):
                        files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
                        total_size = sum(os.path.getsize(os.path.join(folder_path, f)) for f in files)
                        
                        stats[folder_name] = {
                            'file_count': len(files),
                            'total_size_bytes': total_size,
                            'total_size_mb': round(total_size / (1024 * 1024), 2)
                        }
                    else:
                        stats[folder_name] = {
                            'file_count': 0,
                            'total_size_bytes': 0,
                            'total_size_mb': 0
                        }
                
                # Calculate totals
                total_files = sum(s['file_count'] for s in stats.values())
                total_size = sum(s['total_size_bytes'] for s in stats.values())
                
                return {
                    'success': True,
                    'folders': stats,
                    'totals': {
                        'total_files': total_files,
                        'total_size_bytes': total_size,
                        'total_size_mb': round(total_size / (1024 * 1024), 2)
                    },
                    'storage_type': 'local'
                }
        
        except Exception as e:
            logger.error(f"Failed to get storage stats: {e}")
            return {
                'success': False,
                'error': f'Failed to get storage stats: {str(e)}'
            }
    
    def _validate_file(self, file: FileStorage) -> Dict[str, Any]:
        """Validate uploaded file"""
        if not file or not file.filename:
            return {'valid': False, 'error': 'No file provided'}
        
        # Check file extension
        file_extension = os.path.splitext(file.filename)[1].lower()
        if file_extension not in self.allowed_extensions:
            return {
                'valid': False, 
                'error': f'Invalid file type. Allowed: {", ".join(self.allowed_extensions)}'
            }
        
        # Check file size
        file.seek(0, 2)  # Seek to end
        file_size = file.tell()
        file.seek(0)  # Reset to beginning
        
        if file_size > self.max_file_size:
            return {
                'valid': False,
                'error': f'File too large. Max size: {self.max_file_size // (1024*1024)}MB'
            }
        
        return {'valid': True}
    
    def _calculate_hash(self, content: bytes) -> str:
        """Calculate SHA-256 hash of content"""
        hash_sha256 = hashlib.sha256()
        hash_sha256.update(content)
        return hash_sha256.hexdigest()[:16]  # First 16 characters
    
    def _list_folder_files(self, folder_path: str, folder_type: str) -> List[Dict[str, Any]]:
        """List files in a specific local folder"""
        files = []
        
        if not os.path.exists(folder_path):
            return files
        
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            
            if os.path.isfile(file_path):
                file_stats = os.stat(file_path)
                
                file_info = {
                    'filename': filename,
                    'folder_type': folder_type,
                    'file_size': file_stats.st_size,
                    'modified_time': datetime.fromtimestamp(file_stats.st_mtime).isoformat(),
                    'file_extension': os.path.splitext(filename)[1].lower(),
                    'storage_type': 'local'
                }
                
                # Add metadata for converted files
                if folder_type == 'converted' and filename.startswith('converted_'):
                    metadata = self._get_conversion_metadata(filename)
                    if metadata:
                        file_info['metadata'] = metadata
                
                files.append(file_info)
        
        return files
    
    def _get_conversion_metadata(self, converted_filename: str, blob_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get conversion metadata for a converted file"""
        try:
            if self.use_azure and blob_path:
                # Get from Azure
                metadata_blob_path = blob_path.replace('converted_', 'metadata_')
                result = self.azure_storage.download_file(metadata_blob_path)
                
                if result['success']:
                    return json.loads(result['content'].decode('utf-8'))
                return None
            
            else:
                # Get from local
                metadata_filename = converted_filename.replace('converted_', 'metadata_')
                metadata_path = os.path.join(self.converted_folder, metadata_filename)
                
                if os.path.exists(metadata_path):
                    with open(metadata_path, 'r', encoding='utf-8') as f:
                        return json.load(f)
                
                return None
        
        except Exception as e:
            logger.warning(f"Failed to read metadata: {e}")
            return None