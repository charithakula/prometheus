"""
Chat Helpers - Utility functions for chat
File: utils/chat_helpers.py

Functions:
- File processing and validation
- File purpose detection
- Response formatting
- Metadata extraction
"""

import logging
from typing import Dict, Optional, Any
from werkzeug.utils import secure_filename
import json
import re

logger = logging.getLogger(__name__)

# Configuration constants
CHAT_CONFIG = {
    'max_file_size': 16 * 1024 * 1024,  # 16MB
    'supported_file_types': [
        'py', 'js', 'ts', 'java', 'go', 'rs', 'cs', 'cpp', 'c',  # Code
        'json', 'yaml', 'yml', 'xml', 'sql',  # Config/Data
        'md', 'txt', 'rst',  # Documentation
        'pdf', 'docx', 'xlsx'  # Documents
    ]
}


def process_chat_file(file, conversation_id: str) -> Dict[str, Any]:
    """
    Process uploaded file for chat
    
    Args:
        file: FileStorage object from Flask request
        conversation_id: ID of conversation (for tracking)
    
    Returns:
        {
            'success': bool,
            'filename': str,
            'type': str,
            'size': int,
            'size_formatted': str,
            'content': str,
            'detected_purpose': str,
            'word_count': int,
            'char_count': int,
            'error': str (if failed)
        }
    """
    
    try:
        if not file:
            return {'success': False, 'error': 'No file provided'}
        
        # Check file size
        file.seek(0, 2)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > CHAT_CONFIG['max_file_size']:
            max_mb = CHAT_CONFIG['max_file_size'] / (1024 * 1024)
            return {
                'success': False,
                'error': f'File exceeds {max_mb}MB limit'
            }
        
        # Extract filename and extension
        filename = secure_filename(file.filename)
        if not filename:
            return {'success': False, 'error': 'Invalid filename'}
        
        file_ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else 'unknown'
        
        # Check file type
        if file_ext not in CHAT_CONFIG['supported_file_types']:
            supported = ', '.join(CHAT_CONFIG['supported_file_types'][:10])
            return {
                'success': False,
                'error': f'Unsupported file type. Supported: {supported}...'
            }
        
        logger.info(f"Processing file: {filename} ({file_ext}, {file_size} bytes)")
        
        # Extract content
        try:
            file.seek(0)
            content = file.read()
            
            # Try to decode as text
            try:
                content_str = content.decode('utf-8')
            except UnicodeDecodeError:
                # Try with error handling
                content_str = content.decode('utf-8', errors='ignore')
            
            if not content_str:
                return {'success': False, 'error': 'File appears to be empty or binary'}
        
        except Exception as read_error:
            logger.error(f"Failed to read file: {read_error}")
            return {'success': False, 'error': f'Failed to read file: {str(read_error)[:100]}'}
        
        # Detect purpose
        purpose = detect_file_purpose(content_str, filename, file_ext)
        
        # Calculate statistics
        word_count = len(content_str.split())
        char_count = len(content_str)
        
        logger.info(f"✅ File processed: {char_count} chars, {word_count} words")
        
        return {
            'success': True,
            'filename': filename,
            'type': file_ext,
            'size': file_size,
            'size_formatted': format_file_size_local(file_size),
            'content': content_str,
            'detected_purpose': purpose,
            'word_count': word_count,
            'char_count': char_count,
            'content_preview': content_str[:200]
        }
    
    except Exception as e:
        logger.error(f"File processing error: {e}", exc_info=True)
        return {
            'success': False,
            'error': f'File processing failed: {str(e)[:100]}'
        }


def detect_file_purpose(content: str, filename: str, file_ext: str) -> str:
    """
    Detect what the file is for
    
    Detects:
    - Source code (Python, JavaScript, etc.)
    - API specifications (OpenAPI, Swagger)
    - Configuration files (JSON, YAML)
    - Documentation
    - SQL databases
    - Policies and security docs
    """
    
    content_lower = content.lower()
    filename_lower = filename.lower()
    
    # Code files
    if file_ext in ['py', 'js', 'java', 'go', 'rs', 'ts', 'cs', 'cpp', 'c']:
        return f'Source Code ({file_ext.upper()})'
    
    # Configuration/Data files
    if file_ext in ['json', 'yaml', 'yml', 'xml']:
        # Check for API specs
        if 'openapi' in content_lower or 'swagger' in content_lower:
            return 'OpenAPI/Swagger Specification'
        
        if 'components' in content_lower and 'schemas' in content_lower:
            return 'API Specification'
        
        # Check for config
        if 'config' in filename_lower or 'settings' in content_lower or 'environment' in content_lower:
            return 'Configuration File'
        
        return f'{file_ext.upper()} Data'
    
    # SQL
    if file_ext == 'sql' or 'create table' in content_lower or 'select' in content_lower:
        return 'SQL Database Script'
    
    # API/Policy documents
    if 'api' in content_lower or 'endpoint' in content_lower or 'rest' in content_lower:
        if 'policy' in content_lower or 'requirement' in content_lower:
            return 'API Policy Document'
        return 'API Documentation'
    
    if 'policy' in content_lower or 'security' in content_lower or 'compliance' in content_lower:
        return 'Security/Compliance Policy'
    
    # Documentation
    if 'guide' in filename_lower or 'readme' in filename_lower or 'documentation' in content_lower:
        return 'Documentation'
    
    if 'how to' in content_lower or 'tutorial' in content_lower or 'guide' in content_lower:
        return 'How-To Guide'
    
    # Default
    return 'Text Document'


def format_file_size_local(size_bytes: int) -> str:
    """
    Convert bytes to human readable format
    
    Examples:
    - 1024 -> "1.0 KB"
    - 1048576 -> "1.0 MB"
    - 5242880 -> "5.0 MB"
    """
    
    if size_bytes == 0:
        return '0 B'
    
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    size = float(size_bytes)
    unit_index = 0
    
    while size >= 1024.0 and unit_index < len(units) - 1:
        size /= 1024.0
        unit_index += 1
    
    return f'{size:.1f} {units[unit_index]}'


def ensure_code_blocks_formatted(response_text: str, assistant_type: str) -> str:
    """
    Ensure code blocks have proper language specifiers
    
    Before:
    ```
    def hello():
        print("world")
    ```
    
    After:
    ```python
    def hello():
        print("world")
    ```
    """
    
    if assistant_type not in ['code', 'code_review']:
        return response_text
    
    # Pattern: ``` followed by newline (without language)
    pattern = r'```\n((?!```)[^`]*?)```'
    
    def add_language(match):
        code_content = match.group(1)
        
        # Simple heuristic detection
        if 'import ' in code_content or 'from ' in code_content or 'def ' in code_content:
            lang = 'python'
        elif 'const ' in code_content or 'function ' in code_content or 'async ' in code_content:
            lang = 'javascript'
        elif 'public class' in code_content or 'package ' in code_content:
            lang = 'java'
        elif 'func ' in code_content or 'package ' in code_content:
            lang = 'go'
        elif 'impl ' in code_content or 'fn ' in code_content:
            lang = 'rust'
        elif 'using ' in code_content or 'class ' in code_content and 'namespace' in code_content:
            lang = 'csharp'
        else:
            lang = 'plaintext'
        
        return f'```{lang}\n{code_content}```'
    
    response_text = re.sub(pattern, add_language, response_text)
    return response_text


def extract_response_metadata(response_text: str, assistant_type: str) -> Dict[str, Any]:
    """
    Extract useful metadata from response
    
    Returns:
    {
        'assistant_type': str,
        'code_blocks': int,
        'has_examples': bool,
        'has_warnings': bool,
        'sections': int,
        'endpoints': int (for API design),
        'code_elements': int (for code)
    }
    """
    
    metadata = {
        'assistant_type': assistant_type,
        'code_blocks': response_text.count('```'),
        'has_examples': 'example' in response_text.lower() or 'e.g.' in response_text.lower(),
        'has_warnings': '⚠️' in response_text or 'warning' in response_text.lower() or 'important' in response_text.lower(),
        'sections': len([line for line in response_text.split('\n') if line.startswith('#')]),
        'has_lists': response_text.count('-') + response_text.count('•') > 5,
        'response_length': len(response_text)
    }
    
    # Type-specific metadata
    if assistant_type == 'code':
        functions = len(re.findall(r'def |function |class ', response_text))
        metadata['code_elements'] = functions
    
    elif assistant_type == 'api_design':
        endpoints = len(re.findall(r'(?:GET|POST|PUT|DELETE|PATCH|OPTIONS)\s+/', response_text))
        metadata['endpoints'] = endpoints
    
    elif assistant_type == 'policy':
        risk_items = len(re.findall(r'(?:Critical|High|Medium|Low)', response_text, re.IGNORECASE))
        metadata['risk_items'] = risk_items
    
    elif assistant_type == 'code_review':
        issues = len(re.findall(r'(?:Issue|Bug|Warning|Error)[\s:]*', response_text, re.IGNORECASE))
        metadata['issues_found'] = issues
    
    return metadata


def generate_follow_up_suggestions(message: str, assistant_type: str) -> list:
    """
    Generate follow-up suggestion messages
    
    Example:
    ['💾 Save this code', '🧪 Write unit tests', '🔍 Review security']
    """
    
    suggestions = {
        'code': [
            "💾 Save this code to a file",
            "🧪 Write unit tests for this",
            "🔍 Review this for security issues",
            "📚 Add documentation comments",
            "⚡ Optimize for performance"
        ],
        'code_review': [
            "✅ Apply suggested fixes",
            "🧪 Run tests after changes",
            "📊 Check code coverage",
            "🔐 Security review of changes",
            "📈 Performance benchmarks"
        ],
        'api_design': [
            "📝 Generate OpenAPI specification",
            "🧪 Design test cases",
            "📚 Create API documentation",
            "🔐 Review security aspects",
            "⚡ Plan for scaling"
        ],
        'policy': [
            "💻 Generate implementation code",
            "✅ Create compliance checklist",
            "🧪 Design compliance tests",
            "📊 Risk assessment analysis",
            "🔄 Review with security team"
        ],
        'documentation': [
            "📄 Export as PDF document",
            "💾 Save as markdown file",
            "🔄 Generate from OpenAPI spec",
            "👥 Share with team",
            "📊 Add diagrams/visuals"
        ],
        'general': [
            "📝 Get more details",
            "💾 Save this response",
            "📊 Show examples",
            "🔍 Dive deeper",
            "💭 Ask follow-up"
        ]
    }
    
    # Get suggestions for this type, or fall back to general
    type_suggestions = suggestions.get(assistant_type, suggestions['general'])
    
    # Return top 3
    return type_suggestions[:3]


def validate_conversation_id(conversation_id: str) -> bool:
    """
    Validate conversation ID format
    
    Valid formats:
    - conv_1234567890.123456
    - custom-id-123
    """
    
    if not conversation_id:
        return False
    
    if len(conversation_id) > 100:
        return False
    
    # Allow alphanumeric, underscore, dash, dot
    if not re.match(r'^[a-zA-Z0-9_\-\.]+$', conversation_id):
        return False
    
    return True


def truncate_text(text: str, max_length: int = 500, suffix: str = '...') -> str:
    """
    Truncate text to max length with suffix
    
    Example:
    truncate_text("Long text here", 10) -> "Long text ..."
    """
    
    if len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


def clean_response_text(text: str) -> str:
    """
    Clean response text for output
    - Remove null bytes
    - Strip whitespace
    - Fix common encoding issues
    """
    
    if not text:
        return ''
    
    # Remove null bytes
    text = text.replace('\x00', '')
    
    # Remove other problematic characters
    text = text.replace('\r\n', '\n')
    
    # Strip leading/trailing whitespace
    text = text.strip()
    
    # Ensure not empty
    if len(text) == 0:
        text = 'Response generated but appears empty. Please try again.'
    
    return text