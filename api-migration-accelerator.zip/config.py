"""
Production Configuration File - SIMPLIFIED SSL (Only CA_BUNDLE_PATH)
- Centralized settings
- Environment-specific configs
- Security best practices
- Simplified SSL with only CA_BUNDLE_PATH
- Cache Configuration
- No hardcoded credentials (loads from .env)
"""
import os
from datetime import timedelta
from typing import List, Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class BaseConfig:
    """Base configuration - shared across all environments"""
    
    # ==========================================
    # FLASK CONFIGURATION
    # ==========================================
    SECRET_KEY = os.getenv('FLASK_SECRET_KEY', 'dev-secret-key-change-this')
    DEBUG = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    TESTING = False
    
    # ==========================================
    # SERVER CONFIGURATION
    # ==========================================
    HOST = os.getenv('FLASK_HOST', '0.0.0.0')
    PORT = int(os.getenv('FLASK_PORT', 5000))
    
    # ==========================================
    # DATABASE CONFIGURATION
    # ==========================================
    DATABASE_URL = os.getenv('DATABASE_URL')
    
    # Build DATABASE_URL if not provided
    if not DATABASE_URL:
        DB_TYPE = os.getenv('DB_TYPE', 'sqlite').lower()
        
        if DB_TYPE == 'postgresql':
            DB_HOST = os.getenv('DB_HOST', 'localhost')
            DB_PORT = os.getenv('DB_PORT', '5432')
            DB_NAME = os.getenv('DB_NAME', 'api_migration_db')
            DB_USER = os.getenv('DB_USER', 'api_user')
            DB_PASSWORD = os.getenv('DB_PASSWORD', '')
            
            DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        else:
            # Default to SQLite
            DATABASE_URL = 'sqlite:///migrations.db'
    
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Database connection pooling
    if 'postgresql' in DATABASE_URL.lower():
        SQLALCHEMY_ENGINE_OPTIONS = {
            'pool_size': int(os.getenv('DB_POOL_SIZE', 10)),
            'max_overflow': int(os.getenv('DB_MAX_OVERFLOW', 20)),
            'pool_timeout': int(os.getenv('DB_POOL_TIMEOUT', 30)),
            'pool_recycle': int(os.getenv('DB_POOL_RECYCLE', 3600)),
            'pool_pre_ping': True,
            'echo': DEBUG
        }
    else:
        SQLALCHEMY_ENGINE_OPTIONS = {}
    
    # ==========================================
    # FILE HANDLING
    # ==========================================
    UPLOAD_FOLDER = os.getenv('UPLOAD_FOLDER', 'static/uploads')
    CONVERTED_FOLDER = os.getenv('CONVERTED_FOLDER', 'static/converted')
    MAX_CONTENT_LENGTH = int(os.getenv('MAX_CONTENT_LENGTH', 16 * 1024 * 1024))
    ALLOWED_EXTENSIONS = set(os.getenv('ALLOWED_EXTENSIONS', 'json,yaml,yml').split(','))
    MAX_FILES_IN_MEMORY = int(os.getenv('MAX_FILES_IN_MEMORY', 1000))
    
    # ==========================================
    # LOGGING CONFIGURATION
    # ==========================================
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.getenv('LOG_FILE', 'logs/app.log')
    STRUCTURED_LOGGING = os.getenv('STRUCTURED_LOGGING', 'True').lower() == 'true'
    
    # ==========================================
    # SESSION CONFIGURATION
    # ==========================================
    PERMANENT_SESSION_LIFETIME = timedelta(hours=24)
    SESSION_COOKIE_SECURE = os.getenv('SESSION_COOKIE_SECURE', 'True').lower() == 'true'
    SESSION_COOKIE_HTTPONLY = os.getenv('SESSION_COOKIE_HTTPONLY', 'True').lower() == 'true'
    SESSION_COOKIE_SAMESITE = os.getenv('SESSION_COOKIE_SAMESITE', 'Lax')
    SESSION_COOKIE_NAME = os.getenv('SESSION_COOKIE_NAME', 'api_migration_session')
    
    # ==========================================
    # SECURITY CONFIGURATION
    # ==========================================
    SECURITY_HEADERS_ENABLED = os.getenv('SECURITY_HEADERS_ENABLED', 'True').lower() == 'true'
    CORS_ALLOWED_ORIGINS = os.getenv('CORS_ALLOWED_ORIGINS', '*').split(',')
    
    # ==========================================
    # RATE LIMITING
    # ==========================================
    RATELIMIT_ENABLED = os.getenv('RATELIMIT_ENABLED', 'True').lower() == 'true'
    RATELIMIT_DEFAULT_PER_MINUTE = int(os.getenv('RATELIMIT_DEFAULT_PER_MINUTE', '60'))
    RATELIMIT_DEFAULT_PER_HOUR = int(os.getenv('RATELIMIT_DEFAULT_PER_HOUR', '1000'))
    
    RATELIMIT_CONVERSION_PER_MINUTE = int(os.getenv('RATELIMIT_CONVERSION_PER_MINUTE', '10'))
    RATELIMIT_CONVERSION_PER_HOUR = int(os.getenv('RATELIMIT_CONVERSION_PER_HOUR', '200'))
    
    RATELIMIT_MIGRATION_PER_MINUTE = int(os.getenv('RATELIMIT_MIGRATION_PER_MINUTE', '5'))
    RATELIMIT_MIGRATION_PER_HOUR = int(os.getenv('RATELIMIT_MIGRATION_PER_HOUR', '50'))
    
    RATELIMIT_CHAT_PER_MINUTE = int(os.getenv('RATELIMIT_CHAT_PER_MINUTE', '20'))
    RATELIMIT_CHAT_PER_HOUR = int(os.getenv('RATELIMIT_CHAT_PER_HOUR', '500'))
    
    # ==========================================
    # TIMEOUTS (in seconds)
    # ==========================================
    REQUEST_TIMEOUT_SECONDS = int(os.getenv('REQUEST_TIMEOUT_SECONDS', '30'))
    DATABASE_TIMEOUT_SECONDS = int(os.getenv('DATABASE_TIMEOUT_SECONDS', '10'))
    OPENAI_TIMEOUT_SECONDS = int(os.getenv('OPENAI_TIMEOUT_SECONDS', '60'))
    STORAGE_TIMEOUT_SECONDS = int(os.getenv('STORAGE_TIMEOUT_SECONDS', '10'))
    APIM_TIMEOUT_SECONDS = int(os.getenv('APIM_TIMEOUT_SECONDS', '30'))
    
    # ==========================================
    # AZURE CONFIGURATION
    # ==========================================
    AZURE_CLIENT_ID = os.getenv('AZURE_CLIENT_ID')
    AZURE_CLIENT_SECRET = os.getenv('AZURE_CLIENT_SECRET')
    AZURE_TENANT_ID = os.getenv('AZURE_TENANT_ID')
    AZURE_SUBSCRIPTION_ID = os.getenv('AZURE_SUBSCRIPTION_ID')
    
    # ==========================================
    # AZURE OPENAI CONFIGURATION
    # ==========================================
    AZURE_OPENAI_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT')
    AZURE_OPENAI_API_KEY = os.getenv('AZURE_OPENAI_API_KEY')
    AZURE_OPENAI_DEPLOYMENT = os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4o-mini')
    AZURE_OPENAI_VERSION = os.getenv('AZURE_OPENAI_VERSION', '2024-08-01-preview')
    
    # ==========================================
    # AZURE API MANAGEMENT CONFIGURATION
    # ==========================================
    AZURE_APIM_RESOURCE_GROUP = os.getenv('AZURE_APIM_RESOURCE_GROUP')
    AZURE_APIM_SERVICE_NAME = os.getenv('AZURE_APIM_SERVICE_NAME')
    AZURE_APIM_API_KEY = os.getenv('AZURE_APIM_API_KEY')
    AZURE_APIM_BASE_URL = os.getenv('AZURE_APIM_BASE_URL', 'https://management.azure.com')
    
    # ==========================================
    # AZURE STORAGE CONFIGURATION
    # ==========================================
    AZURE_STORAGE_CONNECTION_STRING = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
    AZURE_STORAGE_ACCOUNT_NAME = os.getenv('AZURE_STORAGE_ACCOUNT_NAME')
    AZURE_STORAGE_ACCOUNT_KEY = os.getenv('AZURE_STORAGE_ACCOUNT_KEY')
    AZURE_STORAGE_CONTAINER_NAME = os.getenv('AZURE_STORAGE_CONTAINER_NAME', 'api-migration')
    
    # ==========================================
    # SSL CERTIFICATE CONFIGURATION - SIMPLIFIED ✅
    # ==========================================
    VERIFY_SSL = os.getenv('VERIFY_SSL', 'True').lower() == 'true'
    CA_BUNDLE_PATH = os.getenv('CA_BUNDLE_PATH', None)
    
    # ==========================================
    # CACHE CONFIGURATION - NEW ✅
    # ==========================================
    CACHE_TYPE = os.getenv('CACHE_TYPE', 'SimpleCache')
    CACHE_DEFAULT_TIMEOUT = int(os.getenv('CACHE_DEFAULT_TIMEOUT', '300'))
    CACHE_REDIS_URL = os.getenv('REDIS_URL', None)
    
    # ==========================================
    # CONVERSATION MANAGER
    # ==========================================
    CONVERSATION_MAX_LIMIT = int(os.getenv('CONVERSATION_MAX_LIMIT', '500'))
    CONVERSATION_TTL_HOURS = int(os.getenv('CONVERSATION_TTL_HOURS', '24'))
    CONVERSATION_CLEANUP_INTERVAL = int(os.getenv('CONVERSATION_CLEANUP_INTERVAL', '60'))
    
    # ==========================================
    # DATABASE CLEANUP
    # ==========================================
    DATABASE_CLEANUP_ENABLED = os.getenv('DATABASE_CLEANUP_ENABLED', 'True').lower() == 'true'
    DATABASE_CLEANUP_DAYS_OLD = int(os.getenv('DATABASE_CLEANUP_DAYS_OLD', '90'))
    DATABASE_CLEANUP_INTERVAL_HOURS = int(os.getenv('DATABASE_CLEANUP_INTERVAL_HOURS', '168'))
    
    # ==========================================
    # HEALTH CHECKS
    # ==========================================
    HEALTH_CHECK_INTERVAL_SECONDS = int(os.getenv('HEALTH_CHECK_INTERVAL_SECONDS', '300'))
    HEALTH_CHECK_TIMEOUT_SECONDS = int(os.getenv('HEALTH_CHECK_TIMEOUT_SECONDS', '30'))
    
    # ==========================================
    # BACKGROUND JOBS
    # ==========================================
    BACKGROUND_JOBS_ENABLED = os.getenv('BACKGROUND_JOBS_ENABLED', 'True').lower() == 'true'
    BACKGROUND_JOB_INTERVAL_MINUTES = int(os.getenv('BACKGROUND_JOB_INTERVAL_MINUTES', '60'))
    
    # ==========================================
    # RESPONSE VALIDATION
    # ==========================================
    RESPONSE_MIN_LENGTH = int(os.getenv('RESPONSE_MIN_LENGTH', '10'))
    RESPONSE_MAX_LENGTH = int(os.getenv('RESPONSE_MAX_LENGTH', '50000'))
    RESPONSE_SENSIBILITY_CHECK = os.getenv('RESPONSE_SENSIBILITY_CHECK', 'True').lower() == 'true'
    
    # ==========================================
    # PERFORMANCE
    # ==========================================
    JSON_SORT_KEYS = False
    COMPRESS_RESPONSE = os.getenv('COMPRESS_RESPONSE', 'True').lower() == 'true'
    
    # ==========================================
    # ENVIRONMENT DETECTION
    # ==========================================
    ENV = os.getenv('FLASK_ENV', 'development').lower()
    
    # ==========================================
    # VALIDATION METHODS (CRITICAL!)
    # ==========================================
    
    @classmethod
    def validate_azure_config(cls) -> List[str]:
        """Validate Azure authentication configuration"""
        missing = []
        required_vars = [
            ('AZURE_CLIENT_ID', cls.AZURE_CLIENT_ID),
            ('AZURE_CLIENT_SECRET', cls.AZURE_CLIENT_SECRET),
            ('AZURE_TENANT_ID', cls.AZURE_TENANT_ID),
            ('AZURE_SUBSCRIPTION_ID', cls.AZURE_SUBSCRIPTION_ID),
        ]
        
        for var_name, var_value in required_vars:
            if not var_value:
                missing.append(var_name)
        
        return missing
    
    @classmethod
    def validate_apim_config(cls) -> List[str]:
        """Validate Azure APIM configuration"""
        missing = []
        required_vars = [
            ('AZURE_APIM_RESOURCE_GROUP', cls.AZURE_APIM_RESOURCE_GROUP),
            ('AZURE_APIM_SERVICE_NAME', cls.AZURE_APIM_SERVICE_NAME),
        ]
        
        for var_name, var_value in required_vars:
            if not var_value:
                missing.append(var_name)
        
        return missing
    
    @classmethod
    def validate_openai_config(cls) -> List[str]:
        """Validate Azure OpenAI configuration"""
        missing = []
        required_vars = [
            ('AZURE_OPENAI_ENDPOINT', cls.AZURE_OPENAI_ENDPOINT),
            ('AZURE_OPENAI_API_KEY', cls.AZURE_OPENAI_API_KEY),
            ('AZURE_OPENAI_DEPLOYMENT', cls.AZURE_OPENAI_DEPLOYMENT),
            ('AZURE_OPENAI_VERSION', cls.AZURE_OPENAI_VERSION),
        ]
        
        for var_name, var_value in required_vars:
            if not var_value or not str(var_value).strip():
                missing.append(var_name)
        
        return missing
    
    @classmethod
    def validate_ssl_config(cls) -> List[str]:
        """Validate SSL certificate configuration"""
        issues = []
        
        if cls.VERIFY_SSL and cls.CA_BUNDLE_PATH:
            if not os.path.exists(cls.CA_BUNDLE_PATH):
                issues.append(f"CA_BUNDLE_PATH points to non-existent file: {cls.CA_BUNDLE_PATH}")
        
        return issues
    
    @classmethod
    def get_database_type(cls) -> str:
        """Get the database type from URL"""
        url = cls.SQLALCHEMY_DATABASE_URI.lower()
        if 'postgresql' in url:
            return 'postgresql'
        elif 'sqlite' in url:
            return 'sqlite'
        else:
            return 'unknown'
    
    @classmethod
    def is_production_db(cls) -> bool:
        """Check if using production database"""
        return cls.get_database_type() == 'postgresql'
    
    @classmethod
    def get_ssl_config(cls) -> dict:
        """Get SSL configuration for requests - SIMPLIFIED"""
        config = {}
        
        if not cls.VERIFY_SSL:
            config['verify'] = False
        elif cls.CA_BUNDLE_PATH and os.path.exists(cls.CA_BUNDLE_PATH):
            config['verify'] = cls.CA_BUNDLE_PATH
        else:
            config['verify'] = True
        
        return config


class DevelopmentConfig(BaseConfig):
    """Development environment configuration"""
    DEBUG = True
    TESTING = False
    ENV = 'development'
    LOG_LEVEL = 'DEBUG'
    STRUCTURED_LOGGING = False
    SESSION_COOKIE_SECURE = False
    DATABASE_ECHO = True
    
    RATELIMIT_ENABLED = False
    RATELIMIT_DEFAULT_PER_MINUTE = 1000
    CONVERSATION_TTL_HOURS = 48
    
    # Development: Allow SSL bypass for private networks
    VERIFY_SSL = os.getenv('VERIFY_SSL', 'False').lower() == 'true'


class ProductionConfig(BaseConfig):
    """Production environment configuration"""
    DEBUG = False
    TESTING = False
    ENV = 'production'
    LOG_LEVEL = 'INFO'
    STRUCTURED_LOGGING = True
    SESSION_COOKIE_SECURE = True
    DATABASE_ECHO = False
    
    RATELIMIT_ENABLED = True
    RATELIMIT_DEFAULT_PER_MINUTE = 30
    RATELIMIT_CONVERSION_PER_MINUTE = 5
    RATELIMIT_MIGRATION_PER_MINUTE = 2
    
    DATABASE_CLEANUP_DAYS_OLD = 60
    DATABASE_CLEANUP_INTERVAL_HOURS = 168
    CONVERSATION_TTL_HOURS = 12
    
    # Production: Always verify SSL
    VERIFY_SSL = True
    
    @classmethod
    def validate_production_config(cls) -> List[str]:
        """Validate production configuration"""
        errors = []
        
        if not cls.SECRET_KEY or cls.SECRET_KEY == 'dev-secret-key-change-this':
            errors.append("❌ FLASK_SECRET_KEY must be set")
        
        if not cls.SQLALCHEMY_DATABASE_URI or cls.SQLALCHEMY_DATABASE_URI == 'sqlite:///migrations.db':
            errors.append("⚠️  Using SQLite in production - consider PostgreSQL")
        
        if not cls.SESSION_COOKIE_SECURE:
            errors.append("❌ SESSION_COOKIE_SECURE must be True")
        
        if not cls.AZURE_OPENAI_API_KEY:
            errors.append("⚠️  AZURE_OPENAI_API_KEY not set")
        
        if not cls.AZURE_APIM_SERVICE_NAME:
            errors.append("⚠️  AZURE_APIM_SERVICE_NAME not set")
        
        # Check SSL configuration for production
        ssl_issues = cls.validate_ssl_config()
        errors.extend(ssl_issues)
        
        return errors


class TestingConfig(BaseConfig):
    """Testing environment configuration"""
    DEBUG = True
    TESTING = True
    ENV = 'testing'
    DATABASE_URL = 'sqlite:///:memory:'
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    LOG_LEVEL = 'DEBUG'
    
    RATELIMIT_ENABLED = False
    RATELIMIT_DEFAULT_PER_MINUTE = 10000
    
    REQUEST_TIMEOUT_SECONDS = 5
    OPENAI_TIMEOUT_SECONDS = 5
    STORAGE_TIMEOUT_SECONDS = 5
    
    # Testing: No SSL verification
    VERIFY_SSL = False


CONFIG_MAP = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
}


def get_config(env: Optional[str] = None) -> BaseConfig:
    """Get configuration based on environment"""
    if not env:
        env = os.getenv('FLASK_ENV', 'development').lower()
    
    config_class = CONFIG_MAP.get(env, DevelopmentConfig)
    return config_class()


def validate_all_configurations() -> dict:
    """Validate all service configurations"""
    config = get_config()
    
    return {
        'environment': config.ENV,
        'database': {
            'type': config.get_database_type(),
            'configured': bool(config.SQLALCHEMY_DATABASE_URI),
            'is_production_db': config.is_production_db()
        },
        'azure': {
            'client_id': '✅' if config.AZURE_CLIENT_ID else '❌',
            'client_secret': '✅' if config.AZURE_CLIENT_SECRET else '❌',
            'tenant_id': '✅' if config.AZURE_TENANT_ID else '❌',
            'subscription_id': '✅' if config.AZURE_SUBSCRIPTION_ID else '❌',
        },
        'azure_openai': {
            'endpoint': '✅' if config.AZURE_OPENAI_ENDPOINT else '❌',
            'api_key': '✅' if config.AZURE_OPENAI_API_KEY else '❌',
            'deployment': config.AZURE_OPENAI_DEPLOYMENT or 'NOT SET',
            'version': config.AZURE_OPENAI_VERSION or 'NOT SET',
        },
        'azure_apim': {
            'service_name': '✅' if config.AZURE_APIM_SERVICE_NAME else '❌',
            'resource_group': '✅' if config.AZURE_APIM_RESOURCE_GROUP else '❌',
            'api_key': '✅' if config.AZURE_APIM_API_KEY else '❌',
        },
        'azure_storage': {
            'connection_string': '✅' if config.AZURE_STORAGE_CONNECTION_STRING else '❌',
            'container': config.AZURE_STORAGE_CONTAINER_NAME,
        },
        'ssl': {
            'verify_ssl': config.VERIFY_SSL,
            'ca_bundle_path': config.CA_BUNDLE_PATH or 'Not set (will use system defaults)',
        },
        'cache': {
            'cache_type': config.CACHE_TYPE,
            'cache_timeout': config.CACHE_DEFAULT_TIMEOUT,
            'redis_configured': bool(config.CACHE_REDIS_URL),
        }
    }


def get_missing_configurations() -> List[str]:
    """Get list of all missing critical configuration variables"""
    config = get_config()
    missing = []
    
    critical_vars = [
        ('AZURE_OPENAI_ENDPOINT', config.AZURE_OPENAI_ENDPOINT),
        ('AZURE_OPENAI_API_KEY', config.AZURE_OPENAI_API_KEY),
        ('AZURE_APIM_SERVICE_NAME', config.AZURE_APIM_SERVICE_NAME),
    ]
    
    for var_name, var_value in critical_vars:
        if not var_value or not str(var_value).strip():
            missing.append(var_name)
    
    return missing


def print_config_status():
    """Print configuration status for debugging"""
    config = get_config()
    validation = validate_all_configurations()
    
    print("\n" + "="*70)
    print("CONFIGURATION STATUS")
    print("="*70)
    print(f"\nEnvironment:     {validation['environment'].upper()}")
    print(f"Database:        {validation['database']['type'].upper()}")
    
    print("\nAzure Authentication:")
    for key, value in validation['azure'].items():
        print(f"  {key.replace('_', ' ').title():<20} {value}")
    
    print("\nAzure OpenAI:")
    for key, value in validation['azure_openai'].items():
        print(f"  {key.replace('_', ' ').title():<20} {value}")
    
    print("\nAzure APIM:")
    for key, value in validation['azure_apim'].items():
        print(f"  {key.replace('_', ' ').title():<20} {value}")
    
    print("\nAzure Storage:")
    for key, value in validation['azure_storage'].items():
        print(f"  {key.replace('_', ' ').title():<20} {value}")
    
    print("\nSSL Configuration:")
    for key, value in validation['ssl'].items():
        print(f"  {key.replace('_', ' ').title():<20} {value}")
    
    print("\nCache Configuration:")
    for key, value in validation['cache'].items():
        print(f"  {key.replace('_', ' ').title():<20} {value}")
    
    if 'production_errors' in validation and validation['production_errors']:
        print(f"\n⚠️  PRODUCTION ERRORS:")
        for error in validation['production_errors']:
            print(f"   {error}")
    
    print("\n" + "="*70 + "\n")


__all__ = [
    'BaseConfig',
    'DevelopmentConfig',
    'ProductionConfig',
    'TestingConfig',
    'CONFIG_MAP',
    'get_config',
    'validate_all_configurations',
    'get_missing_configurations',
    'print_config_status',
]