"""
Files Service - Core file management business logic
File: services/files_service.py

Handles:
- File listing and searching
- File information retrieval
- File downloads
- File deletion
- File validation
- Batch operations
- Metadata management
"""

import logging
import os
import json
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
import traceback
from pathlib import Path

logger = logging.getLogger(__name__)


class FilesService:
    """
    Central service for all file management operations
    
    Features:
    - File listing with filtering
    - File search with pattern matching
    - File information retrieval
    - File downloads
    - File deletion
    - File validation (OpenAPI, JSON, YAML)
    - Batch operations
    - Metadata management
    - Azure Blob Storage + local fallback
    
    Usage:
    ```python
    files_service = FilesService()
    
    # List files
    files = files_service.list_files('uploaded')
    
    # Get file info
    info = files_service.get_file_info('myfile.json', 'uploaded')
    
    # Search files
    results = files_service.search_files('query', 'all')
    
    # Download file
    content = files_service.download_file('myfile.json', 'uploaded')
    
    # Delete file
    result = files_service.delete_file('myfile.json', 'uploaded')
    
    # Validate file
    validation = files_service.validate_file('myfile.json')
    ```
    """
    
    def __init__(self):
        """Initialize files service"""
        try:
            # Import file handler (will be initialized when first used)
            from utils.enhanced_file_handler_with_azure import EnhancedFileHandler
            self.file_handler = EnhancedFileHandler()
            logger.info("✅ FilesService initialized")
        except Exception as e:
            logger.error(f"Failed to initialize FilesService: {e}")
            raise
    
    # ==========================================
    # FILE LISTING
    # ==========================================
    
    def list_files(self, folder_type: str = 'all') -> Dict[str, Any]:
        """
        List all files with optional filtering by folder type
        
        Args:
            folder_type: 'uploaded' | 'converted' | 'all' (default: 'all')
        
        Returns:
        {
            'success': bool,
            'files': list,
            'folder_type': str,
            'count': int,
            'total_size_mb': float,
            'folders': dict (if 'all')
        }
        """
        try:
            logger.info(f"Listing files: {folder_type}")
            
            result = self.file_handler.list_files(folder_type)
            
            if result.get('success'):
                logger.info(f"✅ Listed files: {result.get('count', 0)} files")
                return result
            else:
                logger.warning(f"Failed to list files: {result.get('error')}")
                return result
        
        except Exception as e:
            logger.error(f"Failed to list files: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e),
                'files': [],
                'count': 0
            }
    
    # ==========================================
    # FILE INFORMATION
    # ==========================================
    
    def get_file_info(self, filename: str, folder_type: str = 'uploaded') -> Dict[str, Any]:
        """
        Get file information and content for preview
        
        Args:
            filename: Name of the file
            folder_type: 'uploaded' | 'converted'
        
        Returns:
        {
            'success': bool,
            'filename': str,
            'folder_type': str,
            'content': str,
            'content_type': str,
            'file_size': int,
            'parsed_content': dict,
            'storage_type': str
        }
        """
        try:
            logger.info(f"Getting file info: {filename} from {folder_type}")
            
            # Security check
            if not self._is_safe_filename(filename):
                logger.warning(f"Unsafe filename: {filename}")
                return {
                    'success': False,
                    'error': 'Invalid filename'
                }
            
            blob_path = None
            if self.file_handler.use_azure:
                blob_path = f"{folder_type}/{filename}"
            
            file_info = self.file_handler.get_file_info(
                filename,
                folder_type=folder_type,
                blob_path=blob_path
            )
            
            if file_info.get('success'):
                logger.info(f"✅ File info retrieved: {filename}")
                return {
                    'success': True,
                    'filename': file_info.get('filename'),
                    'folder_type': file_info.get('folder_type'),
                    'content': file_info.get('content', ''),
                    'content_type': file_info.get('content_type'),
                    'file_size': file_info.get('file_size', 0),
                    'parsed_content': file_info.get('parsed_content'),
                    'storage_type': file_info.get('storage_type', 'local')
                }
            else:
                logger.warning(f"File not found: {filename}")
                return {
                    'success': False,
                    'error': file_info.get('error', 'File not found')
                }
        
        except Exception as e:
            logger.error(f"Failed to get file info: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # FILE DOWNLOADS
    # ==========================================
    
    def download_file(self, filename: str, folder_type: str = 'uploaded') -> Dict[str, Any]:
        """
        Download file content
        
        Args:
            filename: Name of the file
            folder_type: 'uploaded' | 'converted'
        
        Returns:
        {
            'success': bool,
            'content': bytes,
            'mimetype': str,
            'filename': str
        }
        """
        try:
            logger.info(f"Downloading file: {filename} from {folder_type}")
            
            # Security check
            if not self._is_safe_filename(filename):
                logger.warning(f"Unsafe filename: {filename}")
                return {
                    'success': False,
                    'error': 'Invalid filename'
                }
            
            # Determine mimetype
            mimetype = self._get_mimetype(filename)
            
            if self.file_handler.use_azure:
                blob_path = f"{folder_type}/{filename}"
                result = self.file_handler.azure_storage.download_file(blob_path)
                
                if result.get('success'):
                    logger.info(f"✅ File downloaded from Azure: {filename}")
                    return {
                        'success': True,
                        'content': result.get('content'),
                        'mimetype': mimetype,
                        'filename': filename
                    }
                else:
                    logger.warning(f"Failed to download from Azure: {filename}")
                    return {
                        'success': False,
                        'error': result.get('error', 'Download failed')
                    }
            else:
                # Local filesystem
                if folder_type == 'uploaded':
                    file_path = os.path.join(self.file_handler.upload_folder, filename)
                elif folder_type == 'converted':
                    file_path = os.path.join(self.file_handler.converted_folder, filename)
                else:
                    return {
                        'success': False,
                        'error': 'Invalid folder type'
                    }
                
                if not os.path.exists(file_path):
                    logger.warning(f"File not found: {file_path}")
                    return {
                        'success': False,
                        'error': 'File not found'
                    }
                
                try:
                    with open(file_path, 'rb') as f:
                        content = f.read()
                    
                    logger.info(f"✅ File downloaded from local: {filename}")
                    return {
                        'success': True,
                        'content': content,
                        'mimetype': mimetype,
                        'filename': filename
                    }
                except Exception as read_error:
                    logger.error(f"Failed to read file: {read_error}")
                    return {
                        'success': False,
                        'error': str(read_error)
                    }
        
        except Exception as e:
            logger.error(f"Failed to download file: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # FILE DELETION
    # ==========================================
    
    def delete_file(self, filename: str, folder_type: str = 'uploaded') -> Dict[str, Any]:
        """
        Delete a file
        
        Args:
            filename: Name of the file
            folder_type: 'uploaded' | 'converted'
        
        Returns:
        {
            'success': bool,
            'message': str,
            'filename': str,
            'folder_type': str
        }
        """
        try:
            logger.info(f"Deleting file: {filename} from {folder_type}")
            
            # Security check
            if not self._is_safe_filename(filename):
                logger.warning(f"Unsafe filename: {filename}")
                return {
                    'success': False,
                    'error': 'Invalid filename'
                }
            
            blob_path = None
            if self.file_handler.use_azure:
                blob_path = f"{folder_type}/{filename}"
            
            result = self.file_handler.delete_file(filename, folder_type, blob_path)
            
            if result.get('success'):
                logger.info(f"✅ File deleted: {filename}")
                return {
                    'success': True,
                    'message': f'File deleted successfully',
                    'filename': filename,
                    'folder_type': folder_type
                }
            else:
                logger.warning(f"Failed to delete file: {filename}")
                return result
        
        except Exception as e:
            logger.error(f"Failed to delete file: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # FILE SEARCH
    # ==========================================
    
    def search_files(self, query: str, folder_type: str = 'all', file_type: str = '') -> Dict[str, Any]:
        """
        Search for files by name or type
        
        Args:
            query: Search query (filename pattern)
            folder_type: 'uploaded' | 'converted' | 'all'
            file_type: Filter by extension (e.g., 'json', 'yaml')
        
        Returns:
        {
            'success': bool,
            'results': list,
            'count': int,
            'query': str,
            'folder_type': str
        }
        """
        try:
            logger.info(f"Searching files: query='{query}', folder='{folder_type}'")
            
            # Get files to search
            files_result = self.list_files(folder_type)
            if not files_result.get('success'):
                return files_result
            
            all_files = files_result.get('files', [])
            
            # Filter by query
            results = []
            query_lower = query.lower()
            
            for file_entry in all_files:
                filename = file_entry.get('name', '').lower()
                
                # Check filename match
                if query_lower in filename:
                    # Filter by file type if specified
                    if file_type:
                        if filename.endswith(f'.{file_type}') or filename.endswith(f'.{file_type.lower()}'):
                            results.append(file_entry)
                    else:
                        results.append(file_entry)
            
            logger.info(f"✅ Found {len(results)} files matching query")
            return {
                'success': True,
                'results': results,
                'count': len(results),
                'query': query,
                'folder_type': folder_type
            }
        
        except Exception as e:
            logger.error(f"Failed to search files: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e),
                'results': [],
                'count': 0
            }
    
    # ==========================================
    # FILE VALIDATION
    # ==========================================
    
    def validate_file(self, filename: str) -> Dict[str, Any]:
        """
        Validate file content (OpenAPI spec, JSON, YAML, etc.)
        
        Args:
            filename: Name of the file to validate
        
        Returns:
        {
            'success': bool,
            'is_valid': bool,
            'file_type': str,
            'issues': list,
            'warnings': list,
            'details': dict
        }
        """
        try:
            logger.info(f"Validating file: {filename}")
            
            # Security check
            if not self._is_safe_filename(filename):
                logger.warning(f"Unsafe filename: {filename}")
                return {
                    'success': False,
                    'error': 'Invalid filename'
                }
            
            # Get file content
            file_info = self.get_file_info(filename, 'uploaded')
            if not file_info.get('success'):
                logger.warning(f"Could not read file for validation: {filename}")
                return {
                    'success': False,
                    'error': 'Could not read file'
                }
            
            content = file_info.get('content', '')
            issues = []
            warnings = []
            
            # Try to parse as JSON
            parsed_content = None
            file_type = 'unknown'
            
            try:
                parsed_content = json.loads(content)
                file_type = 'json'
                
                # Check if it's an OpenAPI spec
                if isinstance(parsed_content, dict):
                    if 'openapi' in parsed_content or 'swagger' in parsed_content:
                        file_type = 'openapi'
                        
                        # Validate OpenAPI structure
                        validation_issues = self._validate_openapi_spec(parsed_content)
                        issues.extend(validation_issues)
                        
                        if not issues:
                            logger.info(f"✅ Valid OpenAPI spec: {filename}")
                        else:
                            logger.warning(f"OpenAPI spec has issues: {filename}")
                    else:
                        file_type = 'json'
                        logger.info(f"✅ Valid JSON: {filename}")
            
            except json.JSONDecodeError as json_error:
                # Try YAML
                try:
                    import yaml
                    parsed_content = yaml.safe_load(content)
                    file_type = 'yaml'
                    
                    if isinstance(parsed_content, dict):
                        if 'openapi' in parsed_content or 'swagger' in parsed_content:
                            file_type = 'openapi-yaml'
                            validation_issues = self._validate_openapi_spec(parsed_content)
                            issues.extend(validation_issues)
                    
                    logger.info(f"✅ Valid YAML: {filename}")
                
                except Exception as yaml_error:
                    logger.warning(f"Not valid JSON or YAML: {filename}")
                    file_type = 'text'
                    issues.append(f"Could not parse as JSON or YAML: {str(json_error)[:100]}")
            
            # Determine if valid
            is_valid = len(issues) == 0
            
            logger.info(f"✅ File validation complete: {filename} (valid={is_valid})")
            
            return {
                'success': True,
                'is_valid': is_valid,
                'file_type': file_type,
                'issues': issues,
                'warnings': warnings,
                'details': {
                    'filename': filename,
                    'file_size': file_info.get('file_size', 0),
                    'parsed_successfully': parsed_content is not None
                }
            }
        
        except Exception as e:
            logger.error(f"Failed to validate file: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # BATCH OPERATIONS
    # ==========================================
    
    def batch_delete_files(self, filenames: List[str], folder_type: str = 'uploaded') -> Dict[str, Any]:
        """
        Delete multiple files at once
        
        Args:
            filenames: List of filenames to delete
            folder_type: 'uploaded' | 'converted'
        
        Returns:
        {
            'success': bool,
            'deleted': int,
            'failed': int,
            'errors': list
        }
        """
        try:
            logger.info(f"Batch deleting {len(filenames)} files from {folder_type}")
            
            deleted = 0
            failed = 0
            errors = []
            
            for filename in filenames:
                try:
                    result = self.delete_file(filename, folder_type)
                    if result.get('success'):
                        deleted += 1
                    else:
                        failed += 1
                        errors.append({
                            'filename': filename,
                            'error': result.get('error', 'Unknown error')
                        })
                
                except Exception as e:
                    failed += 1
                    errors.append({
                        'filename': filename,
                        'error': str(e)
                    })
            
            logger.info(f"✅ Batch delete complete: {deleted} deleted, {failed} failed")
            
            return {
                'success': True,
                'deleted': deleted,
                'failed': failed,
                'errors': errors
            }
        
        except Exception as e:
            logger.error(f"Failed to batch delete files: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e),
                'deleted': 0,
                'failed': len(filenames),
                'errors': []
            }
    
    # ==========================================
    # FILE DETAILS/METADATA
    # ==========================================
    
    def get_file_details(self, filename: str) -> Dict[str, Any]:
        """
        Get detailed file information including metadata
        
        Args:
            filename: Name of the file
        
        Returns:
        {
            'success': bool,
            'filename': str,
            'file_size': int,
            'file_size_formatted': str,
            'created_at': str,
            'modified_at': str,
            'content_type': str,
            'storage_type': str,
            'metadata': dict,
            'folder_type': str
        }
        """
        try:
            logger.info(f"Getting file details: {filename}")
            
            # Security check
            if not self._is_safe_filename(filename):
                logger.warning(f"Unsafe filename: {filename}")
                return {
                    'success': False,
                    'error': 'Invalid filename'
                }
            
            # Try to find file (search in both folders)
            uploaded_info = self.get_file_info(filename, 'uploaded')
            if uploaded_info.get('success'):
                folder_type = 'uploaded'
                file_info = uploaded_info
            else:
                converted_info = self.get_file_info(filename, 'converted')
                if converted_info.get('success'):
                    folder_type = 'converted'
                    file_info = converted_info
                else:
                    logger.warning(f"File not found: {filename}")
                    return {
                        'success': False,
                        'error': 'File not found'
                    }
            
            # Get current time for metadata
            now = datetime.now()
            
            file_size = file_info.get('file_size', 0)
            file_size_formatted = self._format_file_size(file_size)
            
            logger.info(f"✅ File details retrieved: {filename}")
            
            return {
                'success': True,
                'filename': filename,
                'file_size': file_size,
                'file_size_formatted': file_size_formatted,
                'created_at': now.isoformat(),
                'modified_at': now.isoformat(),
                'content_type': file_info.get('content_type', 'application/octet-stream'),
                'storage_type': file_info.get('storage_type', 'local'),
                'metadata': self._extract_metadata(file_info),
                'folder_type': folder_type
            }
        
        except Exception as e:
            logger.error(f"Failed to get file details: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # HELPER METHODS
    # ==========================================
    
    def _is_safe_filename(self, filename: str) -> bool:
        """
        Check if filename is safe (prevent directory traversal)
        
        Args:
            filename: Filename to check
        
        Returns:
            True if safe, False otherwise
        """
        if not filename:
            return False
        
        if '..' in filename or '/' in filename or '\\' in filename:
            return False
        
        return True
    
    def _get_mimetype(self, filename: str) -> str:
        """
        Get MIME type based on file extension
        
        Args:
            filename: Name of the file
        
        Returns:
            MIME type string
        """
        extension = os.path.splitext(filename)[1].lower()
        
        mime_types = {
            '.json': 'application/json',
            '.yaml': 'application/yaml',
            '.yml': 'application/yaml',
            '.xml': 'application/xml',
            '.txt': 'text/plain',
            '.pdf': 'application/pdf',
            '.csv': 'text/csv',
            '.html': 'text/html',
            '.js': 'application/javascript',
            '.py': 'text/plain',
        }
        
        return mime_types.get(extension, 'application/octet-stream')
    
    def _format_file_size(self, bytes_size: int) -> str:
        """
        Format file size in human readable format
        
        Args:
            bytes_size: Size in bytes
        
        Returns:
            Formatted size string
        """
        if bytes_size == 0:
            return '0 B'
        
        k = 1024
        sizes = ['B', 'KB', 'MB', 'GB']
        i = 0
        
        while bytes_size >= k and i < len(sizes) - 1:
            bytes_size /= k
            i += 1
        
        return f"{bytes_size:.1f} {sizes[i]}"
    
    def _extract_metadata(self, file_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract metadata from file info
        
        Args:
            file_info: File information dictionary
        
        Returns:
            Metadata dictionary
        """
        try:
            metadata = {}
            
            # Parse content if available
            parsed_content = file_info.get('parsed_content')
            if parsed_content and isinstance(parsed_content, dict):
                if 'info' in parsed_content:
                    info = parsed_content['info']
                    metadata['title'] = info.get('title', 'Unknown')
                    metadata['version'] = info.get('version', '1.0.0')
                    metadata['description'] = info.get('description', '')
                
                if 'openapi' in parsed_content:
                    metadata['spec_type'] = 'OpenAPI'
                    metadata['spec_version'] = parsed_content['openapi']
                elif 'swagger' in parsed_content:
                    metadata['spec_type'] = 'Swagger'
                    metadata['spec_version'] = parsed_content['swagger']
                
                # Count paths and operations
                if 'paths' in parsed_content:
                    metadata['paths_count'] = len(parsed_content['paths'])
                    
                    operations = 0
                    for path_item in parsed_content['paths'].values():
                        if isinstance(path_item, dict):
                            for method in ['get', 'post', 'put', 'delete', 'patch', 'head', 'options']:
                                if method in path_item:
                                    operations += 1
                    
                    metadata['operations_count'] = operations
            
            return metadata
        
        except Exception as e:
            logger.warning(f"Failed to extract metadata: {e}")
            return {}
    
    def _validate_openapi_spec(self, spec: dict) -> List[str]:
        """
        Validate OpenAPI specification
        
        Args:
            spec: OpenAPI specification dictionary
        
        Returns:
            List of validation issues (empty if valid)
        """
        issues = []
        
        try:
            # Check required fields
            required_fields = ['info', 'paths']
            for field in required_fields:
                if field not in spec:
                    issues.append(f"Missing required field: {field}")
            
            # Check info fields
            if 'info' in spec:
                info = spec['info']
                if 'title' not in info:
                    issues.append("Missing info.title")
                if 'version' not in info:
                    issues.append("Missing info.version")
            
            # Check paths
            if 'paths' in spec:
                paths = spec['paths']
                if not isinstance(paths, dict):
                    issues.append("paths must be an object")
                elif len(paths) == 0:
                    issues.append("paths must have at least one path")
            
            # Check servers (optional but if present, should be valid)
            if 'servers' in spec:
                servers = spec['servers']
                if not isinstance(servers, list):
                    issues.append("servers must be an array")
        
        except Exception as e:
            logger.warning(f"Error validating OpenAPI spec: {e}")
            issues.append(f"Validation error: {str(e)[:100]}")
        
        return issues