"""
Chat Service - Core chat business logic
File: services/chat_service.py

Handles:
- Message processing
- Azure OpenAI integration
- Response generation
- Conversation management
- Fallback handling
"""

import logging
from datetime import datetime
from typing import Dict, Any, Optional, Tuple
import traceback

try:
    from enhanced_prompts import (
        UniversalPromptBuilder,
        ASSISTANT_TYPES,
        detect_assistant_type
    )
    PROMPTS_AVAILABLE = True
except ImportError:
    PROMPTS_AVAILABLE = False

from connectors import AzureOpenAIConnector


logger = logging.getLogger(__name__)


class ChatService:
    """
    Central service for all chat operations
    
    Usage:
    ```python
    chat_service = ChatService()
    
    response = chat_service.process_message(
        user_message="Generate Python code",
        file_content=None,
        assistant_type_override='code',
        conversation_id='conv_123'
    )
    ```
    """
    
    def __init__(self):
        """Initialize chat service"""
        self.openai_connector = AzureOpenAIConnector()
        self.conversation_cache = {}  # In-memory cache, can be replaced with Redis
        logger.info("✅ ChatService initialized")
    
    # ==========================================
    # MAIN ENTRY POINT
    # ==========================================
    
    def process_message(
        self,
        user_message: str,
        file_content: Optional[str] = None,
        file_info: Optional[Dict] = None,
        assistant_type_override: Optional[str] = None,
        conversation_id: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process a user message and generate response
        
        Args:
            user_message: The user's input text
            file_content: Uploaded file content (if any)
            file_info: Metadata about the file
            assistant_type_override: Force specific assistant type
            conversation_id: For tracking conversation thread
            user_id: User identifier for multi-user support
        
        Returns:
            {
                'success': bool,
                'response': str,
                'assistant_type': str,
                'confidence': float,
                'metadata': dict,
                'suggestions': list,
                'error': str (if failed)
            }
        """
        
        try:
            logger.info("=" * 70)
            logger.info("🤖 PROCESSING MESSAGE")
            logger.info(f"Message length: {len(user_message)} chars")
            
            # ==========================================
            # INPUT VALIDATION
            # ==========================================
            
            if not user_message and not file_content:
                return {
                    'success': False,
                    'error': 'Please provide a message or attach a file',
                    'response': None
                }
            
            # ==========================================
            # DETECT ASSISTANT TYPE
            # ==========================================
            
            assistant_type, confidence = self._detect_assistant_type(
                user_message,
                file_info,
                assistant_type_override
            )
            
            logger.info(f"🔍 Assistant: {assistant_type} ({confidence:.0%})")
            
            # ==========================================
            # GENERATE RESPONSE
            # ==========================================
            
            response_result = self._generate_response(
                user_message=user_message,
                file_content=file_content,
                file_info=file_info,
                assistant_type=assistant_type
            )
            
            if not response_result['success']:
                logger.error(f"Response generation failed: {response_result['error']}")
                return response_result
            
            logger.info(f"✅ Response generated ({len(response_result['response'])} chars)")
            logger.info("=" * 70)
            
            return {
                'success': True,
                'response': response_result['response'],
                'assistant_type': assistant_type,
                'confidence': confidence,
                'metadata': response_result.get('metadata', {}),
                'suggestions': self._generate_suggestions(user_message, assistant_type),
                'tokens_used': response_result.get('tokens_used', 0)
            }
        
        except Exception as e:
            logger.error(f"Message processing failed: {e}", exc_info=True)
            
            # Return error but don't crash
            return {
                'success': False,
                'error': f'Processing failed: {str(e)[:100]}',
                'response': None,
                'error_type': type(e).__name__
            }
    
    # ==========================================
    # ASSISTANT TYPE DETECTION
    # ==========================================
    
    def _detect_assistant_type(
        self,
        message: str,
        file_info: Optional[Dict],
        override: Optional[str]
    ) -> Tuple[str, float]:
        """
        Detect which assistant type to use
        
        Returns:
            (assistant_type: str, confidence: float)
        """
        
        # Use override if provided and valid
        if override and override in ASSISTANT_TYPES:
            logger.info(f"Using override: {override}")
            return override, 1.0
        
        # Auto-detect from message + file
        if PROMPTS_AVAILABLE:
            try:
                combined_input = message
                if file_info:
                    combined_input += f"\n\nFile: {file_info.get('detected_purpose', 'unknown')}"
                
                assistant_type, confidence, reason = detect_assistant_type(combined_input, file_info)
                logger.info(f"Auto-detected: {assistant_type} - {reason}")
                return assistant_type, confidence
            
            except Exception as e:
                logger.warning(f"Auto-detection failed: {e}, using general")
                return 'general', 0.5
        
        # Fallback: simple keyword detection
        message_lower = message.lower()
        
        if any(word in message_lower for word in ['code', 'function', 'class', 'def', 'implement']):
            return 'code', 0.7
        elif any(word in message_lower for word in ['review', 'check', 'optimize', 'bug']):
            return 'code_review', 0.7
        elif any(word in message_lower for word in ['api', 'endpoint', 'rest', 'route']):
            return 'api_design', 0.7
        elif any(word in message_lower for word in ['policy', 'security', 'compliance', 'requirement']):
            return 'policy', 0.7
        elif any(word in message_lower for word in ['document', 'guide', 'readme', 'how to']):
            return 'documentation', 0.7
        
        return 'general', 0.5
    
    # ==========================================
    # RESPONSE GENERATION
    # ==========================================
    
    def _generate_response(
        self,
        user_message: str,
        file_content: Optional[str],
        file_info: Optional[Dict],
        assistant_type: str
    ) -> Dict[str, Any]:
        """
        Generate response using Azure OpenAI
        
        Returns:
            {
                'success': bool,
                'response': str,
                'metadata': dict,
                'tokens_used': int,
                'error': str (if failed)
            }
        """
        
        try:
            # Build system and user prompts
            system_prompt = self._build_system_prompt(assistant_type)
            user_prompt = self._build_user_prompt(
                user_message,
                file_content,
                file_info,
                assistant_type
            )
            
            logger.info(f"Prompts built - System: {len(system_prompt)} chars, User: {len(user_prompt)} chars")
            
            # ==========================================
            # CALL AZURE OPENAI
            # ==========================================
            
            if not self.openai_connector.is_available:
                logger.warning("Azure OpenAI unavailable - using fallback")
                
                fallback = self._generate_fallback_response(
                    user_message,
                    assistant_type,
                    file_info
                )
                
                return {
                    'success': True,
                    'response': fallback,
                    'metadata': {'fallback': True},
                    'tokens_used': 0
                }
            
            logger.info("Calling Azure OpenAI...")
            
            try:
                # Build model-aware parameters
                params = self.openai_connector._build_chat_completion_params(
                    deployment=self.openai_connector.config.OPENAI_DEPLOYMENT,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    temperature=ASSISTANT_TYPES[assistant_type].get('temperature', 0.7),
                    max_tokens=ASSISTANT_TYPES[assistant_type].get('max_tokens', 2000)
                )
                
                # Make API call
                response = self.openai_connector._client.chat.completions.create(**params)
                response_text = response.choices[0].message.content
                
                # Validation: Check for empty response
                if not response_text or len(response_text.strip()) == 0:
                    logger.warning("Azure OpenAI returned empty response")
                    fallback = self._generate_fallback_response(
                        user_message,
                        assistant_type,
                        file_info
                    )
                    
                    return {
                        'success': True,
                        'response': fallback,
                        'metadata': {'fallback': True, 'reason': 'empty_response'},
                        'tokens_used': 0
                    }
                
                logger.info(f"✅ Response received ({len(response_text)} chars)")
                
                # Extract usage info if available
                tokens_used = 0
                if hasattr(response, 'usage'):
                    tokens_used = response.usage.total_tokens
                    logger.info(f"Tokens used: {tokens_used}")
                
                # Post-process response
                response_text = self._post_process_response(response_text, assistant_type)
                
                metadata = self._extract_metadata(response_text, assistant_type)
                
                return {
                    'success': True,
                    'response': response_text,
                    'metadata': metadata,
                    'tokens_used': tokens_used
                }
            
            except Exception as openai_error:
                logger.error(f"OpenAI API call failed: {openai_error}", exc_info=True)
                
                fallback = self._generate_fallback_response(
                    user_message,
                    assistant_type,
                    file_info
                )
                
                return {
                    'success': True,
                    'response': fallback,
                    'metadata': {'fallback': True, 'error': str(openai_error)},
                    'tokens_used': 0
                }
        
        except Exception as e:
            logger.error(f"Response generation error: {e}", exc_info=True)
            
            error_msg = f"""I encountered an error while processing your request: {str(e)[:100]}

Please try:
1. Simplifying your request
2. Providing a valid file format
3. Checking your input

The system is still available - feel free to try again."""
            
            return {
                'success': True,
                'response': error_msg,
                'metadata': {'error': True, 'error_type': type(e).__name__},
                'tokens_used': 0
            }
    
    # ==========================================
    # PROMPT BUILDERS
    # ==========================================
    
    def _build_system_prompt(self, assistant_type: str) -> str:
        """Build system prompt for assistant type"""
        
        if not PROMPTS_AVAILABLE:
            return ASSISTANT_TYPES.get(assistant_type, {}).get('system_prompt', 'You are a helpful assistant.')
        
        try:
            config = ASSISTANT_TYPES.get(assistant_type, {})
            return config.get('system_prompt', 'You are a helpful assistant.')
        
        except Exception as e:
            logger.warning(f"Failed to build system prompt: {e}")
            return 'You are a helpful assistant.'
    
    def _build_user_prompt(
        self,
        message: str,
        file_content: Optional[str],
        file_info: Optional[Dict],
        assistant_type: str
    ) -> str:
        """Build user prompt based on assistant type"""
        
        prompt = message
        
        if file_content:
            # Add file content with context
            file_context = f"\n\n**File Information:**\n"
            
            if file_info:
                file_context += f"- Name: {file_info.get('filename', 'unknown')}\n"
                file_context += f"- Type: {file_info.get('detected_purpose', 'unknown')}\n"
                file_context += f"- Size: {file_info.get('size_formatted', 'unknown')}\n"
            
            file_context += f"\n**File Content:**\n```\n{file_content[:2000]}\n```\n"
            
            prompt += file_context
        
        return prompt
    
    # ==========================================
    # POST-PROCESSING
    # ==========================================
    
    def _post_process_response(self, response: str, assistant_type: str) -> str:
        """Post-process response for better formatting"""
        
        # Ensure code blocks have language specifiers
        if assistant_type in ['code', 'code_review']:
            import re
            pattern = r'```\n((?!```)[^`]*?)```'
            
            def add_language(match):
                code = match.group(1)
                if 'import ' in code or 'from ' in code:
                    lang = 'python'
                elif 'const ' in code or 'function ' in code:
                    lang = 'javascript'
                elif 'public class' in code:
                    lang = 'java'
                else:
                    lang = 'plaintext'
                
                return f'```{lang}\n{code}```'
            
            response = re.sub(pattern, add_language, response)
        
        # Remove null bytes and whitespace issues
        response = response.replace('\x00', '').strip()
        
        # Ensure non-empty
        if len(response) == 0:
            response = "Response generated but appears empty. Please try again."
        
        return response
    
    def _extract_metadata(self, response: str, assistant_type: str) -> Dict[str, Any]:
        """Extract useful metadata from response"""
        
        metadata = {
            'assistant_type': assistant_type,
            'code_blocks': response.count('```'),
            'has_examples': 'example' in response.lower() or 'e.g.' in response.lower(),
            'has_warnings': '⚠️' in response or 'warning' in response.lower(),
            'sections': len([l for l in response.split('\n') if l.startswith('#')])
        }
        
        return metadata
    
    # ==========================================
    # FALLBACK RESPONSES
    # ==========================================
    
    def _generate_fallback_response(
        self,
        message: str,
        assistant_type: str,
        file_info: Optional[Dict]
    ) -> str:
        """Generate fallback response when Azure OpenAI unavailable"""
        
        file_context = ""
        if file_info:
            file_context = f"\n**File:** {file_info.get('filename')} ({file_info.get('detected_purpose')})"
        
        fallbacks = {
            'code': f"""# Code Generation (Fallback Mode)

Your request: {message[:80]}...
{file_context}

## Standard Template

```python
def main():
    '''Your implementation here'''
    result = process_data()
    return result

def process_data():
    '''Add your logic'''
    return []

if __name__ == "__main__":
    main()
```

**To enable AI:** Configure Azure OpenAI credentials and restart.
**In the meantime:** Use this template as a starting point.""",
            
            'code_review': f"""# Code Review (Fallback Mode)

Your code: {message[:80]}...
{file_context}

## Review Checklist

✅ **Logic** - Does the code do what's intended?
✅ **Performance** - Any unnecessary loops or operations?
✅ **Security** - Any vulnerabilities?
✅ **Style** - Follows conventions?
✅ **Tests** - Is it testable?

**To enable full AI review:** Configure Azure OpenAI.

**For now:** Use automated tools like pylint, eslint, SonarQube.""",
            
            'general': f"""# Assistant Response (Fallback Mode)

Your question: {message[:80]}...
{file_context}

I can help with:
✅ Technical explanations
✅ Code examples
✅ Best practices
✅ Architecture advice
✅ Documentation

**To enable AI:** Configure Azure OpenAI service.

**Available now:**
- File analysis
- Manual templates
- Pattern guidance
- Documentation help"""
        }
        
        return fallbacks.get(assistant_type, fallbacks['general'])
    
    # ==========================================
    # SUGGESTIONS & HELPERS
    # ==========================================
    
    def _generate_suggestions(self, message: str, assistant_type: str) -> list:
        """Generate follow-up suggestions"""
        
        suggestions = {
            'code': [
                "💾 Save this code",
                "🧪 Write unit tests",
                "🔍 Review for security"
            ],
            'code_review': [
                "✅ Apply fixes",
                "🧪 Run tests",
                "📊 Check coverage"
            ],
            'api_design': [
                "📝 Generate OpenAPI spec",
                "🧪 Design tests",
                "🔐 Security review"
            ],
            'policy': [
                "💻 Generate code",
                "✅ Create checklist",
                "📊 Risk assessment"
            ],
            'documentation': [
                "📄 Export as PDF",
                "💾 Save as markdown",
                "👥 Share with team"
            ],
            'general': [
                "📝 Get more details",
                "💾 Save response",
                "📊 See examples"
            ]
        }
        
        return suggestions.get(assistant_type, suggestions['general'])[:3]