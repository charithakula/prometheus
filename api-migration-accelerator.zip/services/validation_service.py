"""
Validation Service - FIXED VERSION
Handles validation of OpenAPI specifications with proper $ref support
"""
import json
import logging
from typing import Dict, Any, List, Optional, Union
import re
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

class ValidationService:
    """Service for validating OpenAPI specifications"""
    
    def __init__(self):
        """Initialize validation service"""
        self.openapi_2_required_fields = ['swagger', 'info', 'paths']
        self.openapi_3_required_fields = ['openapi', 'info', 'paths']
        self.info_required_fields = ['title', 'version']
    
    def validate_openapi_2(self, spec: Dict[str, Any], strict: bool = False) -> Dict[str, Any]:
        """
        Validate OpenAPI 2.0 specification
        
        Args:
            spec: Parsed OpenAPI specification
            strict: If True, apply strict validation. If False, be lenient with $refs
            
        Returns:
            Validation result with errors and warnings
        """
        errors = []
        warnings = []
        
        try:
            # Check required root fields
            for field in self.openapi_2_required_fields:
                if field not in spec:
                    errors.append(f"Missing required field: {field}")
            
            # Validate swagger version
            swagger_version = spec.get('swagger')
            if swagger_version:
                if not str(swagger_version).startswith('2.'):
                    errors.append(f"Invalid swagger version: {swagger_version}. Expected 2.x")
            
            # Validate info section
            info_validation = self._validate_info_section(spec.get('info', {}))
            errors.extend(info_validation['errors'])
            warnings.extend(info_validation['warnings'])
            
            # Validate paths
            paths_validation = self._validate_paths_section(spec.get('paths', {}), version='2.0', strict=strict)
            errors.extend(paths_validation['errors'])
            warnings.extend(paths_validation['warnings'])
            
            # Validate definitions
            if 'definitions' in spec:
                definitions_validation = self._validate_definitions_section(spec['definitions'])
                errors.extend(definitions_validation['errors'])
                warnings.extend(definitions_validation['warnings'])
            
            # Validate security definitions
            if 'securityDefinitions' in spec:
                security_validation = self._validate_security_definitions_2(spec['securityDefinitions'])
                errors.extend(security_validation['errors'])
                warnings.extend(security_validation['warnings'])
            
            # Validate parameters
            if 'parameters' in spec:
                params_validation = self._validate_global_parameters(spec['parameters'])
                errors.extend(params_validation['errors'])
                warnings.extend(params_validation['warnings'])
            
            # OpenAPI 2.0 specific validations
            self._validate_openapi_2_specific(spec, errors, warnings)
            
        except Exception as e:
            logger.error(f"Validation exception: {e}", exc_info=True)
            errors.append(f"Validation error: {str(e)}")
        
        return {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings,
            'version': '2.0',
            'summary': f"{len(errors)} errors, {len(warnings)} warnings"
        }
    
    def validate_openapi_3(self, spec: Dict[str, Any], strict: bool = False) -> Dict[str, Any]:
        """
        Validate OpenAPI 3.0 specification
        
        Args:
            spec: Parsed OpenAPI specification
            strict: If True, apply strict validation
            
        Returns:
            Validation result with errors and warnings
        """
        errors = []
        warnings = []
        
        try:
            # Check required root fields
            for field in self.openapi_3_required_fields:
                if field not in spec:
                    errors.append(f"Missing required field: {field}")
            
            # Validate openapi version
            openapi_version = spec.get('openapi')
            if openapi_version:
                if not str(openapi_version).startswith('3.'):
                    errors.append(f"Invalid openapi version: {openapi_version}. Expected 3.x")
            
            # Validate info section
            info_validation = self._validate_info_section(spec.get('info', {}))
            errors.extend(info_validation['errors'])
            warnings.extend(info_validation['warnings'])
            
            # Validate servers
            if 'servers' in spec:
                servers_validation = self._validate_servers_section(spec['servers'])
                errors.extend(servers_validation['errors'])
                warnings.extend(servers_validation['warnings'])
            else:
                warnings.append("No servers defined. API consumers may need to guess the server URL.")
            
            # Validate paths
            paths_validation = self._validate_paths_section(spec.get('paths', {}), version='3.0', strict=strict)
            errors.extend(paths_validation['errors'])
            warnings.extend(paths_validation['warnings'])
            
            # Validate components
            if 'components' in spec:
                components_validation = self._validate_components_section(spec['components'])
                errors.extend(components_validation['errors'])
                warnings.extend(components_validation['warnings'])
            
            # OpenAPI 3.0 specific validations
            self._validate_openapi_3_specific(spec, errors, warnings)
            
        except Exception as e:
            logger.error(f"Validation exception: {e}", exc_info=True)
            errors.append(f"Validation error: {str(e)}")
        
        return {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings,
            'version': '3.0',
            'summary': f"{len(errors)} errors, {len(warnings)} warnings"
        }
    
    def _validate_info_section(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """Validate info section"""
        errors = []
        warnings = []
        
        # Check required fields
        for field in self.info_required_fields:
            if field not in info:
                errors.append(f"Missing required field in info: {field}")
        
        # Validate version format
        version = info.get('version')
        if version and not re.match(r'^\d+\.\d+(\.\d+)?', str(version)):
            warnings.append(f"Version '{version}' does not follow semantic versioning")
        
        # Check for description
        if not info.get('description'):
            warnings.append("Info section missing description")
        
        # Validate contact info if present
        if 'contact' in info:
            contact = info['contact']
            if 'email' in contact:
                if not re.match(r'^[^@]+@[^@]+\.[^@]+$', contact['email']):
                    warnings.append(f"Invalid email format: {contact['email']}")
        
        # Validate license if present
        if 'license' in info:
            license_info = info['license']
            if 'name' not in license_info:
                errors.append("License object must have a 'name' field")
            if 'url' in license_info:
                if not self._is_valid_url(license_info['url']):
                    warnings.append(f"Invalid license URL: {license_info['url']}")
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_paths_section(self, paths: Dict[str, Any], version: str, strict: bool = False) -> Dict[str, Any]:
        """Validate paths section"""
        errors = []
        warnings = []
        
        if not paths:
            warnings.append("No paths defined in the API")
            return {'errors': errors, 'warnings': warnings}
        
        http_methods = ['get', 'post', 'put', 'delete', 'head', 'options', 'patch', 'trace']
        
        for path, path_item in paths.items():
            if not isinstance(path_item, dict):
                errors.append(f"Path '{path}' must be an object")
                continue
            
            # Validate path format
            if not path.startswith('/'):
                errors.append(f"Path '{path}' must start with '/'")
            
            # Check for path parameters format
            path_params = re.findall(r'\{([^}]+)\}', path)
            
            # Validate operations
            for method, operation in path_item.items():
                if method.lower() in http_methods:
                    op_validation = self._validate_operation(operation, method, path, path_params, version, strict)
                    errors.extend(op_validation['errors'])
                    warnings.extend(op_validation['warnings'])
                elif method not in ['$ref', 'summary', 'description', 'servers', 'parameters']:
                    warnings.append(f"Unknown field '{method}' in path '{path}'")
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_operation(self, operation: Dict[str, Any], method: str, path: str, 
                           path_params: List[str], version: str, strict: bool = False) -> Dict[str, Any]:
        """Validate individual operation - FIXED to handle $ref"""
        errors = []
        warnings = []
        
        if not isinstance(operation, dict):
            errors.append(f"Operation {method.upper()} {path} must be an object")
            return {'errors': errors, 'warnings': warnings}
        
        # Check for operation ID
        if 'operationId' not in operation:
            warnings.append(f"Missing operationId for {method.upper()} {path}")
        else:
            op_id = operation['operationId']
            if not re.match(r'^[a-zA-Z0-9_-]+$', str(op_id)):
                warnings.append(f"OperationId '{op_id}' contains invalid characters")
        
        # Validate responses
        if 'responses' not in operation:
            errors.append(f"Missing responses for {method.upper()} {path}")
        else:
            responses_validation = self._validate_responses(operation['responses'], version)
            errors.extend(responses_validation['errors'])
            warnings.extend(responses_validation['warnings'])
        
        # Validate parameters
        if 'parameters' in operation:
            params_validation = self._validate_operation_parameters(
                operation['parameters'], path_params, method, path, version, strict
            )
            errors.extend(params_validation['errors'])
            warnings.extend(params_validation['warnings'])
        
        # Check for missing path parameters - IMPROVED $ref handling
        if path_params and 'parameters' in operation:
            # Check if parameters use $ref
            has_refs = any(
                isinstance(p, dict) and '$ref' in p 
                for p in operation['parameters']
            )
            
            if has_refs and not strict:
                # Skip strict validation when $refs are present
                # Assume referenced parameters are correctly defined
                logger.debug(f"Skipping strict parameter validation for {method.upper()} {path} (contains $refs)")
            else:
                # Validate inline parameters
                path_param_names = []
                for p in operation['parameters']:
                    if isinstance(p, dict):
                        if '$ref' not in p and p.get('in') == 'path':
                            path_param_names.append(p.get('name'))
                
                # Only check if we have inline path parameters
                if path_param_names:
                    for param_name in path_params:
                        if param_name not in path_param_names:
                            errors.append(f"Path parameter '{param_name}' not defined in {method.upper()} {path}")
        
        # Version-specific validations
        if version == '3.0':
            if 'requestBody' in operation:
                rb_validation = self._validate_request_body(operation['requestBody'])
                errors.extend(rb_validation['errors'])
                warnings.extend(rb_validation['warnings'])
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_responses(self, responses: Dict[str, Any], version: str) -> Dict[str, Any]:
        """Validate responses section"""
        errors = []
        warnings = []
        
        if not responses:
            errors.append("Responses section cannot be empty")
            return {'errors': errors, 'warnings': warnings}
        
        # Check for default or success response
        has_success = any(code.startswith('2') for code in responses.keys() if isinstance(code, str))
        has_default = 'default' in responses
        
        if not has_success and not has_default:
            warnings.append("No success response (2xx) or default response defined")
        
        for code, response in responses.items():
            # Handle $ref in responses
            if isinstance(response, dict) and '$ref' in response:
                continue
            
            if not isinstance(response, dict):
                errors.append(f"Response {code} must be an object")
                continue
            
            # Validate status code
            if code != 'default':
                if not re.match(r'^\d{3}$', str(code)):
                    errors.append(f"Invalid response code: {code}")
                elif int(code) < 100 or int(code) >= 600:
                    errors.append(f"Response code out of range: {code}")
            
            # Check required description
            if 'description' not in response:
                errors.append(f"Missing description for response {code}")
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_operation_parameters(self, parameters: List[Dict[str, Any]], path_params: List[str],
                                     method: str, path: str, version: str, strict: bool = False) -> Dict[str, Any]:
        """Validate operation parameters - IMPROVED $ref handling"""
        errors = []
        warnings = []
        
        if not isinstance(parameters, list):
            errors.append("Parameters must be an array")
            return {'errors': errors, 'warnings': warnings}
        
        param_names_by_location = {}
        
        for param in parameters:
            # Handle $ref parameters
            if isinstance(param, dict) and '$ref' in param:
                # Skip validation for referenced parameters
                logger.debug(f"Skipping validation for $ref parameter: {param['$ref']}")
                continue
            
            if not isinstance(param, dict):
                errors.append("Parameter must be an object")
                continue
            
            # Check required fields
            if 'name' not in param:
                errors.append("Parameter missing 'name' field")
                continue
            if 'in' not in param:
                errors.append(f"Parameter '{param['name']}' missing 'in' field")
                continue
            
            param_name = param['name']
            param_location = param['in']
            
            # Check for duplicate parameters
            if param_location not in param_names_by_location:
                param_names_by_location[param_location] = set()
            
            if param_name in param_names_by_location[param_location]:
                errors.append(f"Duplicate parameter '{param_name}' in '{param_location}'")
            else:
                param_names_by_location[param_location].add(param_name)
            
            # Validate parameter location
            valid_locations = ['query', 'header', 'path', 'cookie'] if version == '3.0' else ['query', 'header', 'path', 'formData', 'body']
            if param_location not in valid_locations:
                errors.append(f"Invalid parameter location: {param_location}")
            
            # Path parameters must be required
            if param_location == 'path' and not param.get('required', False):
                errors.append(f"Path parameter '{param_name}' must be required")
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_definitions_section(self, definitions: Dict[str, Any]) -> Dict[str, Any]:
        """Validate definitions section (OpenAPI 2.0)"""
        errors = []
        warnings = []
        
        for name, schema in definitions.items():
            if not isinstance(schema, dict):
                errors.append(f"Definition '{name}' must be an object")
                continue
            
            schema_validation = self._validate_schema(schema, f"definition '{name}'")
            errors.extend(schema_validation['errors'])
            warnings.extend(schema_validation['warnings'])
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_components_section(self, components: Dict[str, Any]) -> Dict[str, Any]:
        """Validate components section (OpenAPI 3.0)"""
        errors = []
        warnings = []
        
        # Validate schemas
        if 'schemas' in components:
            for name, schema in components['schemas'].items():
                if not isinstance(schema, dict):
                    errors.append(f"Schema '{name}' must be an object")
                    continue
                
                schema_validation = self._validate_schema(schema, f"schema '{name}'")
                errors.extend(schema_validation['errors'])
                warnings.extend(schema_validation['warnings'])
        
        # Validate security schemes
        if 'securitySchemes' in components:
            security_validation = self._validate_security_schemes_3(components['securitySchemes'])
            errors.extend(security_validation['errors'])
            warnings.extend(security_validation['warnings'])
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_schema(self, schema: Dict[str, Any], context: str) -> Dict[str, Any]:
        """Validate JSON schema"""
        errors = []
        warnings = []
        
        # Skip validation for $ref schemas
        if '$ref' in schema:
            return {'errors': errors, 'warnings': warnings}
        
        # Basic schema validation
        if 'type' in schema:
            schema_type = schema['type']
            if schema_type not in ['null', 'boolean', 'object', 'array', 'number', 'string', 'integer']:
                errors.append(f"Invalid schema type '{schema_type}' in {context}")
            
            # Type-specific validations
            if schema_type == 'array' and 'items' not in schema:
                errors.append(f"Array schema missing 'items' property in {context}")
            
            if schema_type == 'object' and 'properties' not in schema and 'additionalProperties' not in schema:
                warnings.append(f"Object schema without properties or additionalProperties in {context}")
        
        # Validate required fields
        if 'required' in schema:
            if not isinstance(schema['required'], list):
                errors.append(f"'required' must be an array in {context}")
            elif 'properties' in schema:
                for required_field in schema['required']:
                    if required_field not in schema['properties']:
                        errors.append(f"Required field '{required_field}' not in properties of {context}")
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_servers_section(self, servers: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Validate servers section (OpenAPI 3.0)"""
        errors = []
        warnings = []
        
        if not isinstance(servers, list):
            errors.append("Servers must be an array")
            return {'errors': errors, 'warnings': warnings}
        
        if not servers:
            warnings.append("Empty servers array")
            return {'errors': errors, 'warnings': warnings}
        
        for i, server in enumerate(servers):
            if not isinstance(server, dict):
                errors.append(f"Server {i} must be an object")
                continue
            
            if 'url' not in server:
                errors.append(f"Server {i} missing 'url' field")
                continue
            
            server_url = server['url']
            
            # Basic URL validation
            if not server_url:
                errors.append(f"Server {i} has empty URL")
            elif not (server_url.startswith('http') or server_url.startswith('/') or '{' in server_url):
                warnings.append(f"Server {i} URL might be invalid: {server_url}")
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_security_definitions_2(self, security_defs: Dict[str, Any]) -> Dict[str, Any]:
        """Validate securityDefinitions (OpenAPI 2.0)"""
        errors = []
        warnings = []
        
        for name, security_def in security_defs.items():
            if not isinstance(security_def, dict):
                errors.append(f"Security definition '{name}' must be an object")
                continue
            
            if 'type' not in security_def:
                errors.append(f"Security definition '{name}' missing 'type' field")
                continue
            
            sec_type = security_def['type']
            if sec_type not in ['basic', 'apiKey', 'oauth2']:
                errors.append(f"Invalid security type '{sec_type}' in '{name}'")
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_security_schemes_3(self, security_schemes: Dict[str, Any]) -> Dict[str, Any]:
        """Validate securitySchemes (OpenAPI 3.0)"""
        errors = []
        warnings = []
        
        for name, scheme in security_schemes.items():
            if not isinstance(scheme, dict):
                errors.append(f"Security scheme '{name}' must be an object")
                continue
            
            if 'type' not in scheme:
                errors.append(f"Security scheme '{name}' missing 'type' field")
                continue
            
            scheme_type = scheme['type']
            if scheme_type not in ['apiKey', 'http', 'oauth2', 'openIdConnect']:
                errors.append(f"Invalid security scheme type '{scheme_type}' in '{name}'")
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_global_parameters(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Validate global parameters section"""
        errors = []
        warnings = []
        
        for name, param in parameters.items():
            if not isinstance(param, dict):
                errors.append(f"Global parameter '{name}' must be an object")
                continue
            
            # Skip $ref validation
            if '$ref' in param:
                continue
            
            param_validation = self._validate_operation_parameters([param], [], '', '', '2.0', strict=False)
            errors.extend(param_validation['errors'])
            warnings.extend(param_validation['warnings'])
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_request_body(self, request_body: Dict[str, Any]) -> Dict[str, Any]:
        """Validate requestBody (OpenAPI 3.0)"""
        errors = []
        warnings = []
        
        # Handle $ref
        if isinstance(request_body, dict) and '$ref' in request_body:
            return {'errors': errors, 'warnings': warnings}
        
        if not isinstance(request_body, dict):
            errors.append("RequestBody must be an object")
            return {'errors': errors, 'warnings': warnings}
        
        if 'content' not in request_body:
            errors.append("RequestBody missing 'content' field")
        else:
            content = request_body['content']
            if not isinstance(content, dict) or not content:
                errors.append("RequestBody content must be a non-empty object")
        
        return {'errors': errors, 'warnings': warnings}
    
    def _validate_openapi_2_specific(self, spec: Dict[str, Any], errors: List[str], warnings: List[str]):
        """OpenAPI 2.0 specific validations"""
        # Check for deprecated fields in 3.0
        if 'host' not in spec and 'basePath' not in spec:
            warnings.append("Consider adding 'host' and/or 'basePath' for better API documentation")
    
    def _validate_openapi_3_specific(self, spec: Dict[str, Any], errors: List[str], warnings: List[str]):
        """OpenAPI 3.0 specific validations"""
        # Check for deprecated 2.0 fields
        deprecated_fields = ['host', 'basePath', 'schemes', 'consumes', 'produces', 'definitions', 'securityDefinitions']
        for field in deprecated_fields:
            if field in spec:
                warnings.append(f"Field '{field}' is deprecated in OpenAPI 3.0")
    
    def _is_valid_url(self, url: str) -> bool:
        """Check if URL is valid"""
        try:
            result = urlparse(url)
            return all([result.scheme, result.netloc])
        except:
            return False
    
    def validate_conversion_quality(self, original: Dict[str, Any], converted: Dict[str, Any]) -> Dict[str, Any]:
        """Validate the quality of conversion from 2.0 to 3.0"""
        issues = []
        score = 100
        
        # Check basic structure preservation
        original_paths = set(original.get('paths', {}).keys())
        converted_paths = set(converted.get('paths', {}).keys())
        
        if original_paths != converted_paths:
            missing_paths = original_paths - converted_paths
            extra_paths = converted_paths - original_paths
            if missing_paths:
                issues.append(f"Missing paths in conversion: {', '.join(missing_paths)}")
                score -= 20
            if extra_paths:
                issues.append(f"Extra paths in conversion: {', '.join(extra_paths)}")
                score -= 10
        
        # Check schema preservation
        original_schemas = len(original.get('definitions', {}))
        converted_schemas = len(converted.get('components', {}).get('schemas', {}))
        
        if original_schemas != converted_schemas:
            issues.append(f"Schema count mismatch: {original_schemas} → {converted_schemas}")
            score -= 15
        
        # Check server conversion
        has_host_info = 'host' in original or 'basePath' in original
        has_servers = 'servers' in converted and converted['servers']
        
        if has_host_info and not has_servers:
            issues.append("Host/basePath information not converted to servers")
            score -= 10
        
        return {
            'conversion_score': max(0, score),
            'issues': issues,
            'quality_rating': 'excellent' if score >= 90 else 'good' if score >= 70 else 'fair' if score >= 50 else 'poor'
        }