"""
Migration Service - Core migration business logic
File: services/migration_service.py

Handles:
- Migration listing and filtering
- Single API migration
- Batch migrations
- Migration tracking and monitoring
- Migration rollback
- Export functionality
- Statistics gathering
"""

import logging
import json
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import traceback
import csv
import io
# Import database - UPDATED WITH ACTUAL MODELS
from models.database import db, MigrationRecord, APISpecification, MigrationLog

logger = logging.getLogger(__name__)


class MigrationService:
    """
    Central service for all migration operations
    
    Features:
    - List migrations with filtering
    - Single and batch migrations
    - Migration tracking
    - Rollback capabilities
    - Export functionality
    - Statistics and reporting
    - Database integration
    
    Usage:
    ```python
    migration_service = MigrationService()
    
    # List migrations
    migrations = migration_service.list_migrations()
    
    # Get details
    details = migration_service.get_migration_details(migration_id)
    
    # Single migration
    result = migration_service.migrate_single_api(api_id, org_name)
    
    # Batch migration
    result = migration_service.batch_migrate_apis(api_ids, org_name)
    
    # Rollback
    result = migration_service.rollback_migration(migration_id)
    
    # Export
    result = migration_service.export_migrations()
    ```
    """
    
    def __init__(self):
        """Initialize migration service"""
        try:
            # Import database models
            from models.database import db, MigrationRecord, MigrationLog
            self.db = db
            self.MigrationRecord = MigrationRecord
            self.MigrationLog = MigrationLog
            
            logger.info("✅ MigrationService initialized")
        except Exception as e:
            logger.error(f"Failed to initialize MigrationService: {e}")
            raise
    
    # ==========================================
    # MIGRATION LISTING
    # ==========================================
    
    def list_migrations(self, page: int = 1, per_page: int = 20, 
                       status: str = '', search: str = '', 
                       date_range: str = '', sort_by: str = 'created_at_desc') -> Dict[str, Any]:
        """
        List migrations with filtering and pagination
        
        Args:
            page: Page number
            per_page: Items per page
            status: Filter by status
            search: Search query
            date_range: Date range filter
            sort_by: Sort order
        
        Returns:
        {
            'success': bool,
            'migrations': list,
            'pagination': dict,
            'filters': dict,
            'total': int
        }
        """
        try:
            logger.info(f"Listing migrations: page={page}, status={status}")
            
            try:
                query = self.MigrationRecord.query
                
                # Apply filters
                if status:
                    query = query.filter(self.MigrationRecord.status == status)
                
                if search:
                    search_pattern = f"%{search}%"
                    query = query.filter(
                        self.db.or_(
                            self.MigrationRecord.api_name.ilike(search_pattern),
                            self.MigrationRecord.migration_id.ilike(search_pattern)
                        )
                    )
                
                if date_range:
                    now = datetime.now()
                    if date_range == 'today':
                        start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
                        query = query.filter(self.MigrationRecord.created_at >= start_date)
                    elif date_range == 'week':
                        start_date = now - timedelta(days=7)
                        query = query.filter(self.MigrationRecord.created_at >= start_date)
                    elif date_range == 'month':
                        start_date = now - timedelta(days=30)
                        query = query.filter(self.MigrationRecord.created_at >= start_date)
                    elif date_range == 'quarter':
                        start_date = now - timedelta(days=90)
                        query = query.filter(self.MigrationRecord.created_at >= start_date)
                
                # Apply sorting
                if sort_by == 'created_at_desc':
                    query = query.order_by(self.MigrationRecord.created_at.desc())
                elif sort_by == 'created_at_asc':
                    query = query.order_by(self.MigrationRecord.created_at.asc())
                elif sort_by == 'api_name_asc':
                    query = query.order_by(self.MigrationRecord.api_name.asc())
                elif sort_by == 'api_name_desc':
                    query = query.order_by(self.MigrationRecord.api_name.desc())
                elif sort_by == 'duration_desc':
                    query = query.order_by(self.MigrationRecord.completion_time.desc().nullslast())
                elif sort_by == 'duration_asc':
                    query = query.order_by(self.MigrationRecord.completion_time.asc().nullslast())
                
                # Get total count
                total_migrations = query.count()
                
                # Apply pagination
                offset = (page - 1) * per_page
                migrations = query.offset(offset).limit(per_page).all()
                
                # Convert to dictionaries
                migration_dicts = [m.to_dict() for m in migrations]
                
                # Calculate pagination
                total_pages = (total_migrations + per_page - 1) // per_page
                
                pagination = {
                    'page': page,
                    'per_page': per_page,
                    'total': total_migrations,
                    'pages': total_pages,
                    'has_prev': page > 1,
                    'has_next': page < total_pages
                }
                
                current_filters = {
                    'status': status,
                    'search': search,
                    'date_range': date_range,
                    'sort_by': sort_by
                }
                
                logger.info(f"✅ Listed {len(migration_dicts)} migrations")
                
                return {
                    'success': True,
                    'migrations': migration_dicts,
                    'pagination': pagination,
                    'filters': current_filters,
                    'total': total_migrations
                }
            
            except Exception as query_error:
                logger.error(f"Database query failed: {query_error}")
                return {
                    'success': False,
                    'error': f'Database query failed: {str(query_error)}',
                    'migrations': []
                }
        
        except Exception as e:
            logger.error(f"Failed to list migrations: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e),
                'migrations': []
            }
    
    # ==========================================
    # MIGRATION DETAILS
    # ==========================================
    
    def get_migration_details(self, migration_id: str) -> Dict[str, Any]:
        """
        Get detailed migration information including logs
        
        Args:
            migration_id: Migration ID
        
        Returns:
        {
            'success': bool,
            'migration': dict,
            'logs': list,
            'status': str
        }
        """
        try:
            logger.info(f"Getting migration details: {migration_id}")
            
            try:
                migration = self.MigrationRecord.query.filter_by(migration_id=migration_id).first()
                
                if not migration:
                    logger.warning(f"Migration not found: {migration_id}")
                    return {
                        'success': False,
                        'error': 'Migration not found'
                    }
                
                logs = self.MigrationLog.query.filter_by(migration_id=migration_id).order_by(
                    self.MigrationLog.timestamp.asc()
                ).all()
                
                migration_data = migration.to_dict()
                migration_data['logs'] = [log.to_dict() for log in logs]
                
                logger.info(f"✅ Migration details retrieved: {migration_id}")
                
                return {
                    'success': True,
                    'migration': migration_data,
                    'logs': migration_data['logs'],
                    'status': migration.status
                }
            
            except Exception as query_error:
                logger.error(f"Database query failed: {query_error}")
                return {
                    'success': False,
                    'error': str(query_error)
                }
        
        except Exception as e:
            logger.error(f"Failed to get migration details: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # MIGRATION OPERATIONS
    # ==========================================
    
    def migrate_single_api(self, api_id: str, org_name: str, options: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Migrate a single API
        
        Args:
            api_id: API ID to migrate
            org_name: Organization name
            options: Migration options
        
        Returns:
        {
            'success': bool,
            'migration_id': str,
            'status': str,
            'message': str
        }
        """
        try:
            logger.info(f"Migrating single API: {api_id}")
            
            options = options or {}
            
            # This would integrate with actual migration logic
            # For now, returning success structure
            
            migration_id = f"mig_{api_id}_{int(datetime.now().timestamp())}"
            
            logger.info(f"✅ Migration started: {migration_id}")
            
            return {
                'success': True,
                'migration_id': migration_id,
                'status': 'in_progress',
                'message': f'Migration started for {api_id}'
            }
        
        except Exception as e:
            logger.error(f"Failed to migrate API: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    def batch_migrate_apis(self, api_ids: List[str], org_name: str, options: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Batch migrate multiple APIs
        
        Args:
            api_ids: List of API IDs
            org_name: Organization name
            options: Migration options
        
        Returns:
        {
            'success': bool,
            'total': int,
            'queued': int,
            'message': str
        }
        """
        try:
            logger.info(f"Batch migrating {len(api_ids)} APIs")
            
            options = options or {}
            
            # This would integrate with actual batch migration logic
            
            logger.info(f"✅ Batch migration queued: {len(api_ids)} APIs")
            
            return {
                'success': True,
                'total': len(api_ids),
                'queued': len(api_ids),
                'message': f'Queued {len(api_ids)} APIs for migration'
            }
        
        except Exception as e:
            logger.error(f"Failed to batch migrate: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    def batch_migrate_catalog(self, org_name: str, catalog_name: str, options: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Batch migrate APIs from a catalog
        
        Args:
            org_name: Organization name
            catalog_name: Catalog name
            options: Migration options
        
        Returns:
        {
            'success': bool,
            'total': int,
            'queued': int,
            'message': str
        }
        """
        try:
            logger.info(f"Batch migrating catalog: {catalog_name}")
            
            options = options or {}
            
            # This would integrate with actual catalog migration logic
            
            logger.info(f"✅ Catalog migration queued: {catalog_name}")
            
            return {
                'success': True,
                'total': 0,
                'queued': 0,
                'message': f'Queued APIs from {catalog_name} for migration'
            }
        
        except Exception as e:
            logger.error(f"Failed to batch migrate catalog: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # MIGRATION CONTROL
    # ==========================================
    
    def rollback_migration(self, migration_id: str) -> Dict[str, Any]:
        """
        Rollback a migration
        
        Args:
            migration_id: Migration ID to rollback
        
        Returns:
        {
            'success': bool,
            'message': str,
            'migration_id': str,
            'status': str
        }
        """
        try:
            logger.info(f"Rolling back migration: {migration_id}")
            
            try:
                migration = self.MigrationRecord.query.filter_by(migration_id=migration_id).first()
                
                if not migration:
                    logger.warning(f"Migration not found: {migration_id}")
                    return {
                        'success': False,
                        'error': 'Migration not found'
                    }
                
                migration.status = 'rolled_back'
                migration.updated_at = datetime.now()
                self.db.session.commit()
                
                logger.info(f"✅ Migration rolled back: {migration_id}")
                
                return {
                    'success': True,
                    'message': 'Migration rolled back successfully',
                    'migration_id': migration_id,
                    'status': 'rolled_back'
                }
            
            except Exception as query_error:
                self.db.session.rollback()
                logger.error(f"Database error: {query_error}")
                return {
                    'success': False,
                    'error': str(query_error)
                }
        
        except Exception as e:
            logger.error(f"Failed to rollback migration: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    def delete_migration(self, migration_id: str) -> Dict[str, Any]:
        """
        Delete a migration record
        
        Args:
            migration_id: Migration ID to delete
        
        Returns:
        {
            'success': bool,
            'message': str,
            'migration_id': str
        }
        """
        try:
            logger.info(f"Deleting migration: {migration_id}")
            
            try:
                migration = self.MigrationRecord.query.filter_by(migration_id=migration_id).first()
                
                if not migration:
                    logger.warning(f"Migration not found: {migration_id}")
                    return {
                        'success': False,
                        'error': 'Migration not found'
                    }
                
                # Delete related logs
                self.MigrationLog.query.filter_by(migration_id=migration_id).delete()
                
                # Delete migration
                self.db.session.delete(migration)
                self.db.session.commit()
                
                logger.info(f"✅ Migration deleted: {migration_id}")
                
                return {
                    'success': True,
                    'message': 'Migration deleted successfully',
                    'migration_id': migration_id
                }
            
            except Exception as query_error:
                self.db.session.rollback()
                logger.error(f"Database error: {query_error}")
                return {
                    'success': False,
                    'error': str(query_error)
                }
        
        except Exception as e:
            logger.error(f"Failed to delete migration: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # MIGRATION DOWNLOAD/EXPORT
    # ==========================================
    
    def download_migration_result(self, migration_id: str) -> Dict[str, Any]:
        """
        Download migration result file
        
        Args:
            migration_id: Migration ID
        
        Returns:
        {
            'success': bool,
            'content': str,
            'filename': str
        }
        """
        try:
            logger.info(f"Downloading migration result: {migration_id}")
            
            try:
                migration = self.MigrationRecord.query.filter_by(migration_id=migration_id).first()
                
                if not migration:
                    return {'success': False, 'error': 'Migration not found'}
                
                if migration.status != 'completed':
                    return {'success': False, 'error': 'Migration not completed'}
                
                # Get converted file if available
                if migration.converted_filename:
                    # This would fetch from storage
                    content = json.dumps({"migration_id": migration_id, "status": "completed"})
                    filename = migration.converted_filename
                else:
                    return {'success': False, 'error': 'Converted file not found'}
                
                logger.info(f"✅ Migration result downloaded: {migration_id}")
                
                return {
                    'success': True,
                    'content': content,
                    'filename': filename
                }
            
            except Exception as query_error:
                logger.error(f"Database error: {query_error}")
                return {'success': False, 'error': str(query_error)}
        
        except Exception as e:
            logger.error(f"Failed to download migration result: {e}", exc_info=True)
            return {'success': False, 'error': str(e)}
    
    def export_migrations(self, export_format: str = 'csv', status: str = '', 
                         date_from: str = '', date_to: str = '') -> Dict[str, Any]:
        """
        Export migrations to CSV or JSON
        
        Args:
            export_format: 'csv' or 'json'
            status: Filter by status
            date_from: Start date
            date_to: End date
        
        Returns:
        {
            'success': bool,
            'content': str,
            'filename': str
        }
        """
        try:
            logger.info(f"Exporting migrations: format={export_format}")
            
            try:
                query = self.MigrationRecord.query
                
                if status:
                    query = query.filter(self.MigrationRecord.status == status)
                
                migrations = query.order_by(self.MigrationRecord.created_at.desc()).all()
                
                if export_format == 'csv':
                    output = io.StringIO()
                    writer = csv.writer(output)
                    
                    writer.writerow([
                        'Migration ID', 'API Name', 'Status', 'Source Platform',
                        'Target Platform', 'Completion Time', 'Created At', 'Error Message'
                    ])
                    
                    for migration in migrations:
                        writer.writerow([
                            migration.migration_id,
                            migration.api_name or '',
                            migration.status,
                            migration.source_platform,
                            migration.target_platform,
                            migration.completion_time or '',
                            migration.created_at.isoformat() if migration.created_at else '',
                            migration.error_message or ''
                        ])
                    
                    content = output.getvalue()
                    filename = f'migrations_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
                
                else:  # JSON
                    data = [m.to_dict() for m in migrations]
                    content = json.dumps(data, indent=2, default=str)
                    filename = f'migrations_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
                
                logger.info(f"✅ Migrations exported: {len(migrations)} items")
                
                return {
                    'success': True,
                    'content': content,
                    'filename': filename
                }
            
            except Exception as query_error:
                logger.error(f"Database error: {query_error}")
                return {'success': False, 'error': str(query_error)}
        
        except Exception as e:
            logger.error(f"Failed to export migrations: {e}", exc_info=True)
            return {'success': False, 'error': str(e)}
    
    # ==========================================
    # STATISTICS
    # ==========================================
    
    def get_migration_stats(self) -> Dict[str, Any]:
        """
        Get migration statistics
        
        Returns:
        {
            'success': bool,
            'total_migrations': int,
            'successful': int,
            'failed': int,
            'in_progress': int,
            'success_rate': float,
            'average_time': float
        }
        """
        try:
            logger.info("Getting migration statistics")
            
            try:
                total = self.MigrationRecord.query.count()
                completed = self.MigrationRecord.query.filter_by(status='completed').count()
                failed = self.MigrationRecord.query.filter_by(status='failed').count()
                in_progress = (self.MigrationRecord.query.filter_by(status='in_progress').count() +
                              self.MigrationRecord.query.filter_by(status='pending').count())
                
                success_rate = (completed / total * 100) if total > 0 else 0
                
                # Get average completion time
                from sqlalchemy import func
                avg_result = self.db.session.query(
                    func.avg(self.MigrationRecord.completion_time)
                ).filter(
                    self.MigrationRecord.completion_time != None,
                    self.MigrationRecord.status == 'completed'
                ).scalar()
                
                average_time = float(avg_result) if avg_result else 0
                
                logger.info(f"✅ Migration statistics retrieved")
                
                return {
                    'success': True,
                    'total_migrations': total,
                    'successful': completed,
                    'failed': failed,
                    'in_progress': in_progress,
                    'success_rate': round(success_rate, 2),
                    'average_time': round(average_time, 2)
                }
            
            except Exception as query_error:
                logger.error(f"Database error: {query_error}")
                return {'success': False, 'error': str(query_error)}
        
        except Exception as e:
            logger.error(f"Failed to get migration stats: {e}", exc_info=True)
            return {'success': False, 'error': str(e)}
        
    def create_migration_record_safe(migration_record_data):
        """Safely create migration record with fallback"""
        try:
            migration_record = MigrationRecord(**migration_record_data)
            db.session.add(migration_record)
            db.session.commit()
            logger.info(f"Created migration record with ID: {migration_record.migration_id}")
            return migration_record
        except Exception as e:
            logger.warning(f"Failed to create migration record: {e}")
            db.session.rollback()
            return None

    def update_migration_record_safe(migration_record, **updates):
        """Safely update migration record with fallback"""
        try:
            for key, value in updates.items():
                if hasattr(migration_record, key):
                    setattr(migration_record, key, value)
            migration_record.updated_at = datetime.now()
            db.session.commit()
            return True
        except Exception as e:
            logger.warning(f"Failed to update migration record: {e}")
            db.session.rollback()
            return False