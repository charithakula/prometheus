"""
Storage Service - Core storage business logic
File: services/storage_service.py

Handles:
- Storage status checking
- Azure Blob Storage management
- Local filesystem fallback
- Storage statistics
- Storage testing
- Cleanup operations
- Quota management
"""

import logging
import os
import json
from typing import Dict, Any, Optional, Tuple
import time
from datetime import datetime, timedelta
import traceback

logger = logging.getLogger(__name__)


class StorageService:
    """
    Central service for all storage operations
    
    Features:
    - Automatic Azure/local fallback
    - Health checking
    - Statistics gathering
    - Quota management
    - Cleanup utilities
    - Testing utilities
    
    Usage:
    ```python
    storage_service = StorageService()
    
    # Check status
    status = storage_service.check_status()
    
    # Get stats
    stats = storage_service.get_stats()
    
    # Test connection
    test = storage_service.test_connection()
    
    # Cleanup old files
    cleanup = storage_service.cleanup_old_files(days=7)
    ```
    """
    
    def __init__(self):
        """Initialize storage service"""
        try:
            # Import file handler (will be initialized when first used)
            from utils.enhanced_file_handler_with_azure import EnhancedFileHandler
            self.file_handler = EnhancedFileHandler()
            logger.info("✅ StorageService initialized")
        except Exception as e:
            logger.error(f"Failed to initialize StorageService: {e}")
            raise
    
    # ==========================================
    # STATUS CHECKING
    # ==========================================
    
    def check_status(self) -> Dict[str, Any]:
        """
        Check storage status and availability
        
        Returns:
        {
            'success': bool,
            'status': str (not_configured|local_fallback|connected|error),
            'storage_type': str (local|azure),
            'message': str,
            'account_name': str (if azure),
            'stats': dict (if available)
        }
        """
        try:
            logger.info("Checking storage status...")
            
            connection_string = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
            account_name = os.getenv('AZURE_STORAGE_ACCOUNT_NAME')
            
            # Not configured
            if not connection_string and not account_name:
                logger.info("Azure Storage not configured - using local filesystem")
                return {
                    'success': True,
                    'status': 'not_configured',
                    'storage_type': 'local',
                    'message': 'Azure Storage not configured - using local filesystem',
                    'account_name': None,
                    'recommendation': 'Set AZURE_STORAGE_CONNECTION_STRING or AZURE_STORAGE_ACCOUNT_NAME',
                    'stats': None
                }
            
            # Check if Azure is actually available
            if not self.file_handler.use_azure:
                logger.warning("Azure Storage configuration failed - using local fallback")
                return {
                    'success': True,
                    'status': 'local_fallback',
                    'storage_type': 'local',
                    'message': 'Azure Storage initialization failed - using local filesystem',
                    'account_name': account_name,
                    'warning': 'Check credentials and network connectivity',
                    'stats': None
                }
            
            # Azure is configured and available
            try:
                stats = self.file_handler.get_storage_stats()
                if stats.get('success'):
                    totals = stats.get('totals', {})
                    logger.info(f"✅ Azure Storage connected: {totals}")
                    
                    return {
                        'success': True,
                        'status': 'connected',
                        'storage_type': 'azure',
                        'message': 'Connected to Azure Blob Storage',
                        'account_name': account_name,
                        'stats': {
                            'total_files': totals.get('total_files', 0),
                            'total_size_mb': totals.get('total_size_mb', 0)
                        }
                    }
                else:
                    logger.warning(f"Failed to get Azure storage stats: {stats.get('error')}")
                    return {
                        'success': True,
                        'status': 'local_fallback',
                        'storage_type': 'local',
                        'message': 'Azure Blob Storage unavailable - using local filesystem',
                        'account_name': account_name,
                        'warning': stats.get('error'),
                        'stats': None
                    }
            
            except Exception as stats_error:
                logger.warning(f"Error getting Azure stats: {stats_error}")
                return {
                    'success': True,
                    'status': 'local_fallback',
                    'storage_type': 'local',
                    'message': 'Error accessing Azure Blob Storage - using local filesystem',
                    'account_name': account_name,
                    'error': str(stats_error)[:100],
                    'stats': None
                }
        
        except Exception as e:
            logger.error(f"Storage status check failed: {e}", exc_info=True)
            return {
                'success': False,
                'status': 'error',
                'storage_type': 'unknown',
                'message': f'Storage status check failed: {str(e)[:100]}',
                'error': str(e)
            }
    
    # ==========================================
    # INFORMATION RETRIEVAL
    # ==========================================
    
    def get_info(self) -> Dict[str, Any]:
        """
        Get detailed storage information
        
        Returns:
        {
            'success': bool,
            'storage_type': str,
            'using_fallback': bool,
            'account_name': str,
            'container_name': str,
            'endpoint': str,
            'stats': dict
        }
        """
        try:
            logger.info("Getting storage information...")
            
            storage_info = {
                'success': True,
                'storage_type': 'azure' if self.file_handler.use_azure else 'local',
                'using_fallback': not self.file_handler.use_azure,
                'account_name': os.getenv('AZURE_STORAGE_ACCOUNT_NAME') if self.file_handler.use_azure else None,
                'container_name': os.getenv('AZURE_STORAGE_CONTAINER_NAME', 'uploads'),
            }
            
            if self.file_handler.use_azure:
                try:
                    account_name = os.getenv('AZURE_STORAGE_ACCOUNT_NAME')
                    storage_info['endpoint'] = f'https://{account_name}.blob.core.windows.net'
                    
                    stats = self.file_handler.get_storage_stats()
                    if stats.get('success'):
                        storage_info['stats'] = stats.get('totals', {})
                    else:
                        storage_info['stats_error'] = stats.get('error')
                
                except Exception as e:
                    logger.warning(f"Error getting Azure storage info: {e}")
                    storage_info['stats_error'] = str(e)[:100]
            
            else:
                storage_info['endpoint'] = 'local_filesystem'
                storage_info['warning'] = 'Using local filesystem - Azure Storage not available'
                try:
                    storage_info['stats'] = self.file_handler.get_storage_stats().get('totals', {})
                except:
                    storage_info['stats'] = {}
            
            logger.info("✅ Storage information retrieved")
            return storage_info
        
        except Exception as e:
            logger.error(f"Failed to get storage info: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # STATISTICS
    # ==========================================
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get comprehensive storage statistics
        
        Returns:
        {
            'success': bool,
            'folders': dict,
            'totals': dict,
            'storage_type': str
        }
        """
        try:
            logger.info("Gathering storage statistics...")
            
            stats = self.file_handler.get_storage_stats()
            
            if stats.get('success'):
                logger.info("✅ Storage stats retrieved")
                return {
                    'success': True,
                    'folders': stats.get('folders', {}),
                    'totals': stats.get('totals', {}),
                    'storage_type': stats.get('storage_type', 'unknown')
                }
            else:
                logger.warning(f"Storage stats failed: {stats.get('error')}")
                return {
                    'success': False,
                    'error': stats.get('error'),
                    'storage_type': 'unknown'
                }
        
        except Exception as e:
            logger.error(f"Failed to get storage stats: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # TESTING
    # ==========================================
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Test storage connection by uploading, downloading, and deleting a test file
        
        Returns:
        {
            'success': bool,
            'storage_type': str,
            'message': str,
            'upload_time_ms': float,
            'download_time_ms': float,
            'delete_time_ms': float
        }
        """
        try:
            logger.info("Testing storage connection...")
            
            # If using local filesystem, just return success
            if not self.file_handler.use_azure:
                logger.info("Local filesystem mode - test skipped")
                return {
                    'success': True,
                    'storage_type': 'local',
                    'message': 'Local filesystem is available',
                    'upload_time_ms': None,
                    'download_time_ms': None,
                    'delete_time_ms': None
                }
            
            # Test Azure connection
            test_data = {
                'test': 'connection_check',
                'timestamp': str(datetime.now())
            }
            test_content = json.dumps(test_data).encode('utf-8')
            test_filename = 'test_connection.json'
            test_blob_path = f'test/{test_filename}'
            
            logger.info(f"Uploading test file: {test_blob_path}")
            
            # Upload test
            upload_start = time.time()
            upload_result = self.file_handler.azure_storage.upload_file(
                test_content,
                test_blob_path,
                metadata={'test': 'true'}
            )
            upload_time = (time.time() - upload_start) * 1000
            
            if not upload_result.get('success'):
                logger.warning(f"Upload test failed: {upload_result.get('error')}")
                return {
                    'success': False,
                    'storage_type': 'azure',
                    'message': f'Upload test failed: {upload_result.get("error")}',
                    'upload_time_ms': round(upload_time, 2)
                }
            
            logger.info(f"✓ Upload test passed ({upload_time:.0f}ms)")
            
            # Download test
            logger.info(f"Downloading test file")
            download_start = time.time()
            download_result = self.file_handler.azure_storage.download_file(test_blob_path)
            download_time = (time.time() - download_start) * 1000
            
            if not download_result.get('success'):
                # Clean up if download fails
                self.file_handler.azure_storage.delete_file(test_blob_path)
                logger.warning(f"Download test failed: {download_result.get('error')}")
                return {
                    'success': False,
                    'storage_type': 'azure',
                    'message': f'Download test failed: {download_result.get("error")}',
                    'upload_time_ms': round(upload_time, 2),
                    'download_time_ms': round(download_time, 2)
                }
            
            logger.info(f"✓ Download test passed ({download_time:.0f}ms)")
            
            # Verify content
            downloaded_content = download_result.get('content')
            if downloaded_content != test_content:
                self.file_handler.azure_storage.delete_file(test_blob_path)
                logger.warning("Content verification failed")
                return {
                    'success': False,
                    'storage_type': 'azure',
                    'message': 'Content verification failed',
                    'upload_time_ms': round(upload_time, 2),
                    'download_time_ms': round(download_time, 2)
                }
            
            logger.info("✓ Content verification passed")
            
            # Delete test
            logger.info(f"Deleting test file")
            delete_start = time.time()
            delete_result = self.file_handler.azure_storage.delete_file(test_blob_path)
            delete_time = (time.time() - delete_start) * 1000
            
            if not delete_result.get('success'):
                logger.warning(f"Delete test failed: {delete_result.get('error')}")
                return {
                    'success': False,
                    'storage_type': 'azure',
                    'message': f'Delete test failed: {delete_result.get("error")}',
                    'upload_time_ms': round(upload_time, 2),
                    'download_time_ms': round(download_time, 2),
                    'delete_time_ms': round(delete_time, 2)
                }
            
            logger.info(f"✓ Delete test passed ({delete_time:.0f}ms)")
            
            logger.info("✅ All storage tests passed")
            return {
                'success': True,
                'storage_type': 'azure',
                'message': 'All storage tests passed successfully',
                'upload_time_ms': round(upload_time, 2),
                'download_time_ms': round(download_time, 2),
                'delete_time_ms': round(delete_time, 2)
            }
        
        except Exception as e:
            logger.error(f"Storage test failed: {e}", exc_info=True)
            return {
                'success': False,
                'storage_type': 'unknown',
                'message': f'Storage test failed: {str(e)[:100]}'
            }
    
    # ==========================================
    # CLEANUP OPERATIONS
    # ==========================================
    
    def cleanup_old_files(self, days_old: int = 7) -> Dict[str, Any]:
        """
        Clean up files older than specified days
        
        Args:
            days_old: Number of days to keep (default: 7)
        
        Returns:
        {
            'success': bool,
            'files_deleted': int,
            'space_freed_mb': float,
            'message': str
        }
        """
        try:
            logger.info(f"Cleaning up files older than {days_old} days...")
            
            result = self.file_handler.cleanup_old_files(days_old)
            
            if result.get('success'):
                logger.info(f"✅ Cleanup completed")
                logger.info(f"   Files deleted: {result.get('files_deleted', 0)}")
                logger.info(f"   Space freed: {result.get('space_freed_mb', 0)}MB")
            else:
                logger.warning(f"Cleanup had issues: {result.get('message')}")
            
            return result
        
        except Exception as e:
            logger.error(f"Cleanup operation failed: {e}", exc_info=True)
            return {
                'success': False,
                'message': f'Cleanup failed: {str(e)[:100]}',
                'error': str(e)
            }
    
    # ==========================================
    # QUOTA MANAGEMENT
    # ==========================================
    
    def get_quota(self) -> Dict[str, Any]:
        """
        Get storage quota information
        
        Returns:
        {
            'success': bool,
            'total_quota_mb': float,
            'used_mb': float,
            'available_mb': float,
            'usage_percent': float,
            'storage_type': str
        }
        """
        try:
            logger.info("Getting storage quota...")
            
            stats = self.get_stats()
            
            if not stats.get('success'):
                logger.warning(f"Failed to get quota: {stats.get('error')}")
                return {
                    'success': False,
                    'error': stats.get('error')
                }
            
            totals = stats.get('totals', {})
            used_mb = totals.get('total_size_mb', 0)
            
            # Default quota (can be configured)
            total_quota_mb = float(os.getenv('STORAGE_QUOTA_MB', 5000))  # 5GB default
            available_mb = max(0, total_quota_mb - used_mb)
            usage_percent = (used_mb / total_quota_mb * 100) if total_quota_mb > 0 else 0
            
            logger.info(f"✅ Quota retrieved: {usage_percent:.1f}% used")
            
            return {
                'success': True,
                'total_quota_mb': total_quota_mb,
                'used_mb': used_mb,
                'available_mb': available_mb,
                'usage_percent': round(usage_percent, 2),
                'storage_type': stats.get('storage_type', 'unknown')
            }
        
        except Exception as e:
            logger.error(f"Failed to get quota: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # CONFIGURATION
    # ==========================================
    
    def get_config(self) -> Dict[str, Any]:
        """
        Get storage configuration (sanitized for security)
        
        Returns:
        {
            'success': bool,
            'storage_type': str,
            'account_name': str (masked),
            'container_name': str,
            'endpoint': str,
            'connection_status': str
        }
        """
        try:
            logger.info("Getting storage configuration...")
            
            storage_type = 'azure' if self.file_handler.use_azure else 'local'
            account_name = os.getenv('AZURE_STORAGE_ACCOUNT_NAME')
            
            # Mask account name for security
            masked_account = None
            if account_name:
                masked_account = account_name[:3] + '***' if len(account_name) > 6 else '***'
            
            endpoint = None
            if account_name:
                endpoint = f'https://{account_name}.blob.core.windows.net'
            
            config = {
                'success': True,
                'storage_type': storage_type,
                'account_name': masked_account,
                'container_name': os.getenv('AZURE_STORAGE_CONTAINER_NAME', 'uploads'),
                'endpoint': endpoint,
                'connection_status': 'connected' if self.file_handler.use_azure else 'using_local'
            }
            
            logger.info(f"✅ Storage config retrieved")
            return config
        
        except Exception as e:
            logger.error(f"Failed to get config: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==========================================
    # DEBUG
    # ==========================================
    
    def get_debug_details(self) -> Dict[str, Any]:
        """
        Get comprehensive debug information
        
        Returns extensive storage debugging data
        """
        try:
            logger.info("Gathering storage debug details...")
            
            status = self.check_status()
            info = self.get_info()
            stats = self.get_stats()
            quota = self.get_quota()
            config = self.get_config()
            
            debug_details = {
                'success': True,
                'timestamp': datetime.now().isoformat(),
                'status': status,
                'info': info,
                'stats': stats,
                'quota': quota,
                'config': config,
                'environment': {
                    'AZURE_STORAGE_CONNECTION_STRING_SET': bool(os.getenv('AZURE_STORAGE_CONNECTION_STRING')),
                    'AZURE_STORAGE_ACCOUNT_NAME': os.getenv('AZURE_STORAGE_ACCOUNT_NAME', 'NOT SET'),
                    'AZURE_STORAGE_CONTAINER_NAME': os.getenv('AZURE_STORAGE_CONTAINER_NAME', 'NOT SET'),
                    'STORAGE_QUOTA_MB': os.getenv('STORAGE_QUOTA_MB', 'NOT SET'),
                }
            }
            
            logger.info("✅ Debug details gathered")
            return debug_details
        
        except Exception as e:
            logger.error(f"Failed to get debug details: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e),
                'traceback': traceback.format_exc()
            }