"""
Production-grade Database Helper
- Atomic transactions
- Batch operations
- Proper error handling
- Connection pooling
"""
from datetime import datetime
from typing import Dict, Any, Optional, List
import logging

logger = logging.getLogger(__name__)


class DatabaseHelper:
    """Helper for atomic database operations"""
    
    def __init__(self, db):
        """Initialize with SQLAlchemy db instance"""
        self.db = db
    
    def create_migration_record(self, 
                               migration_data: Dict[str, Any]) -> Optional[any]:
        """
        Safely create migration record with validation
        
        Args:
            migration_data: Dictionary with migration fields
        
        Returns:
            Migration record object or None if failed
        """
        try:
            from models.database import MigrationRecord
            
            # Validate required fields
            required_fields = ['migration_id', 'api_name', 'status']
            missing = [f for f in required_fields if f not in migration_data]
            if missing:
                logger.error(f"Missing required fields: {missing}")
                return None
            
            record = MigrationRecord(**migration_data)
            self.db.session.add(record)
            self.db.session.commit()
            
            logger.info(f"✅ Created migration record: {record.migration_id}")
            return record
        
        except Exception as e:
            logger.error(f"Failed to create migration record: {e}")
            self.db.session.rollback()
            return None
    
    def update_migration_with_logging(self,
                                     migration_record: any,
                                     updates: Dict[str, Any],
                                     log_info: Optional[Dict[str, Any]] = None) -> bool:
        """
        Atomically update migration record with optional logging
        
        Args:
            migration_record: Migration record to update
            updates: Dictionary of field updates
            log_info: Optional log entry data
        
        Returns:
            True if successful, False otherwise
        """
        try:
            from models.database import MigrationLog
            
            # Update fields
            for key, value in updates.items():
                if hasattr(migration_record, key):
                    setattr(migration_record, key, value)
                else:
                    logger.warning(f"Migration record has no field: {key}")
            
            migration_record.updated_at = datetime.now()
            
            # Add log if provided
            if log_info:
                log_entry = MigrationLog(**log_info)
                self.db.session.add(log_entry)
            
            # Single transaction
            self.db.session.commit()
            logger.debug(f"✅ Updated migration: {migration_record.migration_id}")
            return True
        
        except Exception as e:
            logger.error(f"Failed to update migration: {e}")
            self.db.session.rollback()
            return False
    
    def create_api_specification(self, 
                                api_data: Dict[str, Any]) -> Optional[any]:
        """
        Create API specification record
        
        Args:
            api_data: API specification data
        
        Returns:
            APISpecification record or None
        """
        try:
            from models.database import APISpecification
            
            required_fields = ['api_id', 'name', 'format']
            missing = [f for f in required_fields if f not in api_data]
            if missing:
                logger.error(f"Missing required API fields: {missing}")
                return None
            
            record = APISpecification(**api_data)
            self.db.session.add(record)
            self.db.session.commit()
            
            logger.info(f"✅ Created API spec: {record.api_id}")
            return record
        
        except Exception as e:
            logger.error(f"Failed to create API spec: {e}")
            self.db.session.rollback()
            return None
    
    def batch_create_migration_logs(self,
                                   logs: List[Dict[str, Any]]) -> int:
        """
        Create multiple migration logs in single transaction
        
        Args:
            logs: List of log dictionaries
        
        Returns:
            Number of logs created
        """
        try:
            from models.database import MigrationLog
            
            if not logs:
                return 0
            
            log_records = [MigrationLog(**log_data) for log_data in logs]
            self.db.session.add_all(log_records)
            self.db.session.commit()
            
            logger.info(f"✅ Created {len(log_records)} migration logs")
            return len(log_records)
        
        except Exception as e:
            logger.error(f"Failed to create logs: {e}")
            self.db.session.rollback()
            return 0
    
    def update_migration_status(self,
                               migration_id: str,
                               status: str,
                               error_message: Optional[str] = None) -> bool:
        """
        Update migration status atomically
        
        Args:
            migration_id: ID of migration to update
            status: New status
            error_message: Optional error message
        
        Returns:
            True if successful
        """
        try:
            from models.database import MigrationRecord
            
            migration = MigrationRecord.query.filter_by(
                migration_id=migration_id
            ).first()
            
            if not migration:
                logger.warning(f"Migration not found: {migration_id}")
                return False
            
            migration.status = status
            migration.updated_at = datetime.now()
            
            if error_message:
                migration.error_message = error_message
            
            if status == 'completed':
                migration.end_time = datetime.now()
            
            self.db.session.commit()
            logger.info(f"✅ Updated migration {migration_id}: {status}")
            return True
        
        except Exception as e:
            logger.error(f"Failed to update migration status: {e}")
            self.db.session.rollback()
            return False
    
    def get_migration_stats(self) -> Dict[str, Any]:
        """
        Get database migration statistics
        
        Returns:
            Dictionary with statistics
        """
        try:
            from models.database import MigrationRecord
            
            total = MigrationRecord.query.count()
            completed = MigrationRecord.query.filter_by(status='completed').count()
            failed = MigrationRecord.query.filter_by(status='failed').count()
            in_progress = MigrationRecord.query.filter(
                MigrationRecord.status.in_(['in_progress', 'pending'])
            ).count()
            
            success_rate = (completed / total * 100) if total > 0 else 0
            
            return {
                'total_migrations': total,
                'successful_migrations': completed,
                'failed_migrations': failed,
                'in_progress_migrations': in_progress,
                'success_rate': round(success_rate, 2),
                'average_completion_time': self._get_avg_completion_time()
            }
        
        except Exception as e:
            logger.error(f"Failed to get stats: {e}")
            return {
                'total_migrations': 0,
                'successful_migrations': 0,
                'failed_migrations': 0,
                'in_progress_migrations': 0,
                'success_rate': 0,
                'average_completion_time': 0
            }
    
    def _get_avg_completion_time(self) -> float:
        """Get average completion time"""
        try:
            from models.database import MigrationRecord
            from sqlalchemy import func
            
            result = self.db.session.query(
                func.avg(MigrationRecord.completion_time)
            ).filter(
                MigrationRecord.completion_time != None,
                MigrationRecord.status == 'completed'
            ).scalar()
            
            return round(float(result), 2) if result else 0
        
        except Exception as e:
            logger.warning(f"Failed to get avg completion time: {e}")
            return 0
    
    def cleanup_old_records(self, 
                           days_old: int = 90) -> Dict[str, int]:
        """
        Clean up old migration records
        
        Args:
            days_old: Delete records older than this many days
        
        Returns:
            Dictionary with count of deleted records
        """
        try:
            from models.database import MigrationRecord, MigrationLog
            from sqlalchemy import text
            from datetime import timedelta
            
            cutoff_date = datetime.now() - timedelta(days=days_old)
            
            # Count records to delete
            log_count = MigrationLog.query.filter(
                MigrationLog.timestamp < cutoff_date
            ).count()
            
            migration_count = MigrationRecord.query.filter(
                MigrationRecord.created_at < cutoff_date,
                MigrationRecord.status != 'in_progress'
            ).count()
            
            # Delete in transaction
            MigrationLog.query.filter(
                MigrationLog.timestamp < cutoff_date
            ).delete()
            
            MigrationRecord.query.filter(
                MigrationRecord.created_at < cutoff_date,
                MigrationRecord.status != 'in_progress'
            ).delete()
            
            self.db.session.commit()
            
            logger.info(f"✅ Cleanup complete: {log_count} logs, {migration_count} migrations deleted")
            
            return {
                'logs_deleted': log_count,
                'migrations_deleted': migration_count
            }
        
        except Exception as e:
            logger.error(f"Cleanup failed: {e}")
            self.db.session.rollback()
            return {'error': str(e)}
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check database health
        
        Returns:
            Health status dictionary
        """
        try:
            from models.database import MigrationRecord
            from sqlalchemy import text
            
            # Test query
            result = self.db.session.execute(text('SELECT 1')).fetchone()
            
            if result is None:
                return {'status': 'error', 'message': 'Query returned no results'}
            
            # Get table stats
            record_count = MigrationRecord.query.count()
            
            return {
                'status': 'healthy',
                'message': 'Database connection OK',
                'record_count': record_count,
                'connection_healthy': True
            }
        
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return {
                'status': 'unhealthy',
                'message': f'Database error: {str(e)}',
                'connection_healthy': False
            }
