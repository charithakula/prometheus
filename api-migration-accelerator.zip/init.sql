-- Database Schema Initialization for API Migration Tool - FIXED UTC SYNTAX
-- This script creates the database structure with proper timezone-aware timestamps
-- Compatible with Python 3.12+ datetime.now(timezone.utc)
-- Run with: psql -U api_user -d api_migration_db -f 01_init_schema_UTC_FIXED.sql

-- Connect to your database first:
-- psql -U api_user -d api_migration_db

BEGIN;

-- Create extensions
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
-- CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- ============================================
-- SET TIMEZONE TO UTC
-- ============================================
SET timezone = 'UTC';

-- Drop existing tables if they exist (be careful in production)
DROP TABLE IF EXISTS migration_logs CASCADE;
DROP TABLE IF EXISTS migration_records CASCADE;
DROP TABLE IF EXISTS api_specifications CASCADE;

-- ============================================
-- CREATE migration_records TABLE
-- ============================================
CREATE TABLE migration_records (
    id SERIAL PRIMARY KEY,
    migration_id VARCHAR(100) UNIQUE NOT NULL,
    original_api_id VARCHAR(100) NOT NULL,
    azure_api_id VARCHAR(100),
    api_name VARCHAR(200),
    api_version VARCHAR(50),
    
    -- Migration details
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    source_platform VARCHAR(50) NOT NULL DEFAULT 'ibm_api_connect',
    target_platform VARCHAR(50) NOT NULL DEFAULT 'azure_apim',
    
    -- Timestamps - FIXED: Using TIMESTAMP WITH TIME ZONE (NOW() is already UTC in PostgreSQL)
    start_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    end_time TIMESTAMP WITH TIME ZONE,
    completion_time REAL, -- Time in seconds
    
    -- File information
    original_filename VARCHAR(255),
    converted_filename VARCHAR(255),
    file_size INTEGER,
    
    -- Conversion details
    conversion_method VARCHAR(50),
    conversion_time REAL,
    ai_conversion_used BOOLEAN DEFAULT FALSE,
    
    -- Results and metadata
    conversion_notes TEXT,
    error_message TEXT,
    validation_results JSONB,
    migration_metadata JSONB,
    
    -- Tracking - FIXED: Using TIMESTAMP WITH TIME ZONE with correct syntax
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- ============================================
-- CREATE api_specifications TABLE
-- ============================================
CREATE TABLE api_specifications (
    id SERIAL PRIMARY KEY,
    api_id VARCHAR(100) NOT NULL,
    name VARCHAR(200) NOT NULL,
    version VARCHAR(50) NOT NULL,
    description TEXT,
    
    -- Specification details
    format VARCHAR(20) NOT NULL,
    specification JSONB NOT NULL,
    
    -- Source information
    source_platform VARCHAR(50),
    original_filename VARCHAR(255),
    file_size INTEGER,
    
    -- Validation status
    is_valid BOOLEAN DEFAULT TRUE,
    validation_errors JSONB,
    validation_warnings JSONB,
    
    -- Metadata
    paths_count INTEGER DEFAULT 0,
    operations_count INTEGER DEFAULT 0,
    definitions_count INTEGER DEFAULT 0,
    security_schemes_count INTEGER DEFAULT 0,
    
    -- Timestamps - FIXED: Using correct PostgreSQL syntax
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- ============================================
-- CREATE migration_logs TABLE
-- ============================================
CREATE TABLE migration_logs (
    id SERIAL PRIMARY KEY,
    migration_id VARCHAR(100) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    level VARCHAR(10) NOT NULL,
    stage VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    details JSONB
);

-- ============================================
-- CREATE INDEXES FOR PERFORMANCE
-- ============================================

-- migration_records indexes
CREATE INDEX idx_migration_records_migration_id ON migration_records(migration_id);
CREATE INDEX idx_migration_records_status ON migration_records(status);
CREATE INDEX idx_migration_records_created_at ON migration_records(created_at);
CREATE INDEX idx_migration_records_api_name ON migration_records(api_name);
CREATE INDEX idx_migration_records_original_api_id ON migration_records(original_api_id);

-- api_specifications indexes
CREATE INDEX idx_api_specifications_api_id ON api_specifications(api_id);
CREATE INDEX idx_api_specifications_format ON api_specifications(format);
CREATE INDEX idx_api_specifications_name ON api_specifications(name);
CREATE INDEX idx_api_specifications_created_at ON api_specifications(created_at);

-- migration_logs indexes
CREATE INDEX idx_migration_logs_migration_id ON migration_logs(migration_id);
CREATE INDEX idx_migration_logs_timestamp ON migration_logs(timestamp);
CREATE INDEX idx_migration_logs_level ON migration_logs(level);

-- ============================================
-- CREATE TRIGGER FUNCTION FOR AUTO-UPDATE TIMESTAMP
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    -- FIXED: Using NOW() which is already timezone-aware in PostgreSQL
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- CREATE TRIGGERS FOR AUTOMATIC TIMESTAMP UPDATES
-- ============================================
CREATE TRIGGER update_migration_records_updated_at
    BEFORE UPDATE ON migration_records
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_api_specifications_updated_at
    BEFORE UPDATE ON api_specifications
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- CREATE UTILITY FUNCTIONS
-- ============================================

-- Function to get database statistics
CREATE OR REPLACE FUNCTION get_migration_stats()
RETURNS TABLE(table_name text, row_count bigint, table_size text) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        'migration_records'::text,
        (SELECT COUNT(*) FROM migration_records)::bigint as row_count,
        pg_size_pretty(pg_total_relation_size('migration_records'::regclass))::text as table_size
    UNION ALL
    SELECT 
        'api_specifications'::text,
        (SELECT COUNT(*) FROM api_specifications)::bigint as row_count,
        pg_size_pretty(pg_total_relation_size('api_specifications'::regclass))::text as table_size
    UNION ALL
    SELECT 
        'migration_logs'::text,
        (SELECT COUNT(*) FROM migration_logs)::bigint as row_count,
        pg_size_pretty(pg_total_relation_size('migration_logs'::regclass))::text as table_size;
END;
$$ LANGUAGE plpgsql;

-- Function to cleanup old logs - FIXED: Using correct UTC syntax
CREATE OR REPLACE FUNCTION cleanup_old_logs(days_to_keep integer DEFAULT 30)
RETURNS integer AS $$
DECLARE
    deleted_count integer;
BEGIN
    -- Using INTERVAL for day calculation
    DELETE FROM migration_logs 
    WHERE timestamp < (NOW() - (days_to_keep || ' days')::INTERVAL)
      AND level = 'INFO';
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RAISE NOTICE 'Cleaned up % old log entries', deleted_count;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Function to get migration statistics matching the API response schema
CREATE OR REPLACE FUNCTION get_migration_statistics()
RETURNS TABLE(
    total integer,
    completed integer,
    failed integer,
    pending integer,
    success_rate numeric,
    average_completion_time real
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(*)::integer as total,
        COUNT(*) FILTER (WHERE status = 'completed')::integer as completed,
        COUNT(*) FILTER (WHERE status = 'failed')::integer as failed,
        COUNT(*) FILTER (WHERE status IN ('pending', 'in_progress'))::integer as pending,
        ROUND(
            (COUNT(*) FILTER (WHERE status = 'completed')::numeric / 
             NULLIF(COUNT(*)::numeric, 0) * 100), 2
        ) as success_rate,
        AVG(completion_time) FILTER (WHERE completion_time IS NOT NULL)::real as average_completion_time
    FROM migration_records;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- CREATE VIEWS
-- ============================================

-- Dashboard view for migration overview
CREATE OR REPLACE VIEW migration_dashboard AS
SELECT 
    COUNT(*) FILTER (WHERE status = 'completed') AS completed_migrations,
    COUNT(*) FILTER (WHERE status = 'failed') AS failed_migrations,
    COUNT(*) FILTER (WHERE status = 'in_progress') AS in_progress_migrations,
    COUNT(*) FILTER (WHERE status = 'pending') AS pending_migrations,
    COUNT(*) AS total_migrations,
    ROUND(
        (COUNT(*) FILTER (WHERE status = 'completed')::numeric / 
         NULLIF(COUNT(*), 0) * 100), 2
    ) AS success_rate,
    AVG(completion_time) FILTER (WHERE completion_time IS NOT NULL) AS avg_completion_time
FROM migration_records;

-- Recent migrations view
CREATE OR REPLACE VIEW recent_migrations AS
SELECT 
    migration_id,
    api_name,
    status,
    source_platform,
    target_platform,
    completion_time,
    created_at,
    updated_at
FROM migration_records
ORDER BY created_at DESC
LIMIT 100;

-- Migration statistics by status
CREATE OR REPLACE VIEW migration_status_breakdown AS
SELECT 
    status,
    COUNT(*) as count,
    ROUND(COUNT(*)::numeric / (SELECT COUNT(*) FROM migration_records) * 100, 2) as percentage,
    AVG(completion_time) FILTER (WHERE completion_time IS NOT NULL) as avg_time
FROM migration_records
GROUP BY status;

-- ============================================
-- SET DATABASE TIMEZONE (SYSTEM DEFAULT)
-- ============================================
ALTER DATABASE api_migration_db SET timezone = 'UTC';

-- ============================================
-- VERIFY CONFIGURATION
-- ============================================
-- Run this to verify: SELECT NOW();
-- Should return current time in UTC with +00:00 offset

COMMIT;

-- ============================================
-- FINAL NOTIFICATIONS
-- ============================================
DO $$
BEGIN
    RAISE NOTICE '============================================================';
    RAISE NOTICE 'API Migration Tool Database Schema Created Successfully';
    RAISE NOTICE '============================================================';
    RAISE NOTICE '';
    RAISE NOTICE 'Database Configuration:';
    RAISE NOTICE '  - Timezone: UTC';
    RAISE NOTICE '  - Timestamp Format: TIMESTAMP WITH TIME ZONE';
    RAISE NOTICE '  - Python Compatibility: 3.12+ (datetime.now(timezone.utc))';
    RAISE NOTICE '';
    RAISE NOTICE 'Tables Created:';
    RAISE NOTICE '  1. migration_records - Tracks API migration operations';
    RAISE NOTICE '  2. api_specifications - Stores API specifications';
    RAISE NOTICE '  3. migration_logs - Detailed migration logs';
    RAISE NOTICE '';
    RAISE NOTICE 'Views Created:';
    RAISE NOTICE '  1. migration_dashboard - Overview statistics';
    RAISE NOTICE '  2. recent_migrations - Last 100 migrations';
    RAISE NOTICE '  3. migration_status_breakdown - Status distribution';
    RAISE NOTICE '';
    RAISE NOTICE 'Functions Created:';
    RAISE NOTICE '  1. get_migration_stats() - Database size statistics';
    RAISE NOTICE '  2. cleanup_old_logs(days) - Archive old logs';
    RAISE NOTICE '  3. get_migration_statistics() - Migration metrics';
    RAISE NOTICE '';
    RAISE NOTICE 'Indexes Created: 12 indexes for optimal query performance';
    RAISE NOTICE '';
    RAISE NOTICE 'Key Features:';
    RAISE NOTICE '  ✓ UTC timezone-aware timestamps';
    RAISE NOTICE '  ✓ Automatic updated_at trigger';
    RAISE NOTICE '  ✓ JSONB support for flexible metadata';
    RAISE NOTICE '  ✓ Full-text search support';
    RAISE NOTICE '  ✓ Performance optimizations with indexes';
    RAISE NOTICE '';
    RAISE NOTICE 'Verification Commands:';
    RAISE NOTICE '  1. Verify timezone: SELECT NOW();';
    RAISE NOTICE '  2. Check tables: \dt';
    RAISE NOTICE '  3. Check indexes: \di';
    RAISE NOTICE '  4. Check views: \dv';
    RAISE NOTICE '';
    RAISE NOTICE 'Next Steps:';
    RAISE NOTICE '  1. Run this script: psql -U api_user -d api_migration_db -f 01_init_schema_UTC_FIXED.sql';
    RAISE NOTICE '  2. Test connection from Python application';
    RAISE NOTICE '  3. Verify: python -c "from models import utc_now; print(utc_now())"';
    RAISE NOTICE '';
    RAISE NOTICE '============================================================';
END $$;