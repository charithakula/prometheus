"""
ENHANCED UNIVERSAL CHAT ASSISTANT PROMPTS
Supports: Code Generation, API Analysis, Policy Work, Documentation, Security

Replaces the limited policy-only approach with comprehensive chat capabilities
"""

import re

# ==========================================
# SYSTEM PROMPTS FOR ALL DOMAINS
# ==========================================

SYSTEM_PROMPTS = {
    # ✅ CODE GENERATION & DEVELOPMENT
    'code_expert': """You are an expert software architect and full-stack developer.
You excel at:
- Writing production-ready code in multiple languages (Python, JavaScript, Java, C#, Go, Rust, etc.)
- Implementing best practices, design patterns, and SOLID principles
- Creating scalable, maintainable, and well-documented code
- Debugging and optimizing existing code
- Explaining complex concepts clearly
- Providing security-first implementations

Always:
- Use the latest language best practices
- Include proper error handling and logging
- Add comprehensive comments for complex logic
- Consider performance and scalability
- Include unit test examples
- Suggest improvements for code quality""",

    'code_reviewer': """You are an expert code reviewer and quality assurance specialist.
Analyze code for:
- Correctness and logic errors
- Performance bottlenecks and optimization opportunities
- Security vulnerabilities (SQL injection, XSS, CSRF, etc.)
- Code style and readability improvements
- Design pattern violations
- Missing error handling
- Testing gaps
- Documentation deficiencies

Provide:
- Specific line-by-line feedback
- Risk assessment (critical, high, medium, low)
- Concrete improvement suggestions
- Refactored code examples
- Reference to best practices""",

    'api_architect': """You are an expert API architect and integration specialist.
Design and analyze APIs for:
- RESTful principles and best practices
- GraphQL optimization
- Security (OAuth2, JWT, API keys, CORS)
- Rate limiting and throttling
- Versioning strategies
- Error handling and status codes
- Documentation (OpenAPI/Swagger)
- Performance and caching
- Monitoring and logging

Provide complete, production-ready specifications.""",

    # ✅ POLICY & COMPLIANCE
    'policy_expert': """You are an expert API architect and security consultant.
Analyze policies for:
- Security requirements and vulnerabilities
- Compliance with standards (OWASP, GDPR, SOC2)
- Rate limiting and usage policies
- Authentication and authorization
- Data protection and privacy
- Best practices and recommendations
- OpenAPI specification generation

Provide detailed, actionable guidance.""",

    # ✅ DOCUMENTATION & COMMUNICATION
    'technical_writer': """You are an expert technical writer and API documentarian.
Create documentation that is:
- Clear and concise for different audiences
- Well-structured with examples
- Complete with code samples
- Professionally formatted
- Easy to follow and reference
- SEO-friendly where applicable

Include:
- Getting started guides
- API reference documentation
- Code examples in multiple languages
- Troubleshooting guides
- FAQ sections""",

    # ✅ GENERAL INTELLIGENT ASSISTANT
    'intelligent_assistant': """You are a comprehensive intelligent assistant.
You adapt to any task:
- Answer technical questions accurately
- Provide strategic guidance
- Suggest improvements and optimizations
- Think critically about problems
- Consider edge cases and risks
- Ask clarifying questions when needed
- Provide step-by-step solutions

Always:
- Be thorough but concise
- Consider context and constraints
- Suggest best practices
- Reference standards and guidelines"""
}

# ==========================================
# DYNAMIC ASSISTANT ROUTER
# ==========================================

ASSISTANT_TYPES = {
    'code': {
        'keywords': ['code', 'write', 'function', 'class', 'implement', 'script', 'algorithm', 
                    'python', 'javascript', 'java', 'go', 'rust', 'typescript', 'method', 'logic'],
        'system_prompt': SYSTEM_PROMPTS['code_expert'],
        'temperature': 0.5,
        'max_tokens': 4000,
        'description': '💻 Code Generation & Development'
    },
    
    'code_review': {
        'keywords': ['review', 'refactor', 'improve', 'optimize', 'fix', 'debug', 'analyze code',
                    'issue', 'bug', 'error', 'performance', 'security', 'quality'],
        'system_prompt': SYSTEM_PROMPTS['code_reviewer'],
        'temperature': 0.3,
        'max_tokens': 3000,
        'description': '🔍 Code Review & Optimization'
    },
    
    'api_design': {
        'keywords': ['api', 'endpoint', 'rest', 'graphql', 'openapi', 'swagger', 'http',
                    'request', 'response', 'integration', 'microservice', 'design', 'architecture'],
        'system_prompt': SYSTEM_PROMPTS['api_architect'],
        'temperature': 0.6,
        'max_tokens': 3500,
        'description': '🏗️ API Design & Architecture'
    },
    
    'policy': {
        'keywords': ['policy', 'security', 'compliance', 'governance', 'requirement', 'standard',
                    'oauth', 'jwt', 'cors', 'authentication', 'authorization', 'rate limit'],
        'system_prompt': SYSTEM_PROMPTS['policy_expert'],
        'temperature': 0.6,
        'max_tokens': 4000,
        'description': '🔐 Policy & Compliance'
    },
    
    'documentation': {
        'keywords': ['document', 'guide', 'readme', 'tutorial', 'example', 'reference',
                    'explain', 'how to', 'step by step', 'guide', 'walkthrough'],
        'system_prompt': SYSTEM_PROMPTS['technical_writer'],
        'temperature': 0.7,
        'max_tokens': 3000,
        'description': '📚 Documentation & Guides'
    },
    
    'general': {
        'keywords': [],  # Fallback for anything not covered
        'system_prompt': SYSTEM_PROMPTS['intelligent_assistant'],
        'temperature': 0.7,
        'max_tokens': 3000,
        'description': '🤖 General Assistant'
    }
}

# ==========================================
# SPECIALIZED PROMPTS BY DOMAIN
# ==========================================

# CODE GENERATION PROMPTS
CODE_GENERATION_PROMPTS = {
    'api_client': """Generate a production-ready {language} API client library.

Requirements:
- Base URL: {base_url}
- Authentication: {auth_type}
- Error handling with custom exceptions
- Rate limiting support
- Request/response logging
- Connection pooling
- Retry logic with exponential backoff
- Type hints/documentation
- Unit tests

Output complete, ready-to-use code.""",

    'rest_endpoint': """Implement a REST API endpoint in {language}.

Specifications:
- Method: {http_method}
- Path: {path}
- Request schema: {request_schema}
- Response schema: {response_schema}
- Status codes: {status_codes}
- Error handling: {error_handling}
- Authentication: {auth_type}
- Rate limits: {rate_limit}

Include:
- Input validation
- Error handling
- Logging
- Security measures
- Unit tests""",

    'database_model': """Generate a database model/ORM class in {language}.

Specifications:
- Database type: {db_type}
- Table/Collection name: {table_name}
- Fields: {fields}
- Relationships: {relationships}
- Indexes: {indexes}
- Validations: {validations}

Include:
- Proper typing/annotations
- CRUD methods
- Query helpers
- Migration support
- Error handling""",

    'middleware': """Implement a {middleware_type} middleware in {language}.

Requirements:
- Purpose: {purpose}
- Integration point: {integration}
- Configuration options: {config}
- Error scenarios: {error_scenarios}

Include:
- Clean implementation
- Proper logging
- Performance considerations
- Security aspects
- Configuration examples""",

    'async_handler': """Create an async {language} handler for {use_case}.

Requirements:
- Concurrency model: {concurrency_model}
- Error handling: {error_handling}
- Timeout behavior: {timeout}
- Retry policy: {retry_policy}
- Monitoring: {monitoring}

Include:
- Proper async/await patterns
- Exception handling
- Resource cleanup
- Performance optimization
- Usage examples"""
}

# API ANALYSIS PROMPTS
API_ANALYSIS_PROMPTS = {
    'api_review': """Provide comprehensive API review and recommendations.

API Specification:
{spec}

Analyze:
1. **Design Quality** - RESTful principles, consistency, intuitive design
2. **Security** - Authentication, authorization, data protection, CORS
3. **Performance** - Caching, pagination, rate limiting, efficient queries
4. **Error Handling** - Status codes, error messages, consistency
5. **Documentation** - Clarity, completeness, examples
6. **Versioning** - Strategy, backward compatibility, deprecation
7. **Testing** - Coverage, edge cases, security tests
8. **Monitoring** - Logging, metrics, debugging support

Provide:
- Overall assessment (score 1-10)
- Critical issues (must fix)
- Recommendations (should implement)
- Improvements (nice to have)
- Risk assessment
- Implementation roadmap""",

    'openapi_generation': """Generate complete OpenAPI 3.0 specification from description.

API Details:
- Name: {api_name}
- Version: {version}
- Base URL: {base_url}
- Description: {description}
- Endpoints: {endpoints}
- Authentication: {auth}
- Rate Limits: {rate_limits}

Generate:
- Valid OpenAPI 3.0 JSON
- Complete endpoint definitions
- Request/response schemas
- Security schemes
- Examples and use cases
- Server configurations

Return ONLY valid JSON - no markdown or explanations.""",

    'integration_guide': """Create integration guide for consuming this API.

API Info:
{api_info}

Include:
1. **Setup** - Installation, configuration, prerequisites
2. **Authentication** - How to get credentials, token management
3. **Basic Usage** - Simple examples to get started
4. **Advanced Usage** - Complex scenarios, patterns, optimization
5. **Error Handling** - Common errors and solutions
6. **Rate Limiting** - How to handle limits, retry strategies
7. **Best Practices** - Performance, security, reliability
8. **Troubleshooting** - Common issues and debugging
9. **Examples** - Real-world code samples (Python, JavaScript, etc.)
10. **FAQ** - Common questions

Code examples in multiple languages."""
}

# SECURITY ANALYSIS PROMPTS
SECURITY_PROMPTS = {
    'security_audit': """Conduct comprehensive security audit of API/Code.

Target:
{target}

Analyze:
1. **Authentication & Authorization** - Vulnerabilities, enforcement
2. **Data Protection** - Encryption, PII handling, data leaks
3. **Input Validation** - Injection attacks, buffer overflows, fuzzing
4. **Output Encoding** - XSS, CSRF, security headers
5. **Session Management** - Token handling, CORS, cookie security
6. **API Security** - Rate limiting, resource limits, DoS protection
7. **Dependency Security** - Vulnerable libraries, version issues
8. **Infrastructure** - TLS/SSL, network security, secrets management
9. **Compliance** - OWASP Top 10, GDPR, industry standards
10. **Incident Response** - Error handling, logging, alerting

For each issue:
- Severity (Critical/High/Medium/Low)
- Description and impact
- Specific remediation steps
- Risk if not fixed
- Verification method""",

    'policy_implementation': """Generate security policy implementation code.

Policy Requirements:
{policy}

Implement in {language}:
1. **Authentication** - Strategy and implementation
2. **Authorization** - Role-based/attribute-based access control
3. **Rate Limiting** - Per-user, per-endpoint limits
4. **Encryption** - Data at rest and in transit
5. **Validation** - Input validation rules
6. **Logging** - Security event logging
7. **Monitoring** - Anomaly detection, alerting
8. **Recovery** - Disaster recovery, backup strategy

Include:
- Complete, production-ready code
- Configuration files
- Deployment instructions
- Testing procedures
- Monitoring setup"""
}

# POLICY ANALYSIS PROMPTS
POLICY_ANALYSIS_PROMPTS = {
    'policy_review': """Comprehensive policy analysis and recommendations.

Policy Document:
{policy_text}

Analyze:
1. **Compliance** - Standards adherence, gaps, risks
2. **Security** - Authentication, authorization, encryption
3. **Rate Limiting** - Fairness, DDoS protection, abuse prevention
4. **Error Handling** - Clear error messages, debugging support
5. **Documentation** - Clarity, completeness, examples
6. **Versioning** - Strategy, backward compatibility, sunset policy
7. **Monitoring** - Logging requirements, metrics, SLA
8. **Best Practices** - Industry standards, recommendations
9. **Implementation** - How to implement each requirement
10. **Testing** - Test cases, validation procedures

Provide:
- Executive summary
- Detailed analysis by section
- Risk assessment matrix
- Priority action items
- Implementation roadmap
- Success criteria""",

    'openapi_conversion': """Convert policy document to OpenAPI specification.

Policy:
{policy_text}

Extract and generate:
1. Base information (title, version, description)
2. All endpoints with methods and paths
3. Request/response schemas
4. Security schemes
5. Rate limit definitions
6. Error responses
7. Authentication requirements
8. Example use cases

Return: Valid OpenAPI 3.0 JSON only.""",

    'compliance_assessment': """Assess policy compliance with standards.

Policy Document:
{policy_text}

Check against:
- OWASP API Top 10
- OAuth 2.0 Security Best Practices
- OpenAPI/Swagger Standards
- REST API Best Practices
- Security Headers Checklist
- Rate Limiting Patterns
- Error Handling Guidelines
- Logging Standards

For each standard:
- Compliance status (✅/⚠️/❌)
- Current implementation
- Gaps or issues
- Remediation steps
- Priority level"""
}

# DOCUMENTATION PROMPTS
DOCUMENTATION_PROMPTS = {
    'api_documentation': """Generate complete API documentation.

API Specification:
{spec}

Create:
1. **Overview** - What the API does, key features, use cases
2. **Getting Started** - Setup, prerequisites, first call
3. **Authentication** - How to authenticate, token management
4. **Base Endpoint** - URL structure, versioning
5. **Endpoints Reference** - Each endpoint with examples
6. **Request/Response** - Schemas, examples, error codes
7. **Rate Limits** - Limits, headers, retry strategy
8. **Best Practices** - Performance, security, reliability tips
9. **Code Examples** - Python, JavaScript, cURL samples
10. **FAQ** - Common questions and solutions
11. **Troubleshooting** - Common issues and fixes

Use Markdown format with clear structure.""",

    'quick_start_guide': """Create quick start guide for {use_case}.

Context:
{context}

Include:
1. **Prerequisites** - What's needed
2. **Installation** - Step-by-step setup
3. **Configuration** - Required settings
4. **First Steps** - Minimal working example
5. **Common Tasks** - How to do common things
6. **Debugging** - Troubleshooting tips
7. **Next Steps** - Where to go from here

- Clear, concise language
- Copy-paste code examples
- Assume beginner knowledge
- Real-world, practical focus""",

    'implementation_guide': """Create detailed implementation guide.

Requirements:
{requirements}

Document:
1. **Architecture** - System design, components, flow
2. **Setup** - Installation, configuration, deployment
3. **Implementation** - Step-by-step how to build it
4. **Configuration** - Settings, parameters, customization
5. **Testing** - How to verify it works
6. **Deployment** - Going to production
7. **Monitoring** - Observability and alerting
8. **Troubleshooting** - Common issues and solutions
9. **Security** - Security considerations
10. **Performance** - Optimization tips

Include diagrams, code examples, checklists."""
}

# ==========================================
# SMART ASSISTANT DETECTION
# ==========================================

def detect_assistant_type(user_message, file_info=None):
    """
    Intelligently detect which assistant type to use
    Returns: (assistant_type, confidence_score, reason)
    """
    message_lower = user_message.lower()
    file_name_lower = (file_info.get('filename', '') if file_info else '').lower()
    
    scores = {}
    
    # Score each assistant type
    for assistant_name, config in ASSISTANT_TYPES.items():
        if assistant_name == 'general':
            continue
        
        score = 0
        keywords = config['keywords']
        
        # Check keywords in message
        for keyword in keywords:
            if keyword in message_lower:
                score += 2
        
        # Check keywords in filename
        if file_info:
            for keyword in keywords:
                if keyword in file_name_lower:
                    score += 1
        
        scores[assistant_name] = score
    
    # Get highest scoring assistant
    if scores and max(scores.values()) > 0:
        best_assistant = max(scores, key=scores.get)
        confidence = scores[best_assistant] / 5.0  # Normalize to 0-1
        return best_assistant, min(confidence, 1.0), f"Detected: {ASSISTANT_TYPES[best_assistant]['description']}"
    
    return 'general', 0.5, "Using general assistant"

# ==========================================
# PROMPT BUILDER FOR ALL DOMAINS
# ==========================================

class UniversalPromptBuilder:
    """Build prompts for any domain"""
    
    @staticmethod
    def build_code_generation(language, task_description, requirements=None):
        """Build code generation prompt"""
        requirements_text = f"\n\nDetailed Requirements:\n{requirements}" if requirements else ""
        
        return f"""Generate production-ready {language} code for the following task:

Task: {task_description}
{requirements_text}

Code should:
- Follow {language} best practices and conventions
- Include proper error handling and logging
- Have type hints/documentation
- Include meaningful comments
- Be scalable and maintainable
- Include basic unit tests or test examples

Output: Complete, working code ready for production."""

    @staticmethod
    def build_code_review(code, language, focus_areas=None):
        """Build code review prompt"""
        focus_text = f"\n\nFocus on: {focus_areas}" if focus_areas else ""
        
        return f"""Review this {language} code thoroughly:

```{language}
{code}
```
{focus_text}

Provide:
1. **Issues Found** - Bugs, logic errors, edge cases
2. **Performance** - Optimization opportunities
3. **Security** - Vulnerabilities, safe practices
4. **Code Quality** - Style, readability, maintainability
5. **Best Practices** - Design patterns, SOLID principles
6. **Tests** - Coverage gaps, test suggestions
7. **Refactoring** - Improved version with explanations

For each issue, explain: what, why, and how to fix."""

    @staticmethod
    def build_api_design(endpoints, base_url, auth_type=None):
        """Build API design prompt"""
        return f"""Design a comprehensive API specification:

Base URL: {base_url}
Endpoints to implement: {endpoints}
Authentication: {auth_type or 'To be determined'}

Provide:
1. **Overall Structure** - URL patterns, versioning
2. **Each Endpoint** - Method, path, description
3. **Schemas** - Request/response structures
4. **Error Handling** - Error codes and messages
5. **Security** - Authentication, rate limiting, CORS
6. **Performance** - Caching, pagination strategies
7. **Examples** - cURL and code examples
8. **OpenAPI Spec** - Valid OpenAPI 3.0 specification

Design should be:
- RESTful and intuitive
- Scalable and extensible
- Well-documented
- Security-first
- Developer-friendly"""

    @staticmethod
    def build_security_analysis(target, target_type='api'):
        """Build security analysis prompt"""
        return f"""Conduct comprehensive security analysis of this {target_type}:

{target}

Identify and report:
1. **Vulnerabilities** - OWASP Top 10, CWE common weakness
2. **Security Gaps** - Missing protections, weak implementations
3. **Compliance Issues** - Standard violations, best practice failures
4. **Risk Assessment** - Impact and likelihood for each issue
5. **Recommendations** - Specific remediation steps
6. **Implementation** - Code examples for fixes
7. **Verification** - How to verify fixes work

For each finding:
- Severity level (Critical/High/Medium/Low)
- Description and impact
- Technical details and examples
- Step-by-step fix
- How to prevent recurrence"""

    @staticmethod
    def build_policy_analysis(policy_text):
        """Build policy analysis prompt"""
        return f"""Perform comprehensive analysis of this policy:

{policy_text}

Analyze:
1. **Compliance** - Standards adherence (OWASP, OAuth2, etc.)
2. **Security** - Auth, data protection, rate limiting requirements
3. **Completeness** - Coverage gaps, missing requirements
4. **Clarity** - Ambiguities, unclear requirements
5. **Feasibility** - Implementation complexity, effort estimate
6. **Best Practices** - Alignment with industry standards
7. **Risks** - Security risks if not implemented correctly
8. **Priority** - Which requirements are critical vs. nice-to-have

Provide:
- Executive summary
- Detailed analysis with examples
- Risk matrix
- Implementation roadmap
- Success criteria"""

    @staticmethod
    def build_documentation(subject, subject_type='api'):
        """Build documentation prompt"""
        return f"""Create professional documentation for this {subject_type}:

{subject}

Documentation should include:
1. **Overview** - Clear description of what it does
2. **Getting Started** - Step-by-step setup guide
3. **Basic Usage** - Simple example to get started
4. **Advanced Usage** - Complex scenarios and patterns
5. **Configuration** - All settings and options
6. **API Reference** - Complete endpoint/function reference
7. **Examples** - Real-world code samples
8. **Troubleshooting** - Common issues and solutions
9. **FAQ** - Frequently asked questions
10. **Best Practices** - Tips for optimal usage

Use clear, professional writing.
Include code examples where relevant.
Assume developer audience."""

# ==========================================
# CONFIGURATION & SETTINGS
# ==========================================

CHAT_CONFIG = {
    'max_file_size': 10 * 1024 * 1024,  # 10MB
    'supported_file_types': ['pdf', 'docx', 'doc', 'txt', 'py', 'js', 'java', 'go', 'rs', 'ts', 'json', 'yaml', 'yml', 'sql'],
    'max_code_length': 50000,  # chars
    'max_policy_length': 100000,  # chars
    'code_languages': ['python', 'javascript', 'typescript', 'java', 'c#', 'go', 'rust', 'php', 'ruby', 'swift', 'kotlin', 'scala'],
    'conversation_history_limit': 20,  # messages to keep
    'response_timeout': 120,  # seconds
}

# ==========================================
# EXAMPLE USAGE
# ==========================================

"""
USAGE IN FLASK APP:

from enhanced_prompts import UniversalPromptBuilder, detect_assistant_type, ASSISTANT_TYPES, CHAT_CONFIG

def handle_universal_chat(message, file_info=None):
    # Detect assistant type
    assistant_type, confidence, reason = detect_assistant_type(message, file_info)
    config = ASSISTANT_TYPES[assistant_type]
    
    # Get system prompt and LLM settings
    system_prompt = config['system_prompt']
    temperature = config['temperature']
    max_tokens = config['max_tokens']
    
    # Build appropriate prompt based on assistant type
    if assistant_type == 'code':
        user_prompt = UniversalPromptBuilder.build_code_generation(
            language='python',
            task_description=message
        )
    elif assistant_type == 'code_review':
        user_prompt = UniversalPromptBuilder.build_code_review(
            code=file_info.get('content') if file_info else message,
            language='python',
            focus_areas='security and performance'
        )
    elif assistant_type == 'api_design':
        user_prompt = UniversalPromptBuilder.build_api_design(
            endpoints=message,
            base_url='https://api.example.com'
        )
    # ... etc for other types
    
    # Call Azure OpenAI with appropriate settings
    params = openai_connector._build_chat_completion_params(
        deployment=openai_connector.config.OPENAI_DEPLOYMENT,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=temperature,
        max_tokens=max_tokens
    )
    
    response = openai_connector._client.chat.completions.create(**params)
    return response.choices[0].message.content
"""