"""
Pydantic schemas for data validation and serialization
Contains schemas for API requests and responses
Updated for Pydantic v2 compatibility with all alignment fixes
"""
from typing import Dict, Any, List, Optional, Union
from datetime import datetime
from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict
from enum import Enum

class MigrationStatus(str, Enum):
    """Migration status enumeration"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    EXTRACTING = "extracting"
    CONVERTING = "converting"
    DEPLOYING = "deploying"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"

class APIFormat(str, Enum):
    """API specification format enumeration"""
    OPENAPI_2_0 = "openapi_2.0"
    OPENAPI_3_0 = "openapi_3.0"
    SWAGGER_2_0 = "swagger_2.0"

class ConversionMethod(str, Enum):
    """Conversion method enumeration"""
    AI = "ai"
    FALLBACK = "fallback"

# Base schemas
class BaseSchema(BaseModel):
    """Base schema with common configuration"""
    
    model_config = ConfigDict(
        extra="forbid",
        use_enum_values=True,
        json_encoders={
            datetime: lambda dt: dt.isoformat()
        }
    )

# API Information Schemas
class APIInfoSchema(BaseSchema):
    """Schema for API information"""
    title: str = Field(..., min_length=1, max_length=200)
    version: str = Field(..., min_length=1, max_length=50)
    description: Optional[str] = Field(None, max_length=1000)

class ServerSchema(BaseSchema):
    """Schema for API server information"""
    url: str = Field(..., min_length=1)
    description: Optional[str] = None

# Validation Schemas
class ValidationResultSchema(BaseSchema):
    """Schema for API specification validation results"""
    is_valid: bool
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    version: str
    summary: str

class ConversionMetadataSchema(BaseSchema):
    """Schema for conversion metadata"""
    api_title: str
    api_version: str
    api_description: Optional[str] = ""
    original_paths_count: int = Field(ge=0)
    converted_paths_count: int = Field(ge=0)
    original_definitions_count: int = Field(ge=0)
    converted_schemas_count: int = Field(ge=0)
    has_security: bool = False
    servers_created: int = Field(ge=0)
    conversion_timestamp: str
    target_servers: List[str] = Field(default_factory=list)

# Request Schemas
class ConversionRequestSchema(BaseSchema):
    """Schema for API conversion requests"""
    spec_content: str = Field(..., min_length=1)
    source_format: Optional[str] = Field("auto", pattern="^(auto|json|yaml|yml)$")
    include_debug: Optional[bool] = Field(False)
    
    @field_validator('spec_content')
    @classmethod
    def validate_spec_content(cls, v):
        if len(v.strip()) == 0:
            raise ValueError('Specification content cannot be empty')
        return v

class MigrationRequestSchema(BaseSchema):
    """Schema for API migration requests"""
    api_ids: Union[str, List[str]] = Field(..., description="Single API ID or list of API IDs")
    org_name: Optional[str] = Field(None, max_length=100)
    catalog_name: Optional[str] = Field(None, max_length=100)
    options: Optional[Dict[str, Any]] = Field(default_factory=dict)
    
    @field_validator('api_ids', mode='before')
    @classmethod
    def validate_api_ids(cls, v):
        if isinstance(v, str):
            if not v.strip():
                raise ValueError('API ID cannot be empty')
            return [v.strip()]
        elif isinstance(v, list):
            if not v:
                raise ValueError('API IDs list cannot be empty')
            return [id.strip() if isinstance(id, str) else id for id in v]
        else:
            raise ValueError('API IDs must be string or list of strings')

class BatchMigrationRequestSchema(BaseSchema):
    """Schema for batch migration requests"""
    migration_type: str = Field(..., pattern="^(apis|catalog)$")
    api_ids: Optional[List[str]] = Field(None, min_length=1)
    org_name: Optional[str] = Field(None, max_length=100)
    catalog_name: Optional[str] = Field(None, max_length=100)
    options: Optional[Dict[str, Any]] = Field(default_factory=dict)
    
    @model_validator(mode='after')
    def validate_migration_requirements(self):
        """Validate that required fields are set based on migration type"""
        if self.migration_type == 'apis' and not self.api_ids:
            raise ValueError('API IDs are required for APIs migration type')
        if self.migration_type == 'catalog' and not self.catalog_name:
            raise ValueError('Catalog name is required for catalog migration type')
        return self

class FileUploadSchema(BaseSchema):
    """Schema for file upload validation"""
    filename: str = Field(..., min_length=1, max_length=255)
    content_type: str = Field(..., pattern="^(application/json|application/x-yaml|text/yaml|text/plain)$")
    file_size: int = Field(..., gt=0, le=16*1024*1024)  # Max 16MB
    
    @field_validator('filename')
    @classmethod
    def validate_filename(cls, v):
        """Validate filename has proper extension"""
        allowed_extensions = ('.json', '.yaml', '.yml', '.txt')
        if not any(v.lower().endswith(ext) for ext in allowed_extensions):
            raise ValueError(f'Filename must end with one of: {", ".join(allowed_extensions)}')
        return v

class DeploymentRequestSchema(BaseSchema):
    """Schema for Azure APIM deployment requests"""
    converted_spec: Dict[str, Any] = Field(...)
    original_api_id: str = Field(..., min_length=1)
    options: Optional[Dict[str, Any]] = Field(default_factory=dict)
    
    @field_validator('converted_spec')
    @classmethod
    def validate_spec_has_required_fields(cls, v):
        """Ensure converted spec has required OpenAPI 3.0 fields"""
        required = ['openapi', 'info', 'paths']
        for field in required:
            if field not in v:
                raise ValueError(f'Converted spec missing required field: {field}')
        return v

# Response Schemas
class ConversionResponseSchema(BaseSchema):
    """Schema for API conversion responses"""
    status: str = Field(..., pattern="^(success|error)$")
    message: str
    original_spec: Optional[Dict[str, Any]] = None
    converted_spec: Optional[Dict[str, Any]] = None
    source_format: Optional[str] = None
    target_format: Optional[str] = None
    conversion_time_seconds: float = Field(ge=0)
    ai_conversion_used: bool = False
    raw_openai_response: Optional[str] = None
    cleaned_json: Optional[str] = None
    cleaning_issues: Optional[str] = None
    validation: Optional[Dict[str, Any]] = None
    conversion_metadata: Optional[ConversionMetadataSchema] = None

class DeploymentResultSchema(BaseSchema):
    """Schema for Azure APIM deployment results"""
    status: str = Field(..., pattern="^(success|error)$")
    api_id: Optional[str] = None
    display_name: Optional[str] = None
    path: Optional[str] = None
    service_url: Optional[str] = None
    management_url: Optional[str] = None
    developer_portal_url: Optional[str] = None
    message: str

class MigrationResponseSchema(BaseSchema):
    """Schema for single API migration responses"""
    status: str = Field(..., pattern="^(success|error)$")
    migration_id: str
    api_id: str
    original_api_info: Optional[Dict[str, Any]] = None
    converted_spec_preview: Optional[Dict[str, Any]] = None
    azure_deployment: Optional[DeploymentResultSchema] = None
    migration_time_seconds: float = Field(ge=0)
    conversion_metadata: Optional[ConversionMetadataSchema] = None
    validation_results: Optional[Dict[str, Any]] = None
    message: str

class BatchMigrationResponseSchema(BaseSchema):
    """Schema for batch migration responses"""
    status: str = Field(..., pattern="^(completed|in_progress)$")
    batch_id: str
    total_apis: int = Field(ge=0)
    successful_migrations: int = Field(ge=0)
    failed_migrations: int = Field(ge=0)
    batch_time_seconds: float = Field(ge=0)
    average_time_per_migration: float = Field(ge=0)
    results: List[MigrationResponseSchema]
    summary: str

# Database Model Schemas
class MigrationRecordSchema(BaseSchema):
    """Schema for migration record data - aligned with database model"""
    id: Optional[int] = None
    migration_id: str = Field(..., min_length=1, max_length=100)
    original_api_id: str = Field(..., min_length=1, max_length=100)
    azure_api_id: Optional[str] = Field(None, max_length=100)
    api_name: Optional[str] = Field(None, max_length=200)
    api_version: Optional[str] = Field(None, max_length=50)
    status: MigrationStatus = MigrationStatus.PENDING
    source_platform: str = "ibm_api_connect"
    target_platform: str = "azure_apim"
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    completion_time: Optional[float] = Field(None, ge=0)
    original_filename: Optional[str] = Field(None, max_length=255)
    converted_filename: Optional[str] = Field(None, max_length=255)
    file_size: Optional[int] = Field(None, ge=0)
    conversion_method: Optional[ConversionMethod] = None
    conversion_time: Optional[float] = Field(None, ge=0)
    ai_conversion_used: bool = False
    conversion_notes: Optional[str] = None
    error_message: Optional[str] = None
    validation_results: Optional[Dict[str, Any]] = None
    migration_metadata: Optional[Dict[str, Any]] = None  # ALIGNED: Fixed naming
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class APISpecificationSchema(BaseSchema):
    """Schema for API specification data - aligned with database model"""
    id: Optional[int] = None
    api_id: str = Field(..., min_length=1, max_length=100)
    name: str = Field(..., min_length=1, max_length=200)
    version: str = Field(..., min_length=1, max_length=50)
    description: Optional[str] = None
    format: APIFormat
    specification: Dict[str, Any]
    source_platform: Optional[str] = None
    original_filename: Optional[str] = Field(None, max_length=255)
    file_size: Optional[int] = Field(None, ge=0)
    is_valid: bool = True
    validation_errors: Optional[List[str]] = None
    validation_warnings: Optional[List[str]] = None
    paths_count: int = Field(ge=0, default=0)
    operations_count: int = Field(ge=0, default=0)
    definitions_count: int = Field(ge=0, default=0)
    security_schemes_count: int = Field(ge=0, default=0)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class MigrationLogSchema(BaseSchema):
    """Schema for migration log entries - aligned with database model"""
    id: Optional[int] = None
    migration_id: str = Field(..., min_length=1, max_length=100)
    timestamp: Optional[datetime] = None
    level: str = Field(..., pattern="^(INFO|WARNING|ERROR)$")
    stage: str = Field(..., min_length=1, max_length=50)
    message: str = Field(..., min_length=1)
    details: Optional[Dict[str, Any]] = None

# Statistics Schemas
class MigrationStatisticsSchema(BaseSchema):
    """Schema for migration statistics"""
    total_migrations: int = Field(ge=0)
    completed: int = Field(ge=0)
    failed: int = Field(ge=0)
    pending: int = Field(ge=0)
    success_rate: float = Field(ge=0, le=100)
    average_completion_time: float = Field(ge=0)

class ServiceStatusSchema(BaseSchema):
    """Schema for service connection status"""
    status: str = Field(..., pattern="^(success|error)$")
    message: str
    service_name: Optional[str] = None
    api_count: Optional[int] = None
    model: Optional[str] = None

class PrerequisitesValidationSchema(BaseSchema):
    """Schema for migration prerequisites validation"""
    all_services_available: bool
    service_status: Dict[str, ServiceStatusSchema]
    can_migrate: bool
    recommendations: List[str]

# Error Schemas
class ErrorResponseSchema(BaseSchema):
    """Schema for error responses"""
    status: str = Field("error")
    message: str
    error_code: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class ValidationErrorSchema(BaseSchema):
    """Schema for validation error responses"""
    status: str = Field("validation_error")
    message: str = "Validation failed"
    errors: List[Dict[str, Any]]
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# Pagination Schemas
class PaginationSchema(BaseSchema):
    """Schema for pagination parameters"""
    limit: int = Field(50, ge=1, le=100)
    offset: int = Field(0, ge=0)

class PaginatedResponseSchema(BaseSchema):
    """Schema for paginated responses"""
    items: List[Dict[str, Any]]
    total_count: int = Field(ge=0)
    limit: int = Field(ge=1)
    offset: int = Field(ge=0)
    has_next: bool
    has_prev: bool

# Search Schemas
class APISearchRequestSchema(BaseSchema):
    """Schema for API search requests"""
    query: str = Field(..., min_length=1, max_length=200)
    filters: Optional[Dict[str, Any]] = Field(default_factory=dict)
    
class APISearchResponseSchema(BaseSchema):
    """Schema for API search responses"""
    query: str
    results: List[APISpecificationSchema]
    total_results: int = Field(ge=0)
    search_time_ms: int = Field(ge=0)

# Health Check Schema
class HealthCheckSchema(BaseSchema):
    """Schema for health check responses"""
    status: str = Field(..., pattern="^(healthy|unhealthy)$")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    version: str = "1.0.0"
    services: Dict[str, ServiceStatusSchema]
    uptime_seconds: int = Field(ge=0)

# Utility functions for schema validation
def validate_openapi_spec(spec: Dict[str, Any]) -> bool:
    """Validate if dictionary is a valid OpenAPI spec structure"""
    required_fields = ['info', 'paths']
    version_field = 'swagger' if 'swagger' in spec else 'openapi'
    
    if version_field not in spec:
        return False
    
    for field in required_fields:
        if field not in spec:
            return False
    
    return True

def detect_api_format(spec: Dict[str, Any]) -> APIFormat:
    """Detect API specification format"""
    if 'swagger' in spec:
        version = spec['swagger']
        if isinstance(version, str) and version.startswith('2.'):
            return APIFormat.SWAGGER_2_0
        return APIFormat.OPENAPI_2_0
    elif 'openapi' in spec:
        version = spec['openapi']
        if isinstance(version, str) and version.startswith('3.'):
            return APIFormat.OPENAPI_3_0
        return APIFormat.OPENAPI_2_0
    
    return APIFormat.OPENAPI_2_0  # Default fallback
