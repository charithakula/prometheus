import os
from dotenv import load_dotenv

load_dotenv()

# Bind (Azure requires 0.0.0.0:8000)
bind = os.getenv("GUNICORN_BIND", "0.0.0.0:8000")

# Worker processes
workers = int(os.getenv("GUNICORN_WORKERS", 4))

# Worker class
worker_class = os.getenv("GUNICORN_WORKER_CLASS", "sync")

# Timeouts (long migrations supported)
timeout = int(os.getenv("GUNICORN_TIMEOUT", 1200))
graceful_timeout = int(os.getenv("GUNICORN_GRACEFUL_TIMEOUT", 60))
keepalive = int(os.getenv("GUNICORN_KEEPALIVE", 5))

# Logs (Azure captures stdout/stderr)
accesslog = os.getenv("GUNICORN_ACCESS_LOG", "-")
errorlog  = os.getenv("GUNICORN_ERROR_LOG", "-")
loglevel  = os.getenv("GUNICORN_LOG_LEVEL", "info")

# Memory management (avoid leaks)
max_requests = int(os.getenv("GUNICORN_MAX_REQUESTS", 1000))
max_requests_jitter = int(os.getenv("GUNICORN_MAX_REQUESTS_JITTER", 100))

# Environment mode
FLASK_ENV = os.getenv("FLASK_ENV", "production")
preload_app = FLASK_ENV == "production"

def when_ready(server):
    print("Gunicorn running with:")
    print(f"  bind={bind}")
    print(f"  workers={workers}")
    print(f"  class={worker_class}")
    print(f"  timeout={timeout}")
    print(f"  env={FLASK_ENV}")
