# 📊 APPLICATION ARCHITECTURE DIAGRAMS

## 1. OVERALL APPLICATION ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│                     Flask Application (app.py)                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │           Authentication & Session Management            │  │
│  │  @login_required decorator on all main routes            │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   Routes    │  │ Blueprints   │  │   Services   │          │
│  ├──────────────┤  ├──────────────┤  ├──────────────┤          │
│  │ GET  /      │  │ /api/chat    │  │ Conversion   │          │
│  │ GET  /upload│  │ /api/storage │  │ Migration    │          │
│  │ GET  /history│ │ /api/files   │  │ Validation   │          │
│  │ GET  /convert│ │ /api/migrate │  │              │          │
│  │ POST /api/* │  │ /api/convert │  │              │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│         │                  │                 │                  │
└─────────────────────────────────────────────────────────────────┘
         │                  │                 │
         ▼                  ▼                 ▼
┌──────────────────┬──────────────────┬──────────────────┐
│   SQLAlchemy     │  Azure Services  │   File Handler   │
│   Database       │                  │                  │
│                  │  ┌────────────┐  │  ┌────────────┐  │
│  ┌─────────────┐ │  │ Azure APIM │  │  │   Azure    │  │
│  │ Migration   │ │  │ Connector  │  │  │   Blob     │  │
│  │ Record      │ │  └────────────┘  │  │  Storage   │  │
│  │             │ │                  │  │   or Local │  │
│  │ API Spec    │ │  ┌────────────┐  │  │ Filesystem │  │
│  │             │ │  │ Azure      │  │  └────────────┘  │
│  │ Migration   │ │  │ OpenAI     │  │                  │
│  │ Log         │ │  │ Connector  │  │                  │
│  └─────────────┘ │  └────────────┘  │                  │
│                  │                  │                  │
└──────────────────┴──────────────────┴──────────────────┘
```

---

## 2. REQUEST LIFECYCLE

```
┌─────────────────┐
│  User Request   │
│  (Browser/API)  │
└────────┬────────┘
         │
         ▼
┌──────────────────────────────────┐
│  Flask Routes (@app.route)       │
├──────────────────────────────────┤
│  1. Match URL to route           │
│  2. Extract parameters           │
│  3. Call handler function        │
└────────────┬─────────────────────┘
             │
             ▼
┌──────────────────────────────────┐
│  Authentication Check            │
├──────────────────────────────────┤
│  @login_required decorator       │
│  - Check session                 │
│  - Verify user logged in         │
│  - Redirect if not authenticated │
└────────┬───────────────────────┬─┘
         │ (Authenticated)       │ (Not authenticated)
         ▼                       ▼
    Continue          Redirect to /login
         │
         ▼
┌──────────────────────────────────────┐
│  Route Handler Function              │
├──────────────────────────────────────┤
│  1. Validate request data            │
│  2. Call service/connector methods   │
│  3. Database operations              │
│  4. External API calls               │
└────────┬──────────────────────────────┘
         │
         ▼
┌──────────────────────────────────────┐
│  Error Handling                      │
├──────────────────────────────────────┤
│  - Database connection errors        │
│  - File I/O errors                   │
│  - Azure service errors              │
│  - Validation errors                 │
│  → Return error response             │
└────────┬──────────────────────────────┘
         │
         ▼
┌──────────────────────────────────────┐
│  Response Generation                 │
├──────────────────────────────────────┤
│  - HTML Template render              │
│  - JSON response                     │
│  - HTTP status code                  │
└────────┬──────────────────────────────┘
         │
         ▼
┌──────────────────────────────────────┐
│  Send Response to Client             │
├──────────────────────────────────────┤
│  200: Success                        │
│  400: Bad Request                    │
│  404: Not Found                      │
│  500: Server Error                   │
└──────────────────────────────────────┘
```

---

## 3. API MIGRATION FLOW (DETAILED)

```
STEP 1: USER UPLOADS FILE
┌─────────────────────┐
│  User clicks upload │
│  Selects file       │
└──────────┬──────────┘
           │
           ▼
     /api/upload
           │
           ▼
    File validation
    - Check size (max 16MB)
    - Check extension
           │
           ▼
    Save to storage
    - Azure Blob Storage (primary)
    - Local filesystem (fallback)
           │
           ▼
    Extract metadata
    - API title
    - API version
    - Number of endpoints
           │
           ▼
┌─────────────────────┐
│  Return file info   │
│  to frontend        │
└─────────────────────┘


STEP 2: USER INITIATES MIGRATION
┌──────────────────────────┐
│  User clicks "Migrate"   │
│  Selects options         │
└──────────┬───────────────┘
           │
           ▼
     /api/migrate (POST)
           │
           ▼
    ✅ Create MigrationRecord
    - Generate migration ID
    - Set status = "in_progress"
    - Record start time
           │
           ▼
    ✅ Read uploaded spec
    - Load from storage
    - Parse JSON/YAML
           │
           ▼
    ✅ Validate spec
    - Check required fields
    - Verify endpoints
    - Check security definitions
           │
           ▼
    ✅ Call ConversionService
    - Normalize format
    - Apply transformations
           │
           ▼
    ✅ Call AzureOpenAI for conversion
    - Sends spec to GPT-5-mini
    - Uses model-aware parameters
    - Returns enhanced spec
           │
           ▼
    ✅ Save converted spec
    - Store in database
    - Store in storage


STEP 3: USER DEPLOYS TO AZURE
┌──────────────────────────┐
│  User clicks "Deploy"    │
│  Selects APIM location   │
└──────────┬───────────────┘
           │
           ▼
    /api/deploy (POST)
           │
           ▼
    ✅ Validate converted spec
    - APIM-specific checks
    - Security requirements
    - Resource limits
           │
           ▼
    ✅ Connect to Azure APIM
    - Authenticate with credentials
    - Get access token
           │
           ▼
    ✅ Create API in APIM
    - Generate API ID
    - Set display name
    - Configure endpoints
           │
           ▼
    ✅ Create policies
    - Rate limiting
    - Authentication
    - Transformation
           │
           ▼
    ✅ Create product (optional)
    - Group related APIs
    - Set subscriptions
    - Configure access
           │
           ▼
    ✅ Update MigrationRecord
    - Set status = "completed"
    - Record completion time
    - Store deployment URLs
           │
           ▼
┌──────────────────────────┐
│  Return deployment info  │
│  - API ID                │
│  - Management URL        │
│  - Developer portal URL  │
└──────────────────────────┘
```

---

## 4. DATABASE SCHEMA RELATIONSHIPS

```
┌──────────────────────────┐
│   MigrationRecord        │
├──────────────────────────┤
│ • migration_id (PK)      │ ──┐
│ • api_name               │   │
│ • source_platform        │   │ 1:N Relationship
│ • target_platform        │   │
│ • status                 │   │
│ • created_at             │   │
│ • completed_at           │   │
│ • completion_time        │   │
│ • error_message          │   │
│ • deployment_urls        │   │
└──────────────────────────┘   │
                               │
                               │
┌──────────────────────────┐   │
│   MigrationLog           │ ◄─┘
├──────────────────────────┤
│ • log_id (PK)            │
│ • migration_id (FK) ─────┘
│ • log_level              │
│ • message                │
│ • timestamp              │
│ • details                │
└──────────────────────────┘


┌──────────────────────────┐
│   APISpecification       │
├──────────────────────────┤
│ • spec_id (PK)           │
│ • api_name               │
│ • api_version            │
│ • spec_content           │
│ • spec_format            │
│ • is_valid               │
│ • validation_errors      │
│ • created_at             │
│ • updated_at             │
│ • storage_location       │
└──────────────────────────┘
```

---

## 5. ERROR HANDLING FLOW

```
Request comes in
      │
      ▼
Route handler executes
      │
      ├─ Success ──→ Return response (200, 201)
      │
      └─ Error
           │
           ├─ Database Error
           │  │
           │  ├─ OperationalError (connection failed)
           │  │  └─ Return: Connection error message (500)
           │  │
           │  ├─ DatabaseError (SQL syntax error)
           │  │  └─ Return: Database error message (500)
           │  │
           │  └─ SQLAlchemyError (other errors)
           │     └─ Return: Generic database error (500)
           │
           ├─ Validation Error
           │  │
           │  ├─ Missing required fields
           │  │  └─ Return: "Missing field X" (400)
           │  │
           │  ├─ Invalid format
           │  │  └─ Return: "Invalid JSON format" (400)
           │  │
           │  └─ Invalid OpenAPI spec
           │     └─ Return: Validation errors list (400)
           │
           ├─ File Error
           │  │
           │  ├─ File too large (>16MB)
           │  │  └─ Return: RequestEntityTooLarge error (413)
           │  │
           │  └─ File I/O error
           │     └─ Return: "Failed to read file" (500)
           │
           ├─ Azure Service Error
           │  │
           │  ├─ Azure APIM unavailable
           │  │  └─ Return: "Service unavailable" (503)
           │  │
           │  ├─ Azure OpenAI quota exceeded
           │  │  └─ Return: "Quota exceeded" (429)
           │  │
           │  └─ Authentication failed
           │     └─ Return: "Authentication failed" (401)
           │
           ├─ 404 Error Handler
           │  └─ Resource not found
           │     └─ Return: 404 page or JSON (404)
           │
           └─ 500 Error Handler
              └─ Unexpected error
                 └─ Log error, return generic message (500)
```

---

## 6. AUTHENTICATION & SESSION FLOW

```
User Request
      │
      ▼
┌──────────────────────────┐
│  Check @login_required   │
│  decorator               │
└────────┬─────────────────┘
         │
         ▼
    Is user logged in?
    (Check session)
         │
    ┌────┴────┐
    │          │
   YES        NO
    │          │
    ▼          ▼
Continue  Redirect to
execution /login
    │
    ├─→ Login page
    │   GET /login
    │
    ├─ User enters
    │  credentials
    │
    ├─ POST /login
    │  - Verify credentials
    │  - Create session
    │  - Set session cookie
    │
    └─→ Redirect to
        requested page
```

---

## 7. SERVICE LAYER ARCHITECTURE

```
API Routes
    │
    ├─→ ConversionService
    │   │
    │   ├─ convert_spec()
    │   │  ├─ Validate format
    │   │  ├─ Transform structure
    │   │  └─ Return converted spec
    │   │
    │   └─ validate_spec()
    │      ├─ Check required fields
    │      ├─ Verify endpoints
    │      └─ Return validation result
    │
    ├─→ MigrationService
    │   │
    │   ├─ migrate_single_api()
    │   │  ├─ Create migration record
    │   │  ├─ Call conversion service
    │   │  ├─ Call deployment
    │   │  └─ Update record status
    │   │
    │   └─ migrate_batch_apis()
    │      ├─ Process multiple APIs
    │      └─ Aggregate results
    │
    └─→ ValidationService
        │
        ├─ validate_openapi()
        │  ├─ Check OpenAPI version
        │  ├─ Verify required fields
        │  └─ Return validation errors
        │
        └─ validate_against_apim()
           ├─ Check APIM compatibility
           └─ Return compatibility issues
```

---

## 8. EXTERNAL SERVICE INTEGRATIONS

```
┌────────────────────────────────────┐
│      Flask Application             │
└────────────────────────────────────┘
         │              │              │
         ▼              ▼              ▼
    ┌─────────┐   ┌──────────┐   ┌──────────┐
    │Database │   │  Azure   │   │  Azure   │
    │         │   │  APIM    │   │  OpenAI  │
    │         │   │          │   │          │
    │PostgreSQL   │ HTTP API │   │ REST API │
    │or SQLite│   │ Token    │   │ Token    │
    │         │   │Auth      │   │Auth      │
    └─────────┘   └──────────┘   └──────────┘
         │              │              │
    ┌────┴──────────────┴──────────────┴────┐
    │      EnhancedFileHandler              │
    │  (Storage Management)                 │
    ├───────────────────────────────────────┤
    │  Primary: Azure Blob Storage          │
    │  Fallback: Local Filesystem           │
    │                                       │
    │  - save_uploaded_file()               │
    │  - read_file_content()                │
    │  - delete_file()                      │
    │  - get_storage_stats()                │
    └───────────────────────────────────────┘
```

---

## 9. LOGGING & MONITORING FLOW

```
Application Start
      │
      ▼
Initialize Logger
      │
      ├─ Log level: INFO
      ├─ Log format: structured JSON
      ├─ Log destination: files/stdout
      │
      ▼
Application Running
      │
      ├─ DEBUG logs: Detailed execution info
      ├─ INFO logs: Important events (migrations, deployments)
      ├─ WARNING logs: Non-fatal issues (slow queries, retries)
      ├─ ERROR logs: Failures that need attention
      └─ CRITICAL logs: System failures
           │
           ▼
Log Rotation
      │
      ├─ Max file size: 10MB
      ├─ Backup count: 5 files
      ├─ Automatic cleanup: old logs
      │
      ▼
Monitoring & Alerting
      │
      ├─ Error rate > 5%: Alert
      ├─ Response time p95 > 1000ms: Alert
      ├─ Database unavailable: Alert
      ├─ Disk space < 10%: Alert
      └─ CPU > 80%: Alert
```

---

## 10. DEPLOYMENT ARCHITECTURE

```
┌─────────────────────────────────────────┐
│         Production Environment          │
├─────────────────────────────────────────┤
│                                         │
│  ┌───────────────────────────────────┐  │
│  │     Load Balancer / Reverse Proxy │  │
│  │     (Azure App Service / Nginx)   │  │
│  └────────────────┬──────────────────┘  │
│                   │                      │
│        ┌──────────┴──────────┐           │
│        │                     │           │
│  ┌─────▼──────┐        ┌─────▼──────┐   │
│  │  Instance 1│        │ Instance N │   │
│  │ (Gunicorn) │        │ (Gunicorn) │   │
│  └─────┬──────┘        └─────┬──────┘   │
│        │                     │           │
│        └──────────┬──────────┘           │
│                   │                      │
│        ┌──────────▼──────────┐           │
│        │  Shared Database    │           │
│        │  PostgreSQL/MySQL   │           │
│        └─────────────────────┘           │
│                                         │
│        ┌──────────────────────┐         │
│        │  Shared Storage      │         │
│        │  Azure Blob Storage  │         │
│        │  or NFS              │         │
│        └──────────────────────┘         │
│                                         │
└─────────────────────────────────────────┘
         │              │              │
         ▼              ▼              ▼
    ┌─────────┐   ┌──────────┐   ┌──────────┐
    │Monitoring   │Logging   │   │Backups   │
    │Azure        │ELK Stack │   │S3/Blob   │
    │Application  │Datadog   │   │          │
    │Insights     │          │   │          │
    └─────────┘   └──────────┘   └──────────┘
```

---

## 11. KEY PERFORMANCE CHARACTERISTICS

```
RESPONSE TIMES (Target):
Dashboard           ├─ < 500ms (with cache)
Upload File         ├─ < 2s (depends on file size)
Conversion          ├─ 30-120s (AI processing)
Deployment to APIM  ├─ 20-60s (depends on API size)
History Query       ├─ < 1s (with pagination)

THROUGHPUT:
Concurrent Users    ├─ 100+ (with proper scaling)
Requests/second     ├─ 1000+ (distributed)
Concurrent Uploads  ├─ 20+ (with rate limiting)

RESOURCE USAGE:
Memory per Instance ├─ ~500MB (minimal)
Database Connections├─ 10-20 per instance
Disk Usage          ├─ Variable (depends on files)
```

---

## 12. SECURITY LAYERS

```
┌─────────────────────────────────────┐
│    HTTPS / TLS Encryption           │ ← Network Layer
├─────────────────────────────────────┤
│    Authentication (Login/Session)   │ ← Session Layer
├─────────────────────────────────────┤
│    Authorization (@login_required)  │ ← Route Layer
├─────────────────────────────────────┤
│    Input Validation (Pydantic)      │ ← Data Layer
├─────────────────────────────────────┤
│    SQL Injection Prevention (ORM)   │ ← Database Layer
├─────────────────────────────────────┤
│    CSRF Protection (Flask-Session)  │ ← Form Layer
├─────────────────────────────────────┤
│    Rate Limiting                    │ ← API Layer
├─────────────────────────────────────┤
│    Secrets in Key Vault             │ ← Secrets Layer
├─────────────────────────────────────┤
│    CORS Whitelisting                │ ← CORS Layer
├─────────────────────────────────────┤
│    Security Headers (HSTS, CSP)     │ ← Header Layer
└─────────────────────────────────────┘
```