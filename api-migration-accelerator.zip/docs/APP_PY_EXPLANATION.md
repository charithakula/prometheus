# 🏗️ COMPLETE APP.PY DOCUMENTATION

## Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Imports & Dependencies](#imports--dependencies)
3. [Core Components](#core-components)
4. [Application Factory](#application-factory)
5. [Error Handling](#error-handling)
6. [Main Routes](#main-routes)
7. [API Endpoints](#api-endpoints)
8. [Helper Functions](#helper-functions)
9. [Production Configuration](#production-configuration)
10. [Database Integration](#database-integration)

---

## 🎯 Architecture Overview

The application follows the **Flask Application Factory Pattern** with a modular, production-ready architecture:

```
Flask App (app.py)
├── Database (SQLAlchemy ORM)
├── Authentication (Login/Session)
├── Blueprints (Modular routes)
│   ├── Chat Blueprint
│   ├── Storage Blueprint
│   ├── Files Blueprint
│   ├── Migration Blueprint
│   ├── Conversion Blueprint
│   └── Health Blueprint
├── Services (Business logic)
│   ├── ConversionService
│   ├── MigrationService
│   └── ValidationService
├── Connectors (External services)
│   ├── AzureAPIMConnector
│   └── AzureOpenAIConnector
└── Utilities (Helpers)
    ├── Logger
    ├── File Handler
    └── ID Generator
```

---

## 📦 Imports & Dependencies

### Core Flask
```python
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_file, session
from flask_cors import CORS
```
- **Flask**: Main web framework
- **CORS**: Enable cross-origin requests for frontend

### Database & ORM
```python
from sqlalchemy.exc import OperationalError, DatabaseError, SQLAlchemyError
from models.database import db, MigrationRecord, APISpecification, MigrationLog
```
- **SQLAlchemy**: ORM for database operations
- **Models**: Three main database models for storing migration data

### Azure Services
```python
from connectors import AzureAPIMConnector, AzureOpenAIConnector
from utils.enhanced_file_handler_with_azure import EnhancedFileHandler
```
- **AzureAPIMConnector**: Deploy APIs to Azure API Management
- **AzureOpenAIConnector**: AI-powered API conversion
- **EnhancedFileHandler**: Manage files with Azure Blob Storage fallback

### Business Logic
```python
from services import ConversionService, MigrationService, ValidationService
```
- **ConversionService**: Convert specs between formats
- **MigrationService**: Handle API migrations
- **ValidationService**: Validate OpenAPI specs

### Utilities
```python
from auth import configure_session, register_auth_routes, login_required
from utils import setup_logger, generate_id
```
- **Auth**: User authentication and session management
- **Logging**: Structured logging with rotation
- **ID Generator**: Unique ID generation for records

### LLM Prompts
```python
try:
    from enhanced_prompts import (
        UniversalPromptBuilder,
        ASSISTANT_TYPES,
        SYSTEM_PROMPTS,
        CHAT_CONFIG,
        detect_assistant_type,
        CODE_GENERATION_PROMPTS,
        API_ANALYSIS_PROMPTS,
        SECURITY_PROMPTS,
        POLICY_ANALYSIS_PROMPTS,
        DOCUMENTATION_PROMPTS
    )
    PROMPTS_AVAILABLE = True
except ImportError:
    PROMPTS_AVAILABLE = False
```
- **Enhanced Prompts**: Centralized LLM prompt management
- **Graceful fallback**: Uses default responses if prompts unavailable

---

## 🔧 Core Components

### 1. Database Models

#### MigrationRecord
```python
# Stores information about each API migration
- migration_id: Unique identifier
- api_name: Name of the migrated API
- source_platform: Where the API came from (IBM API Connect)
- target_platform: Destination platform (Azure APIM)
- status: current status (pending, in_progress, completed, failed)
- created_at: When migration was initiated
- completed_at: When migration finished
- completion_time: Duration in seconds
- original_api_id: Original API identifier
```

#### APISpecification
```python
# Stores OpenAPI specifications
- spec_id: Unique identifier
- api_name: Name of the API
- spec_content: Full OpenAPI specification (JSON)
- spec_format: Format type (openapi, swagger)
- is_valid: Whether spec passed validation
- validation_errors: List of validation issues
- created_at: When spec was stored
```

#### MigrationLog
```python
# Stores detailed migration logs
- log_id: Unique identifier
- migration_id: Reference to MigrationRecord
- log_level: (info, warning, error)
- message: Log message
- timestamp: When log was created
```

### 2. Service Layer

**ConversionService**
- Converts between API formats (Swagger → OpenAPI 3.0)
- Applies transformation rules
- Validates converted specs
- Uses Azure OpenAI for intelligent conversion

**MigrationService**
- Orchestrates the full migration workflow
- Creates migration records
- Calls conversion service
- Deploys to Azure APIM
- Updates status and logs

**ValidationService**
- Validates OpenAPI specifications
- Checks for required fields
- Identifies compatibility issues
- Generates validation reports

### 3. Connectors

**AzureAPIMConnector**
```python
# Manages Azure API Management operations
- create_api_from_openapi()      # Create API in APIM
- create_product()                # Create APIM product
- validate_openapi_for_apim()    # Pre-deployment validation
- get_api_management_url()        # Generate management URL
- get_developer_portal_url()      # Get developer portal link
```

**AzureOpenAIConnector**
```python
# Manages Azure OpenAI API calls
- build_chat_completion_params() # Model-aware parameter building
- convert_spec()                  # AI-powered spec conversion
- analyze_policy()                # Analyze security policies
- generate_documentation()        # Auto-generate API docs
```

### 4. File Handler

**EnhancedFileHandler**
```python
# Manages file storage with smart fallback
- Primary: Azure Blob Storage (if credentials available)
- Fallback: Local filesystem
- Methods:
  - save_uploaded_file()    # Save user uploads
  - read_file_content()     # Read and parse files
  - delete_file()           # Clean up files
  - get_storage_stats()     # Get storage usage info
```

---

## 🏭 Application Factory

The `create_app()` function follows the Flask Application Factory pattern:

### Step 1: Initialize Flask
```python
app = Flask(__name__)
config = get_config()
app.config.from_object(config)
```
- Creates Flask instance
- Loads environment-based configuration
- Sets up config variables

### Step 2: Configure Extensions
```python
CORS(app)              # Enable CORS for API requests
db.init_app(app)      # Initialize SQLAlchemy database
configure_session(app) # Setup user sessions
```

### Step 3: Initialize Services
```python
conversion_service = ConversionService()
migration_service = MigrationService()
validation_service = ValidationService()
file_handler = EnhancedFileHandler()
```

### Step 4: Register Blueprints
```python
app.register_blueprint(health_bp, url_prefix='')
app.register_blueprint(chat_bp, url_prefix='/api/chat')
app.register_blueprint(storage_bp, url_prefix='/api/storage')
app.register_blueprint(files_bp, url_prefix='/api/files')
app.register_blueprint(migration_bp, url_prefix='/api/migrations')
app.register_blueprint(conversion_bp, url_prefix='/api/convert')
```

**Blueprints** are modular route containers:
- Each blueprint handles a specific feature area
- Reduces code in main app.py
- Makes testing easier
- Improves code organization

### Step 5: Add Global Context
```python
app.jinja_env.globals.update({
    'min': min, 'max': max, 'len': len,
    'abs': abs, 'round': round, ...
})
```
- Makes Python built-ins available in templates
- Used in HTML templating for dynamic content

---

## ⚠️ Error Handling

### Database Error Handling

```python
def test_database_connection():
    """Comprehensive database health check"""
    try:
        db.session.execute(text('SELECT 1'))
        db.session.commit()
        tables_exist = check_tables_exist()
        
        return {
            'status': 'success',
            'message': 'Database connected successfully',
            'details': {
                'database_type': db_type,
                'database_name': db_name,
                'tables_exist': tables_exist
            }
        }
    except OperationalError as e:
        # Handle database not found, connection errors
        return {
            'status': 'error',
            'message': 'Cannot connect to database',
            'error_type': 'connection_failed'
        }
```

**Error Types Handled:**
- `OperationalError`: Database doesn't exist or connection failed
- `DatabaseError`: SQL syntax or constraint errors
- `SQLAlchemyError`: General SQLAlchemy errors
- `Exception`: Unexpected errors with graceful fallback

### Flask Error Handlers

```python
@app.errorhandler(404)
def not_found_error(error):
    """Handle missing resources"""
    if request.is_json:
        return jsonify({'error': 'Resource not found'}), 404
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle server errors"""
    logger.error(f"Internal error: {error}")
    if request.is_json:
        return jsonify({'error': 'Internal server error'}), 500
    return render_template('500.html'), 500

@app.errorhandler(RequestEntityTooLarge)
def file_too_large(error):
    """Handle oversized uploads"""
    if request.is_json:
        return jsonify({'error': 'File too large (max 16MB)'}), 413
    flash('File is too large', 'error')
    return redirect(url_for('upload_page'))
```

---

## 🛣️ Main Routes

### 1. Dashboard Route

```python
@app.route('/')
@login_required
def index():
    """Main dashboard - fast loading with fallbacks"""
```

**What it does:**
1. Gets database statistics (migration counts, success rates)
2. Fetches recent migrations (last 5)
3. Gets storage statistics (files, space used)
4. Renders dashboard template

**Error Handling:**
- If database unavailable: shows cached/default stats
- If storage check times out: uses fallback values
- Uses threading with timeout to prevent hangs

**Returns:**
- HTML template with dashboard data
- Stats dashboard showing:
  - Total migrations
  - Success rate
  - Recent migration history
  - Storage usage

### 2. Upload Page Route

```python
@app.route('/upload')
@login_required
def upload_page():
    """File upload interface"""
```

**What it does:**
1. Gets current storage statistics
2. Renders upload page template

**Returns:**
- HTML upload form with:
  - File input field
  - Storage statistics
  - Progress indicators

### 3. History Route

```python
@app.route('/history')
@login_required
def migration_history():
    """Migration history with filtering and pagination"""
```

**Features:**
- **Pagination**: Show 20 records per page
- **Filtering**: 
  - Status (pending, completed, failed)
  - Search by API name
  - Date range (today, week, month, quarter)
- **Sorting**:
  - By date (newest/oldest)
  - By name (A-Z)
  - By duration (fastest/slowest)

**Returns:**
- HTML table with:
  - Migration records
  - Pagination controls
  - Filter options
  - Sorting controls

### 4. YAML Converter Route

```python
@app.route('/converter')
@login_required
def yaml_converter():
    """YAML ↔ JSON converter tool"""
```

**Returns:**
- Interactive converter interface
- Code editor with syntax highlighting
- Format detection

---

## 🔌 API Endpoints

### File Management

#### Upload File
```python
@app.route('/api/upload', methods=['POST'])
@login_required
def upload_file():
    """Handle file uploads with validation"""
```

**Request:**
```json
{
  "file": <binary file data>
}
```

**Response:**
```json
{
  "success": true,
  "file_info": {
    "filename": "api-spec.json",
    "file_path": "/path/to/file",
    "file_size": 5120
  },
  "api_info": {
    "title": "User API",
    "version": "1.0.0",
    "paths_count": 15
  }
}
```

### Database Operations

#### Get Database Status
```python
@app.route('/api/database/status')
@login_required
def get_database_status():
    """Check database health and statistics"""
```

**Response:**
```json
{
  "connection": {
    "status": "success",
    "database_type": "postgresql",
    "tables_exist": true
  },
  "health": {
    "record_counts": {
      "migrations": 42,
      "api_specifications": 15,
      "logs": 234
    },
    "last_migration": {
      "id": "mig-001",
      "status": "completed",
      "created_at": "2025-01-13T21:00:00"
    }
  }
}
```

#### Initialize Database
```python
@app.route('/api/database/initialize', methods=['POST'])
@login_required
def initialize_database_endpoint():
    """Create database tables if not exist"""
```

### Migration & Conversion

#### Start Single API Migration
```python
@app.route('/api/migrate', methods=['POST'])
@login_required
def migrate_api():
    """Migrate a single API to Azure APIM"""
```

**Request:**
```json
{
  "api_ids": ["api-001"],
  "org_name": "my-organization",
  "options": {
    "convert_format": true,
    "validate": true
  }
}
```

**Response:**
```json
{
  "migration_id": "mig-123",
  "status": "in_progress",
  "message": "Migration started",
  "api_name": "User API",
  "estimated_time": 45
}
```

#### Deploy to Azure APIM
```python
@app.route('/api/deploy', methods=['POST'])
@login_required
def deploy_to_azure_apim():
    """Deploy converted OpenAPI spec to Azure APIM"""
```

**Request:**
```json
{
  "converted_spec": {
    "openapi": "3.0.0",
    "info": {"title": "User API", "version": "1.0.0"},
    "paths": {...}
  },
  "original_api_id": "api-001",
  "options": {
    "api_id": "user-api",
    "create_product": true,
    "product_name": "User Services"
  }
}
```

**Response:**
```json
{
  "status": "success",
  "message": "API deployed successfully",
  "api_id": "user-api",
  "deployment_id": "deploy-456",
  "management_url": "https://management.azure.com/...",
  "developer_portal_url": "https://portal.azure.com/..."
}
```

### Statistics

#### Get Application Statistics
```python
@app.route('/api/statistics')
@login_required
def get_statistics():
    """Get comprehensive application statistics"""
```

**Response:**
```json
{
  "migrations": {
    "total_migrations": 150,
    "successful_migrations": 145,
    "failed_migrations": 5,
    "in_progress_migrations": 0,
    "success_rate": 96.67,
    "average_completion_time": 32.5
  },
  "database": {
    "total_specifications": 75,
    "valid_specifications": 72,
    "invalid_specifications": 3,
    "database_available": true
  },
  "storage": {
    "total_files": 245,
    "total_size_mb": 1024,
    "storage_type": "azure_blob_storage"
  },
  "application": {
    "version": "1.0.0",
    "uptime_seconds": 86400,
    "start_time": "2025-01-13T00:00:00"
  }
}
```

### Health Check

#### Prerequisites Check
```python
@app.route('/api/prerequisites')
def check_prerequisites():
    """Check if all services are available"""
```

**Response:**
```json
{
  "all_services_available": true,
  "can_migrate": true,
  "service_status": {
    "database": {"status": "success"},
    "azure_apim": {"status": "success"},
    "azure_openai": {"status": "success"},
    "storage": {"status": "success"}
  }
}
```

---

## 🛠️ Helper Functions

### Database Helpers

#### `test_database_connection()`
- Executes test query
- Checks if tables exist
- Returns detailed status

#### `check_tables_exist()`
- Queries each model table
- Returns boolean result
- Handles all error types

#### `get_database_statistics_safe()`
- Safely fetches statistics
- Falls back if any query fails
- Never hangs or crashes

#### `get_database_health()`
- Gets record counts
- Finds last migration
- Returns health metrics

### File Helpers

#### `format_file_size(bytes_size)`
```python
# Converts bytes to human readable format
1024 → "1.0 KB"
1048576 → "1.0 MB"
1073741824 → "1.0 GB"
```

### API Helpers

#### `extract_api_info(spec: dict)`
```python
# Extracts metadata from OpenAPI spec
Returns: {
    'title': 'User API',
    'version': '1.0.0',
    'paths_count': 15,
    'definitions_count': 8,
    'operations_count': 42
}
```

#### `_generate_api_id_from_spec(spec, fallback)`
```python
# Generates unique API ID from spec title
"User API" → "user-api-5f3d2c"
```

---

## ⚙️ Production Configuration

### Environment Variables (Required)

```bash
# Flask
FLASK_ENV=production
FLASK_DEBUG=False
FLASK_SECRET_KEY=<random-32-char-string>

# Azure
AZURE_CLIENT_ID=<your-client-id>
AZURE_CLIENT_SECRET=<your-client-secret>
AZURE_TENANT_ID=<your-tenant-id>
AZURE_SUBSCRIPTION_ID=<your-subscription-id>

# Azure OpenAI
AZURE_OPENAI_ENDPOINT=https://<name>.openai.azure.com/
AZURE_OPENAI_API_KEY=<your-api-key>
AZURE_OPENAI_DEPLOYMENT=gpt-5-mini

# Database
DB_HOST=localhost
DB_NAME=api_migration_db
DB_USER=admin
DB_PASSWORD=password

# Azure Storage
AZURE_STORAGE_ACCOUNT_NAME=<account-name>
AZURE_STORAGE_ACCOUNT_KEY=<account-key>
```

### Production Validation

```python
def validate_production_config(app):
    """Checks critical production settings"""
    - FLASK_SECRET_KEY is set
    - FLASK_DEBUG is False
    - Azure credentials configured
    - Database SSL enabled
    - Valid OpenAI model configured
```

**Fails if:**
- Debug mode enabled
- Secrets not set
- Invalid model name
- SSL disabled for database

---

## 🗄️ Database Integration

### SQLAlchemy ORM

The app uses SQLAlchemy for all database operations:

```python
from models.database import db, MigrationRecord, APISpecification, MigrationLog

# Query example
migrations = MigrationRecord.query.filter_by(status='completed').all()

# Create example
record = MigrationRecord(
    api_name='User API',
    source_platform='ibm_api_connect',
    target_platform='azure_apim',
    status='in_progress'
)
db.session.add(record)
db.session.commit()

# Update example
record.status = 'completed'
record.completion_time = 45.5
db.session.commit()
```

### Database Connection Pool

```python
# Configured for:
DB_POOL_SIZE=10           # Max connections
DB_MAX_OVERFLOW=20        # Temporary extra connections
DB_POOL_TIMEOUT=30        # Wait time for connection
DB_POOL_RECYCLE=3600      # Recycle connections after 1 hour
DB_POOL_PRE_PING=True     # Test connections before use
```

---

## 🚀 Application Startup

### Main Entry Point

```python
if __name__ == '__main__':
    # Create required directories
    os.makedirs('logs', exist_ok=True)
    os.makedirs('static/uploads', exist_ok=True)
    
    # Initialize logging
    logger = setup_logger('app')
    
    # Get configuration
    port = int(os.environ.get('PORT', 8000))
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    
    # Log startup info
    logger.info(f"Starting on port {port}")
    logger.info(f"Debug mode: {debug}")
    logger.info("✅ Azure Storage with fallback enabled")
    logger.info("✅ Azure OpenAI with model-aware parameters enabled")
    logger.info("✅ Enhanced prompts integration enabled")
    
    # Run application
    app.run(host='0.0.0.0', port=port, debug=debug)
```

### Startup Sequence

1. **Load Configuration**
   - Read environment variables
   - Initialize config object

2. **Initialize Extensions**
   - Setup database connection
   - Configure CORS
   - Setup session management

3. **Load Services**
   - Initialize converters
   - Setup file handler
   - Create connectors

4. **Register Blueprints**
   - Mount modular route handlers
   - Setup middleware

5. **Create Directories**
   - Ensure logs directory exists
   - Ensure uploads directory exists

6. **Start Server**
   - Bind to 0.0.0.0:8000
   - Accept requests

---

## 📊 Data Flow Example

### Complete API Migration Flow

```
1. User uploads OpenAPI spec
   ↓
2. /api/upload endpoint
   - Saves file to storage
   - Extracts API metadata
   - Returns file info
   ↓
3. User clicks "Migrate"
   ↓
4. /api/migrate endpoint
   - Creates MigrationRecord
   - Calls ConversionService
   ↓
5. ConversionService
   - Validates spec
   - Calls AzureOpenAIConnector for AI conversion
   - Returns converted spec
   ↓
6. /api/deploy endpoint
   - Validates converted spec for APIM
   - Calls AzureAPIMConnector
   - Creates API in Azure APIM
   ↓
7. Success Response
   - Returns deployment details
   - Provides management URL
   - Updates migration record status
```

---

## ✨ Key Features

✅ **Production Ready**
- Comprehensive error handling
- Database connection pooling
- Graceful fallbacks

✅ **Secure**
- Authentication required on all routes
- CSRF protection
- SQL injection prevention (ORM)
- Secure file handling

✅ **Scalable**
- Modular blueprint architecture
- Database indexing
- Async-ready (can add Celery)

✅ **Observable**
- Structured logging
- Health check endpoints
- Statistics collection
- Error tracking

✅ **Maintainable**
- Clean code organization
- Well-documented functions
- Separation of concerns
- Easy to test