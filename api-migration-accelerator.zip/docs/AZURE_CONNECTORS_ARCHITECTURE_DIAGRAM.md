AZURE_CONNECTORS_ARCHITECTURE_DIAGR# 📊 AZURE CONNECTORS - VISUAL ARCHITECTURE & INTERACTIONS

## Table of Contents
1. [Connector Interaction Diagram](#connector-interaction-diagram)
2. [API Migration End-to-End Flow](#api-migration-end-to-end-flow)
3. [Authentication Flows](#authentication-flows)
4. [Model-Aware Parameter Selection](#model-aware-parameter-selection)
5. [Conversion Strategies](#conversion-strategies)
6. [Error Recovery Paths](#error-recovery-paths)
7. [Component Relationships](#component-relationships)

---

## 🔗 Connector Interaction Diagram

```
┌────────────────────────────────────────────────────────────────┐
│                    Flask Application                           │
│                    (app.py)                                    │
└────────────────┬─────────────────────────────┬─────────────────┘
                 │                             │
                 │                             │
    ┌────────────▼──────────────┐   ┌─────────▼──────────────┐
    │  AzureOpenAIConnector     │   │ AzureAPIMConnector     │
    │  (Intelligent Conversion) │   │ (API Deployment)       │
    ├───────────────────────────┤   ├────────────────────────┤
    │                           │   │                        │
    │ Purpose:                  │   │ Purpose:               │
    │ • Convert specs           │   │ • Deploy APIs          │
    │ • Normalize formats       │   │ • Create products      │
    │ • Validate OpenAPI        │   │ • Manage APIs          │
    │                           │   │                        │
    │ Input:                    │   │ Input:                 │
    │ • Any OpenAPI spec        │   │ • OpenAPI 3.0 spec     │
    │ • Any format (JSON/YAML)  │   │ • API ID               │
    │ • Any version (2.0/3.0)   │   │ • Azure credentials    │
    │                           │   │                        │
    │ Output:                   │   │ Output:                │
    │ • Normalized spec         │   │ • Deployment status    │
    │ • OpenAPI 3.0 JSON        │   │ • APIM URLs            │
    │ • Metadata                │   │ • Product ID           │
    │                           │   │                        │
    └────────┬──────────────────┘   └─────────┬──────────────┘
             │                               │
             ▼                               ▼
    ┌────────────────────────┐   ┌──────────────────────────┐
    │ Azure OpenAI API       │   │ Azure APIM API           │
    │ • gpt-4o-mini          │   │ • Create APIs            │
    │ • gpt-5-mini           │   │ • Manage operations      │
    │ • gpt-4-turbo          │   │ • Deploy products        │
    │                        │   │ • Handle SSL certificates│
    └────────────────────────┘   └──────────────────────────┘
             │                               │
             └───────────────┬───────────────┘
                             │
                    Azure Subscription
```

---

## 🔄 API Migration End-to-End Flow

```
STEP 1: USER UPLOADS SPEC
┌─────────────────────────────────┐
│  User selects OpenAPI 2.0 file  │
│  File: swagger.json             │
└────────────┬────────────────────┘
             │
             ▼
       /api/upload endpoint
             │
             ▼
    ┌────────────────────────┐
    │  Save file to storage  │
    │  Extract metadata      │
    └────────────┬───────────┘
                 │
                 ▼
         Return file info


STEP 2: USER REQUESTS CONVERSION
┌─────────────────────────────────┐
│  User clicks "Convert to 3.0"   │
│  Specifies options              │
└────────────┬────────────────────┘
             │
             ▼
      /api/convert endpoint
             │
             ▼
    ┌──────────────────────────────────────┐
    │ AzureOpenAIConnector.convert()       │
    ├──────────────────────────────────────┤
    │ 1. Parse spec (detect format/version)│
    │ 2. Check if AI conversion needed     │
    │ 3. Call Azure OpenAI with prompt     │
    │ 4. Extract and validate JSON         │
    │ 5. Fix Azure APIM compatibility      │
    │ 6. Create missing components         │
    │ 7. Return converted spec             │
    └────────────┬─────────────────────────┘
                 │
                 ▼
    ┌──────────────────────────────────────┐
    │  Azure OpenAI Service                │
    │  (Model: gpt-4o-mini or gpt-5-mini)  │
    │                                      │
    │  Input: OpenAPI 2.0 spec + prompt    │
    │  Output: Optimized OpenAPI 3.0       │
    │                                      │
    │  Features:                           │
    │  • Intelligent transformations       │
    │  • Reference path fixing             │
    │  • Component creation                │
    │  • Format optimization               │
    └────────────┬─────────────────────────┘
                 │
                 ▼
    OpenAPI 3.0 spec (JSON/YAML)
                 │
                 ▼
       Save to storage & database


STEP 3: USER DEPLOYS TO APIM
┌─────────────────────────────────┐
│  User clicks "Deploy to Azure"  │
│  Enters API ID and options      │
└────────────┬────────────────────┘
             │
             ▼
      /api/deploy endpoint
             │
             ▼
    ┌──────────────────────────────────────┐
    │ AzureAPIMConnector.create_api()      │
    ├──────────────────────────────────────┤
    │ 1. Validate converted spec           │
    │ 2. Fix any remaining issues          │
    │ 3. Extract API metadata              │
    │ 4. Call Azure APIM API               │
    │ 5. Create API in APIM                │
    │ 6. Optionally create product         │
    │ 7. Return deployment info            │
    └────────────┬─────────────────────────┘
                 │
                 ▼
    ┌──────────────────────────────────────┐
    │  Azure API Management Service        │
    │                                      │
    │  Operations:                         │
    │  • Create API from OpenAPI           │
    │  • Add to product (optional)         │
    │  • Configure policies                │
    │  • Setup SSL/TLS certificates        │
    │                                      │
    │  Result:                             │
    │  • API accessible at APIM endpoint   │
    │  • Developer portal shows API        │
    │  • Subscriptions enabled             │
    └────────────┬─────────────────────────┘
                 │
                 ▼
    ┌─────────────────────────────────┐
    │  Return success to user:        │
    │  • API ID: user-api-xyz123      │
    │  • Management URL: link         │
    │  • Developer Portal: link       │
    │  • API Version: 1.0.0           │
    │  • Status: Ready for use        │
    └─────────────────────────────────┘
```

---

## 🔐 Authentication Flows

### Azure OpenAI Authentication

```
START: Initialize AzureOpenAIConnector
       │
       ▼
VALIDATE Configuration
       │
       ├─ Check AZURE_OPENAI_ENDPOINT
       ├─ Check AZURE_OPENAI_DEPLOYMENT
       ├─ Check AZURE_OPENAI_VERSION
       └─ Check auth method
           │
           ├─ API key?
           └─ Entra ID?
           
       If any missing → Return error


API KEY AUTHENTICATION
┌─────────────────────────────────┐
│ AZURE_OPENAI_API_KEY exists?    │
│  YES ↓                          │
│                                 │
│ 1. Read API key from env        │
│ 2. Read endpoint                │
│ 3. Read API version             │
│ 4. Create AzureOpenAI client    │
│    with api_key parameter       │
│ 5. Set auth_method = "api_key"  │
│ 6. Ready for API calls          │
│                                 │
│ Authentication header:          │
│  api-key: <api-key-value>       │
│  Content-Type: application/json │
└─────────────────────────────────┘


ENTRA ID AUTHENTICATION
┌──────────────────────────────────┐
│ AZURE_OPENAI_API_KEY missing?    │
│  YES ↓                           │
│                                  │
│ 1. Try Entra ID via:            │
│    • Environment variables       │
│    • Managed Identity (Azure VM) │
│    • Azure CLI                   │
│    • System credentials          │
│                                  │
│ 2. Create DefaultAzureCredential │
│                                  │
│ 3. Get bearer token provider    │
│    for Azure CognitiveServices   │
│                                  │
│ 4. Create AzureOpenAI client    │
│    with token_provider           │
│                                  │
│ 5. Set auth_method = "entra_id" │
│                                  │
│ 6. Ready for API calls          │
│    (tokens auto-refresh)         │
│                                  │
│ Authentication header:           │
│  Authorization: Bearer <token>   │
│  Content-Type: application/json  │
└──────────────────────────────────┘


Azure API Management Authentication

┌────────────────────────────────────┐
│ Initialize AzureAPIMConnector      │
├────────────────────────────────────┤
│                                    │
│ 1. Read credentials:               │
│    • AZURE_CLIENT_ID               │
│    • AZURE_CLIENT_SECRET           │
│    • AZURE_TENANT_ID               │
│    • AZURE_SUBSCRIPTION_ID         │
│                                    │
│ 2. Create ClientSecretCredential   │
│    (Service Principal auth)        │
│                                    │
│ 3. Create ApiManagementClient      │
│    with credential object          │
│                                    │
│ 4. Verify SSL certificate config   │
│    (custom CA, client certs)       │
│                                    │
│ 5. Ready for APIM operations       │
│                                    │
│ Request format:                    │
│  Authorization: Bearer <token>     │
│  Content-Type: application/json    │
│  With SSL cert validation          │
└────────────────────────────────────┘
```

---

## 🧠 Model-Aware Parameter Selection

```
INCOMING REQUEST:
deployment = "gpt-5-mini"
messages = [...]
temperature = 0.7
max_tokens = 8000

         │
         ▼
_get_model_config(deployment)
         │
         ├─ Check if "gpt-5-mini" in MODEL_CONFIGS
         │  YES ↓
         │
         └─ Return config:
            {
              'use_max_completion_tokens': True,
              'supports_temperature': False,
              'supports_top_p': False,
              'supports_frequency_penalty': False,
              'supports_presence_penalty': False,
              'default_max': 8000
            }
         
         │
         ▼
_build_chat_completion_params()
         │
         ├─ Add base params
         │  └─ model, messages, stream
         │
         ├─ Check use_max_completion_tokens?
         │  YES: Add "max_completion_tokens": 8000
         │  NO:  Add "max_tokens": 8000
         │
         ├─ Check supports_temperature?
         │  NO: Skip temperature
         │  YES: Add "temperature": 0.7
         │
         ├─ Check supports_top_p?
         │  NO: Skip
         │  YES: Add "top_p": 0.95
         │
         ├─ Check supports_frequency_penalty?
         │  NO: Skip
         │  YES: Add "frequency_penalty": 0
         │
         └─ Check supports_presence_penalty?
            NO: Skip
            YES: Add "presence_penalty": 0

         │
         ▼
FINAL PARAMETERS (for gpt-5-mini):
{
  "model": "gpt-5-mini",
  "messages": [...],
  "stream": False,
  "max_completion_tokens": 8000  ✓ (NOT max_tokens)
}

FINAL PARAMETERS (for gpt-4o-mini):
{
  "model": "gpt-4o-mini",
  "messages": [...],
  "stream": False,
  "max_tokens": 8000,            ✓ (NOT max_completion_tokens)
  "temperature": 0.7,
  "top_p": 0.95,
  "frequency_penalty": 0,
  "presence_penalty": 0
}

         │
         ▼
SEND TO AZURE OPENAI API
         │
         ✓ Success: Get response
         ✗ Error: Retry or fallback
```

---

## 🔄 Conversion Strategies

```
INPUT: API Specification
       │
       ▼
DETECT FORMAT
├─ Try JSON parse
│  ├─ Success → format = "json"
│  └─ Fail ↓
│
├─ Try YAML parse
│  ├─ Success → format = "yaml"
│  └─ Fail → ERROR
│
└─ format = "json" or "yaml"

       │
       ▼
DETECT VERSION
├─ spec has "swagger" field?
│  YES → version = "2.0"
│
└─ spec has "openapi" field?
   YES → version = "3.0"
   NO → ERROR


DECISION TREE:

                    Is conversion needed?
                            │
              ┌─────────────┴──────────────┐
              │                           │
          NO  │                           │  YES
              │                           │
              ▼                           ▼
        NORMALIZATION            VERSION CONVERSION
                                        │
        (Same version)          ┌───────┼───────┐
                                │               │
        • Clean structure       │               │
        • Validate fields   2.0→3.0         3.0→2.0
        • Fix formatting       │               │
        • Fix refs             ▼               ▼
        • Add components   ┌─────────┐   ┌─────────┐
        • Add servers     │   AI    │   │Programm │
                          │ Convert │   │ atic    │
                          └────┬────┘   └────┬────┘
                               │             │
                               ├─ Retry x3  │
                               ├─ Fallback  │
                               │ if fail    │
                               │             │
                               └──────┬──────┘
                                      │
                                      ▼
                          AZURE APIM COMPATIBILITY
                                      │
                          ├─ Fix $ref paths
                          ├─ Create stubs
                          ├─ Fix structure
                          └─ Add servers
                                      │
                                      ▼
                        FORMAT CONVERSION
                                      │
                        (JSON ↔ YAML if needed)
                                      │
                                      ▼
                          RETURN RESULT
```

---

## 🚨 Error Recovery Paths

```
REQUEST STARTS
     │
     ▼
TRY PRIMARY METHOD
     │
     ├─ Success → RETURN RESULT
     │
     └─ FAILURE
        │
        ▼
   WHAT KIND OF ERROR?
        │
   ┌────┼────┬──────────┬────────┐
   │    │    │          │        │
 TIMEOUT CONFIG INVALID JSON  NETWORK
   │    │    │          │        │
   └─┬──┴─┬──┴────┬────┴────┬───┘
     │    │       │         │
     ▼    ▼       ▼         ▼
  RETRY FALLBACK EXTRACT  FALLBACK
  LOOP  SYNC  JSON    CONVERTER
     │    │       │         │
     ├─ Wait 2-60s │         │
     ├─ Retry x3   │         │
     │    │         │         │
   STILL │    │     ▼         │
  FAIL? ├─┐  ├─ If still invalid
     │  │ │  │   └─ Manual cleanup
     │  │ │  │   └─ Retry parse
     │  │ │  │   └─ If fail: ERROR
     │  │ │  │
     ▼  │ │  ▼
  YES   │ └─ PROGRAMMATIC
     │  │    CONVERTER
     │  │    (No AI needed)
     │  │    │
     │  │    ├─ Transform automatically
     │  │    ├─ Fixed logic
     │  │    └─ Returns spec
     │  │
     └──┴──→ FINAL RESULT
              (Success or Error)


SPECIFIC ERROR SCENARIOS:

1. TIMEOUT (>30s)
   ├─ Retry x3 with exponential backoff
   ├─ Detect large spec size
   ├─ If large: Summarize spec
   ├─ If still timeout: Use programmatic
   └─ If still fail: Return error

2. RATE LIMITED (429)
   ├─ Wait 60 seconds
   ├─ Retry once
   ├─ If still limited: Use programmatic
   └─ Log rate limit warning

3. INVALID JSON RESPONSE
   ├─ Strip markdown code blocks
   ├─ Find matching braces
   ├─ Extract JSON substring
   ├─ Validate with json.loads()
   ├─ If still invalid: Retry
   └─ If all fail: Use programmatic

4. CONFIGURATION ERROR
   ├─ Log missing config
   ├─ Suggest fixes
   ├─ Use programmatic converter
   └─ Still provide best result

5. AUTH ERROR
   ├─ Check credentials
   ├─ Verify permissions
   ├─ Try alternative auth
   └─ If all fail: Return error
```

---

## 🏗️ Component Relationships

```
┌────────────────────────────────────────────────────────┐
│                  Flask Application                     │
├────────────────────────────────────────────────────────┤
│                                                        │
│  Routes (app.py)                                       │
│  ├─ /api/upload           ← Handle file uploads       │
│  ├─ /api/migrate          ← Start migration           │
│  ├─ /api/convert          ← Convert specifications   │
│  ├─ /api/deploy           ← Deploy to Azure APIM     │
│  └─ /api/statistics       ← Get stats                 │
│                                                        │
└───────────┬──────────────────────────┬────────────────┘
            │                          │
            ▼                          ▼
    ┌───────────────────┐   ┌──────────────────┐
    │  Services Layer   │   │  File Handler    │
    │                   │   │                  │
    │  • Conversion     │   │  • Save files    │
    │  • Migration      │   │  • Read files    │
    │  • Validation     │   │  • Azure Blob    │
    │                   │   │  • Local FS      │
    └────────┬──────────┘   └──────────────────┘
             │
    ┌────────┴──────────────────────┐
    │                               │
    ▼                               ▼
┌───────────────────────┐   ┌──────────────────────┐
│ AzureOpenAIConnector  │   │ AzureAPIMConnector   │
│                       │   │                      │
│ Responsibilities:     │   │ Responsibilities:    │
│ • Convert specs       │   │ • Create APIs        │
│ • Normalize formats   │   │ • Manage APIs        │
│ • AI conversion       │   │ • Create products    │
│ • Validation          │   │ • Deployment         │
│ • Error recovery      │   │ • SSL/TLS handling   │
│                       │   │                      │
│ External Calls:       │   │ External Calls:      │
│ • Azure OpenAI API    │   │ • Azure APIM API     │
│ • Retry logic         │   │ • Certificate checks │
│ • Backoff strategy    │   │ • Resource mgmt      │
│                       │   │                      │
└───────────┬───────────┘   └──────────┬───────────┘
            │                          │
            │          ┌───────────────┴──────────┐
            │          │                          │
            ▼          ▼                          ▼
    ┌────────────────────┐   ┌────────────────────┐
    │  Azure OpenAI      │   │  Azure APIM        │
    │  • Models          │   │  • APIs            │
    │  • Conversions     │   │  • Products        │
    │  • Optimizations   │   │  • Policies        │
    │                    │   │  • SSL certificates│
    └────────────────────┘   └────────────────────┘
            │                          │
            │          ┌───────────────┴──────────┐
            │          │                          │
            ▼          ▼                          ▼
    ┌────────────────────────────────────────────┐
    │         Azure Subscription                 │
    │  (Resource Group / Storage / Databases)    │
    └────────────────────────────────────────────┘


DATA FLOW WITHIN COMPONENTS:

User Input (File)
       │
       ▼
File Handler
├─ Save to storage
├─ Parse content
└─ Return metadata
       │
       ▼
AzureOpenAIConnector
├─ Parse spec
├─ Detect version
├─ Call AI if needed
├─ Fix compatibility
└─ Return converted spec
       │
       ▼
AzureAPIMConnector
├─ Validate spec
├─ Extract metadata
├─ Create in APIM
├─ Create product
└─ Return deployment info
       │
       ▼
Database / Storage
├─ Save migration record
├─ Store converted spec
├─ Log operations
└─ Track status
       │
       ▼
User Response
├─ Status
├─ Result
├─ Metadata
└─ Links
```

---

## 📈 Performance & Scaling

```
THROUGHPUT LIMITS:

User Uploads
├─ File size: 16 MB max
├─ Format: JSON, YAML, XML
├─ Rate: 20 concurrent

AI Conversion
├─ Model: gpt-5-mini / gpt-4o-mini
├─ Rate limit: Tier dependent
├─ Timeout: 30-120 seconds
├─ Retries: Up to 3x
└─ Fallback: Programmatic (2 seconds)

APIM Deployment
├─ APIs: Limited by service tier
├─ Quota: Deployments per subscription
├─ Rate: ~10-20 deployments/minute
└─ Size: Depends on spec complexity

Database
├─ Records: Unlimited
├─ Queries: Optimized with indexes
├─ Connections: 10-20 pooled
└─ Transactions: Async-safe


SCALING STRATEGY:

HORIZONTAL SCALING:
┌─ Load Balancer
├─ Instance 1 (app.py)
│  ├─ Azure OpenAI Client
│  ├─ Azure APIM Client
│  └─ File Handler
├─ Instance 2 (app.py)
├─ Instance N (app.py)
└─ Shared:
   ├─ Database (PostgreSQL)
   ├─ Storage (Azure Blob)
   └─ Cache (Redis optional)

CACHING STRATEGY:
├─ Converted specs cache
├─ Model config cache
├─ APIM API list cache
└─ TTL: 1 hour


MONITORING POINTS:

AzureOpenAI:
├─ API response time (avg/p95)
├─ Conversion success rate
├─ Token usage per request
├─ Retry rate and reasons

AzureAPIM:
├─ Deployment success rate
├─ API creation time
├─ Quota usage
├─ SSL certificate validation rate

System:
├─ Request latency
├─ Error rate
├─ Database query time
├─ Storage operation time
└─ Memory/CPU usage
```

---

## 🔒 Security Architecture

```
┌──────────────────────────────────────────────────┐
│           SECURITY LAYERS                        │
├──────────────────────────────────────────────────┤
│                                                  │
│ 1. NETWORK SECURITY                              │
│    ├─ HTTPS/TLS encryption                       │
│    ├─ Custom CA certificates (private networks) │
│    ├─ Client certificates (mTLS)                │
│    └─ VPN/ExpressRoute support                   │
│                                                  │
│ 2. AUTHENTICATION SECURITY                       │
│    ├─ API Key (stored in Key Vault)             │
│    ├─ Entra ID / Managed Identity                │
│    ├─ Service Principal (APIM)                   │
│    └─ Token auto-refresh                         │
│                                                  │
│ 3. DATA SECURITY                                 │
│    ├─ Spec encryption at rest                    │
│    ├─ Spec encryption in transit                 │
│    ├─ Database encryption                        │
│    └─ Secure file handling                       │
│                                                  │
│ 4. APPLICATION SECURITY                          │
│    ├─ Input validation                           │
│    ├─ SQL injection prevention (ORM)             │
│    ├─ XSS protection (templating)                │
│    ├─ CSRF protection                            │
│    └─ Rate limiting                              │
│                                                  │
│ 5. SECRET MANAGEMENT                             │
│    ├─ Azure Key Vault integration                │
│    ├─ No secrets in code                         │
│    ├─ Environment variable rotation              │
│    └─ Audit logging for access                   │
│                                                  │
└──────────────────────────────────────────────────┘
```