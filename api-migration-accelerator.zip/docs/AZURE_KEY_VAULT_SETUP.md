# =============================================================================
# AZURE KEY VAULT INTEGRATION GUIDE
# Secure secrets management for production
# =============================================================================

## 🎯 OVERVIEW
═════════════════════════════════════════════════════════════════════════════

Azure Key Vault provides:
✅ Centralized secrets management
✅ Automatic secret rotation
✅ Audit logging
✅ Access control (RBAC)
✅ Encryption at rest and in transit
✅ Compliance (HIPAA, PCI-DSS, SOC 2)


## 📋 STEP 1: CREATE AZURE KEY VAULT
═════════════════════════════════════════════════════════════════════════════

Using Azure CLI:

```bash
# Create Key Vault
az keyvault create \
  --resource-group ai-rg \
  --name icoe-vault \
  --location eastus \
  --enable-soft-delete true \
  --soft-delete-retention 90

# Verify creation
az keyvault show --name icoe-vault --resource-group ai-rg
```

Using Azure Portal:
1. Go to Key Vault service
2. Click "Create"
3. Fill in:
   - Resource group: ai-rg
   - Vault name: icoe-vault
   - Region: East US
4. Click "Review + create"


## 🔑 STEP 2: ADD SECRETS TO KEY VAULT
═════════════════════════════════════════════════════════════════════════════

Using Azure CLI:

```bash
# Add AZURE_CLIENT_ID
az keyvault secret set \
  --vault-name icoe-vault \
  --name AZURE-CLIENT-ID \
  --value "44a2abd9-26cb-4246-9dd8-ed2ff219ebd6"

# Add AZURE_CLIENT_SECRET
az keyvault secret set \
  --vault-name icoe-vault \
  --name AZURE-CLIENT-SECRET \
  --value "z628Q~OXWeiXGHBas51fs8ay1gOODPA4DCASYbh3"

# Add DB_PASSWORD
az keyvault secret set \
  --vault-name icoe-vault \
  --name DB-PASSWORD \
  --value "Om%40Shiva1714"

# Add FLASK_SECRET_KEY (generate random)
az keyvault secret set \
  --vault-name icoe-vault \
  --name FLASK-SECRET-KEY \
  --value "$(openssl rand -base64 32)"

# Add SECRET_KEY (generate random)
az keyvault secret set \
  --vault-name icoe-vault \
  --name SECRET-KEY \
  --value "$(openssl rand -base64 32)"

# Add AZURE_OPENAI_API_KEY
az keyvault secret set \
  --vault-name icoe-vault \
  --name AZURE-OPENAI-API-KEY \
  --value "3DzQEWn65yWt0YYnUdtj3O1TgOZQiV53i0efENTfe1X2lxovvt4EJQQJ99BIACYeBjFXJ3w3AAABACOGuVOh"

# Add AZURE_STORAGE_ACCOUNT_KEY
az keyvault secret set \
  --vault-name icoe-vault \
  --name AZURE-STORAGE-ACCOUNT-KEY \
  --value "m5QmMaC7ccF+0OtKAh7Syk+0hPR/l4clLNBCDEPPyrEqETw5kDbrzgEQVnmbgSSGLnEm5SFuDd26+ASt4/2JYQ=="
```

Using Azure Portal:
1. Open your Key Vault
2. Go to Secrets
3. Click "+ Generate/Import"
4. Fill in Name and Value
5. Click Create


## 📝 STEP 3: CONFIGURE APP SERVICE WITH KEY VAULT REFERENCES
═════════════════════════════════════════════════════════════════════════════

Using Azure CLI:

```bash
az webapp config appsettings set \
  --resource-group ai-rg \
  --name icoe-api-prod \
  --settings \
    AZURE_CLIENT_ID="@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/AZURE-CLIENT-ID/)" \
    AZURE_CLIENT_SECRET="@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/AZURE-CLIENT-SECRET/)" \
    DB_PASSWORD="@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/DB-PASSWORD/)" \
    FLASK_SECRET_KEY="@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/FLASK-SECRET-KEY/)" \
    SECRET_KEY="@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/SECRET-KEY/)" \
    AZURE_OPENAI_API_KEY="@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/AZURE-OPENAI-API-KEY/)" \
    AZURE_STORAGE_ACCOUNT_KEY="@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/AZURE-STORAGE-ACCOUNT-KEY/)"
```

Using Azure Portal:
1. Go to your App Service
2. Settings → Configuration
3. For each secret setting, click "+ New application setting"
4. Name: AZURE_CLIENT_ID
5. Value: @Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/AZURE-CLIENT-ID/)
6. Repeat for all secrets


## 🔐 STEP 4: GRANT APP SERVICE PERMISSION TO KEY VAULT
═════════════════════════════════════════════════════════════════════════════

OPTION A: Using System-Assigned Managed Identity (RECOMMENDED)

```bash
# Enable System-Assigned Identity on App Service
az webapp identity assign \
  --resource-group ai-rg \
  --name icoe-api-prod

# Get the principal ID
PRINCIPAL_ID=$(az webapp identity show \
  --resource-group ai-rg \
  --name icoe-api-prod \
  --query principalId -o tsv)

# Grant Key Vault Secret Reader role
az role assignment create \
  --role "Key Vault Secrets User" \
  --assignee $PRINCIPAL_ID \
  --scope /subscriptions/<subscription-id>/resourceGroups/ai-rg/providers/Microsoft.KeyVault/vaults/icoe-vault

# Or use legacy command:
az keyvault set-policy \
  --name icoe-vault \
  --object-id $PRINCIPAL_ID \
  --secret-permissions get list
```

OPTION B: Using User-Assigned Managed Identity

```bash
# Create User-Assigned Identity
az identity create \
  --resource-group ai-rg \
  --name icoe-identity

# Get principal ID
PRINCIPAL_ID=$(az identity show \
  --resource-group ai-rg \
  --name icoe-identity \
  --query principalId -o tsv)

# Assign to App Service
az webapp identity assign \
  --resource-group ai-rg \
  --name icoe-api-prod \
  --identities /subscriptions/<subscription-id>/resourceGroups/ai-rg/providers/Microsoft.ManagedIdentity/userAssignedIdentities/icoe-identity

# Grant permissions
az keyvault set-policy \
  --name icoe-vault \
  --object-id $PRINCIPAL_ID \
  --secret-permissions get list
```

Using Azure Portal:
1. Go to App Service → Identity
2. System assigned → Status: ON
3. Go to Key Vault → Access policies
4. Click "+ Create"
5. Select permissions: Get, List (Secrets)
6. Select principal: Your App Service
7. Click Create


## ✅ STEP 5: VERIFY KEY VAULT INTEGRATION
═════════════════════════════════════════════════════════════════════════════

```bash
# Check app settings
az webapp config appsettings list \
  --resource-group ai-rg \
  --name icoe-api-prod

# Should show @Microsoft.KeyVault(...) references

# Check app service identity
az webapp identity show \
  --resource-group ai-rg \
  --name icoe-api-prod

# Test by accessing your app
curl https://icoe-api-prod.azurewebsites.net/health

# Check Application Insights logs
az monitor app-insights metrics show \
  --resource-group ai-rg \
  --app icoe-insights \
  --metric requests/count
```


## 🔒 AZURE KEY VAULT SECURITY BEST PRACTICES
═════════════════════════════════════════════════════════════════════════════

1. USE MANAGED IDENTITIES
   ✅ System-assigned identity (simplest)
   ✅ User-assigned identity (for multiple resources)
   ❌ Never use connection strings or keys

2. RBAC PERMISSIONS
   ✅ Use "Key Vault Secrets User" role (get, list)
   ❌ Never grant "Owner" or "Contributor"

3. ENABLE SOFT DELETE & PURGE PROTECTION
   ```bash
   az keyvault update \
     --name icoe-vault \
     --enable-purge-protection true \
     --enable-soft-delete true
   ```

4. ENABLE FIREWALL
   ```bash
   az keyvault update \
     --name icoe-vault \
     --default-action Deny \
     --bypass AzureServices
   ```

5. ENABLE AUDIT LOGGING
   ```bash
   az monitor diagnostic-settings create \
     --name icoe-vault-audit \
     --resource /subscriptions/<sub>/resourceGroups/ai-rg/providers/Microsoft.KeyVault/vaults/icoe-vault \
     --logs '[{"category": "AuditEvent", "enabled": true}]' \
     --workspace <workspace-id>
   ```

6. ENABLE VERSIONING
   - Key Vault automatically versions secrets
   - Track changes and rotate without breaking references

7. KEY ROTATION
   - Set up automatic key rotation
   - Review rotation schedule quarterly


## 📊 COMPLETE APP SETTINGS WITH KEY VAULT
═════════════════════════════════════════════════════════════════════════════

Name: icoe-vault
Location: East US

Secrets (in Key Vault):
  ✅ AZURE-CLIENT-ID
  ✅ AZURE-CLIENT-SECRET
  ✅ DB-PASSWORD
  ✅ FLASK-SECRET-KEY
  ✅ SECRET-KEY
  ✅ AZURE-OPENAI-API-KEY
  ✅ AZURE-STORAGE-ACCOUNT-KEY

App Settings (in App Service - with Key Vault references):
```json
{
  "AZURE_CLIENT_ID": "@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/AZURE-CLIENT-ID/)",
  "AZURE_CLIENT_SECRET": "@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/AZURE-CLIENT-SECRET/)",
  "DB_PASSWORD": "@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/DB-PASSWORD/)",
  "FLASK_SECRET_KEY": "@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/FLASK-SECRET-KEY/)",
  "SECRET_KEY": "@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/SECRET-KEY/)",
  "AZURE_OPENAI_API_KEY": "@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/AZURE-OPENAI-API-KEY/)",
  "AZURE_STORAGE_ACCOUNT_KEY": "@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/AZURE-STORAGE-ACCOUNT-KEY/)",
  
  "FLASK_ENV": "production",
  "FLASK_DEBUG": "False",
  "FLASK_HOST": "0.0.0.0",
  "FLASK_PORT": "8000",
  
  "AZURE_TENANT_ID": "f49ee784-e9e4-4c2c-98b3-980169c7fa33",
  "AZURE_SUBSCRIPTION_ID": "e86f4dcb-cf8f-42d6-aa1e-6e677cb0579a",
  "AZURE_APIM_RESOURCE_GROUP": "ai-rg",
  "AZURE_APIM_SERVICE_NAME": "charith-apim-rn",
  "AZURE_APIM_BASE_URL": "https://management.azure.com",
  "AZURE_OPENAI_ENDPOINT": "https://charith-open-001.openai.azure.com/",
  "AZURE_OPENAI_DEPLOYMENT": "gpt-5-mini",
  "AZURE_OPENAI_VERSION": "2025-01-01-preview",
  
  "DB_TYPE": "postgresql",
  "DB_HOST": "charith-postgres-migration.postgres.database.azure.com",
  "DB_PORT": "5432",
  "DB_NAME": "api_migration_db",
  "DB_USER": "apiadmin",
  "DB_SSLMODE": "require",
  "DB_POOL_SIZE": "10",
  "DB_MAX_OVERFLOW": "20",
  "DB_POOL_TIMEOUT": "30",
  "DB_POOL_RECYCLE": "3600",
  "DB_POOL_PRE_PING": "True",
  
  "AZURE_STORAGE_ACCOUNT_NAME": "aiappstorage123",
  "AZURE_STORAGE_CONNECTION_STRING": "DefaultEndpointsProtocol=https;AccountName=aiappstorage123;AccountKey=...",
  "AZURE_STORAGE_CONTAINER_NAME": "uploads",
  
  "GUNICORN_WORKERS": "4",
  "GUNICORN_WORKER_CLASS": "sync",
  "GUNICORN_TIMEOUT": "120",
  "GUNICORN_GRACEFUL_TIMEOUT": "60",
  "GUNICORN_KEEPALIVE": "5",
  
  "SECURITY_HEADERS_ENABLED": "True",
  "FORCE_HTTPS": "True",
  "CORS_ORIGINS": "https://yourdomain.com",
  "RATELIMIT_ENABLED": "True",
  "RATELIMIT_DEFAULT": "100 per hour",
  
  "LOG_LEVEL": "INFO",
  "LOG_HTTP_REQUESTS": "True",
  "LOG_SQL_QUERIES": "False",
  
  "SESSION_PERMANENT": "False",
  "SESSION_TYPE": "filesystem",
  "PERMANENT_SESSION_LIFETIME": "3600",
  
  "UPLOAD_FOLDER": "static/uploads",
  "MAX_CONTENT_LENGTH": "16777216",
  "ALLOWED_EXTENSIONS": "json,yaml,yml,txt",
  "FILE_RETENTION_DAYS": "30",
  "CLEANUP_ENABLED": "True"
}
```


## 🔄 KEY ROTATION PROCESS
═════════════════════════════════════════════════════════════════════════════

### Quarterly Key Rotation (RECOMMENDED)

1. Generate new secret in Key Vault
   ```bash
   az keyvault secret set \
     --vault-name icoe-vault \
     --name AZURE-CLIENT-SECRET-v2 \
     --value "new-secret-value"
   ```

2. Update App Service setting
   ```bash
   az webapp config appsettings set \
     --resource-group ai-rg \
     --name icoe-api-prod \
     --settings AZURE_CLIENT_SECRET="@Microsoft.KeyVault(SecretUri=https://icoe-vault.vault.azure.net/secrets/AZURE-CLIENT-SECRET-v2/)"
   ```

3. Test application
   ```bash
   curl https://icoe-api-prod.azurewebsites.net/health
   ```

4. Archive old secret (keep for 30 days)
5. Delete old secret after 30 days

### Automated Rotation (Premium Feature)
- Use Azure Key Vault Premium tier
- Configure automatic rotation
- Set rotation frequency (e.g., 90 days)
- Apply rotation function


## 🧪 TESTING KEY VAULT INTEGRATION
═════════════════════════════════════════════════════════════════════════════

Locally (with managed identity):

```bash
# Install Azure SDK
pip install azure-identity azure-keyvault-secrets

# Test connection
python
>>> from azure.identity import DefaultAzureCredential
>>> from azure.keyvault.secrets import SecretClient
>>> 
>>> credential = DefaultAzureCredential()
>>> client = SecretClient(
...     vault_url="https://icoe-vault.vault.azure.net/",
...     credential=credential
... )
>>> secret = client.get_secret("AZURE-CLIENT-ID")
>>> print(secret.value)
44a2abd9-26cb-4246-9dd8-ed2ff219ebd6
```

In Production:

```bash
# Check app logs
az webapp log tail \
  --resource-group ai-rg \
  --name icoe-api-prod

# Monitor Key Vault access
az monitor activity-log list \
  --resource-group ai-rg \
  --resource-type Microsoft.KeyVault/vaults

# Test health endpoint
curl https://icoe-api-prod.azurewebsites.net/health
```


## ❌ COMMON ISSUES & SOLUTIONS
═════════════════════════════════════════════════════════════════════════════

Issue: Access Denied Error
  → Check managed identity is enabled
  → Verify RBAC role assignment
  → Check Key Vault firewall rules
  → Solution: az keyvault set-policy

Issue: Secret Not Found
  → Verify secret exists in Key Vault
  → Check secret name (case-sensitive)
  → Verify URI format in app setting
  → Solution: az keyvault secret show --name AZURE-CLIENT-ID

Issue: App Service Can't Connect to Key Vault
  → Check network connectivity
  → Verify Key Vault firewall allows App Service
  → Check managed identity is in same subscription
  → Solution: az keyvault update --default-action Allow

Issue: Secrets Showing as Null
  → App Service needs to restart
  → Managed identity assignment takes time (5-10 min)
  → Clear app cache
  → Solution: Restart App Service


## 📋 MIGRATION CHECKLIST
═════════════════════════════════════════════════════════════════════════════

Pre-Migration:
  [ ] Create Key Vault
  [ ] Create managed identity
  [ ] Enable system-assigned identity on App Service
  [ ] Add RBAC role assignment
  [ ] Add all secrets to Key Vault

Migration:
  [ ] Update app settings with Key Vault references
  [ ] Test health endpoint
  [ ] Monitor logs for errors
  [ ] Verify secrets are being read
  [ ] Check performance metrics

Post-Migration:
  [ ] Remove old app settings (with plain secrets)
  [ ] Enable soft delete on Key Vault
  [ ] Enable purge protection
  [ ] Set up audit logging
  [ ] Document rotation schedule
  [ ] Train team on Key Vault management


## 🚀 SCRIPT: AUTOMATED KEY VAULT SETUP
═════════════════════════════════════════════════════════════════════════════

Save as: setup-keyvault.sh

```bash
#!/bin/bash

# Configuration
RESOURCE_GROUP="ai-rg"
VAULT_NAME="icoe-vault"
LOCATION="eastus"
APP_NAME="icoe-api-prod"
SUBSCRIPTION_ID="<your-subscription-id>"

echo "Creating Key Vault..."
az keyvault create \
  --resource-group $RESOURCE_GROUP \
  --name $VAULT_NAME \
  --location $LOCATION \
  --enable-soft-delete true \
  --soft-delete-retention 90

echo "Adding secrets to Key Vault..."
az keyvault secret set --vault-name $VAULT_NAME --name AZURE-CLIENT-ID --value "44a2abd9-26cb-4246-9dd8-ed2ff219ebd6"
az keyvault secret set --vault-name $VAULT_NAME --name AZURE-CLIENT-SECRET --value "z628Q~OXWeiXGHBas51fs8ay1gOODPA4DCASYbh3"
az keyvault secret set --vault-name $VAULT_NAME --name DB-PASSWORD --value "Om%40Shiva1714"
az keyvault secret set --vault-name $VAULT_NAME --name FLASK-SECRET-KEY --value "$(openssl rand -base64 32)"
az keyvault secret set --vault-name $VAULT_NAME --name SECRET-KEY --value "$(openssl rand -base64 32)"

echo "Enabling managed identity on App Service..."
az webapp identity assign \
  --resource-group $RESOURCE_GROUP \
  --name $APP_NAME

PRINCIPAL_ID=$(az webapp identity show \
  --resource-group $RESOURCE_GROUP \
  --name $APP_NAME \
  --query principalId -o tsv)

echo "Granting permissions..."
az keyvault set-policy \
  --name $VAULT_NAME \
  --object-id $PRINCIPAL_ID \
  --secret-permissions get list

echo "✅ Key Vault setup complete!"
echo "Vault: $VAULT_NAME"
echo "Principal ID: $PRINCIPAL_ID"
```

Run:
```bash
chmod +x setup-keyvault.sh
./setup-keyvault.sh
```


## 📚 ADDITIONAL RESOURCES
═════════════════════════════════════════════════════════════════════════════

Azure Key Vault Documentation:
  https://docs.microsoft.com/azure/key-vault/

Managed Identities:
  https://docs.microsoft.com/azure/active-directory/managed-identities-azure-resources/

App Service Key Vault Integration:
  https://docs.microsoft.com/azure/app-service/app-service-key-vault-references

Key Rotation Best Practices:
  https://docs.microsoft.com/azure/key-vault/key-vault-key-rotation-log-monitoring