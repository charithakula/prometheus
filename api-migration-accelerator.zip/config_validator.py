"""
Configuration Validator for Azure OpenAI
Separate, reusable validation class
"""
import os
import re
from typing import List, Dict, Any
from urllib.parse import urlparse
import logging

logger = logging.getLogger(__name__)


class ConfigValidator:
    """Validate Azure OpenAI configuration"""
    
    @staticmethod
    def validate_all() -> Dict[str, Any]:
        """
        Validate complete Azure OpenAI configuration
        
        Returns:
            {
                'valid': bool,
                'errors': [str],
                'warnings': [str],
                'config': {validated config dict}
            }
        """
        errors = []
        warnings = []
        config = {}
        
        # Validate endpoint
        endpoint = os.getenv('AZURE_OPENAI_ENDPOINT', '').strip()
        endpoint_error = ConfigValidator._validate_endpoint(endpoint)
        if endpoint_error:
            errors.append(endpoint_error)
        else:
            config['endpoint'] = endpoint
        
        # Validate authentication
        api_key = os.getenv('AZURE_OPENAI_API_KEY', '').strip()
        auth_error, auth_method = ConfigValidator._validate_auth(api_key)
        if auth_error:
            errors.append(auth_error)
        else:
            config['auth_method'] = auth_method
            if auth_method == 'api_key':
                config['api_key'] = api_key[:10] + '***'  # Mask for logging
        
        # Validate deployment
        deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT', '').strip()
        deployment_error = ConfigValidator._validate_deployment(deployment)
        if deployment_error:
            errors.append(deployment_error)
        else:
            config['deployment'] = deployment
        
        # Validate API version
        version = os.getenv('AZURE_OPENAI_VERSION', '').strip()
        version_error = ConfigValidator._validate_version(version)
        if version_error:
            errors.append(version_error)
        else:
            config['version'] = version
        
        # Add warnings for potentially problematic configs
        if not api_key:
            warnings.append("No API key configured - will attempt Entra ID authentication")
        
        if endpoint and endpoint.startswith('http://'):
            warnings.append("Endpoint is HTTP, not HTTPS - security risk")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings,
            'config': config
        }
    
    @staticmethod
    def _validate_endpoint(endpoint: str) -> str:
        """
        Validate Azure OpenAI endpoint
        
        Returns:
            Error message if invalid, empty string if valid
        """
        if not endpoint:
            return "AZURE_OPENAI_ENDPOINT not set"
        
        try:
            parsed = urlparse(endpoint)
            
            if not parsed.scheme:
                return "AZURE_OPENAI_ENDPOINT missing scheme (http/https)"
            
            if parsed.scheme not in ['http', 'https']:
                return f"AZURE_OPENAI_ENDPOINT invalid scheme: {parsed.scheme} (must be http or https)"
            
            if not parsed.netloc:
                return "AZURE_OPENAI_ENDPOINT missing hostname"
            
            # Check if it looks like a valid Azure endpoint
            if 'azure' not in endpoint.lower() and 'openai' not in endpoint.lower():
                return "AZURE_OPENAI_ENDPOINT doesn't look like an Azure OpenAI endpoint"
            
            return ""  # Valid
            
        except Exception as e:
            return f"AZURE_OPENAI_ENDPOINT URL parse error: {e}"
    
    @staticmethod
    def _validate_auth(api_key: str) -> tuple:
        """
        Validate authentication configuration
        
        Returns:
            (error_message, auth_method)
            - error_message: empty if valid
            - auth_method: 'api_key', 'entra_id', or None if invalid
        """
        if api_key:
            # Validate API key format
            if len(api_key) < 20:
                return "AZURE_OPENAI_API_KEY appears too short", None
            return "", "api_key"
        
        # Check if Entra ID libs are available
        try:
            from azure.identity import DefaultAzureCredential
            return "", "entra_id"
        except ImportError:
            return (
                "AZURE_OPENAI_API_KEY not set and azure-identity not installed. "
                "Install with: pip install azure-identity",
                None
            )
    
    @staticmethod
    def _validate_deployment(deployment: str) -> str:
        """
        Validate deployment name
        
        Returns:
            Error message if invalid, empty string if valid
        """
        if not deployment:
            return "AZURE_OPENAI_DEPLOYMENT not set"
        
        if len(deployment) < 3:
            return f"AZURE_OPENAI_DEPLOYMENT too short: '{deployment}'"
        
        if len(deployment) > 64:
            return f"AZURE_OPENAI_DEPLOYMENT too long: {len(deployment)} chars (max 64)"
        
        # Valid chars: alphanumeric, underscore, hyphen
        if not re.match(r'^[a-zA-Z0-9_-]+$', deployment):
            return f"AZURE_OPENAI_DEPLOYMENT contains invalid characters: '{deployment}'"
        
        return ""  # Valid
    
    @staticmethod
    def _validate_version(version: str) -> str:
        """
        Validate API version format
        
        Returns:
            Error message if invalid, empty string if valid
        """
        if not version:
            return "AZURE_OPENAI_VERSION not set"
        
        # Expected format: YYYY-MM-DD followed by optional -preview
        if not re.match(r'^\d{4}-\d{2}-\d{2}', version):
            return f"AZURE_OPENAI_VERSION invalid format: '{version}' (expected YYYY-MM-DD)"
        
        # Check if it's a reasonable year
        year = int(version.split('-')[0])
        if year < 2023 or year > 2030:
            return f"AZURE_OPENAI_VERSION year seems wrong: {year}"
        
        return ""  # Valid
    
    @staticmethod
    def print_validation_report() -> None:
        """Print validation report to console"""
        result = ConfigValidator.validate_all()
        
        print("\n" + "="*70)
        print("AZURE OPENAI CONFIGURATION VALIDATION REPORT")
        print("="*70)
        
        if result['valid']:
            print("✅ STATUS: VALID")
        else:
            print("❌ STATUS: INVALID")
        
        if result['errors']:
            print("\n🔴 ERRORS:")
            for i, error in enumerate(result['errors'], 1):
                print(f"  {i}. {error}")
        
        if result['warnings']:
            print("\n🟡 WARNINGS:")
            for i, warning in enumerate(result['warnings'], 1):
                print(f"  {i}. {warning}")
        
        if result['config']:
            print("\n✓ CONFIGURATION:")
            for key, value in result['config'].items():
                print(f"  {key}: {value}")
        
        print("\n" + "="*70 + "\n")
