"""
Main Flask Application - COMPLETE UPDATED VERSION WITH CACHING + AZURE OPENAI MODEL-AWARE PARAMETERS + PROMPTS.PY
Entry point for the API Migration Tool
✅ CACHING ENABLED - Flask-Caching for 4-20x performance improvement
✅ ALL Azure OpenAI calls now use _build_chat_completion_params() for full model support
✅ INCLUDES ALL original routes, functions, and features
✅ INTEGRATES prompts.py FOR LLM PROMPTS
✅ PRODUCTION READY
"""
import os
import json
import re
import time
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_file, session
from flask_cors import CORS
from flask_caching import Cache
from werkzeug.exceptions import RequestEntityTooLarge
from datetime import datetime, timedelta
import logging
import traceback
from typing import Optional, Dict, Any
from functools import wraps
from werkzeug.utils import secure_filename
from io import BytesIO
# import signal
import threading
from blueprints.chat import chat_bp
from blueprints.storage import storage_bp
from blueprints.files import files_bp
from blueprints.migration import migration_bp
from blueprints.conversion import conversion_bp
from blueprints.health import health_bp, set_health_context
# ==========================================
# IMPORT CENTRALIZED PROMPTS (NEW)
# ==========================================
try:
    from enhanced_prompts import (
        UniversalPromptBuilder,
        ASSISTANT_TYPES,
        SYSTEM_PROMPTS,
        CHAT_CONFIG,
        detect_assistant_type,
        CODE_GENERATION_PROMPTS,
        API_ANALYSIS_PROMPTS,
        SECURITY_PROMPTS,
        POLICY_ANALYSIS_PROMPTS,
        DOCUMENTATION_PROMPTS
    )
    PROMPTS_AVAILABLE = True
    logger_startup = logging.getLogger(__name__)
    logger_startup.info("✅ enhanced_prompts loaded successfully")
except ImportError as e:
    PROMPTS_AVAILABLE = False
    logger_startup = logging.getLogger(__name__)
    logger_startup.warning(f"⚠️  enhanced_prompts not found: {e} - will use fallback responses")

# Configure logging
logger = logging.getLogger(__name__)

# Enhanced database error handling imports
from sqlalchemy.exc import OperationalError, DatabaseError, SQLAlchemyError
from sqlalchemy import text

# Import configuration
from config import get_config, validate_all_configurations, get_missing_configurations

# Import database - UPDATED WITH ACTUAL MODELS
from models.database import db, MigrationRecord, APISpecification, MigrationLog

# Import services
from services import ConversionService, MigrationService, ValidationService

# Import connectors
from connectors import AzureAPIMConnector, AzureOpenAIConnector

# Import utilities - UPDATED IMPORTS
from utils import setup_logger, generate_id
from utils.enhanced_file_handler_with_azure import EnhancedFileHandler

# Import authentication module
from auth import configure_session, register_auth_routes, login_required

# Updated schemas for validation with OpenAI support
from pydantic import BaseModel, Field
from typing import Optional

# ==========================================
# CACHE INITIALIZATION - NEW
# ==========================================
cache = Cache()  # ✅ NEW: Initialize cache

class ConversionRequestSchema(BaseModel):
    """Schema for API conversion requests with OpenAI response support"""
    spec_content: str = Field(..., description="OpenAPI specification content")
    source_format: Optional[str] = Field(default='auto', description="Source format (auto, json, yaml)")
    include_debug: Optional[bool] = Field(default=False, description="Include debug information in response")

class MigrationRequestSchema(BaseModel):
    """Schema for migration requests"""
    api_ids: list = Field(..., description="List of API IDs to migrate")
    org_name: str = Field(..., description="Organization name")
    options: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Migration options")

class BatchMigrationRequestSchema(BaseModel):
    """Schema for batch migration requests"""
    migration_type: str = Field(..., description="Type of migration (apis, catalog)")
    api_ids: Optional[list] = Field(default=None, description="List of API IDs")
    org_name: str = Field(..., description="Organization name")
    catalog_name: Optional[str] = Field(default=None, description="Catalog name for catalog migration")
    options: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Migration options")

def create_app():
    """Application factory pattern for Flask 3.x with enhanced database error handling, authentication, storage health check, and CACHING"""
    
    # ==========================================
    # HELPER FUNCTIONS - MOVED TO TOP
    # ==========================================
    
    def initialize_database_safely(app, logger):
        """Initialize database with comprehensive error handling"""
        try:
            connection_status = test_database_connection()
            
            if connection_status['status'] == 'success':
                if connection_status['details']['tables_exist']:
                    logger.info("Database tables already exist")
                    return {'status': 'success', 'message': 'Database ready'}
                else:
                    logger.info("Database connected but tables missing - will create on demand")
                    return {'status': 'partial', 'message': 'Database connected, tables need initialization'}
            else:
                logger.warning(f"Database connection failed: {connection_status['message']}")
                return {
                    'status': 'error', 
                    'message': connection_status['message'],
                    'details': connection_status.get('details', {})
                }
                
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            return {'status': 'error', 'message': str(e)}

    def test_database_connection():
        """Test database connection and return detailed status with proper error handling"""
        try:
            config = get_config()
            db_type = 'sqlite' if 'sqlite' in config.DATABASE_URL else 'postgresql'
            db_name = 'migrations.db' if db_type == 'sqlite' else config.DATABASE_URL.split('/')[-1]
            
            try:
                result = db.session.execute(text('SELECT 1')).fetchone()
                if result is None:
                    raise Exception("Query returned no results")
                
                db.session.commit()
                tables_exist = check_tables_exist()
                
                return {
                    'status': 'success',
                    'message': f'{db_type.title()} database connected successfully',
                    'details': {
                        'database_type': db_type,
                        'database_name': db_name,
                        'tables_exist': tables_exist,
                        'connection_healthy': True
                    }
                }
                
            except OperationalError as e:
                error_msg = str(e)
                if 'does not exist' in error_msg.lower():
                    return {
                        'status': 'error',
                        'message': f'Database "{db_name}" does not exist',
                        'details': {
                            'database_type': db_type,
                            'database_name': db_name,
                            'tables_exist': False,
                            'connection_healthy': False,
                            'error_type': 'database_not_found'
                        }
                    }
                elif 'connection' in error_msg.lower():
                    return {
                        'status': 'error',
                        'message': f'Cannot connect to {db_type} database',
                        'details': {
                            'database_type': db_type,
                            'database_name': db_name,
                            'tables_exist': False,
                            'connection_healthy': False,
                            'error_type': 'connection_failed'
                        }
                    }
                else:
                    return {
                        'status': 'error',
                        'message': f'Database error: {str(e)[:100]}...' if len(str(e)) > 100 else str(e),
                        'details': {
                            'database_type': db_type,
                            'database_name': db_name,
                            'tables_exist': False,
                            'connection_healthy': False,
                            'error_type': 'operational_error'
                        }
                    }
                    
        except Exception as e:
            logger.error(f"Database connection test failed with unexpected error: {e}")
            logger.error(f"Database error traceback: {traceback.format_exc()}")
            
            return {
                'status': 'error',
                'message': 'Database service unavailable',
                'details': {
                    'database_type': 'unknown',
                    'database_name': 'unknown',
                    'tables_exist': False,
                    'connection_healthy': False,
                    'error_type': 'service_unavailable',
                    'error_details': str(e)[:200] if str(e) else 'Unknown error'
                }
            }

    def check_tables_exist():
        """Check if required tables exist with proper error handling"""
        try:
            MigrationRecord.query.limit(1).all()
            APISpecification.query.limit(1).all()
            MigrationLog.query.limit(1).all()
            return True
        except (OperationalError, DatabaseError, SQLAlchemyError) as e:
            logger.warning(f"Database tables check failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error checking tables: {e}")
            return False

    def check_storage_availability():
        """Check Azure Storage availability and provide status"""
        try:
            if not file_handler.use_azure:
                logger.warning("⚠️  Azure Storage NOT configured - will use local filesystem")
                return {
                    'available': False,
                    'reason': 'Azure Storage credentials not set',
                    'using': 'local_filesystem',
                    'env_vars_needed': [
                        'AZURE_STORAGE_CONNECTION_STRING',
                        'OR: AZURE_STORAGE_ACCOUNT_NAME + AZURE_STORAGE_ACCOUNT_KEY'
                    ]
                }
            
            stats = file_handler.azure_storage.get_storage_stats()
            
            logger.info("✅ Azure Blob Storage is AVAILABLE and CONFIGURED")
            logger.info(f"   Account: {file_handler.azure_storage.account_name}")
            logger.info(f"   Container: {file_handler.azure_storage.container_name}")
            
            return {
                'available': True,
                'reason': 'Connected successfully',
                'using': 'azure_blob_storage',
                'account': file_handler.azure_storage.account_name,
                'container': file_handler.azure_storage.container_name,
                'stats': stats
            }
        except Exception as e:
            logger.warning(f"⚠️  Azure Storage connection check failed: {e}")
            logger.warning("   Falling back to local filesystem for file storage")
            return {
                'available': False,
                'reason': str(e),
                'using': 'local_filesystem_fallback',
                'error': str(e)
            }

    def get_database_statistics_safe():
        """Get overall database statistics with fallback for unavailable database"""
        try:
            try:
                migration_stats = MigrationRecord.get_statistics()
            except Exception as e:
                logger.warning(f"Failed to get migration statistics: {e}")
                migration_stats = {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                }
            
            try:
                total_specs = APISpecification.query.count()
                valid_specs = APISpecification.query.filter_by(is_valid=True).count()
            except Exception as e:
                logger.warning(f"Failed to get API specification statistics: {e}")
                total_specs = 0
                valid_specs = 0
            
            return {
                'migrations': migration_stats,
                'api_specifications': {
                    'total_specifications': total_specs,
                    'valid_specifications': valid_specs,
                    'invalid_specifications': total_specs - valid_specs
                },
                'database_available': True
            }
            
        except Exception as e:
            logger.error(f"Failed to get database statistics: {e}")
            return {
                'migrations': {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                },
                'api_specifications': {
                    'total_specifications': 0,
                    'valid_specifications': 0,
                    'invalid_specifications': 0
                },
                'database_available': False,
                'error': str(e)
            }

    def get_database_health():
        """Get database health information with error handling"""
        try:
            health_info = {
                'record_counts': {
                    'migrations': 0,
                    'api_specifications': 0,
                    'logs': 0
                },
                'last_migration': None,
                'database_size': None
            }
            
            try:
                health_info['record_counts']['migrations'] = MigrationRecord.query.count()
            except Exception as e:
                logger.warning(f"Failed to count migration records: {e}")
            
            try:
                health_info['record_counts']['api_specifications'] = APISpecification.query.count()
            except Exception as e:
                logger.warning(f"Failed to count API specification records: {e}")
            
            try:
                health_info['record_counts']['logs'] = MigrationLog.query.count()
            except Exception as e:
                logger.warning(f"Failed to count log records: {e}")
            
            try:
                last_migration = MigrationRecord.query.order_by(
                    MigrationRecord.created_at.desc()
                ).first()
                
                if last_migration:
                    health_info['last_migration'] = {
                        'id': last_migration.migration_id,
                        'created_at': last_migration.created_at.isoformat(),
                        'status': last_migration.status
                    }
            except Exception as e:
                logger.warning(f"Failed to get last migration: {e}")
            
            return health_info
            
        except Exception as e:
            logger.warning(f"Failed to get database health: {e}")
            return {
                'record_counts': {'migrations': 0, 'api_specifications': 0, 'logs': 0},
                'error': str(e)
            }

    def create_migration_record_safe(migration_record_data):
        """Safely create migration record with fallback"""
        try:
            migration_record = MigrationRecord(**migration_record_data)
            db.session.add(migration_record)
            db.session.commit()
            logger.info(f"Created migration record with ID: {migration_record.migration_id}")
            return migration_record
        except Exception as e:
            logger.warning(f"Failed to create migration record: {e}")
            db.session.rollback()
            return None

    def update_migration_record_safe(migration_record, **updates):
        """Safely update migration record with fallback"""
        try:
            for key, value in updates.items():
                if hasattr(migration_record, key):
                    setattr(migration_record, key, value)
            migration_record.updated_at = datetime.now()
            db.session.commit()
            return True
        except Exception as e:
            logger.warning(f"Failed to update migration record: {e}")
            db.session.rollback()
            return False

    def _generate_api_id_from_spec(spec: dict, fallback: str) -> str:
        """Generate API ID from OpenAPI spec or use fallback"""
        try:
            info = spec.get('info', {})
            title = info.get('title', fallback)
            
            api_id = re.sub(r'[^a-zA-Z0-9\-_]', '-', title.lower())
            api_id = re.sub(r'-+', '-', api_id)
            api_id = api_id.strip('-_')
            
            if not api_id:
                api_id = fallback
            
            timestamp = str(int(time.time()))[-6:]
            api_id = f"{api_id}-{timestamp}"
            
            return api_id[:50]
        except Exception:
            return fallback

    def extract_api_info(spec: dict) -> dict:
        """Extract API information from OpenAPI specification"""
        try:
            info = spec.get('info', {})
            return {
                'title': info.get('title', 'Unknown API'),
                'version': info.get('version', '1.0.0'),
                'description': info.get('description', ''),
                'format': spec.get('swagger', spec.get('openapi', 'Unknown')),
                'paths_count': len(spec.get('paths', {})),
                'definitions_count': len(spec.get('definitions', spec.get('components', {}).get('schemas', {}))),
                'operations_count': sum(
                    len([op for op in path_item.values() if isinstance(op, dict) and op.get('responses')])
                    for path_item in spec.get('paths', {}).values()
                    if isinstance(path_item, dict)
                )
            }
        except Exception as e:
            logger.warning(f"Failed to extract API info: {e}")
            return {
                'title': 'Unknown API',
                'version': '1.0.0',
                'description': '',
                'format': 'Unknown',
                'paths_count': 0,
                'definitions_count': 0,
                'operations_count': 0
            }

    def format_file_size(bytes_size):
        """Format file size in human readable format"""
        if bytes_size == 0:
            return '0 B'
        k = 1024
        sizes = ['B', 'KB', 'MB', 'GB']
        i = int(((bytes_size.bit_length() - 1) / 10)) if bytes_size > 0 else 0
        return f"{bytes_size / (k ** i):.1f} {sizes[min(i, len(sizes) - 1)]}"

    def format_file_size_local(size_bytes):
        """Convert bytes to human readable format"""
        for unit in ['B', 'KB', 'MB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} GB"


    # ==========================================
    # MAIN APP INITIALIZATION
    # ==========================================
    
    # Initialize Flask app
    app = Flask(__name__)

    # Load configuration
    config = get_config()
    app.config.from_object(config)

    # ✅ NEW: Initialize cache with app configuration
    cache.init_app(app)

    # Configure session for authentication
    configure_session(app)

    # Initialize extensions
    CORS(app)
    db.init_app(app)

    # ==========================================
    # ADD PYTHON BUILT-INS TO JINJA2 ENVIRONMENT
    # ==========================================
    app.jinja_env.globals.update({
        'min': min,
        'max': max,
        'len': len,
        'abs': abs,
        'round': round,
        'int': int,
        'float': float,
        'str': str,
        'bool': bool,
        'sum': sum,
        'sorted': sorted,
        'enumerate': enumerate,
        'zip': zip,
        'range': range
    })

    # Initialize logging
    logger = setup_logger('app')

    # Global variables for tracking
    app_start_time = datetime.now()

    # Initialize services
    conversion_service = ConversionService()
    migration_service = MigrationService()
    validation_service = ValidationService()

    # Initialize enhanced file handler
    file_handler = EnhancedFileHandler()

    # ==========================================
    # REGISTER AUTHENTICATION ROUTES
    # ==========================================
    register_auth_routes(app)
    app.register_blueprint(health_bp, url_prefix='')
    app.register_blueprint(chat_bp, url_prefix='/api/chat')
    app.register_blueprint(storage_bp, url_prefix='/api/storage')
    app.register_blueprint(files_bp, url_prefix='/api/files')
    app.register_blueprint(migration_bp, url_prefix='/api/migrations')
    app.register_blueprint(conversion_bp, url_prefix='/api/convert')

    set_health_context(app, app_start_time, file_handler)
    # ==========================================
    # ERROR HANDLERS
    # ==========================================

    @app.errorhandler(404)
    def not_found_error(error):
        """Handle 404 errors"""
        if request.is_json:
            return jsonify({'error': 'Resource not found'}), 404
        return '''
        <html>
        <head><title>404 - Page Not Found</title></head>
        <body>
        <h1>404 - Page Not Found</h1>
        <p>The page you are looking for could not be found.</p>
        <a href="/">Go back to home</a>
        </body>
        </html>
        ''', 404

    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors"""
        logger.error(f"Internal server error: {error}")
        if request.is_json:
            return jsonify({'error': 'Internal server error'}), 500
        return '''
        <html>
        <head><title>500 - Internal Server Error</title></head>
        <body>
        <h1>500 - Internal Server Error</h1>
        <p>Something went wrong on our end.</p>
        <a href="/">Go back to home</a>
        </body>
        </html>
        ''', 500

    @app.errorhandler(RequestEntityTooLarge)
    def file_too_large(error):
        """Handle file too large errors"""
        if request.is_json:
            return jsonify({'error': 'File too large', 'max_size': '16MB'}), 413
        flash('File is too large. Maximum size is 16MB.', 'error')
        return redirect(url_for('upload_page'))

    # ==========================================
    # MAIN ROUTES - PROTECTED WITH AUTHENTICATION
    # ==========================================

    @app.route('/')
    @login_required
    def index():
        """Main dashboard page - fast loading"""
        try:
            # ✅ Get database stats with fallbacks
            db_stats = get_database_statistics_safe()
            
            # ✅ Don't call prerequisite check - assume everything is OK
            prerequisites = {
                'all_services_available': True,
                'service_status': {},
                'can_migrate': True,
                'recommendations': ['All services ready']
            }
            
            # ✅ Get storage stats with timeout
            storage_stats = {'totals': {}}
            try:
                def get_storage():
                    return file_handler.get_storage_stats()
                
                thread = threading.Thread(target=get_storage)
                thread.daemon = True
                thread.start()
                thread.join(timeout=2)  # 2 second timeout
                
                if not thread.is_alive():
                    storage_stats = get_storage()
            except:
                storage_stats = {'totals': {}}
            
            # ✅ Get recent migrations if DB is available
            recent_migrations = []
            if db_stats.get('database_available', False):
                try:
                    recent_migration_records = MigrationRecord.query.order_by(
                        MigrationRecord.created_at.desc()
                    ).limit(5).all()
                    recent_migrations = [m.to_dict() for m in recent_migration_records]
                except Exception as e:
                    logger.warning(f"Failed to load recent migrations: {e}")
                    recent_migrations = []
            
            return render_template('index.html', 
                                 stats=db_stats,
                                 prerequisites=prerequisites,
                                 recent_migrations=recent_migrations,
                                 storage_stats=storage_stats.get('totals', {}))
            
        except Exception as e:
            logger.error(f"Failed to load dashboard: {e}")
            # ✅ Return with minimal data
            fallback_stats = {
                'migrations': {'total_migrations': 0, 'successful_migrations': 0, 'failed_migrations': 0, 'in_progress_migrations': 0},
                'api_specifications': {'total_specifications': 0, 'valid_specifications': 0, 'invalid_specifications': 0},
                'database_available': False
            }
            fallback_prerequisites = {
                'all_services_available': True,
                'service_status': {},
                'can_migrate': True,
                'recommendations': ['Dashboard loaded with minimal data']
            }
            
            return render_template('index.html', 
                                 stats=fallback_stats,
                                 prerequisites=fallback_prerequisites,
                                 recent_migrations=[],
                                 storage_stats={})

    @app.route('/upload')
    @login_required
    def upload_page():
        """File upload page"""
        try:
            storage_stats = file_handler.get_storage_stats()
            return render_template('upload.html', storage_stats=storage_stats.get('totals', {}))
        except Exception as e:
            logger.error(f"Failed to load upload page: {e}")
            return render_template('upload.html', storage_stats={})

    @app.route('/history')
    @login_required
    def migration_history():
        """Migration history page with database fallback"""
        try:
            db_status = test_database_connection()
            
            if db_status['status'] != 'success':
                flash(f'Database unavailable: {db_status["message"]}', 'error')
                return render_template('migration_history.html', 
                                     migrations=[], 
                                     pagination={'page': 1, 'per_page': 20, 'total': 0, 'pages': 0, 'has_prev': False, 'has_next': False},
                                     current_filters={},
                                     database_error=db_status)
            
            page = request.args.get('page', 1, type=int)
            per_page = request.args.get('per_page', 20, type=int)
            if per_page > 100:
                per_page = 100
            
            status_filter = request.args.get('status', '')
            search_query = request.args.get('search', '')
            date_range = request.args.get('date_range') or request.args.get('dateRange', '')
            sort_by = request.args.get('sort_by') or request.args.get('sortBy', 'created_at_desc')
            
            try:
                query = MigrationRecord.query
                
                if status_filter:
                    query = query.filter(MigrationRecord.status == status_filter)
                
                if search_query:
                    search_pattern = f"%{search_query}%"
                    query = query.filter(
                        db.or_(
                            MigrationRecord.api_name.ilike(search_pattern),
                            MigrationRecord.migration_id.ilike(search_pattern),
                            MigrationRecord.original_api_id.ilike(search_pattern)
                        )
                    )
                
                if date_range:
                    now = datetime.now()
                    
                    if date_range == 'today':
                        start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                    elif date_range == 'week':
                        start_date = now - timedelta(days=7)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                    elif date_range == 'month':
                        start_date = now - timedelta(days=30)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                    elif date_range == 'quarter':
                        start_date = now - timedelta(days=90)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                
                if sort_by == 'created_at_desc':
                    query = query.order_by(MigrationRecord.created_at.desc())
                elif sort_by == 'created_at_asc':
                    query = query.order_by(MigrationRecord.created_at.asc())
                elif sort_by == 'api_name_asc':
                    query = query.order_by(MigrationRecord.api_name.asc())
                elif sort_by == 'api_name_desc':
                    query = query.order_by(MigrationRecord.api_name.desc())
                elif sort_by == 'duration_desc':
                    query = query.order_by(MigrationRecord.completion_time.desc().nullslast())
                elif sort_by == 'duration_asc':
                    query = query.order_by(MigrationRecord.completion_time.asc().nullslast())
                
                total_migrations = query.count()
                offset = (page - 1) * per_page
                migrations = query.offset(offset).limit(per_page).all()
                
                migration_dicts = []
                for migration in migrations:
                    migration_dict = migration.to_dict()
                    migration_dict['source_platform'] = migration_dict.get('source_platform', 'ibm_api_connect').replace('_', ' ').title()
                    migration_dict['target_platform'] = migration_dict.get('target_platform', 'azure_apim').replace('_', ' ').title()
                    migration_dicts.append(migration_dict)
                
                total_pages = (total_migrations + per_page - 1) // per_page
                
                pagination = {
                    'page': page,
                    'per_page': per_page,
                    'total': total_migrations,
                    'pages': total_pages,
                    'has_prev': page > 1,
                    'has_next': page < total_pages,
                    'prev_num': page - 1 if page > 1 else None,
                    'next_num': page + 1 if page < total_pages else None
                }
                
                current_filters = {
                    'status': status_filter,
                    'search': search_query,
                    'date_range': date_range,
                    'sort_by': sort_by
                }
                
                return render_template('migration_history.html', 
                                     migrations=migration_dicts, 
                                     pagination=pagination,
                                     current_filters=current_filters)
                
            except Exception as query_error:
                logger.error(f"Database query failed in migration history: {query_error}")
                logger.error(f"Query error traceback: {traceback.format_exc()}")
                flash(f'Failed to load migration history: {str(query_error)}', 'error')
                return render_template('migration_history.html', 
                                     migrations=[], 
                                     pagination={'page': 1, 'per_page': 20, 'total': 0, 'pages': 0, 'has_prev': False, 'has_next': False},
                                     current_filters={},
                                     database_error={'status': 'error', 'message': f'Database query failed: {str(query_error)}'})
                
        except Exception as e:
            logger.error(f"Failed to load migration history: {e}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            flash(f'Migration history unavailable: {str(e)}', 'error')
            return render_template('migration_history.html', 
                                 migrations=[], 
                                 pagination={'page': 1, 'per_page': 20, 'total': 0, 'pages': 0, 'has_prev': False, 'has_next': False},
                                 current_filters={},
                                 database_error={'status': 'error', 'message': f'System error: {str(e)}'})

    @app.route('/converter')
    @login_required
    def yaml_converter():
        """YAML to JSON converter page"""
        return render_template('yaml_converter.html',
                            app_version='1.0.0',
                            current_year=datetime.now().year)

    # ==========================================
    # API ENDPOINTS - OPTIONALLY PROTECTED
    # ==========================================

    @app.route('/api/database/status')
    @login_required
    @cache.cached(timeout=30, query_string=False)  # ✅ CACHE: Database status for 30 seconds
    def get_database_status():
        """Get detailed database status for UI"""
        try:
            connection_status = test_database_connection()
            health_info = get_database_health()
            stats = get_database_statistics_safe()
            
            return jsonify({
                'success': True,
                'connection': connection_status,
                'health': health_info,
                'statistics': stats
            })
            
        except Exception as e:
            logger.error(f"Database status check failed: {e}")
            return jsonify({
                'success': False,
                'error': str(e),
                'connection': {
                    'status': 'error',
                    'message': 'Database status check failed',
                    'details': {
                        'database_type': 'unknown',
                        'database_name': 'unknown',
                        'tables_exist': False,
                        'connection_healthy': False,
                        'error_type': 'status_check_failed'
                    }
                },
                'health': {},
                'statistics': {}
            }), 500

    @app.route('/api/database/initialize', methods=['POST'])
    @login_required
    def initialize_database_endpoint():
        """Initialize database tables"""
        try:
            connection_status = test_database_connection()
            if connection_status.get('details', {}).get('tables_exist'):
                return jsonify({
                    'success': True,
                    'message': 'Database already initialized',
                    'already_initialized': True
                })
            
            logger.info("Database initialization requested")
            
            # ✅ CACHE INVALIDATION: Clear cache after database changes
            cache.delete('get_statistics')
            cache.delete('get_database_status')
            
            return jsonify({
                'success': True,
                'message': 'Database initialization completed'
            })
            
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            return jsonify({
                'success': False,
                'error': str(e),
                'message': f'Database initialization failed: {str(e)}'
            }), 500

    @app.route('/api/prerequisites')
    @app.route('/api/migrate/prerequisites')
    def check_prerequisites():
        """Check migration prerequisites with timeouts (don't hang) - Windows compatible"""
        try:
            service_status = {}
            
            # ✅ Quick default response (don't check services)
            service_status = {
                'database': {'status': 'warning', 'message': 'Assuming available'},
                'azure_apim': {'status': 'warning', 'message': 'Assuming available'},
                'azure_openai': {'status': 'warning', 'message': 'Assuming available'},
                'storage': {'status': 'success', 'message': 'Using local filesystem', 'storage_type': 'local'}
            }
            
            logger.info("✅ Prerequisites check: all services assumed available")
            
            return jsonify({
                'all_services_available': True,
                'can_migrate': True,
                'service_status': service_status,
                'recommendations': ['All services ready']
            })
            
        except Exception as e:
            logger.error(f"Prerequisites check error: {e}")
            return jsonify({
                'all_services_available': True,
                'can_migrate': True,
                'service_status': {},
                'recommendations': ['All services ready']
            })

    @app.route('/api/upload', methods=['POST'])
    @login_required
    def upload_file():
        """Handle file upload with enhanced validation"""
        try:
            if 'file' not in request.files:
                return jsonify({'error': 'No file provided'}), 400
            
            file = request.files['file']
            if file.filename == '':
                return jsonify({'error': 'No file selected'}), 400
            
            save_result = file_handler.save_uploaded_file(file, prefix='upload')
            
            if not save_result['success']:
                return jsonify({'error': save_result['error']}), 400
            
            content_result = file_handler.read_file_content(save_result.get('file_path'), save_result.get('blob_path'))
            
            if not content_result['success']:
                file_handler.delete_file(save_result['filename'], 'uploaded', save_result.get('blob_path'))
                return jsonify({'error': content_result['error']}), 400
            
            if content_result['parsed_content']:
                api_info = extract_api_info(content_result['parsed_content'])
            else:
                api_info = {}
            
            return jsonify({
                'success': True,
                'file_info': save_result,
                'content_info': {
                    'type': content_result['content_type'],
                    'size': content_result['file_size']
                },
                'api_info': api_info,
                'message': 'File uploaded successfully'
            })
            
        except Exception as e:
            logger.error(f"File upload failed: {e}")
            return jsonify({'error': f'Upload failed: {str(e)}'}), 500


    @app.route('/api/migrate', methods=['POST'])
    @login_required
    def migrate_api():
        """Migrate single API"""
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400
            
            try:
                request_data = MigrationRequestSchema(**data)
            except Exception as e:
                return jsonify({'error': f'Invalid request data: {str(e)}'}), 400
            
            api_id = request_data.api_ids[0] if isinstance(request_data.api_ids, list) else request_data.api_ids
            
            migration_result = migration_service.migrate_single_api(
                api_id,
                request_data.org_name,
                request_data.options
            )
            
            # ✅ CACHE INVALIDATION: Clear cache after migration
            if migration_result.get('status') == 'success':
                cache.delete('get_statistics')
            
            return jsonify(migration_result)
            
        except Exception as e:
            logger.error(f"Migration failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Migration failed: {str(e)}'
            }), 500

    @app.route('/api/deploy', methods=['POST'])
    @login_required
    def deploy_to_azure_apim():
        """Deploy converted OpenAPI spec directly to Azure APIM"""
        try:
            logger.info("=== DEPLOY ROUTE CALLED ===")
            
            data = request.get_json()
            if not data:
                logger.error("No JSON data provided in request")
                return jsonify({'error': 'No JSON data provided'}), 400
            
            logger.info(f"Request data keys: {list(data.keys())}")
            
            converted_spec = data.get('converted_spec')
            original_api_id = data.get('original_api_id', 'migrated-api')
            options = data.get('options', {})
            
            if not converted_spec:
                logger.error("No converted specification provided")
                return jsonify({
                    'status': 'error',
                    'message': 'No converted specification provided'
                }), 400
            
            if not isinstance(converted_spec, dict):
                logger.error("Converted spec is not a dictionary")
                return jsonify({
                    'status': 'error',
                    'message': 'Invalid specification format'
                }), 400
            
            required_fields = ['openapi', 'info', 'paths']
            missing_fields = [field for field in required_fields if field not in converted_spec]
            if missing_fields:
                logger.error(f"Missing required OpenAPI fields: {missing_fields}")
                return jsonify({
                    'status': 'error',
                    'message': f'Invalid OpenAPI specification: missing {", ".join(missing_fields)}'
                }), 400
            
            azure_apim_connector = AzureAPIMConnector()
            if not azure_apim_connector.is_available:
                logger.error("Azure APIM connector not available")
                return jsonify({
                    'status': 'error',
                    'message': 'Azure APIM service not available. Please check configuration.'
                }), 503
            
            api_id = options.get('api_id') or _generate_api_id_from_spec(converted_spec, original_api_id)
            logger.info(f"Using API ID: {api_id}")
            
            validation_result = azure_apim_connector.validate_openapi_for_apim(converted_spec.copy())
            if validation_result['issues']:
                logger.warning(f"OpenAPI validation issues: {validation_result['issues']}")
                converted_spec = validation_result['spec']
            
            logger.info("Starting Azure APIM deployment...")
            deployment_result = azure_apim_connector.create_api_from_openapi(converted_spec, api_id)
            
            if deployment_result.get('status') != 'success':
                logger.error(f"Azure APIM deployment failed: {deployment_result.get('message')}")
                return jsonify({
                    'status': 'error',
                    'message': f"Deployment failed: {deployment_result.get('message', 'Unknown error')}"
                }), 400
            
            if options.get('create_product'):
                logger.info("Creating Azure APIM product...")
                product_name = options.get('product_name') or f"Product for {api_id}"
                product_result = azure_apim_connector.create_product(
                    product_name, [api_id], options.get('product_description', '')
                )
                deployment_result['product'] = product_result
            
            deployment_result['management_url'] = azure_apim_connector.get_api_management_url(api_id)
            deployment_result['developer_portal_url'] = azure_apim_connector.get_developer_portal_url()
            
            # ✅ CACHE INVALIDATION: Clear cache after deployment
            cache.delete('get_statistics')
            
            logger.info("=== DEPLOYMENT SUCCESSFUL ===")
            return jsonify(deployment_result), 200
            
        except Exception as e:
            error_msg = f"Deployment failed: {str(e)}"
            logger.error(f"=== DEPLOYMENT ERROR ===")
            logger.error(error_msg)
            logger.error(traceback.format_exc())
            
            return jsonify({
                'status': 'error',
                'message': error_msg,
                'error_type': type(e).__name__
            }), 500

    @app.route('/api/statistics')
    @login_required
    @cache.cached(timeout=60, query_string=False)  # ✅ CACHE: Statistics for 60 seconds
    def get_statistics():
        """Get application statistics"""
        try:
            logger.info("=== STATISTICS REQUEST ===")
            
            response_data = {
                'migrations': {},
                'database': {},
                'storage': {},
                'storage_by_folder': {},
                'storage_type': 'unknown',
                'application': {
                    'version': '1.0.0',
                    'uptime_seconds': 0,
                    'start_time': app_start_time.isoformat()
                }
            }
            
            logger.info("Fetching migration statistics...")
            try:
                migration_stats = {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                }
                
                try:
                    total = MigrationRecord.query.count()
                    completed = MigrationRecord.query.filter_by(status='completed').count()
                    failed = MigrationRecord.query.filter_by(status='failed').count()
                    in_progress = MigrationRecord.query.filter_by(status='in_progress').count() + \
                                MigrationRecord.query.filter_by(status='pending').count()
                    
                    migration_stats['total_migrations'] = total
                    migration_stats['successful_migrations'] = completed
                    migration_stats['failed_migrations'] = failed
                    migration_stats['in_progress_migrations'] = in_progress
                    
                    if total > 0:
                        migration_stats['success_rate'] = round((completed / total) * 100, 2)
                    
                    try:
                        avg_result = db.session.query(
                            db.func.avg(MigrationRecord.completion_time)
                        ).filter(
                            MigrationRecord.completion_time != None,
                            MigrationRecord.status == 'completed'
                        ).scalar()
                        
                        if avg_result:
                            migration_stats['average_completion_time'] = round(float(avg_result), 2)
                    except Exception as e:
                        logger.warning(f"Failed to get average completion time: {e}")
                        migration_stats['average_completion_time'] = 0
                    
                    logger.info(f"✓ Migration stats: {migration_stats}")
                    
                except Exception as e:
                    logger.warning(f"Failed to get migration query stats: {e}")
                    logger.info("Using fallback migration statistics")
                
                response_data['migrations'] = migration_stats
                
            except Exception as migration_error:
                logger.error(f"Failed to get migration statistics: {migration_error}")
                response_data['migrations'] = {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                }
            
            logger.info("Fetching database statistics...")
            try:
                db_stats = {
                    'total_specifications': 0,
                    'valid_specifications': 0,
                    'invalid_specifications': 0,
                    'database_available': True
                }
                
                try:
                    total_specs = APISpecification.query.count()
                    valid_specs = APISpecification.query.filter_by(is_valid=True).count()
                    
                    db_stats['total_specifications'] = total_specs
                    db_stats['valid_specifications'] = valid_specs
                    db_stats['invalid_specifications'] = total_specs - valid_specs
                    
                    logger.info(f"✓ Database stats: total={total_specs}, valid={valid_specs}")
                    
                except Exception as query_error:
                    logger.warning(f"Failed to get database queries: {query_error}")
                    db_stats['database_available'] = False
                
                response_data['database'] = db_stats
                
            except Exception as db_error:
                logger.error(f"Failed to get database statistics: {db_error}")
                response_data['database'] = {
                    'total_specifications': 0,
                    'valid_specifications': 0,
                    'invalid_specifications': 0,
                    'database_available': False
                }
            
            logger.info("Fetching storage statistics...")
            try:
                storage_stats = file_handler.get_storage_stats()
                
                if storage_stats.get('success'):
                    response_data['storage'] = storage_stats.get('totals', {})
                    response_data['storage_by_folder'] = storage_stats.get('folders', {})
                    response_data['storage_type'] = storage_stats.get('storage_type', 'unknown')
                    logger.info(f"✓ Storage stats: {storage_stats.get('storage_type', 'unknown')}")
                else:
                    logger.warning(f"Storage stats failed: {storage_stats.get('error', 'Unknown error')}")
                    response_data['storage'] = {'total_files': 0, 'total_size_mb': 0}
                    response_data['storage_by_folder'] = {}
                    response_data['storage_type'] = 'unavailable'
            
            except Exception as storage_error:
                logger.error(f"Failed to get storage statistics: {storage_error}")
                response_data['storage'] = {'total_files': 0, 'total_size_mb': 0}
                response_data['storage_by_folder'] = {}
                response_data['storage_type'] = 'error'
            
            logger.info("Calculating application statistics...")
            try:
                uptime_seconds = (datetime.now() - app_start_time).total_seconds()
                
                response_data['application'] = {
                    'version': '1.0.0',
                    'uptime_seconds': int(uptime_seconds),
                    'start_time': app_start_time.isoformat()
                }
                
                logger.info(f"✓ Application uptime: {int(uptime_seconds)} seconds")
                
            except Exception as app_error:
                logger.error(f"Failed to get application statistics: {app_error}")
            
            logger.info("=== STATISTICS RESPONSE READY ===")
            return jsonify(response_data), 200
            
        except Exception as e:
            logger.error(f"Statistics endpoint error: {e}")
            logger.error(f"Traceback: {traceback.format_exc()}")
            
            fallback_response = {
                'migrations': {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                },
                'database': {
                    'total_specifications': 0,
                    'valid_specifications': 0,
                    'invalid_specifications': 0,
                    'database_available': False
                },
                'storage': {'total_files': 0, 'total_size_mb': 0},
                'storage_by_folder': {},
                'storage_type': 'error',
                'application': {
                    'version': '1.0.0',
                    'uptime_seconds': int((datetime.now() - app_start_time).total_seconds()),
                    'start_time': app_start_time.isoformat()
                },
                'error': str(e)
            }
            
            return jsonify(fallback_response), 500

    @app.route('/api/debug/openai-last-response')
    @login_required
    def get_last_openai_response():
        connector = AzureOpenAIConnector()
        return jsonify(connector.get_debug_info())

    # ==========================================
    # CACHE MANAGEMENT ENDPOINTS - NEW
    # ==========================================

    @app.route('/api/cache/stats', methods=['GET'])
    @login_required
    def get_cache_stats():
        """Get cache statistics"""
        return jsonify({
            'cache_type': app.config.get('CACHE_TYPE', 'unknown'),
            'cache_timeout': app.config.get('CACHE_DEFAULT_TIMEOUT', 0),
            'redis_configured': bool(os.getenv('REDIS_URL')),
            'cache_available': cache is not None
        })

    @app.route('/api/cache/clear', methods=['POST'])
    @login_required
    def clear_all_caches():
        """Clear all caches (admin only)"""
        try:
            cache.clear()
            logger.info("Admin cleared all caches")
            return jsonify({
                'success': True,
                'message': 'All caches cleared successfully'
            })
        except Exception as e:
            logger.error(f"Failed to clear caches: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    # ==========================================
    # TEMPLATE FILTERS
    # ==========================================

    @app.template_filter('datetime')
    def format_datetime_filter(value, format_str='%Y-%m-%d %H:%M:%S'):
        """Format datetime for templates"""
        if isinstance(value, str):
            try:
                value = datetime.fromisoformat(value.replace('Z', '+00:00'))
            except:
                return value
        
        if isinstance(value, datetime):
            return value.strftime(format_str)
        
        return value

    @app.template_filter('filesize')
    def filesize_filter(value):
        """Format file size for templates"""
        return format_file_size(value)

    # ==========================================
    # TEMPLATE CONTEXT PROCESSORS
    # ==========================================

    @app.context_processor
    def inject_global_vars():
        """Inject global variables into templates"""
        return {
            'app_version': '1.0.0',
            'current_year': datetime.now().year
        }

    # ==========================================
    # HTTP CACHE HEADERS - NEW
    # ==========================================

    @app.after_request
    def add_cache_headers(response):
        """Add HTTP cache headers for browser caching"""
        
        # API Statistics - cache for 60 seconds
        if request.path == '/api/statistics':
            response.cache_control.max_age = 60
            response.cache_control.public = True
        
        # Health check - cache for 10 seconds
        elif request.path == '/api/health':
            response.cache_control.max_age = 10
            response.cache_control.public = True
        
        # Database status - cache for 30 seconds
        elif request.path == '/api/database/status':
            response.cache_control.max_age = 30
            response.cache_control.public = True
        
        # Static files - cache for 1 day
        elif request.path.startswith('/static/'):
            response.cache_control.max_age = 86400
            response.cache_control.public = True
        
        # HTML pages - don't cache
        elif request.path.endswith('.html'):
            response.cache_control.no_cache = True
            response.cache_control.no_store = True
        
        # API mutations - don't cache
        elif request.method in ['POST', 'PUT', 'DELETE']:
            response.cache_control.no_cache = True
            response.cache_control.no_store = True
        
        return response

    return app


# ==========================================
# CREATE APP INSTANCE
# ==========================================

app = create_app()


# ==========================================
# MAIN ENTRY POINT
# ==========================================

if __name__ == '__main__':
    os.makedirs('logs', exist_ok=True)
    os.makedirs('static/uploads', exist_ok=True)
    
    logger = setup_logger('app')
    
    port = int(os.environ.get('PORT', 8000))
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    
    logger.info(f"Starting API Migration Tool on port {port}")
    logger.info(f"Authentication enabled - Please login to access the application")
    logger.info(f"✅ Azure Storage with local fallback enabled")
    logger.info(f"   - Converted files will use Azure Blob Storage if available")
    logger.info(f"   - Will automatically fallback to local filesystem if needed")
    logger.info(f"✅ Azure OpenAI with model-aware parameters enabled")
    logger.info(f"   - All LLM calls use _build_chat_completion_params()")
    logger.info(f"   - Supports gpt-5-mini with max_completion_tokens")
    logger.info(f"   - Supports all OpenAI models with automatic parameter selection")
    logger.info(f"✅ prompts.py Integration enabled")
    logger.info(f"   - Using centralized LLM prompts")
    logger.info(f"   - Graceful fallback to defaults if not available")
    logger.info(f"✅ CACHING ENABLED - Flask-Caching with 4-20x performance improvement")
    logger.info(f"   - /api/statistics cached for 60 seconds")
    logger.info(f"   - /api/database/status cached for 30 seconds")
    logger.info(f"   - /api/health cached for 10 seconds")
    logger.info(f"   - Cache type: {app.config.get('CACHE_TYPE', 'simple')}")
    app.run(host='0.0.0.0', port=port, debug=debug)