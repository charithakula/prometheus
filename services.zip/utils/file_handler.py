"""
File handling utilities
Manages file upload, download, validation, and processing
Updated to handle YAML MIME type issues
"""
import os
import json
import yaml
import hashlib
import mimetypes
from typing import Dict, Any, Optional, Tuple, Union, BinaryIO
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename
from datetime import datetime
import logging

from config import Config

logger = logging.getLogger(__name__)

class FileHandler:
    """Utility class for handling file operations"""
    
    ALLOWED_EXTENSIONS = {'json', 'yaml', 'yml', 'txt'}
    ALLOWED_MIME_TYPES = {
        'application/json',
        'application/x-yaml', 
        'text/yaml',
        'text/plain',
        'text/x-yaml',
        'application/octet-stream'  # Added to handle misidentified YAML files
    }
    MAX_FILE_SIZE = 16 * 1024 * 1024  # 16MB
    
    def __init__(self, upload_folder: str = None):
        """
        Initialize file handler
        
        Args:
            upload_folder: Directory for file uploads
        """
        self.upload_folder = upload_folder or getattr(Config, 'UPLOAD_FOLDER', 'static/uploads')
        self.ensure_upload_directory()
    
    def ensure_upload_directory(self):
        """Ensure upload directory exists"""
        try:
            os.makedirs(self.upload_folder, exist_ok=True)
            logger.debug(f"Upload directory ready: {self.upload_folder}")
        except Exception as e:
            logger.error(f"Failed to create upload directory {self.upload_folder}: {e}")
            raise
    
    def validate_file(self, file: FileStorage) -> Dict[str, Any]:
        """
        Validate uploaded file
        
        Args:
            file: Uploaded file object
            
        Returns:
            Validation result
        """
        if not file or not file.filename:
            return {
                'valid': False,
                'error': 'No file provided'
            }
        
        # Check file extension
        if not self._allowed_file(file.filename):
            return {
                'valid': False,
                'error': f'File type not allowed. Allowed types: {", ".join(self.ALLOWED_EXTENSIONS)}'
            }
        
        # Check MIME type with more lenient handling
        if file.mimetype and file.mimetype not in self.ALLOWED_MIME_TYPES:
            logger.warning(f"Unexpected MIME type: {file.mimetype} for file: {file.filename}")
            # Check if it's a known problematic MIME type for YAML files
            file_ext = os.path.splitext(file.filename)[1].lower()
            if file_ext in ['.yaml', '.yml'] and file.mimetype == 'application/octet-stream':
                logger.info(f"Allowing YAML file with octet-stream MIME type: {file.filename}")
            # Don't reject based on MIME type alone, as it can be unreliable
        
        # Check file size
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)  # Reset file pointer
        
        if file_size > self.MAX_FILE_SIZE:
            return {
                'valid': False,
                'error': f'File too large. Maximum size: {self._format_file_size(self.MAX_FILE_SIZE)}'
            }
        
        if file_size == 0:
            return {
                'valid': False,
                'error': 'Empty file'
            }
        
        return {
            'valid': True,
            'file_size': file_size,
            'mime_type': file.mimetype
        }
    
    def save_uploaded_file(self, file: FileStorage, prefix: str = None) -> Dict[str, Any]:
        """
        Save uploaded file to upload directory
        
        Args:
            file: Uploaded file object
            prefix: Optional filename prefix
            
        Returns:
            Save result with file information
        """
        try:
            # Validate file first
            validation = self.validate_file(file)
            if not validation['valid']:
                return {
                    'success': False,
                    'error': validation['error']
                }
            
            # Generate secure filename
            original_filename = file.filename
            filename = self._generate_filename(original_filename, prefix)
            file_path = os.path.join(self.upload_folder, filename)
            
            # Save file
            file.save(file_path)
            
            # Calculate file hash for integrity
            file_hash = self.calculate_file_hash(file_path)
            
            # Get file info
            file_info = {
                'success': True,
                'filename': filename,
                'original_filename': original_filename,
                'file_path': file_path,
                'file_size': validation['file_size'],
                'file_hash': file_hash,
                'mime_type': validation['mime_type'],
                'upload_timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"File saved successfully: {filename} ({self._format_file_size(validation['file_size'])})")
            return file_info
            
        except Exception as e:
            logger.error(f"Failed to save file {file.filename}: {e}")
            return {
                'success': False,
                'error': f'Failed to save file: {str(e)}'
            }
    
    def read_file_content(self, file_path: str) -> Dict[str, Any]:
        """
        Read and parse file content
        
        Args:
            file_path: Path to file
            
        Returns:
            File content and metadata
        """
        try:
            if not os.path.exists(file_path):
                return {
                    'success': False,
                    'error': 'File not found'
                }
            
            # Determine file type
            file_extension = os.path.splitext(file_path)[1].lower()
            
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse content based on file type
            parsed_content = None
            content_type = 'text'
            
            if file_extension in ['.json']:
                try:
                    parsed_content = json.loads(content)
                    content_type = 'json'
                except json.JSONDecodeError as e:
                    return {
                        'success': False,
                        'error': f'Invalid JSON format: {str(e)}'
                    }
            
            elif file_extension in ['.yaml', '.yml']:
                try:
                    parsed_content = yaml.safe_load(content)
                    content_type = 'yaml'
                except yaml.YAMLError as e:
                    return {
                        'success': False,
                        'error': f'Invalid YAML format: {str(e)}'
                    }
            
            # If parsed_content is None but no error, treat as plain text
            if parsed_content is None and content_type == 'text':
                # Try to auto-detect JSON or YAML in plain text files
                try:
                    parsed_content = json.loads(content)
                    content_type = 'json'
                except json.JSONDecodeError:
                    try:
                        parsed_content = yaml.safe_load(content)
                        content_type = 'yaml'
                    except yaml.YAMLError:
                        # Keep as plain text
                        pass
            
            return {
                'success': True,
                'content': content,
                'parsed_content': parsed_content,
                'content_type': content_type,
                'file_size': len(content.encode('utf-8'))
            }
            
        except Exception as e:
            logger.error(f"Failed to read file {file_path}: {e}")
            return {
                'success': False,
                'error': f'Failed to read file: {str(e)}'
            }
    
    def save_content_to_file(self, content: Union[str, Dict[str, Any]], 
                           filename: str, format_type: str = 'json') -> Dict[str, Any]:
        """
        Save content to file
        
        Args:
            content: Content to save
            filename: Target filename
            format_type: Format type ('json' or 'yaml')
            
        Returns:
            Save result
        """
        try:
            file_path = os.path.join(self.upload_folder, filename)
            
            # Convert content to string based on format
            if format_type == 'json':
                if isinstance(content, dict):
                    content_str = json.dumps(content, indent=2)
                else:
                    content_str = str(content)
                    # Validate it's valid JSON
                    json.loads(content_str)
            
            elif format_type == 'yaml':
                if isinstance(content, dict):
                    content_str = yaml.dump(content, default_flow_style=False, indent=2)
                else:
                    content_str = str(content)
                    # Validate it's valid YAML
                    yaml.safe_load(content_str)
            
            else:
                content_str = str(content)
            
            # Write to file
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content_str)
            
            # Calculate file hash
            file_hash = self.calculate_file_hash(file_path)
            file_size = os.path.getsize(file_path)
            
            logger.info(f"Content saved to file: {filename} ({self._format_file_size(file_size)})")
            
            return {
                'success': True,
                'filename': filename,
                'file_path': file_path,
                'file_size': file_size,
                'file_hash': file_hash,
                'format': format_type
            }
            
        except Exception as e:
            logger.error(f"Failed to save content to file {filename}: {e}")
            return {
                'success': False,
                'error': f'Failed to save content: {str(e)}'
            }
    
    def delete_file(self, filename: str) -> Dict[str, Any]:
        """
        Delete file from upload directory
        
        Args:
            filename: File to delete
            
        Returns:
            Deletion result
        """
        try:
            file_path = os.path.join(self.upload_folder, filename)
            
            if not os.path.exists(file_path):
                return {
                    'success': False,
                    'error': 'File not found'
                }
            
            os.remove(file_path)
            logger.info(f"File deleted: {filename}")
            
            return {
                'success': True,
                'message': f'File {filename} deleted successfully'
            }
            
        except Exception as e:
            logger.error(f"Failed to delete file {filename}: {e}")
            return {
                'success': False,
                'error': f'Failed to delete file: {str(e)}'
            }
    
    def list_files(self, pattern: str = None) -> Dict[str, Any]:
        """
        List files in upload directory
        
        Args:
            pattern: Optional filename pattern to filter
            
        Returns:
            List of files
        """
        try:
            files = []
            
            for filename in os.listdir(self.upload_folder):
                file_path = os.path.join(self.upload_folder, filename)
                
                if os.path.isfile(file_path):
                    if pattern and pattern not in filename:
                        continue
                    
                    stat = os.stat(file_path)
                    file_info = {
                        'filename': filename,
                        'file_size': stat.st_size,
                        'created_at': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                        'modified_at': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                        'extension': os.path.splitext(filename)[1].lower()
                    }
                    files.append(file_info)
            
            # Sort by modification time (newest first)
            files.sort(key=lambda x: x['modified_at'], reverse=True)
            
            return {
                'success': True,
                'files': files,
                'total_files': len(files)
            }
            
        except Exception as e:
            logger.error(f"Failed to list files: {e}")
            return {
                'success': False,
                'error': f'Failed to list files: {str(e)}'
            }
    
    def calculate_file_hash(self, file_path: str, algorithm: str = 'sha256') -> str:
        """
        Calculate file hash for integrity checking
        
        Args:
            file_path: Path to file
            algorithm: Hash algorithm (md5, sha1, sha256)
            
        Returns:
            File hash string
        """
        try:
            hash_obj = hashlib.new(algorithm)
            
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_obj.update(chunk)
            
            return hash_obj.hexdigest()
            
        except Exception as e:
            logger.error(f"Failed to calculate hash for {file_path}: {e}")
            return ""
    
    def _allowed_file(self, filename: str) -> bool:
        """Check if file extension is allowed"""
        return '.' in filename and \
               filename.rsplit('.', 1)[1].lower() in self.ALLOWED_EXTENSIONS
    
    def _generate_filename(self, original_filename: str, prefix: str = None) -> str:
        """Generate secure filename with timestamp"""
        # Secure the original filename
        secure_name = secure_filename(original_filename)
        
        # Generate timestamp prefix
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if prefix:
            filename = f"{prefix}_{timestamp}_{secure_name}"
        else:
            filename = f"{timestamp}_{secure_name}"
        
        return filename
    
    def _format_file_size(self, size_bytes: int) -> str:
        """Format file size in human readable format"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.1f} TB"
    
    def get_file_info(self, filename: str) -> Dict[str, Any]:
        """
        Get detailed file information
        
        Args:
            filename: File to inspect
            
        Returns:
            File information
        """
        try:
            file_path = os.path.join(self.upload_folder, filename)
            
            if not os.path.exists(file_path):
                return {
                    'success': False,
                    'error': 'File not found'
                }
            
            stat = os.stat(file_path)
            file_hash = self.calculate_file_hash(file_path)
            
            # Determine MIME type
            mime_type, _ = mimetypes.guess_type(file_path)
            
            # Read file content to return it
            content_result = self.read_file_content(file_path)
            
            result = {
                'success': True,
                'filename': filename,
                'file_path': file_path,
                'file_size': stat.st_size,
                'file_size_formatted': self._format_file_size(stat.st_size),
                'file_hash': file_hash,
                'mime_type': mime_type,
                'extension': os.path.splitext(filename)[1].lower(),
                'created_at': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                'modified_at': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                'is_readable': os.access(file_path, os.R_OK),
                'is_writable': os.access(file_path, os.W_OK)
            }
            
            # Add content if successfully read
            if content_result['success']:
                result.update({
                    'content': content_result['content'],
                    'parsed_content': content_result['parsed_content'],
                    'content_type': content_result['content_type']
                })
            else:
                result.update({
                    'content_error': content_result['error']
                })
            
            return result
            
        except Exception as e:
            logger.error(f"Failed to get file info for {filename}: {e}")
            return {
                'success': False,
                'error': f'Failed to get file info: {str(e)}'
            }
    
    def cleanup_old_files(self, max_age_days: int = 7) -> Dict[str, Any]:
        """
        Clean up old files from upload directory
        
        Args:
            max_age_days: Maximum age in days for files to keep
            
        Returns:
            Cleanup result
        """
        try:
            current_time = datetime.now()
            max_age_seconds = max_age_days * 24 * 60 * 60
            
            deleted_files = []
            total_size_freed = 0
            
            for filename in os.listdir(self.upload_folder):
                file_path = os.path.join(self.upload_folder, filename)
                
                if os.path.isfile(file_path):
                    stat = os.stat(file_path)
                    age_seconds = (current_time.timestamp() - stat.st_mtime)
                    
                    if age_seconds > max_age_seconds:
                        file_size = stat.st_size
                        os.remove(file_path)
                        deleted_files.append(filename)
                        total_size_freed += file_size
                        logger.info(f"Cleaned up old file: {filename}")
            
            return {
                'success': True,
                'deleted_files': deleted_files,
                'files_deleted': len(deleted_files),
                'total_size_freed': total_size_freed,
                'size_freed_formatted': self._format_file_size(total_size_freed)
            }
            
        except Exception as e:
            logger.error(f"Failed to cleanup old files: {e}")
            return {
                'success': False,
                'error': f'Failed to cleanup files: {str(e)}'
            }