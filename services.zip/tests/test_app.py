"""
Tests for the main Flask application
Tests routes, API endpoints, and application functionality
"""
import pytest
import json
import io
from unittest.mock import Mock, patch, MagicMock
from . import (
    SAMPLE_OPENAPI_2_SPEC, 
    SAMPLE_OPENAPI_3_SPEC,
    generate_migration_record_data
)

class TestApplicationSetup:
    """Test application setup and configuration"""
    
    def test_app_creation(self, app):
        """Test that app is created successfully"""
        assert app is not None
        assert app.config['TESTING'] is True
    
    def test_database_initialization(self, app):
        """Test database initialization"""
        from models.database import db
        
        with app.app_context():
            # Database should be initialized
            assert db is not None
            # Tables should be created (this happens in the fixture)

class TestMainRoutes:
    """Test main application routes"""
    
    def test_index_route(self, client):
        """Test main dashboard route"""
        response = client.get('/')
        
        assert response.status_code == 200
        assert b'Migration Dashboard' in response.data
        assert b'Quick Actions' in response.data
    
    def test_upload_route(self, client):
        """Test upload page route"""
        response = client.get('/upload')
        
        assert response.status_code == 200
        assert b'Upload & Convert' in response.data
        assert b'drop-zone' in response.data
    
    def test_migration_history_route(self, client):
        """Test migration history route"""
        response = client.get('/history')
        
        assert response.status_code == 200
        assert b'Migration History' in response.data
    
    def test_404_error_handler(self, client):
        """Test 404 error handling"""
        response = client.get('/nonexistent-route')
        
        assert response.status_code == 404

class TestAPIEndpoints:
    """Test API endpoints"""
    
    def test_health_check(self, client):
        """Test health check endpoint"""
        with patch('app.IBMAPIConnector') as mock_ibm, \
             patch('app.AzureAPIMConnector') as mock_azure, \
             patch('app.AzureOpenAIConnector') as mock_openai:
            
            # Mock service responses
            mock_ibm.return_value.test_connection.return_value = {'status': 'success', 'message': 'Connected'}
            mock_azure.return_value.test_connection.return_value = {'status': 'success', 'message': 'Connected'}
            mock_openai.return_value.test_connection.return_value = {'status': 'success', 'message': 'Connected'}
            
            response = client.get('/api/health')
            
            assert response.status_code == 200
            
            data = json.loads(response.data)
            assert 'status' in data
            assert 'services' in data
            assert 'uptime_seconds' in data
    
    def test_upload_api_success(self, client):
        """Test successful file upload"""
        with patch('app.file_handler') as mock_file_handler:
            # Mock successful file handling
            mock_file_handler.save_uploaded_file.return_value = {
                'success': True,
                'filename': 'test.json',
                'original_filename': 'api.json',
                'file_size': 1024,
                'file_hash': 'abc123'
            }
            
            mock_file_handler.read_file_content.return_value = {
                'success': True,
                'content': json.dumps(SAMPLE_OPENAPI_2_SPEC),
                'parsed_content': SAMPLE_OPENAPI_2_SPEC,
                'content_type': 'json',
                'file_size': 1024
            }
            
            # Create test file
            data = {
                'file': (io.BytesIO(json.dumps(SAMPLE_OPENAPI_2_SPEC).encode()), 'test.json')
            }
            
            response = client.post('/api/upload', data=data, content_type='multipart/form-data')
            
            assert response.status_code == 200
            
            response_data = json.loads(response.data)
            assert response_data['success'] is True
            assert 'file_info' in response_data
            assert 'api_info' in response_data
    
    def test_upload_api_no_file(self, client):
        """Test upload API with no file"""
        response = client.post('/api/upload', data={})
        
        assert response.status_code == 400
        
        data = json.loads(response.data)
        assert 'error' in data
        assert 'No file' in data['error']
    
    @patch('app.conversion_service')
    def test_convert_api_success(self, mock_conversion_service, client):
        """Test successful API conversion"""
        # Mock conversion service
        mock_conversion_service.convert_specification.return_value = {
            'status': 'success',
            'converted_spec': SAMPLE_OPENAPI_3_SPEC,
            'conversion_time_seconds': 2.5
        }
        
        request_data = {
            'spec_content': json.dumps(SAMPLE_OPENAPI_2_SPEC),
            'source_format': 'json'
        }
        
        response = client.post('/api/convert', 
                              data=json.dumps(request_data),
                              content_type='application/json')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['status'] == 'success'
        assert 'converted_spec' in data
    
    def test_convert_api_invalid_data(self, client):
        """Test conversion API with invalid data"""
        response = client.post('/api/convert', 
                              data=json.dumps({}),
                              content_type='application/json')
        
        assert response.status_code == 400
        
        data = json.loads(response.data)
        assert 'error' in data
    
    @patch('app.conversion_service')
    def test_conversion_preview(self, mock_conversion_service, client):
        """Test conversion preview endpoint"""
        mock_conversion_service.get_conversion_preview.return_value = {
            'status': 'success',
            'api_info': {'title': 'Test API', 'version': '1.0.0'},
            'conversion_preview': {
                'paths_count': 2,
                'estimated_complexity': 'low',
                'ai_conversion_available': True
            }
        }
        
        request_data = {
            'spec_content': json.dumps(SAMPLE_OPENAPI_2_SPEC)
        }
        
        response = client.post('/api/convert/preview',
                              data=json.dumps(request_data),
                              content_type='application/json')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['status'] == 'success'
        assert 'conversion_preview' in data
    
    @patch('app.migration_service')
    def test_migrate_api_success(self, mock_migration_service, client):
        """Test successful single API migration"""
        mock_migration_service.migrate_single_api.return_value = {
            'status': 'success',
            'migration_id': 'test-migration-123',
            'api_id': 'test-api',
            'migration_time_seconds': 10.5
        }
        
        request_data = {
            'api_ids': 'test-api',
            'org_name': 'test-org',
            'options': {}
        }
        
        response = client.post('/api/migrate',
                              data=json.dumps(request_data),
                              content_type='application/json')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['status'] == 'success'
        assert 'migration_id' in data
    
    @patch('app.migration_service')
    def test_migrate_batch_apis(self, mock_migration_service, client):
        """Test batch API migration"""
        mock_migration_service.migrate_multiple_apis.return_value = {
            'status': 'completed',
            'total_apis': 2,
            'successful_migrations': 2,
            'failed_migrations': 0,
            'results': []
        }
        
        request_data = {
            'migration_type': 'apis',
            'api_ids': ['api1', 'api2'],
            'org_name': 'test-org'
        }
        
        response = client.post('/api/migrate/batch',
                              data=json.dumps(request_data),
                              content_type='application/json')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['status'] == 'completed'
        assert data['total_apis'] == 2
    
    @patch('app.migration_service')
    def test_migrate_by_catalog(self, mock_migration_service, client):
        """Test migration by catalog"""
        mock_migration_service.migrate_by_catalog.return_value = {
            'status': 'completed',
            'total_apis': 5,
            'successful_migrations': 4,
            'failed_migrations': 1
        }
        
        request_data = {
            'migration_type': 'catalog',
            'catalog_name': 'test-catalog',
            'org_name': 'test-org'
        }
        
        response = client.post('/api/migrate/batch',
                              data=json.dumps(request_data),
                              content_type='application/json')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['status'] == 'completed'
    
    @patch('app.migration_service')
    def test_check_prerequisites(self, mock_migration_service, client):
        """Test prerequisites check endpoint"""
        mock_migration_service.validate_migration_prerequisites.return_value = {
            'all_services_available': True,
            'service_status': {
                'ibm_api_connect': {'status': 'success'},
                'azure_apim': {'status': 'success'},
                'azure_openai': {'status': 'success'}
            },
            'can_migrate': True,
            'recommendations': []
        }
        
        response = client.get('/api/migrate/prerequisites')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['all_services_available'] is True
        assert data['can_migrate'] is True
    
    @patch('app.migration_service')
    def test_list_migrations(self, mock_migration_service, client):
        """Test list migrations endpoint"""
        mock_migration_service.list_migrations.return_value = {
            'migrations': [
                generate_migration_record_data(),
                generate_migration_record_data()
            ],
            'total_count': 2
        }
        
        response = client.get('/api/migrations?limit=10&offset=0')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'migrations' in data
        assert data['total_count'] == 2
    
    @patch('app.migration_service')
    def test_get_migration_status(self, mock_migration_service, client):
        """Test get migration status endpoint"""
        test_migration_id = 'test-migration-123'
        
        mock_migration_service.get_migration_status.return_value = {
            'migration_id': test_migration_id,
            'status': 'completed',
            'api_id': 'test-api'
        }
        
        response = client.get(f'/api/migrations/{test_migration_id}')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['migration_id'] == test_migration_id
        assert data['status'] == 'completed'
    
    @patch('app.migration_service')
    def test_rollback_migration(self, mock_migration_service, client):
        """Test migration rollback endpoint"""
        test_migration_id = 'test-migration-123'
        
        mock_migration_service.rollback_migration.return_value = {
            'status': 'success',
            'migration_id': test_migration_id,
            'message': 'Migration rolled back successfully'
        }
        
        response = client.post(f'/api/migrations/{test_migration_id}/rollback')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['status'] == 'success'
    
    @patch('app.IBMAPIConnector')
    def test_list_ibm_apis(self, mock_connector, client):
        """Test list IBM APIs endpoint"""
        mock_instance = Mock()
        mock_instance.is_available = True
        mock_instance.list_apis.return_value = [
            {'id': 'api1', 'name': 'Test API 1'},
            {'id': 'api2', 'name': 'Test API 2'}
        ]
        mock_connector.return_value = mock_instance
        
        response = client.get('/api/ibm/apis?org_name=test-org')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['status'] == 'success'
        assert len(data['apis']) == 2
    
    def test_list_ibm_apis_unavailable(self, client):
        """Test list IBM APIs when service unavailable"""
        with patch('app.IBMAPIConnector') as mock_connector:
            mock_instance = Mock()
            mock_instance.is_available = False
            mock_connector.return_value = mock_instance
            
            response = client.get('/api/ibm/apis')
            
            assert response.status_code == 503
            
            data = json.loads(response.data)
            assert 'error' in data
    
    @patch('app.AzureAPIMConnector')
    def test_list_azure_apis(self, mock_connector, client):
        """Test list Azure APIs endpoint"""
        mock_instance = Mock()
        mock_instance.is_available = True
        mock_instance.list_apis.return_value = [
            {'id': 'azure-api1', 'display_name': 'Azure API 1'},
            {'id': 'azure-api2', 'display_name': 'Azure API 2'}
        ]
        mock_connector.return_value = mock_instance
        
        response = client.get('/api/azure/apis')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['status'] == 'success'
        assert len(data['apis']) == 2
    
    @patch('app.get_database_statistics')
    @patch('app.migration_service')
    def test_get_statistics(self, mock_migration_service, mock_db_stats, client):
        """Test get statistics endpoint"""
        mock_db_stats.return_value = {
            'migrations': {'total_migrations': 10},
            'api_specifications': {'total_specifications': 25}
        }
        
        mock_migration_service.get_migration_statistics.return_value = {
            'total_migrations': 10,
            'successful_migrations': 8,
            'failed_migrations': 2
        }
        
        response = client.get('/api/statistics')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert 'database' in data
        assert 'migrations' in data
        assert 'application' in data

class TestFileOperations:
    """Test file-related operations"""
    
    @patch('app.file_handler')
    def test_list_files(self, mock_file_handler, client):
        """Test list files endpoint"""
        mock_file_handler.list_files.return_value = {
            'success': True,
            'files': [
                {'filename': 'test1.json', 'file_size': 1024},
                {'filename': 'test2.yaml', 'file_size': 2048}
            ],
            'total_files': 2
        }
        
        response = client.get('/api/files')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] is True
        assert len(data['files']) == 2
    
    @patch('app.file_handler')
    def test_get_file_info(self, mock_file_handler, client):
        """Test get file info endpoint"""
        mock_file_handler.get_file_info.return_value = {
            'success': True,
            'filename': 'test.json',
            'file_size': 1024,
            'created_at': '2023-01-01T00:00:00'
        }
        
        response = client.get('/api/files/test.json')
        
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['success'] is True
        assert data['filename'] == 'test.json'
    
    @patch('os.path.exists')
    @patch('app.send_file')
    def test_download_file(self, mock_send_file, mock_exists, client):
        """Test file download endpoint"""
        mock_exists.return_value = True
        mock_send_file.return_value = Mock()
        
        response = client.get('/api/files/test.json/download')
        
        # send_file should be called
        mock_send_file.assert_called_once()
    
    @patch('os.path.exists')
    def test_download_file_not_found(self, mock_exists, client):
        """Test file download when file doesn't exist"""
        mock_exists.return_value = False
        
        response = client.get('/api/files/nonexistent.json/download')
        
        assert response.status_code == 404
        
        data = json.loads(response.data)
        assert 'error' in data

class TestErrorHandling:
    """Test application error handling"""
    
    def test_400_bad_request(self, client):
        """Test 400 error handling"""
        # Send invalid JSON to an endpoint that expects JSON
        response = client.post('/api/convert', 
                              data='invalid json',
                              content_type='application/json')
        
        assert response.status_code == 400
    
    def test_413_file_too_large(self, client):
        """Test file too large error"""
        # This would require actually sending a large file
        # For now, just test that the error handler exists
        assert hasattr(client.application, 'errorhandler')
    
    def test_500_internal_error_handling(self, client):
        """Test 500 error handling"""
        with patch('app.index') as mock_index:
            mock_index.side_effect = Exception("Test error")
            
            response = client.get('/')
            
            # Should handle the error gracefully
            assert response.status_code == 500

class TestTemplateFilters:
    """Test custom template filters"""
    
    def test_datetime_filter(self, app):
        """Test datetime template filter"""
        with app.app_context():
            from app import datetime_filter
            
            # Test with ISO string
            result = datetime_filter('2023-01-01T12:00:00Z')
            assert '2023-01-01 12:00:00' in result or '2023-01-01' in result
            
            # Test with datetime object
            from datetime import datetime
            dt = datetime(2023, 1, 1, 12, 0, 0)
            result = datetime_filter(dt)
            assert '2023-01-01 12:00:00' == result
            
            # Test with invalid input
            result = datetime_filter('invalid')
            assert result == 'invalid'
    
    def test_filesize_filter(self, app):
        """Test filesize template filter"""
        with app.app_context():
            from app import filesize_filter
            
            # Test various file sizes
            assert filesize_filter(1024) == '1.0 KB'
            assert filesize_filter(1024 * 1024) == '1.0 MB'
            assert filesize_filter(0) == '0 B'

class TestApplicationSecurity:
    """Test application security features"""
    
    def test_csrf_protection_disabled_in_testing(self, app):
        """Test that CSRF is disabled in testing"""
        assert app.config.get('WTF_CSRF_ENABLED', True) is False
    
    def test_secure_headers(self, client):
        """Test that appropriate security headers are present"""
        response = client.get('/')
        
        # Check that response doesn't expose sensitive info
        assert 'Server' not in response.headers or 'Werkzeug' not in response.headers.get('Server', '')
    
    def test_file_upload_security(self, client):
        """Test file upload security measures"""
        # Test that only allowed file types can be uploaded
        data = {
            'file': (io.BytesIO(b'malicious content'), 'test.exe')
        }
        
        response = client.post('/api/upload', data=data, content_type='multipart/form-data')
        
        # Should reject executable files
        assert response.status_code == 400

class TestApplicationPerformance:
    """Test application performance considerations"""
    
    def test_database_connection_pooling(self, app):
        """Test database connection handling"""
        with app.app_context():
            from models.database import db
            
            # Database should be properly configured
            assert db is not None
            # In a real test, you might check connection pool settings
    
    def test_large_file_handling(self, client):
        """Test handling of large file uploads"""
        # Test that large files are properly rejected
        # This is configured via MAX_CONTENT_LENGTH
        assert client.application.config['MAX_CONTENT_LENGTH'] == 16 * 1024 * 1024
    
    @patch('app.migration_service')
    def test_concurrent_migration_handling(self, mock_migration_service, client):
        """Test that concurrent migrations don't interfere"""
        # Mock migration service to simulate concurrent operations
        mock_migration_service.migrate_single_api.return_value = {
            'status': 'success',
            'migration_id': 'unique-id'
        }
        
        # Multiple concurrent requests
        import threading
        results = []
        
        def make_request():
            request_data = {
                'api_ids': 'test-api',
                'org_name': 'test-org'
            }
            response = client.post('/api/migrate',
                                  data=json.dumps(request_data),
                                  content_type='application/json')
            results.append(response.status_code)
        
        # Create multiple threads
        threads = [threading.Thread(target=make_request) for _ in range(5)]
        
        # Start all threads
        for thread in threads:
            thread.start()
        
        # Wait for completion
        for thread in threads:
            thread.join()
        
        # All requests should succeed
        assert all(status == 200 for status in results)