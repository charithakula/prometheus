#!/usr/bin/env python3
"""
Test SSL certificate connectivity to Azure
"""
import os
import sys
from connectors import AzureAPIMConnector

def test_azure_connection():
    """Test Azure APIM connection with SSL"""
    print("=" * 60)
    print("Testing Azure APIM Connection with SSL Configuration")
    print("=" * 60)
    
    # Display configuration
    print("\n[Configuration]")
    print(f"  VERIFY_SSL: {os.environ.get('VERIFY_SSL', 'True')}")
    print(f"  CA_BUNDLE_PATH: {os.environ.get('CA_BUNDLE_PATH', 'Not set')}")
    print(f"  CLIENT_CERT_PATH: {os.environ.get('CLIENT_CERT_PATH', 'Not set')}")
    
    # Try to connect
    print("\n[Connection Test]")
    try:
        connector = AzureAPIMConnector()
        
        if connector.is_available:
            print("✓ Azure APIM client initialized successfully")
            
            # Test connection
            result = connector.test_connection()
            
            if result['status'] == 'success':
                print(f"✓ Connection successful!")
                print(f"  Service: {result.get('service_name')}")
                print(f"  APIs: {result.get('api_count')}")
            else:
                print(f"✗ Connection failed: {result['message']}")
                sys.exit(1)
        else:
            print("✗ Failed to initialize Azure APIM client")
            sys.exit(1)
            
    except Exception as e:
        print(f"✗ Error: {e}")
        sys.exit(1)
    
    print("\n[Result]")
    print("✓ All tests passed!")

if __name__ == '__main__':
    test_azure_connection()