"""
Configuration management for API Migration Tool
Handles environment variables and application settings
"""
import os
from typing import List, Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    """Base configuration class"""
    
    # Flask Configuration
    SECRET_KEY = os.getenv('FLASK_SECRET_KEY', 'dev-secret-key-change-this')
    DEBUG = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    HOST = os.getenv('FLASK_HOST', '127.0.0.1')
    PORT = int(os.getenv('FLASK_PORT', 5000))
    
    # Database Configuration
    DATABASE_URL = os.getenv('DATABASE_URL')
    
    # If DATABASE_URL is not provided, build from components
    if not DATABASE_URL:
        DB_TYPE = os.getenv('DB_TYPE', 'sqlite')
        if DB_TYPE == 'postgresql':
            DB_HOST = os.getenv('DB_HOST', 'localhost')
            DB_PORT = os.getenv('DB_PORT', '5432')
            DB_NAME = os.getenv('DB_NAME', 'api_migration_db')
            DB_USER = os.getenv('DB_USER', 'api_user')
            DB_PASSWORD = os.getenv('DB_PASSWORD', '')
            
            DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        else:
            DATABASE_URL = 'sqlite:///migrations.db'
    
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # PostgreSQL specific settings
    if 'postgresql' in DATABASE_URL:
        SQLALCHEMY_ENGINE_OPTIONS = {
            'pool_size': int(os.getenv('DB_POOL_SIZE', 10)),
            'max_overflow': int(os.getenv('DB_MAX_OVERFLOW', 20)),
            'pool_timeout': int(os.getenv('DB_POOL_TIMEOUT', 30)),
            'pool_recycle': int(os.getenv('DB_POOL_RECYCLE', 3600)),
            'pool_pre_ping': True,  # Verify connections before use
            'echo': DEBUG  # Log SQL queries in debug mode
        }
    else:
        SQLALCHEMY_ENGINE_OPTIONS = {}
    
    # File Upload Configuration
    UPLOAD_FOLDER = os.getenv('UPLOAD_FOLDER', 'static/uploads')
    MAX_CONTENT_LENGTH = int(os.getenv('MAX_CONTENT_LENGTH', 16 * 1024 * 1024))  # 16MB
    ALLOWED_EXTENSIONS = os.getenv('ALLOWED_EXTENSIONS', 'json,yaml,yml').split(',')
    
    # Logging Configuration
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.getenv('LOG_FILE', 'logs/app.log')
    
    @classmethod
    def get_database_type(cls) -> str:
        """Get the database type from URL"""
        if 'postgresql' in cls.DATABASE_URL:
            return 'postgresql'
        elif 'sqlite' in cls.DATABASE_URL:
            return 'sqlite'
        else:
            return 'unknown'
    
    @classmethod
    def is_production_db(cls) -> bool:
        """Check if using production database"""
        return cls.get_database_type() == 'postgresql'

class AzureConfig:
    """Azure services configuration"""
    
    # Azure Authentication
    CLIENT_ID = os.getenv('AZURE_CLIENT_ID')
    CLIENT_SECRET = os.getenv('AZURE_CLIENT_SECRET')
    TENANT_ID = os.getenv('AZURE_TENANT_ID')
    SUBSCRIPTION_ID = os.getenv('AZURE_SUBSCRIPTION_ID')
    
    # Azure OpenAI Configuration
    OPENAI_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT')
    OPENAI_API_KEY = os.getenv('AZURE_OPENAI_API_KEY')
    OPENAI_DEPLOYMENT = os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4')
    OPENAI_VERSION = os.getenv('AZURE_OPENAI_VERSION', '2024-02-15-preview')
    
    # Azure API Management Configuration
    APIM_RESOURCE_GROUP = os.getenv('AZURE_APIM_RESOURCE_GROUP')
    APIM_SERVICE_NAME = os.getenv('AZURE_APIM_SERVICE_NAME')
    APIM_BASE_URL = os.getenv('AZURE_APIM_BASE_URL', 'https://management.azure.com')
    
    @classmethod
    def validate_azure_config(cls) -> List[str]:
        """Validate Azure configuration and return list of missing variables"""
        missing = []
        required_vars = [
            ('AZURE_CLIENT_ID', cls.CLIENT_ID),
            ('AZURE_CLIENT_SECRET', cls.CLIENT_SECRET),
            ('AZURE_TENANT_ID', cls.TENANT_ID),
            ('AZURE_SUBSCRIPTION_ID', cls.SUBSCRIPTION_ID),
        ]
        
        for var_name, var_value in required_vars:
            if not var_value:
                missing.append(var_name)
        
        return missing
    
    @classmethod
    def validate_openai_config(cls) -> List[str]:
        """Validate Azure OpenAI configuration"""
        missing = []
        required_vars = [
            ('AZURE_OPENAI_ENDPOINT', cls.OPENAI_ENDPOINT),
            ('AZURE_OPENAI_API_KEY', cls.OPENAI_API_KEY),
        ]
        
        for var_name, var_value in required_vars:
            if not var_value:
                missing.append(var_name)
        
        return missing
    
    @classmethod
    def validate_apim_config(cls) -> List[str]:
        """Validate Azure APIM configuration"""
        missing = []
        required_vars = [
            ('AZURE_APIM_RESOURCE_GROUP', cls.APIM_RESOURCE_GROUP),
            ('AZURE_APIM_SERVICE_NAME', cls.APIM_SERVICE_NAME),
        ]
        
        for var_name, var_value in required_vars:
            if not var_value:
                missing.append(var_name)
        
        return missing

class IBMConfig:
    """IBM API Connect configuration"""
    
    API_CONNECT_URL = os.getenv('IBM_API_CONNECT_URL')
    USERNAME = os.getenv('IBM_API_CONNECT_USERNAME')
    PASSWORD = os.getenv('IBM_API_CONNECT_PASSWORD')
    ORGANIZATION = os.getenv('IBM_API_CONNECT_ORG')
    CATALOG = os.getenv('IBM_API_CONNECT_CATALOG', 'sandbox')
    
    @classmethod
    def validate_ibm_config(cls) -> List[str]:
        """Validate IBM API Connect configuration"""
        missing = []
        required_vars = [
            ('IBM_API_CONNECT_URL', cls.API_CONNECT_URL),
            ('IBM_API_CONNECT_USERNAME', cls.USERNAME),
            ('IBM_API_CONNECT_PASSWORD', cls.PASSWORD),
            ('IBM_API_CONNECT_ORG', cls.ORGANIZATION),
        ]
        
        for var_name, var_value in required_vars:
            if not var_value:
                missing.append(var_name)
        
        return missing

class DevelopmentConfig(Config):
    """Development environment configuration"""
    DEBUG = True
    TESTING = False

class ProductionConfig(Config):
    """Production environment configuration"""
    DEBUG = False
    TESTING = False
    SECRET_KEY = os.getenv('FLASK_SECRET_KEY')
    
    @classmethod
    def validate_production_config(cls):
        """Validate production configuration"""
        if not cls.SECRET_KEY or cls.SECRET_KEY == 'dev-secret-key-change-this':
            raise ValueError("Production SECRET_KEY must be set and different from default")

class TestingConfig(Config):
    """Testing environment configuration"""
    TESTING = True
    DATABASE_URL = 'sqlite:///:memory:'
    SQLALCHEMY_DATABASE_URI = DATABASE_URL

# Configuration mapping
config_mapping = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}

def get_config(env: Optional[str] = None) -> Config:
    """Get configuration based on environment"""
    if not env:
        env = os.getenv('FLASK_ENV', 'development')
    
    return config_mapping.get(env, config_mapping['default'])

def validate_all_configurations() -> dict:
    """Validate all service configurations and return status"""
    validation_results = {
        'azure_auth': AzureConfig.validate_azure_config(),
        'azure_openai': AzureConfig.validate_openai_config(),
        'azure_apim': AzureConfig.validate_apim_config(),
        'ibm_api_connect': IBMConfig.validate_ibm_config(),
    }
    
    return validation_results

def get_missing_configurations() -> List[str]:
    """Get list of all missing configuration variables"""
    all_missing = []
    validation_results = validate_all_configurations()
    
    for service, missing_vars in validation_results.items():
        all_missing.extend(missing_vars)
    
    return all_missing