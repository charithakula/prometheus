"""
Flask Code Review API - Port 5000
AI-powered code review and unit test generation with detailed logging
ENHANCED: Detailed AI response logging + reason tracking + Token limit fixes
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from openai import AzureOpenAI
from dotenv import load_dotenv
import os
import logging
from datetime import datetime
import json
import webbrowser
from threading import Timer


# Load environment variables
load_dotenv()

# Define frontend path at module level
frontend_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'frontend')
assets_path = os.path.join(frontend_path, 'assets')

# Configure logging with UTF-8 encoding
log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
os.makedirs(log_dir, exist_ok=True)

file_handler = logging.FileHandler(
    os.path.join(log_dir, 'code_review.log'),
    encoding='utf-8'
)
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

logging.basicConfig(
    level=logging.DEBUG,
    handlers=[file_handler, console_handler]
)
logger = logging.getLogger(__name__)

# Flask app initialization with static folder configuration
app = Flask(
    __name__,
    static_folder=assets_path,
    static_url_path='/assets'
)

CORS(app, resources={
    r"/api/*": {
        "origins": "*",
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"],
        "expose_headers": ["Content-Type"],
        "supports_credentials": False
    }
})

# Azure OpenAI Configuration
try:
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2025-01-01-preview")
    logger.info(f"Using Azure OpenAI API version: {api_version}")
    
    client = AzureOpenAI(
        api_key=os.getenv("OPENAI_API_KEY"),
        api_version=api_version,
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
    )
    logger.info("Azure OpenAI client initialized successfully")
    logger.info(f"Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT', 'not set')}")
except Exception as e:
    logger.error(f"Failed to initialize Azure OpenAI client: {str(e)}")
    client = None

review_history = []

@app.route('/')
def index():
    """Serve the code review HTML interface"""
    try:
        logger.info(f"Serving HTML from: {frontend_path}")
        return send_from_directory(frontend_path, 'code-review.html')
    except Exception as e:
        logger.error(f"Error serving HTML: {str(e)}")
        try:
            return send_from_directory('.', 'code-review.html')
        except:
            return jsonify({'error': 'Frontend files not found. Place code-review.html in frontend/ folder'}), 404

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'Code Review API',
        'timestamp': datetime.now().isoformat(),
        'openai_configured': client is not None
    })

@app.route('/api/analyze-code', methods=['POST'])
def analyze_code():
    """Analyze code for issues and best practices"""
    try:
        data = request.json
        code = data.get('code', '')
        platform = data.get('platform', 'generic')
        
        if not code:
            return jsonify({'error': 'No code provided'}), 400
        
        logger.info(f"[ANALYZE] Starting code analysis for platform: {platform}")
        logger.debug(f"[ANALYZE] Code length: {len(code)} characters")
        
        if client is None:
            logger.warning("[ANALYZE] Azure OpenAI not configured, using mock analysis")
            analysis = generate_mock_analysis(code, platform)
            using_ai = False
        else:
            prompt = f"""Find issues in this code and return JSON.

Code:
{code[:2000]}

Find: null checks, error handling, security issues, performance problems.
Return JSON format:
{{"issues": [{{"severity": "high/medium/low", "line": number, "message": "specific issue found", "suggestion": "how to fix it"}}], "metrics": {{"complexity": number, "coverage": "percentage", "maintainability": "A-F"}}}}"""
            
            using_ai = False
            try:
                model_name = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4").lower()
                logger.info(f"[ANALYZE] Using model: {model_name}")
                
                completion_params = {
                    'model': os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
                    'messages': [
                        {
                            "role": "system",
                            "content": [{"type": "text", "text": "Code reviewer. Find real issues. Return JSON only."}]
                        },
                        {
                            "role": "user",
                            "content": [{"type": "text", "text": "Find issues: function test() { return x + y; }"}]
                        },
                        {
                            "role": "assistant",
                            "content": [{"type": "text", "text": '{"issues": [{"severity": "high", "line": 1, "message": "Variables x and y are undefined", "suggestion": "Declare variables: let x = 0; let y = 0;"}], "metrics": {"complexity": 1, "coverage": "0%", "maintainability": "D"}}'}]
                        },
                        {
                            "role": "user",
                            "content": [{"type": "text", "text": prompt}]
                        }
                    ],
                    'max_completion_tokens': 6000,
                    'stop': None,
                    'stream': False
                }
                
                if 'gpt-5' not in model_name:
                    completion_params['temperature'] = 0.3
                
                logger.info(f"[ANALYZE] Calling Azure OpenAI API...")
                response = client.chat.completions.create(**completion_params)
                
                logger.info(f"[ANALYZE] ✅ API Response received - ID: {response.id}")
                logger.info(f"[ANALYZE] Finish reason: {response.choices[0].finish_reason}")
                logger.info(f"[ANALYZE] Completion tokens: {response.usage.completion_tokens}")
                logger.info(f"[ANALYZE] Prompt tokens: {response.usage.prompt_tokens}")
                
                analysis_text = response.choices[0].message.content
                logger.info(f"[ANALYZE] Response content length: {len(analysis_text)} characters")
                logger.debug(f"[ANALYZE] Response preview: {analysis_text[:500]}")
                
                if not analysis_text or len(analysis_text.strip()) < 10:
                    logger.error(f"[ANALYZE] Empty or very short response received")
                    raise ValueError("Empty or truncated response from AI")
                
                json_str = analysis_text.strip()
                
                if '```json' in json_str:
                    json_str = json_str.split('```json')[1].split('```')[0].strip()
                    logger.debug("[ANALYZE] Extracted JSON from markdown code block")
                elif '```' in json_str:
                    parts = json_str.split('```')
                    if len(parts) >= 3:
                        json_str = parts[1].strip()
                    elif len(parts) == 2:
                        json_str = parts[1].strip()
                    logger.debug("[ANALYZE] Extracted JSON from code block")
                
                if json_str.startswith('json\n'):
                    json_str = json_str[5:].strip()
                    logger.debug("[ANALYZE] Removed 'json' language identifier")
                
                start_idx = json_str.find('{')
                if start_idx != -1:
                    brace_count = 0
                    end_idx = -1
                    for i in range(start_idx, len(json_str)):
                        if json_str[i] == '{':
                            brace_count += 1
                        elif json_str[i] == '}':
                            brace_count -= 1
                            if brace_count == 0:
                                end_idx = i + 1
                                break
                    
                    if end_idx > start_idx:
                        json_str = json_str[start_idx:end_idx]
                        logger.debug(f"[ANALYZE] Extracted valid JSON object (length: {len(json_str)})")
                        try:
                            analysis = json.loads(json_str)
                            using_ai = True
                            issue_count = len(analysis.get('issues', []))
                            logger.info(f"[ANALYZE] ✅ Successfully parsed AI response - Found {issue_count} issues")
                        except json.JSONDecodeError as je:
                            logger.error(f"[ANALYZE] JSON parsing failed: {je}")
                            raise ValueError(f"Invalid JSON: {je}")
                    else:
                        logger.warning("[ANALYZE] Could not find complete JSON object")
                        raise ValueError("No complete JSON found in response")
                else:
                    logger.warning("[ANALYZE] No JSON object found in response")
                    raise ValueError("No JSON found in response")
                    
            except Exception as e:
                logger.error(f"[ANALYZE] Error: {str(e)}")
                logger.warning("[ANALYZE] Falling back to mock analysis")
                analysis = generate_mock_analysis(code, platform)
        
        review_entry = {
            'id': len(review_history) + 1,
            'timestamp': datetime.now().isoformat(),
            'platform': platform,
            'code_snippet': code[:100] + '...' if len(code) > 100 else code,
            'issues_count': len(analysis.get('issues', []))
        }
        review_history.append(review_entry)
        
        logger.info(f"[ANALYZE] ✅ Analysis completed. Source: {'AI' if using_ai else 'Mock'}")
        
        return jsonify({
            'success': True,
            'analysis': json.dumps(analysis),
            'review_id': review_entry['id'],
            'source': 'ai' if using_ai else 'mock'
        })
        
    except Exception as e:
        logger.error(f"[ANALYZE] Exception: {str(e)}")
        return jsonify({'error': str(e)}), 500

def generate_mock_analysis(code, platform):
    """Generate mock analysis when OpenAI is not available"""
    logger.info("[MOCK] Generating mock analysis")
    issues = []
    lines = code.split('\n')
    
    if 'null' not in code.lower() and 'undefined' not in code.lower():
        issues.append({
            "severity": "high",
            "line": 1,
            "message": "Missing null/undefined checks",
            "suggestion": "Add validation to handle null or undefined values"
        })
    
    if 'try' not in code.lower() or 'catch' not in code.lower():
        issues.append({
            "severity": "medium",
            "line": 1,
            "message": "No error handling detected",
            "suggestion": "Wrap risky operations in try-catch blocks"
        })
    
    if len(code) < 50:
        issues.append({
            "severity": "low",
            "line": 1,
            "message": "Function lacks documentation",
            "suggestion": "Add JSDoc or similar documentation"
        })
    
    complexity = min(len(lines) // 5, 10)
    logger.info(f"[MOCK] Generated {len(issues)} mock issues")
    
    return {
        "issues": issues,
        "metrics": {
            "complexity": complexity,
            "coverage": "85%",
            "maintainability": "B"
        }
    }

@app.route('/api/generate-tests', methods=['POST'])
def generate_tests():
    """Generate unit tests for the provided code"""
    try:
        data = request.json
        code = data.get('code', '')
        platform = data.get('platform', 'generic')
        
        if not code:
            return jsonify({'error': 'No code provided'}), 400
        
        logger.info(f"[TESTS] Starting test generation for platform: {platform}")
        
        if client is None:
            logger.warning("[TESTS] Azure OpenAI not configured, using mock tests")
            test_code = generate_mock_tests(code, platform)
        else:
            framework = detect_test_framework(code)
            logger.info(f"[TESTS] Detected test framework: {framework}")
            
            prompt = f"""Generate unit tests using {framework} for this {platform} code.

Code:
```
{code}
```

Create 5-8 tests covering:
- Happy path
- Edge cases  
- Null/undefined
- Error handling

Return ONLY test code, no explanations."""
            
            try:
                model_name = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4").lower()
                logger.info(f"[TESTS] Calling Azure OpenAI with model: {model_name}")
                
                if 'gpt-5' in model_name:
                    max_tokens = 16000
                    temperature = 0.5
                else:
                    max_tokens = 8000
                    temperature = 0.4
                
                logger.info(f"[TESTS] Using max_tokens: {max_tokens}, temperature: {temperature}")
                
                completion_params = {
                    'model': os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
                    'messages': [
                        {
                            "role": "system",
                            "content": [{"type": "text", "text": "You are a test engineer. Generate clean, comprehensive test code."}]
                        },
                        {
                            "role": "user",
                            "content": [{"type": "text", "text": prompt}]
                        }
                    ],
                    'max_completion_tokens': max_tokens,
                    'temperature': temperature,
                    'stop': None,
                    'stream': False
                }
                
                response = client.chat.completions.create(**completion_params)
                
                logger.info(f"[TESTS] ✅ API Response received - ID: {response.id}")
                logger.info(f"[TESTS] Finish reason: {response.choices[0].finish_reason}")
                logger.info(f"[TESTS] Completion tokens: {response.usage.completion_tokens}")
                logger.info(f"[TESTS] Prompt tokens: {response.usage.prompt_tokens}")
                
                test_code = response.choices[0].message.content
                finish_reason = response.choices[0].finish_reason
                
                logger.info(f"[TESTS] Raw test content length: {len(test_code) if test_code else 0} characters")
                logger.debug(f"[TESTS] Test content preview: {test_code[:300] if test_code else 'EMPTY'}")
                
                if not test_code or len(test_code.strip()) < 50:
                    if finish_reason == "length":
                        logger.warning("[TESTS] Response was truncated due to token limit")
                    logger.error("[TESTS] Insufficient test content generated")
                    raise ValueError("Insufficient test content generated")
                
                original_length = len(test_code)
                if '```' in test_code:
                    parts = test_code.split('```')
                    if len(parts) >= 3:
                        test_code = parts[1].strip()
                        logger.debug("[TESTS] Extracted test code from markdown block (triple backticks)")
                    elif len(parts) == 2:
                        test_code = parts[1].strip()
                        logger.debug("[TESTS] Extracted test code from single markdown block")
                    
                    lines = test_code.split('\n')
                    first_line = lines[0].lower().strip()
                    
                    if first_line in ['javascript', 'js', 'java', 'python', 'py', 'junit', 'pytest', 'jest', 'xml', 'json', 'typescript', 'ts']:
                        test_code = '\n'.join(lines[1:]).strip()
                        logger.debug(f"[TESTS] Removed language identifier: {first_line}")
                
                logger.info(f"[TESTS] Test code cleaned - Before: {original_length} chars, After: {len(test_code)} chars")
                logger.info(f"[TESTS] ✅ Test generation successful")
                
            except Exception as e:
                logger.error(f"[TESTS] Error: {str(e)}")
                logger.warning("[TESTS] Falling back to mock tests")
                test_code = generate_mock_tests(code, platform)
        
        logger.info("[TESTS] ✅ Test generation completed")
        
        return jsonify({
            'success': True,
            'tests': test_code,
            'source': 'ai'
        })
        
    except Exception as e:
        logger.error(f"[TESTS] Exception: {str(e)}")
        return jsonify({'error': str(e)}), 500

def detect_test_framework(code):
    """Detect appropriate test framework based on code"""
    code_lower = code.lower()
    
    if 'java' in code_lower or ('class' in code and '{' in code):
        return 'JUnit'
    elif 'def ' in code or ('import ' in code and 'python' in code_lower):
        return 'pytest'
    else:
        return 'Jest'

def generate_mock_tests(code, platform):
    """Generate mock tests when OpenAI is not available"""
    logger.info("[MOCK] Generating mock tests")
    func_name = 'processOrder'
    if 'function ' in code:
        try:
            match = code.split('function ')[1].split('(')[0].strip()
            if match:
                func_name = match
        except:
            pass
    elif 'def ' in code:
        try:
            match = code.split('def ')[1].split('(')[0].strip()
            if match:
                func_name = match
        except:
            pass
    
    return f"""describe('{func_name}', () => {{
  test('should handle valid input successfully', () => {{
    const result = {func_name}({{
      items: [
        {{ price: 10.99 }},
        {{ price: 5.50 }}
      ]
    }});
    expect(result.success).toBe(true);
    expect(result.total).toBeGreaterThan(0);
  }});

  test('should handle empty input', () => {{
    const result = {func_name}({{ items: [] }});
    expect(result.success).toBe(false);
  }});

  test('should handle null input', () => {{
    const result = {func_name}(null);
    expect(result.success).toBe(false);
    expect(result.error).toBeDefined();
  }});

  test('should handle missing properties', () => {{
    const result = {func_name}({{}});
    expect(result.success).toBe(false);
  }});

  test('should handle invalid data types', () => {{
    const result = {func_name}({{
      items: [
        {{ price: 'invalid' }},
        {{ price: 20 }}
      ]
    }});
    expect(result.success).toBe(false);
  }});

  test('should handle negative values', () => {{
    const result = {func_name}({{
      items: [
        {{ price: -10 }},
        {{ price: 20 }}
      ]
    }});
    expect(result.total).toBe(10);
  }});

  test('should handle decimal precision', () => {{
    const result = {func_name}({{
      items: [
        {{ price: 10.99 }},
        {{ price: 5.01 }}
      ]
    }});
    expect(result.total).toBe(16.00);
  }});

  test('should validate all required fields', () => {{
    const result = {func_name}({{
      items: [
        {{ price: undefined }},
        {{ price: 10 }}
      ]
    }});
    expect(result.success).toBe(false);
  }});
}});"""

@app.route('/api/review-history', methods=['GET'])
def get_review_history():
    """Get code review history"""
    try:
        recent_reviews = review_history[-20:][::-1]
        return jsonify({
            'success': True,
            'total': len(review_history),
            'reviews': recent_reviews
        })
    except Exception as e:
        logger.error(f"Error fetching history: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

def open_browser():
    """Open browser after a delay"""
    webbrowser.open('http://localhost:5000')

# Then replace the if __name__ section at the end with:
if __name__ == '__main__':
    logger.info("="*80)
    logger.info("Starting Code Review API on port 5000")
    logger.info(f"Frontend path: {frontend_path}")
    logger.info(f"Static assets path: {assets_path}")
    logger.info("="*80)
    
    if not os.getenv("OPENAI_API_KEY"):
        logger.warning("⚠️ OPENAI_API_KEY not found in .env file!")
    if not os.getenv("AZURE_OPENAI_ENDPOINT"):
        logger.warning("⚠️ AZURE_OPENAI_ENDPOINT not found in .env file!")
    
    logger.info("="*80)
    
    # Only open browser in main process (not in reloader)
    if os.environ.get('WERKZEUG_RUN_MAIN') == 'true':
        timer = Timer(1.0, open_browser)
        timer.daemon = True
        timer.start()
    
    app.run(debug=True, port=5000, host='0.0.0.0')