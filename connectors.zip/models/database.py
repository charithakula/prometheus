"""
Database models for API migration tool
Contains SQLAlchemy models for tracking migrations and API specifications
"""
import json
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Text, DateTime, Float, Boolean, JSON

# Initialize SQLAlchemy
db = SQLAlchemy()

class MigrationRecord(db.Model):
    """Model for tracking API migration records"""
    
    __tablename__ = 'migration_records'
    
    id = Column(Integer, primary_key=True)
    migration_id = Column(String(100), unique=True, nullable=False, index=True)
    original_api_id = Column(String(100), nullable=False)
    azure_api_id = Column(String(100), nullable=True)
    api_name = Column(String(200), nullable=True)
    api_version = Column(String(50), nullable=True)
    
    # Migration details
    status = Column(String(20), nullable=False, default='pending')  # pending, in_progress, completed, failed, rolled_back
    source_platform = Column(String(50), nullable=False, default='ibm_api_connect')
    target_platform = Column(String(50), nullable=False, default='azure_apim')
    
    # Timestamps
    start_time = Column(DateTime, nullable=False, default=datetime.utcnow)
    end_time = Column(DateTime, nullable=True)
    completion_time = Column(Float, nullable=True)  # Time in seconds
    
    # File information
    original_filename = Column(String(255), nullable=True)
    converted_filename = Column(String(255), nullable=True)
    file_size = Column(Integer, nullable=True)
    
    # Conversion details
    conversion_method = Column(String(50), nullable=True)  # ai, fallback
    conversion_time = Column(Float, nullable=True)
    ai_conversion_used = Column(Boolean, default=False)
    
    # Results and metadata - RENAMED from 'metadata' to 'migration_metadata'
    conversion_notes = Column(Text, nullable=True)
    error_message = Column(Text, nullable=True)
    validation_results = Column(JSON, nullable=True)
    migration_metadata = Column(JSON, nullable=True)  # FIXED: was 'metadata'
    
    # Tracking
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
    
    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'migration_id': self.migration_id,
            'original_api_id': self.original_api_id,
            'azure_api_id': self.azure_api_id,
            'api_name': self.api_name,
            'api_version': self.api_version,
            'status': self.status,
            'source_platform': self.source_platform,
            'target_platform': self.target_platform,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'completion_time': self.completion_time,
            'original_filename': self.original_filename,
            'converted_filename': self.converted_filename,
            'file_size': self.file_size,
            'conversion_method': self.conversion_method,
            'conversion_time': self.conversion_time,
            'ai_conversion_used': self.ai_conversion_used,
            'conversion_notes': self.conversion_notes,
            'error_message': self.error_message,
            'validation_results': self.validation_results,
            'migration_metadata': self.migration_metadata,  # FIXED: was 'metadata'
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def update_status(self, status: str, error_message: str = None):
        """Update migration status"""
        self.status = status
        self.updated_at = datetime.utcnow()
        if error_message:
            self.error_message = error_message
        if status == 'completed':
            self.end_time = datetime.utcnow()
            if self.start_time:
                self.completion_time = (self.end_time - self.start_time).total_seconds()
    
    def add_conversion_metadata(self, conversion_result: dict):
        """Add conversion metadata from conversion result"""
        if conversion_result:
            self.conversion_time = conversion_result.get('conversion_time_seconds')
            self.ai_conversion_used = conversion_result.get('ai_conversion_used', False)
            self.conversion_method = 'ai' if self.ai_conversion_used else 'fallback'
            self.validation_results = conversion_result.get('validation', {})
            
            # Store conversion metadata - FIXED: was 'metadata'
            conversion_metadata = conversion_result.get('conversion_metadata', {})
            self.migration_metadata = json.dumps(conversion_metadata) if conversion_metadata else None
    
    @classmethod
    def get_by_migration_id(cls, migration_id: str):
        """Get migration record by migration ID"""
        return cls.query.filter_by(migration_id=migration_id).first()
    
    @classmethod
    def get_recent_migrations(cls, limit: int = 50, offset: int = 0):
        """Get recent migrations"""
        return cls.query.order_by(cls.created_at.desc()).offset(offset).limit(limit).all()
    
    @classmethod
    def get_statistics(cls):
        """Get migration statistics"""
        total = cls.query.count()
        successful = cls.query.filter_by(status='completed').count()
        failed = cls.query.filter_by(status='failed').count()
        in_progress = cls.query.filter(cls.status.in_(['pending', 'in_progress'])).count()
        
        # Calculate average completion time
        completed_migrations = cls.query.filter(
            cls.status == 'completed',
            cls.completion_time.isnot(None)
        ).all()
        
        avg_time = 0
        if completed_migrations:
            avg_time = sum(m.completion_time for m in completed_migrations) / len(completed_migrations)
        
        return {
            'total_migrations': total,
            'successful_migrations': successful,
            'failed_migrations': failed,
            'in_progress_migrations': in_progress,
            'success_rate': (successful / total * 100) if total > 0 else 0,
            'average_completion_time': avg_time
        }

class APISpecification(db.Model):
    """Model for storing API specifications"""
    
    __tablename__ = 'api_specifications'
    
    id = Column(Integer, primary_key=True)
    api_id = Column(String(100), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    version = Column(String(50), nullable=False)
    description = Column(Text, nullable=True)
    
    # Specification details
    format = Column(String(20), nullable=False)  # openapi_2.0, openapi_3.0, swagger_2.0
    specification = Column(JSON, nullable=False)  # The actual spec as JSON
    
    # Source information
    source_platform = Column(String(50), nullable=True)  # ibm_api_connect, manual_upload
    original_filename = Column(String(255), nullable=True)
    file_size = Column(Integer, nullable=True)
    
    # Validation status
    is_valid = Column(Boolean, default=True)
    validation_errors = Column(JSON, nullable=True)
    validation_warnings = Column(JSON, nullable=True)
    
    # Metadata
    paths_count = Column(Integer, default=0)
    operations_count = Column(Integer, default=0)
    definitions_count = Column(Integer, default=0)
    security_schemes_count = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if self.specification:
            self._extract_metadata()
    
    def _extract_metadata(self):
        """Extract metadata from specification"""
        try:
            if isinstance(self.specification, str):
                spec = json.loads(self.specification)
            else:
                spec = self.specification
            
            # Count paths and operations
            paths = spec.get('paths', {})
            self.paths_count = len(paths)
            
            operations = 0
            for path_data in paths.values():
                if isinstance(path_data, dict):
                    operations += sum(1 for key in path_data.keys() 
                                    if key.lower() in ['get', 'post', 'put', 'delete', 'head', 'options', 'patch'])
            self.operations_count = operations
            
            # Count definitions/schemas
            if 'definitions' in spec:
                self.definitions_count = len(spec['definitions'])
            elif 'components' in spec and 'schemas' in spec['components']:
                self.definitions_count = len(spec['components']['schemas'])
            
            # Count security schemes
            if 'securityDefinitions' in spec:
                self.security_schemes_count = len(spec['securityDefinitions'])
            elif 'components' in spec and 'securitySchemes' in spec['components']:
                self.security_schemes_count = len(spec['components']['securitySchemes'])
                
        except Exception as e:
            print(f"Error extracting metadata: {e}")
    
    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'api_id': self.api_id,
            'name': self.name,
            'version': self.version,
            'description': self.description,
            'format': self.format,
            'specification': self.specification,
            'source_platform': self.source_platform,
            'original_filename': self.original_filename,
            'file_size': self.file_size,
            'is_valid': self.is_valid,
            'validation_errors': self.validation_errors,
            'validation_warnings': self.validation_warnings,
            'paths_count': self.paths_count,
            'operations_count': self.operations_count,
            'definitions_count': self.definitions_count,
            'security_schemes_count': self.security_schemes_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def get_by_api_id(cls, api_id: str):
        """Get API specification by API ID"""
        return cls.query.filter_by(api_id=api_id).first()
    
    @classmethod
    def search_apis(cls, query: str):
        """Search APIs by name or description"""
        search_pattern = f"%{query}%"
        return cls.query.filter(
            cls.name.ilike(search_pattern) | 
            cls.description.ilike(search_pattern)
        ).all()

class MigrationLog(db.Model):
    """Model for detailed migration logs"""
    
    __tablename__ = 'migration_logs'
    
    id = Column(Integer, primary_key=True)
    migration_id = Column(String(100), nullable=False, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    level = Column(String(10), nullable=False)  # INFO, WARNING, ERROR
    stage = Column(String(50), nullable=False)  # extraction, conversion, deployment
    message = Column(Text, nullable=False)
    details = Column(JSON, nullable=True)
    
    def __init__(self, migration_id: str, level: str, stage: str, message: str, details: dict = None):
        self.migration_id = migration_id
        self.level = level
        self.stage = stage
        self.message = message
        self.details = details
    
    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'migration_id': self.migration_id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'level': self.level,
            'stage': self.stage,
            'message': self.message,
            'details': self.details
        }
    
    @classmethod
    def get_logs_for_migration(cls, migration_id: str):
        """Get all logs for a specific migration"""
        return cls.query.filter_by(migration_id=migration_id).order_by(cls.timestamp.asc()).all()
    
    @classmethod
    def log_info(cls, migration_id: str, stage: str, message: str, details: dict = None):
        """Log info message"""
        log_entry = cls(migration_id, 'INFO', stage, message, details)
        db.session.add(log_entry)
        db.session.commit()
        return log_entry
    
    @classmethod
    def log_warning(cls, migration_id: str, stage: str, message: str, details: dict = None):
        """Log warning message"""
        log_entry = cls(migration_id, 'WARNING', stage, message, details)
        db.session.add(log_entry)
        db.session.commit()
        return log_entry
    
    @classmethod
    def log_error(cls, migration_id: str, stage: str, message: str, details: dict = None):
        """Log error message"""
        log_entry = cls(migration_id, 'ERROR', stage, message, details)
        db.session.add(log_entry)
        db.session.commit()
        return log_entry

def init_database(app):
    """Initialize database with Flask app"""
    # Note: db.init_app(app) is already called in create_app()
    # Only create tables here
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # You can add any initial data here
        print("Database initialized successfully")

def get_database_statistics():
    """Get overall database statistics"""
    migration_stats = MigrationRecord.get_statistics()
    
    total_specs = APISpecification.query.count()
    valid_specs = APISpecification.query.filter_by(is_valid=True).count()
    
    return {
        'migrations': migration_stats,
        'api_specifications': {
            'total_specifications': total_specs,
            'valid_specifications': valid_specs,
            'invalid_specifications': total_specs - valid_specs
        }
    }