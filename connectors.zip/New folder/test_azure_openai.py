#!/usr/bin/env python3
"""
Test Azure OpenAI connection and diagnose issues
Run this script to debug Azure OpenAI API problems
"""
import os
import sys
import json
import time
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def test_azure_openai():
    """Test Azure OpenAI connection step by step"""
    print("🔍 Testing Azure OpenAI Connection...")
    print("=" * 50)
    
    # 1. Check environment variables
    print("1. Checking Environment Variables:")
    required_vars = [
        'AZURE_OPENAI_API_KEY',
        'AZURE_OPENAI_ENDPOINT',
        'AZURE_OPENAI_DEPLOYMENT'
    ]
    
    config = {}
    missing_vars = []
    
    for var in required_vars:
        value = os.getenv(var)
        if value:
            config[var] = value
            if 'KEY' in var:
                print(f"   ✅ {var}: {'*' * (len(value) - 4) + value[-4:]}")
            else:
                print(f"   ✅ {var}: {value}")
        else:
            print(f"   ❌ {var}: NOT SET")
            missing_vars.append(var)
    
    if missing_vars:
        print(f"\n❌ Missing variables: {missing_vars}")
        print("\nPlease set these in your .env file:")
        print("AZURE_OPENAI_API_KEY=your-api-key")
        print("AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com")
        print("AZURE_OPENAI_DEPLOYMENT=your-deployment-name")
        return False
    
    # 2. Test the connection
    print("\n2. Testing Azure OpenAI API Connection:")
    
    try:
        from openai import AzureOpenAI
        
        # Initialize client
        client = AzureOpenAI(
            api_key=config['AZURE_OPENAI_API_KEY'],
            api_version="2024-02-01",
            azure_endpoint=config['AZURE_OPENAI_ENDPOINT']
        )
        
        print("   ✅ Client initialized")
        
        # 3. Test with a simple request
        print("\n3. Testing API Call:")
        print("   Sending test request...")
        
        test_prompt = "Convert this simple test: respond with 'SUCCESS'"
        
        try:
            response = client.chat.completions.create(
                model=config['AZURE_OPENAI_DEPLOYMENT'],
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": test_prompt}
                ],
                max_tokens=50,
                temperature=0
            )
            
            if response and response.choices:
                result = response.choices[0].message.content
                print(f"   ✅ API Response: {result}")
                print("   ✅ Azure OpenAI connection successful!")
                return True
            else:
                print("   ❌ Empty response from API")
                return False
                
        except Exception as e:
            print(f"   ❌ API call failed: {e}")
            
            # Common error diagnostics
            error_str = str(e)
            if "401" in error_str or "Unauthorized" in error_str:
                print("\n   🔍 Diagnosis: Authentication failed")
                print("      - Check your API key is correct")
                print("      - Ensure the key has not expired")
                
            elif "404" in error_str:
                print("\n   🔍 Diagnosis: Resource not found")
                print("      - Check your endpoint URL")
                print("      - Verify deployment name is correct")
                
            elif "429" in error_str:
                print("\n   🔍 Diagnosis: Rate limit exceeded")
                print("      - You may have hit your quota")
                print("      - Wait a moment and try again")
                
            elif "timeout" in error_str.lower():
                print("\n   🔍 Diagnosis: Connection timeout")
                print("      - Check network connectivity")
                print("      - Verify endpoint URL is accessible")
            
            return False
            
    except ImportError as e:
        print(f"   ❌ Failed to import OpenAI library: {e}")
        print("\n   Install with: pip install openai")
        return False
    except Exception as e:
        print(f"   ❌ Unexpected error: {e}")
        return False

def test_conversion_with_openai():
    """Test actual OpenAPI conversion with Azure OpenAI"""
    print("\n4. Testing OpenAPI Conversion:")
    
    sample_swagger = {
        "swagger": "2.0",
        "info": {
            "title": "Test API",
            "version": "1.0.0"
        },
        "paths": {
            "/test": {
                "get": {
                    "responses": {
                        "200": {
                            "description": "Success"
                        }
                    }
                }
            }
        }
    }
    
    try:
        from openai import AzureOpenAI
        
        client = AzureOpenAI(
            api_key=os.getenv('AZURE_OPENAI_API_KEY'),
            api_version="2024-02-01",
            azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT')
        )
        
        prompt = f"""Convert this Swagger 2.0 to OpenAPI 3.0. Return only valid JSON:
{json.dumps(sample_swagger, indent=2)}"""
        
        print("   Sending conversion request...")
        start_time = time.time()
        
        response = client.chat.completions.create(
            model=os.getenv('AZURE_OPENAI_DEPLOYMENT'),
            messages=[
                {"role": "system", "content": "Convert API specs to OpenAPI 3.0. Return only JSON."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.1,
            max_tokens=1000
        )
        
        elapsed = time.time() - start_time
        print(f"   Response received in {elapsed:.2f}s")
        
        if response and response.choices:
            result = response.choices[0].message.content
            
            # Try to parse as JSON
            try:
                # Extract JSON from response
                import re
                json_match = re.search(r'\{.*\}', result, re.DOTALL)
                if json_match:
                    converted = json.loads(json_match.group())
                    
                    if 'openapi' in converted and converted['openapi'].startswith('3.'):
                        print("   ✅ Successfully converted to OpenAPI 3.0!")
                        print(f"   Converted spec preview:")
                        print(f"      - OpenAPI version: {converted.get('openapi')}")
                        print(f"      - Title: {converted.get('info', {}).get('title')}")
                        print(f"      - Paths: {list(converted.get('paths', {}).keys())}")
                        return True
                    else:
                        print("   ⚠️  Response doesn't appear to be OpenAPI 3.0")
                else:
                    print("   ❌ Could not extract JSON from response")
                    
            except json.JSONDecodeError as e:
                print(f"   ❌ Failed to parse response as JSON: {e}")
                print(f"   Response preview: {result[:200]}...")
        
    except Exception as e:
        print(f"   ❌ Conversion test failed: {e}")
    
    return False

def suggest_fixes():
    """Suggest fixes based on test results"""
    print("\n" + "=" * 50)
    print("💡 SUGGESTED FIXES:")
    print("=" * 50)
    
    print("\n1. If Azure OpenAI connection is failing:")
    print("   - Verify your Azure OpenAI resource is deployed")
    print("   - Check the API key in Azure Portal > Keys and Endpoint")
    print("   - Ensure your deployment name matches (e.g., 'gpt-35-turbo')")
    print("   - Check if you have quota/credits available")
    
    print("\n2. Update your .env file with correct values:")
    print("   AZURE_OPENAI_API_KEY=<your-key>")
    print("   AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com")
    print("   AZURE_OPENAI_DEPLOYMENT=<your-deployment-name>")
    
    print("\n3. If API returns empty responses:")
    print("   - The deployment might not be fully provisioned")
    print("   - Try a different deployment or model")
    print("   - Check Azure OpenAI Studio to test the deployment")
    
    print("\n4. Use the fallback converter:")
    print("   - The programmatic converter in the fixed code will work")
    print("   - It doesn't require Azure OpenAI to function")

def main():
    """Run all tests"""
    print("🚀 Azure OpenAI Diagnostic Tests")
    print("=" * 50)
    
    # Test basic connection
    connection_ok = test_azure_openai()
    
    # Test conversion if connection works
    if connection_ok:
        conversion_ok = test_conversion_with_openai()
        
        if conversion_ok:
            print("\n✅ All tests passed! Azure OpenAI is working correctly.")
        else:
            print("\n⚠️  Connection works but conversion has issues.")
    else:
        print("\n❌ Azure OpenAI connection failed.")
    
    # Show suggestions
    suggest_fixes()
    
    return connection_ok

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)