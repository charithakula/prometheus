"""
Logging configuration and utilities
Provides centralized logging setup for the application
"""
import logging
import logging.handlers
import os
import sys
from typing import Optional
from datetime import datetime
from config import Config

class CustomFormatter(logging.Formatter):
    """Custom formatter for enhanced log output"""
    
    # ANSI color codes
    COLORS = {
        'DEBUG': '\033[36m',    # Cyan
        'INFO': '\033[32m',     # Green
        'WARNING': '\033[33m',  # Yellow
        'ERROR': '\033[31m',    # Red
        'CRITICAL': '\033[35m', # Magenta
    }
    RESET = '\033[0m'
    
    def __init__(self, use_colors: bool = True):
        super().__init__()
        self.use_colors = use_colors
        
        # Format string with timestamp, level, logger name, and message
        self.base_format = "%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s"
        
        # Format for file logging (no colors)
        self.file_format = logging.Formatter(
            fmt=self.base_format,
            datefmt="%Y-%m-%d %H:%M:%S"
        )
    
    def format(self, record):
        """Format log record with colors for console output"""
        if not self.use_colors or record.levelname not in self.COLORS:
            return self.file_format.format(record)
        
        # Add colors for console output
        color = self.COLORS.get(record.levelname, '')
        level_color = f"{color}{record.levelname:<8}{self.RESET}"
        
        # Create colored format
        colored_format = f"%(asctime)s | {level_color} | %(name)-20s | %(message)s"
        formatter = logging.Formatter(fmt=colored_format, datefmt="%Y-%m-%d %H:%M:%S")
        
        return formatter.format(record)

def setup_logger(
    name: str = "api_migration_tool",
    log_level: str = None,
    log_file: str = None,
    enable_console: bool = True,
    enable_file: bool = True,
    max_file_size: int = 10 * 1024 * 1024,  # 10MB
    backup_count: int = 5
) -> logging.Logger:
    """
    Set up centralized logging configuration
    
    Args:
        name: Logger name
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Log file path
        enable_console: Enable console logging
        enable_file: Enable file logging
        max_file_size: Maximum log file size before rotation
        backup_count: Number of backup files to keep
        
    Returns:
        Configured logger
    """
    
    # Use config values as defaults
    log_level = log_level or Config.LOG_LEVEL
    log_file = log_file or Config.LOG_FILE
    
    # Convert string level to logging constant
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    
    # Get or create logger
    logger = logging.getLogger(name)
    
    # Clear existing handlers to avoid duplicates
    logger.handlers.clear()
    
    # Set logger level
    logger.setLevel(numeric_level)
    
    # Prevent propagation to avoid duplicate logs
    logger.propagate = False
    
    # Console handler
    if enable_console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(numeric_level)
        console_handler.setFormatter(CustomFormatter(use_colors=True))
        logger.addHandler(console_handler)
    
    # File handler with rotation
    if enable_file and log_file:
        # Ensure log directory exists
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
        
        # Rotating file handler
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=max_file_size,
            backupCount=backup_count
        )
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(CustomFormatter(use_colors=False))
        logger.addHandler(file_handler)
    
    return logger

def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for a specific module
    
    Args:
        name: Logger name (typically __name__)
        
    Returns:
        Logger instance
    """
    return logging.getLogger(name)

class MigrationLogHandler(logging.Handler):
    """Custom log handler for storing migration-specific logs"""
    
    def __init__(self, migration_id: str):
        super().__init__()
        self.migration_id = migration_id
        self.logs = []
    
    def emit(self, record):
        """Store log record for migration"""
        try:
            log_entry = {
                'timestamp': datetime.fromtimestamp(record.created),
                'level': record.levelname,
                'message': self.format(record),
                'module': record.name,
                'stage': getattr(record, 'stage', 'general')
            }
            self.logs.append(log_entry)
            
            # In a real application, you might save to database here
            # from models.database import MigrationLog
            # MigrationLog.objects.create(
            #     migration_id=self.migration_id,
            #     level=record.levelname,
            #     stage=getattr(record, 'stage', 'general'),
            #     message=log_entry['message']
            # )
            
        except Exception:
            # Don't let logging errors break the application
            pass
    
    def get_logs(self) -> list:
        """Get all stored logs for this migration"""
        return self.logs.copy()
    
    def get_logs_by_level(self, level: str) -> list:
        """Get logs filtered by level"""
        return [log for log in self.logs if log['level'] == level.upper()]

class LoggerAdapter(logging.LoggerAdapter):
    """Logger adapter for adding context to log messages"""
    
    def __init__(self, logger: logging.Logger, extra: dict):
        super().__init__(logger, extra)
    
    def process(self, msg, kwargs):
        """Process log message with additional context"""
        # Add migration context if available
        if 'migration_id' in self.extra:
            msg = f"[{self.extra['migration_id']}] {msg}"
        
        if 'api_id' in self.extra:
            msg = f"[API:{self.extra['api_id']}] {msg}"
        
        if 'stage' in self.extra:
            # Add stage to the record for custom handlers
            kwargs.setdefault('extra', {})['stage'] = self.extra['stage']
        
        return msg, kwargs

def create_migration_logger(migration_id: str, api_id: str = None, stage: str = None) -> LoggerAdapter:
    """
    Create a logger adapter for a specific migration
    
    Args:
        migration_id: Migration identifier
        api_id: API identifier (optional)
        stage: Migration stage (optional)
        
    Returns:
        Logger adapter with migration context
    """
    base_logger = get_logger("migration")
    
    # Build context
    context = {'migration_id': migration_id}
    if api_id:
        context['api_id'] = api_id
    if stage:
        context['stage'] = stage
    
    return LoggerAdapter(base_logger, context)

def log_function_call(logger: logging.Logger):
    """Decorator to log function calls"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            logger.debug(f"Calling {func.__name__} with args={args}, kwargs={kwargs}")
            try:
                result = func(*args, **kwargs)
                logger.debug(f"{func.__name__} completed successfully")
                return result
            except Exception as e:
                logger.error(f"{func.__name__} failed: {str(e)}")
                raise
        return wrapper
    return decorator

def log_execution_time(logger: logging.Logger):
    """Decorator to log function execution time"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            import time
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                execution_time = time.time() - start_time
                logger.info(f"{func.__name__} executed in {execution_time:.2f} seconds")
                return result
            except Exception as e:
                execution_time = time.time() - start_time
                logger.error(f"{func.__name__} failed after {execution_time:.2f} seconds: {str(e)}")
                raise
        return wrapper
    return decorator

# Application-specific loggers
def setup_application_loggers():
    """Set up all application loggers"""
    loggers = {
        'api_migration_tool': setup_logger('api_migration_tool'),
        'connectors': setup_logger('connectors'),
        'services': setup_logger('services'),
        'models': setup_logger('models'),
        'utils': setup_logger('utils'),
        'migration': setup_logger('migration'),
        'conversion': setup_logger('conversion'),
        'validation': setup_logger('validation'),
        'azure': setup_logger('azure'),
        'ibm': setup_logger('ibm'),
    }
    
    return loggers

# Initialize default logger when module is imported
default_logger = setup_logger()

# Export for easy access
__all__ = [
    'setup_logger',
    'get_logger', 
    'MigrationLogHandler',
    'LoggerAdapter',
    'create_migration_logger',
    'log_function_call',
    'log_execution_time',
    'setup_application_loggers',
    'CustomFormatter'
]