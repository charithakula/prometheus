"""
Conversion Service - FIXED VERSION
Orchestrates OpenAPI 2.0 to 3.0 conversion process with clean output
"""
import json
import logging
from typing import Dict, Any, Optional, Tuple
from datetime import datetime

from connectors import AzureOpenAIConnector
from .validation_service import ValidationService

logger = logging.getLogger(__name__)

class ConversionService:
    """Service for handling OpenAPI specification conversions"""
    
    def __init__(self):
        """Initialize conversion service with required connectors"""
        self.openai_connector = AzureOpenAIConnector()
        self.validation_service = ValidationService()
    
    def convert_specification(self, spec_content: str, source_format: str = 'auto', include_debug: bool = False) -> Dict[str, Any]:
        """
        Convert OpenAPI specification from 2.0 to 3.0
        
        Args:
            spec_content: Raw specification content
            source_format: Source format ('auto', 'json', 'yaml')
            include_debug: Include debug information in response
        
        Returns:
            Dictionary with conversion results
        """
        try:
            # Step 1: Parse and validate input
            parse_result = self._parse_input_specification(spec_content, source_format)
            if parse_result['status'] == 'error':
                return parse_result
            
            original_spec = parse_result['specification']
            detected_format = parse_result['format']
            
            # Step 2: Validate it's OpenAPI 2.0
            validation_result = self.validation_service.validate_openapi_2(original_spec)
            if not validation_result['is_valid']:
                return {
                    'status': 'error',
                    'message': 'Input is not a valid OpenAPI 2.0 specification',
                    'validation_errors': validation_result['errors']
                }
            
            # Step 3: Perform conversion using the universal converter
            logger.info("Starting OpenAPI 2.0 to 3.0 conversion")
            conversion_start = datetime.now()
            
            # Use the universal converter method that returns the proper structure
            conversion_result = self.openai_connector.universal_openapi_converter(spec_content, include_debug)
            
            if conversion_result['status'] != 'success':
                return conversion_result
            
            # Extract the clean converted spec
            converted_spec = conversion_result['converted_spec']
            
            conversion_time = (datetime.now() - conversion_start).total_seconds()
            
            # Step 4: Validate converted specification
            converted_validation = self.validation_service.validate_openapi_3(converted_spec)
            if not converted_validation['is_valid']:
                logger.warning("Converted specification has validation issues")
            
            # Step 5: Compare original vs converted
            comparison_result = self._compare_specifications(original_spec, converted_spec)
            
            # Step 6: Prepare results with CLEAN structure
            result = {
                'status': 'success',
                'message': 'Conversion completed successfully',
                'converted_spec': converted_spec,  # THIS IS THE CLEAN OPENAPI 3.0 SPEC
                'source_format': detected_format,
                'target_format': 'openapi_3.0',
                'conversion_time_seconds': conversion_time,
                'ai_conversion_used': conversion_result.get('ai_conversion_used', False),
                'conversion_metadata': conversion_result.get('conversion_metadata', {})
            }
            
            # Add debug info if requested
            if include_debug:
                debug_info = {}
                if 'raw_openai_response' in conversion_result:
                    debug_info['raw_openai_response'] = conversion_result['raw_openai_response']
                if 'cleaned_json' in conversion_result:
                    debug_info['cleaned_json'] = conversion_result['cleaned_json']
                if 'cleaning_issues' in conversion_result:
                    debug_info['cleaning_issues'] = conversion_result['cleaning_issues']
                
                if debug_info:
                    result.update(debug_info)
            
            # Optional: Include validation and comparison (but not the original spec)
            if include_debug:
                result['validation'] = {
                    'original_validation': validation_result,
                    'converted_validation': converted_validation,
                    'comparison': comparison_result
                }
            
            logger.info(f"Conversion completed in {conversion_time:.2f} seconds")
            return result
            
        except Exception as e:
            logger.error(f"Conversion failed: {e}")
            return {
                'status': 'error',
                'message': f'Conversion failed: {str(e)}',
                'conversion_time_seconds': 0
            }
    
    def _parse_input_specification(self, spec_content: str, source_format: str) -> Dict[str, Any]:
        """Parse input specification and detect format"""
        try:
            if source_format == 'auto':
                # Try to parse and detect format
                spec, detected_format = self.openai_connector.parse_api_spec(spec_content)
            else:
                # Use specified format
                if source_format == 'json':
                    spec = json.loads(spec_content)
                    detected_format = 'json'
                elif source_format in ['yaml', 'yml']:
                    import yaml
                    spec = yaml.safe_load(spec_content)
                    detected_format = 'yaml'
                else:
                    raise ValueError(f"Unsupported format: {source_format}")
            
            return {
                'status': 'success',
                'specification': spec,
                'format': detected_format
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Failed to parse specification: {str(e)}'
            }
    
    def _compare_specifications(self, original: Dict[str, Any], converted: Dict[str, Any]) -> Dict[str, Any]:
        """Compare original and converted specifications"""
        comparison = {
            'paths_preserved': len(original.get('paths', {})) == len(converted.get('paths', {})),
            'definitions_preserved': len(original.get('definitions', {})) == len(converted.get('components', {}).get('schemas', {})),
            'security_preserved': 'securityDefinitions' in original and 'components' in converted and 'securitySchemes' in converted['components'],
            'info_preserved': original.get('info', {}).get('title') == converted.get('info', {}).get('title'),
            'version_preserved': original.get('info', {}).get('version') == converted.get('info', {}).get('version')
        }
        
        # Calculate preservation score
        preserved_count = sum(1 for v in comparison.values() if v)
        total_checks = len(comparison)
        preservation_score = (preserved_count / total_checks) * 100
        
        comparison['preservation_score'] = preservation_score
        comparison['summary'] = f"{preserved_count}/{total_checks} checks passed ({preservation_score:.1f}%)"
        
        return comparison
    
    def batch_convert_specifications(self, specifications: list) -> Dict[str, Any]:
        """
        Convert multiple specifications in batch
        
        Args:
            specifications: List of dicts with 'content' and optional 'name' keys
        
        Returns:
            Batch conversion results
        """
        results = []
        successful_conversions = 0
        failed_conversions = 0
        
        batch_start = datetime.now()
        
        for i, spec_data in enumerate(specifications):
            spec_content = spec_data.get('content', '')
            spec_name = spec_data.get('name', f'specification_{i+1}')
            
            logger.info(f"Converting specification {i+1}/{len(specifications)}: {spec_name}")
            
            # Convert individual specification
            conversion_result = self.convert_specification(spec_content)
            conversion_result['name'] = spec_name
            conversion_result['index'] = i + 1
            
            results.append(conversion_result)
            
            if conversion_result['status'] == 'success':
                successful_conversions += 1
            else:
                failed_conversions += 1
        
        batch_time = (datetime.now() - batch_start).total_seconds()
        
        return {
            'status': 'completed',
            'total_specifications': len(specifications),
            'successful_conversions': successful_conversions,
            'failed_conversions': failed_conversions,
            'batch_time_seconds': batch_time,
            'average_time_per_conversion': batch_time / len(specifications) if specifications else 0,
            'results': results,
            'summary': f"Converted {successful_conversions}/{len(specifications)} specifications successfully"
        }
    
    def get_conversion_preview(self, spec_content: str) -> Dict[str, Any]:
        """
        Get preview of what will be converted without doing full conversion
        
        Args:
            spec_content: Raw specification content
        
        Returns:
            Preview information
        """
        try:
            # Parse input
            original_spec, format_type = self.openai_connector.parse_api_spec(spec_content)
            
            # Validate it's OpenAPI 2.0
            validation_result = self.validation_service.validate_openapi_2(original_spec)
            
            info = original_spec.get('info', {})
            paths = original_spec.get('paths', {})
            definitions = original_spec.get('definitions', {})
            security_defs = original_spec.get('securityDefinitions', {})
            
            # Calculate conversion complexity
            complexity_score = self._calculate_conversion_complexity(original_spec)
            
            return {
                'status': 'success',
                'api_info': {
                    'title': info.get('title', 'Unknown API'),
                    'version': info.get('version', 'Unknown'),
                    'description': info.get('description', '')
                },
                'current_format': format_type,
                'openapi_version': original_spec.get('swagger', 'Unknown'),
                'is_valid_openapi_2': validation_result['is_valid'],
                'validation_errors': validation_result['errors'] if not validation_result['is_valid'] else [],
                'conversion_preview': {
                    'paths_count': len(paths),
                    'definitions_count': len(definitions),
                    'security_schemes_count': len(security_defs),
                    'estimated_complexity': complexity_score,
                    'estimated_conversion_time': self._estimate_conversion_time(complexity_score),
                    'will_create_servers': bool(original_spec.get('host') or original_spec.get('basePath')),
                    'ai_conversion_available': self.openai_connector.is_available
                }
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Failed to generate preview: {str(e)}'
            }
    
    def _calculate_conversion_complexity(self, spec: Dict[str, Any]) -> str:
        """Calculate conversion complexity score"""
        score = 0
        
        # Base complexity factors
        paths_count = len(spec.get('paths', {}))
        definitions_count = len(spec.get('definitions', {}))
        security_count = len(spec.get('securityDefinitions', {}))
        
        score += min(paths_count * 2, 20)  # Max 20 points for paths
        score += min(definitions_count * 3, 30)  # Max 30 points for definitions
        score += min(security_count * 5, 25)  # Max 25 points for security
        
        # Additional complexity factors
        if spec.get('produces') or spec.get('consumes'):
            score += 10
        
        if any('$ref' in str(path_data) for path_data in spec.get('paths', {}).values()):
            score += 15  # References add complexity
        
        # Classify complexity
        if score <= 20:
            return 'low'
        elif score <= 50:
            return 'medium'
        else:
            return 'high'
    
    def _estimate_conversion_time(self, complexity: str) -> str:
        """Estimate conversion time based on complexity"""
        estimates = {
            'low': '< 5 seconds',
            'medium': '5-15 seconds',
            'high': '15-30 seconds'
        }
        return estimates.get(complexity, '< 5 seconds')