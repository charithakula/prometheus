"""
Main Flask Application - COMPLETE UPDATED VERSION WITH ENHANCED DATABASE ERROR HANDLING
Entry point for the API Migration Tool
Updated with comprehensive database error handling and graceful degradation
"""
import os
import json
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_file
from flask_cors import CORS
from werkzeug.exceptions import RequestEntityTooLarge
from datetime import datetime
import logging
import traceback
from typing import Optional, Dict, Any

# Enhanced database error handling imports
from sqlalchemy.exc import OperationalError, DatabaseError, SQLAlchemyError
from sqlalchemy import text

# Import configuration
from config import get_config, validate_all_configurations, get_missing_configurations

# Import database - UPDATED WITH ACTUAL MODELS
from models.database import db, init_database, get_database_statistics, MigrationRecord, APISpecification, MigrationLog

# Import services
from services import ConversionService, MigrationService, ValidationService

# Import connectors
from connectors import AzureAPIMConnector, AzureOpenAIConnector, IBMAPIConnector

# Import utilities - UPDATED IMPORTS
from utils import setup_logger, generate_id
from utils.enhanced_file_handler import EnhancedFileHandler

# Updated schemas for validation with OpenAI support
from pydantic import BaseModel, Field
from typing import Optional

class ConversionRequestSchema(BaseModel):
    """Schema for API conversion requests with OpenAI response support"""
    spec_content: str = Field(..., description="OpenAPI specification content")
    source_format: Optional[str] = Field(default='auto', description="Source format (auto, json, yaml)")
    include_debug: Optional[bool] = Field(default=False, description="Include debug information in response")

class MigrationRequestSchema(BaseModel):
    """Schema for migration requests"""
    api_ids: list = Field(..., description="List of API IDs to migrate")
    org_name: str = Field(..., description="Organization name")
    options: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Migration options")

class BatchMigrationRequestSchema(BaseModel):
    """Schema for batch migration requests"""
    migration_type: str = Field(..., description="Type of migration (apis, catalog)")
    api_ids: Optional[list] = Field(default=None, description="List of API IDs")
    org_name: str = Field(..., description="Organization name")
    catalog_name: Optional[str] = Field(default=None, description="Catalog name for catalog migration")
    options: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Migration options")


def create_app():
    """Application factory pattern for Flask 3.x with enhanced database error handling"""
    
    # ==========================================
    # HELPER FUNCTIONS - MOVED TO TOP
    # ==========================================
    
    def initialize_database_safely(app, logger):
        """Initialize database with comprehensive error handling"""
        try:
            # Test connection first
            connection_status = test_database_connection()
            
            if connection_status['status'] == 'success':
                if connection_status['details']['tables_exist']:
                    logger.info("Database tables already exist")
                    return {'status': 'success', 'message': 'Database ready'}
                else:
                    logger.info("Database connected but tables missing - will create on demand")
                    return {'status': 'partial', 'message': 'Database connected, tables need initialization'}
            else:
                logger.warning(f"Database connection failed: {connection_status['message']}")
                return {
                    'status': 'error', 
                    'message': connection_status['message'],
                    'details': connection_status.get('details', {})
                }
                
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            return {'status': 'error', 'message': str(e)}

    def test_database_connection():
        """Test database connection and return detailed status with proper error handling"""
        try:
            # Get configuration info
            config = get_config()
            db_type = 'sqlite' if 'sqlite' in config.DATABASE_URL else 'postgresql'
            db_name = 'migrations.db' if db_type == 'sqlite' else config.DATABASE_URL.split('/')[-1]
            
            # Test basic connection with timeout
            try:
                # Test if we can execute a simple query
                result = db.session.execute(text('SELECT 1')).fetchone()
                if result is None:
                    raise Exception("Query returned no results")
                
                db.session.commit()
                
                # Check if tables exist
                tables_exist = check_tables_exist()
                
                return {
                    'status': 'success',
                    'message': f'{db_type.title()} database connected successfully',
                    'details': {
                        'database_type': db_type,
                        'database_name': db_name,
                        'tables_exist': tables_exist,
                        'connection_healthy': True
                    }
                }
                
            except OperationalError as e:
                error_msg = str(e)
                if 'does not exist' in error_msg.lower():
                    return {
                        'status': 'error',
                        'message': f'Database "{db_name}" does not exist',
                        'details': {
                            'database_type': db_type,
                            'database_name': db_name,
                            'tables_exist': False,
                            'connection_healthy': False,
                            'error_type': 'database_not_found'
                        }
                    }
                elif 'connection' in error_msg.lower():
                    return {
                        'status': 'error',
                        'message': f'Cannot connect to {db_type} database',
                        'details': {
                            'database_type': db_type,
                            'database_name': db_name,
                            'tables_exist': False,
                            'connection_healthy': False,
                            'error_type': 'connection_failed'
                        }
                    }
                else:
                    return {
                        'status': 'error',
                        'message': f'Database error: {str(e)[:100]}...' if len(str(e)) > 100 else str(e),
                        'details': {
                            'database_type': db_type,
                            'database_name': db_name,
                            'tables_exist': False,
                            'connection_healthy': False,
                            'error_type': 'operational_error'
                        }
                    }
                    
        except Exception as e:
            logger.error(f"Database connection test failed with unexpected error: {e}")
            logger.error(f"Database error traceback: {traceback.format_exc()}")
            
            return {
                'status': 'error',
                'message': 'Database service unavailable',
                'details': {
                    'database_type': 'unknown',
                    'database_name': 'unknown',
                    'tables_exist': False,
                    'connection_healthy': False,
                    'error_type': 'service_unavailable',
                    'error_details': str(e)[:200] if str(e) else 'Unknown error'
                }
            }

    def check_tables_exist():
        """Check if required tables exist with proper error handling"""
        try:
            # Try to query each table with a simple count
            MigrationRecord.query.limit(1).all()
            APISpecification.query.limit(1).all()
            MigrationLog.query.limit(1).all()
            return True
        except (OperationalError, DatabaseError, SQLAlchemyError) as e:
            # Tables likely don't exist or database schema issues
            logger.warning(f"Database tables check failed: {e}")
            return False
        except Exception as e:
            # Other unexpected errors
            logger.error(f"Unexpected error checking tables: {e}")
            return False

# Add this section after the app context initialization, around line 195:

    # Initialize services (moved outside app context but after app creation)
    conversion_service = ConversionService()
    migration_service = MigrationService()
    validation_service = ValidationService()

    # Initialize enhanced file handler
    file_handler = EnhancedFileHandler()

    # ==========================================
    # ==========================================
    # MAIN APP INITIALIZATION CONTINUES...
    # ==========================================
    
    # Initialize Flask app
    app = Flask(__name__)

    # Load configuration
    config = get_config()
    app.config.from_object(config)

    # Initialize extensions
    CORS(app)
    db.init_app(app)

    # Initialize logging
    logger = setup_logger('app')

    # Global variables for tracking
    app_start_time = datetime.now()

    # Initialize application within app context with enhanced error handling
    with app.app_context():
        try:
            # NOW THIS WILL WORK - Initialize database with enhanced error handling
            database_status = initialize_database_safely(app, logger)
            
            # Validate configurations
            missing_configs = get_missing_configurations()
            if missing_configs:
                logger.warning(f"Missing configurations: {missing_configs}")
            
            logger.info(f"Application initialized successfully - Database status: {database_status['status']}")
            
        except Exception as e:
            logger.error(f"Failed to initialize application: {e}")
            logger.error(f"Initialization traceback: {traceback.format_exc()}")


    def get_database_statistics_safe():
        """Get overall database statistics with fallback for unavailable database"""
        try:
            # Try to get migration statistics
            try:
                migration_stats = MigrationRecord.get_statistics()
            except Exception as e:
                logger.warning(f"Failed to get migration statistics: {e}")
                migration_stats = {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                }
            
            # Try to get API specification statistics
            try:
                total_specs = APISpecification.query.count()
                valid_specs = APISpecification.query.filter_by(is_valid=True).count()
            except Exception as e:
                logger.warning(f"Failed to get API specification statistics: {e}")
                total_specs = 0
                valid_specs = 0
            
            return {
                'migrations': migration_stats,
                'api_specifications': {
                    'total_specifications': total_specs,
                    'valid_specifications': valid_specs,
                    'invalid_specifications': total_specs - valid_specs
                },
                'database_available': True
            }
            
        except Exception as e:
            logger.error(f"Failed to get database statistics: {e}")
            return {
                'migrations': {
                    'total_migrations': 0,
                    'successful_migrations': 0,
                    'failed_migrations': 0,
                    'in_progress_migrations': 0,
                    'success_rate': 0,
                    'average_completion_time': 0
                },
                'api_specifications': {
                    'total_specifications': 0,
                    'valid_specifications': 0,
                    'invalid_specifications': 0
                },
                'database_available': False,
                'error': str(e)
            }

    def get_database_health():
        """Get database health information with error handling"""
        try:
            health_info = {
                'record_counts': {
                    'migrations': 0,
                    'api_specifications': 0,
                    'logs': 0
                },
                'last_migration': None,
                'database_size': None
            }
            
            # Try to get record counts
            try:
                health_info['record_counts']['migrations'] = MigrationRecord.query.count()
            except Exception as e:
                logger.warning(f"Failed to count migration records: {e}")
            
            try:
                health_info['record_counts']['api_specifications'] = APISpecification.query.count()
            except Exception as e:
                logger.warning(f"Failed to count API specification records: {e}")
            
            try:
                health_info['record_counts']['logs'] = MigrationLog.query.count()
            except Exception as e:
                logger.warning(f"Failed to count log records: {e}")
            
            # Try to get last migration
            try:
                last_migration = MigrationRecord.query.order_by(
                    MigrationRecord.created_at.desc()
                ).first()
                
                if last_migration:
                    health_info['last_migration'] = {
                        'id': last_migration.migration_id,
                        'created_at': last_migration.created_at.isoformat(),
                        'status': last_migration.status
                    }
            except Exception as e:
                logger.warning(f"Failed to get last migration: {e}")
            
            return health_info
            
        except Exception as e:
            logger.warning(f"Failed to get database health: {e}")
            return {
                'record_counts': {'migrations': 0, 'api_specifications': 0, 'logs': 0},
                'error': str(e)
            }

    def initialize_database_safely(app, logger):
        """Initialize database with comprehensive error handling"""
        try:
            # Test connection first
            connection_status = test_database_connection()
            
            if connection_status['status'] == 'success':
                if connection_status['details']['tables_exist']:
                    logger.info("Database tables already exist")
                    return {'status': 'success', 'message': 'Database ready'}
                else:
                    logger.info("Database connected but tables missing - will create on demand")
                    return {'status': 'partial', 'message': 'Database connected, tables need initialization'}
            else:
                logger.warning(f"Database connection failed: {connection_status['message']}")
                return {
                    'status': 'error', 
                    'message': connection_status['message'],
                    'details': connection_status.get('details', {})
                }
                
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            return {'status': 'error', 'message': str(e)}

    def create_migration_record_safe(migration_record_data):
        """Safely create migration record with fallback"""
        try:
            migration_record = MigrationRecord(**migration_record_data)
            db.session.add(migration_record)
            db.session.commit()
            logger.info(f"Created migration record with ID: {migration_record.migration_id}")
            return migration_record
        except Exception as e:
            logger.warning(f"Failed to create migration record: {e}")
            db.session.rollback()
            return None

    def update_migration_record_safe(migration_record, **updates):
        """Safely update migration record with fallback"""
        try:
            for key, value in updates.items():
                if hasattr(migration_record, key):
                    setattr(migration_record, key, value)
            migration_record.updated_at = datetime.now()
            db.session.commit()
            return True
        except Exception as e:
            logger.warning(f"Failed to update migration record: {e}")
            db.session.rollback()
            return False

    # ==========================================
    # ERROR HANDLERS
    # ==========================================

    @app.errorhandler(404)
    def not_found_error(error):
        """Handle 404 errors"""
        if request.is_json:
            return jsonify({'error': 'Resource not found'}), 404
        return '''
        <html>
        <head><title>404 - Page Not Found</title></head>
        <body>
        <h1>404 - Page Not Found</h1>
        <p>The page you are looking for could not be found.</p>
        <a href="/">Go back to home</a>
        </body>
        </html>
        ''', 404

    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors"""
        logger.error(f"Internal server error: {error}")
        if request.is_json:
            return jsonify({'error': 'Internal server error'}), 500
        return '''
        <html>
        <head><title>500 - Internal Server Error</title></head>
        <body>
        <h1>500 - Internal Server Error</h1>
        <p>Something went wrong on our end.</p>
        <a href="/">Go back to home</a>
        </body>
        </html>
        ''', 500

    @app.errorhandler(RequestEntityTooLarge)
    def file_too_large(error):
        """Handle file too large errors"""
        if request.is_json:
            return jsonify({'error': 'File too large', 'max_size': '16MB'}), 413
        flash('File is too large. Maximum size is 16MB.', 'error')
        return redirect(url_for('upload_page'))

    # ==========================================
    # MAIN ROUTES WITH ENHANCED ERROR HANDLING
    # ==========================================

    @app.route('/')
    def index():
        """Main dashboard page with enhanced database error handling"""
        try:
            # Get basic statistics with fallback
            db_stats = get_database_statistics_safe()
            
            # Check service availability
            try:
                prerequisites = migration_service.validate_migration_prerequisites()
            except Exception as e:
                logger.warning(f"Failed to validate prerequisites: {e}")
                prerequisites = {
                    'all_services_available': False,
                    'service_status': {},
                    'can_migrate': False,
                    'recommendations': ['Check system configuration']
                }
            
            # Get storage stats
            try:
                storage_stats = file_handler.get_storage_stats()
            except Exception as e:
                logger.warning(f"Failed to get storage stats: {e}")
                storage_stats = {'totals': {}}
            
            # Get recent migrations with database fallback
            recent_migrations = []
            if db_stats.get('database_available', False):
                try:
                    recent_migration_records = MigrationRecord.query.order_by(
                        MigrationRecord.created_at.desc()
                    ).limit(5).all()
                    recent_migrations = [m.to_dict() for m in recent_migration_records]
                except Exception as e:
                    logger.warning(f"Failed to load recent migrations: {e}")
                    recent_migrations = []
            
            return render_template('index.html', 
                                 stats=db_stats,
                                 prerequisites=prerequisites,
                                 recent_migrations=recent_migrations,
                                 storage_stats=storage_stats.get('totals', {}))
            
        except Exception as e:
            logger.error(f"Failed to load dashboard: {e}")
            # Provide minimal fallback data
            fallback_stats = {
                'migrations': {'total_migrations': 0, 'successful_migrations': 0, 'failed_migrations': 0, 'in_progress_migrations': 0},
                'api_specifications': {'total_specifications': 0, 'valid_specifications': 0, 'invalid_specifications': 0},
                'database_available': False
            }
            fallback_prerequisites = {
                'all_services_available': False,
                'service_status': {'database': {'status': 'error', 'message': 'Database service unavailable'}},
                'can_migrate': False,
                'recommendations': ['Database service needs attention']
            }
            
            flash('Dashboard loaded with limited functionality due to database issues', 'warning')
            return render_template('index.html', 
                                 stats=fallback_stats,
                                 prerequisites=fallback_prerequisites,
                                 recent_migrations=[],
                                 storage_stats={})

    @app.route('/upload')
    def upload_page():
        """File upload page"""
        try:
            # Get storage stats for display
            storage_stats = file_handler.get_storage_stats()
            return render_template('upload.html', storage_stats=storage_stats.get('totals', {}))
        except Exception as e:
            logger.error(f"Failed to load upload page: {e}")
            return render_template('upload.html', storage_stats={})

    @app.route('/history')
    def migration_history():
        """Migration history page with database fallback"""
        try:
            # Check if database is available first
            db_status = test_database_connection()
            
            if db_status['status'] != 'success':
                # Database not available - show error page
                flash(f'Database unavailable: {db_status["message"]}', 'error')
                return render_template('migration_history.html', 
                                     migrations=[], 
                                     pagination={'page': 1, 'per_page': 20, 'total': 0, 'pages': 0, 'has_prev': False, 'has_next': False},
                                     current_filters={},
                                     database_error=db_status)
            
            # Database is available - proceed with normal logic
            page = request.args.get('page', 1, type=int)
            per_page = min(request.args.get('per_page', 20, type=int), 100)
            
            # Get filter parameters
            status_filter = request.args.get('status', '')
            search_query = request.args.get('search', '')
            date_range = request.args.get('date_range', '')
            sort_by = request.args.get('sort_by', 'created_at_desc')
            
            try:
                # Build query
                query = MigrationRecord.query
                
                # Apply filters
                if status_filter:
                    query = query.filter(MigrationRecord.status == status_filter)
                
                if search_query:
                    search_pattern = f"%{search_query}%"
                    query = query.filter(
                        db.or_(
                            MigrationRecord.api_name.ilike(search_pattern),
                            MigrationRecord.migration_id.ilike(search_pattern),
                            MigrationRecord.original_api_id.ilike(search_pattern)
                        )
                    )
                
                # Apply date range filter
                if date_range:
                    from datetime import datetime, timedelta
                    now = datetime.now()
                    
                    if date_range == 'today':
                        start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                    elif date_range == 'week':
                        start_date = now - timedelta(days=7)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                    elif date_range == 'month':
                        start_date = now - timedelta(days=30)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                    elif date_range == 'quarter':
                        start_date = now - timedelta(days=90)
                        query = query.filter(MigrationRecord.created_at >= start_date)
                
                # Apply sorting
                if sort_by == 'created_at_desc':
                    query = query.order_by(MigrationRecord.created_at.desc())
                elif sort_by == 'created_at_asc':
                    query = query.order_by(MigrationRecord.created_at.asc())
                elif sort_by == 'api_name_asc':
                    query = query.order_by(MigrationRecord.api_name.asc())
                elif sort_by == 'api_name_desc':
                    query = query.order_by(MigrationRecord.api_name.desc())
                elif sort_by == 'duration_desc':
                    query = query.order_by(MigrationRecord.completion_time.desc().nullslast())
                elif sort_by == 'duration_asc':
                    query = query.order_by(MigrationRecord.completion_time.asc().nullslast())
                
                # Get total count before pagination
                total_migrations = query.count()
                
                # Apply pagination
                offset = (page - 1) * per_page
                migrations = query.offset(offset).limit(per_page).all()
                
                # Convert to dictionaries for template
                migration_dicts = []
                for migration in migrations:
                    migration_dict = migration.to_dict()
                    migration_dict['source_platform'] = migration_dict.get('source_platform', 'ibm_api_connect').replace('_', ' ').title()
                    migration_dict['target_platform'] = migration_dict.get('target_platform', 'azure_apim').replace('_', ' ').title()
                    migration_dicts.append(migration_dict)
                
                # Calculate pagination info
                total_pages = (total_migrations + per_page - 1) // per_page
                
                pagination = {
                    'page': page,
                    'per_page': per_page,
                    'total': total_migrations,
                    'pages': total_pages,
                    'has_prev': page > 1,
                    'has_next': page < total_pages,
                    'prev_num': page - 1 if page > 1 else None,
                    'next_num': page + 1 if page < total_pages else None
                }
                
                current_filters = {
                    'status': status_filter,
                    'search': search_query,
                    'date_range': date_range,
                    'sort_by': sort_by
                }
                
                return render_template('migration_history.html', 
                                     migrations=migration_dicts, 
                                     pagination=pagination,
                                     current_filters=current_filters)
                
            except Exception as query_error:
                logger.error(f"Database query failed in migration history: {query_error}")
                flash('Failed to load migration history due to database error', 'error')
                return render_template('migration_history.html', 
                                     migrations=[], 
                                     pagination={'page': 1, 'per_page': 20, 'total': 0, 'pages': 0, 'has_prev': False, 'has_next': False},
                                     current_filters={},
                                     database_error={'status': 'error', 'message': 'Database query failed'})
                
        except Exception as e:
            logger.error(f"Failed to load migration history: {e}")
            flash('Migration history unavailable due to system error', 'error')
            return render_template('migration_history.html', 
                                 migrations=[], 
                                 pagination={'page': 1, 'per_page': 20, 'total': 0, 'pages': 0, 'has_prev': False, 'has_next': False},
                                 current_filters={},
                                 database_error={'status': 'error', 'message': 'System error occurred'})

    # ==========================================
    # API ENDPOINTS WITH ENHANCED ERROR HANDLING
    # ==========================================

    @app.route('/api/health')
    def health_check():
        """Health check endpoint with database status"""
        uptime = (datetime.now() - app_start_time).total_seconds()
        
        # Check service connections
        service_status = {
            'ibm_api_connect': IBMAPIConnector().test_connection(),
            'azure_apim': AzureAPIMConnector().test_connection(),
            'azure_openai': AzureOpenAIConnector().test_connection(),
            'database': test_database_connection()
        }
        
        # Check file storage
        storage_stats = file_handler.get_storage_stats()
        service_status['file_storage'] = {
            'status': 'success' if storage_stats.get('success') else 'error',
            'message': f"Storage available: {storage_stats.get('totals', {}).get('total_size_mb', 0)} MB used"
        }
        
        # Determine overall health
        all_services_healthy = all(
            status.get('status') == 'success' 
            for status in service_status.values()
        )
        
        return jsonify({
            'status': 'healthy' if all_services_healthy else 'degraded',
            'timestamp': datetime.now().isoformat(),
            'uptime_seconds': int(uptime),
            'version': '1.0.0',
            'services': service_status
        })

    @app.route('/api/database/status')
    def get_database_status():
        """Get detailed database status for UI"""
        try:
            connection_status = test_database_connection()
            health_info = get_database_health()
            stats = get_database_statistics_safe()
            
            return jsonify({
                'success': True,
                'connection': connection_status,
                'health': health_info,
                'statistics': stats
            })
            
        except Exception as e:
            logger.error(f"Database status check failed: {e}")
            return jsonify({
                'success': False,
                'error': str(e),
                'connection': {
                    'status': 'error',
                    'message': 'Database status check failed',
                    'details': {
                        'database_type': 'unknown',
                        'database_name': 'unknown',
                        'tables_exist': False,
                        'connection_healthy': False,
                        'error_type': 'status_check_failed'
                    }
                },
                'health': {},
                'statistics': {}
            }), 500

    @app.route('/api/database/initialize', methods=['POST'])
    def initialize_database_endpoint():
        """Initialize database tables"""
        try:
            # Check if already initialized
            connection_status = test_database_connection()
            if connection_status.get('details', {}).get('tables_exist'):
                return jsonify({
                    'success': True,
                    'message': 'Database already initialized',
                    'already_initialized': True
                })
            
            # Initialize database
            init_database(app)
            
            return jsonify({
                'success': True,
                'message': 'Database initialized successfully'
            })
            
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            return jsonify({
                'success': False,
                'error': str(e),
                'message': f'Database initialization failed: {str(e)}'
            }), 500

    @app.route('/api/prerequisites')
    @app.route('/api/migrate/prerequisites')
    def check_prerequisites():
        """Check migration prerequisites including database with proper error handling"""
        try:
            # Get all service statuses including database
            service_status = {}
            
            # Test database first
            try:
                service_status['database'] = test_database_connection()
            except Exception as e:
                logger.error(f"Database status check failed: {e}")
                service_status['database'] = {
                    'status': 'error',
                    'message': 'Database service unavailable',
                    'details': {
                        'database_type': 'unknown',
                        'database_name': 'unknown',
                        'tables_exist': False,
                        'connection_healthy': False,
                        'error_type': 'service_check_failed'
                    }
                }
            
            # Test other services with individual error handling
            try:
                service_status['ibm_api_connect'] = IBMAPIConnector().test_connection()
            except Exception as e:
                logger.warning(f"IBM API Connect status check failed: {e}")
                service_status['ibm_api_connect'] = {
                    'status': 'error',
                    'message': 'IBM API Connect service check failed'
                }
            
            try:
                service_status['azure_apim'] = AzureAPIMConnector().test_connection()
            except Exception as e:
                logger.warning(f"Azure APIM status check failed: {e}")
                service_status['azure_apim'] = {
                    'status': 'error',
                    'message': 'Azure APIM service check failed'
                }
            
            try:
                service_status['azure_openai'] = AzureOpenAIConnector().test_connection()
            except Exception as e:
                logger.warning(f"Azure OpenAI status check failed: {e}")
                service_status['azure_openai'] = {
                    'status': 'error',
                    'message': 'Azure OpenAI service check failed'
                }
            
            # Check if all services are available
            all_services_available = all(
                status.get('status') == 'success' 
                for status in service_status.values()
            )
            
            # Generate recommendations
            recommendations = []
            for service_name, status in service_status.items():
                if status.get('status') != 'success':
                    if service_name == 'database':
                        if status.get('details', {}).get('tables_exist') is False:
                            recommendations.append("Database tables need to be initialized")
                        elif status.get('details', {}).get('error_type') == 'database_not_found':
                            recommendations.append("Database does not exist and needs to be created")
                        elif status.get('details', {}).get('error_type') == 'connection_failed':
                            recommendations.append("Database connection failed - check database server")
                        else:
                            recommendations.append(f"Database issue: {status.get('message', 'Unknown error')}")
                    else:
                        recommendations.append(f"{service_name.replace('_', ' ').title()} configuration needs attention")
            
            return jsonify({
                'all_services_available': all_services_available,
                'can_migrate': all_services_available,
                'service_status': service_status,
                'recommendations': recommendations
            })
            
        except Exception as e:
            logger.error(f"Prerequisites check failed: {e}")
            return jsonify({
                'all_services_available': False,
                'can_migrate': False,
                'service_status': {
                    'database': {
                        'status': 'error', 
                        'message': f'Prerequisites check failed: {str(e)}',
                        'details': {
                            'error_type': 'system_error'
                        }
                    }
                },
                'recommendations': ['Check system configuration and database connectivity'],
                'error': f'Prerequisites check failed: {str(e)}'
            }), 500

    # MIGRATION API ENDPOINTS - UPDATED WITH DATABASE INTEGRATION
    @app.route('/api/migrations/stats')
    def get_migration_stats():
        """Get migration statistics for the UI"""
        try:
            stats = {
                'total': MigrationRecord.query.count(),
                'completed': MigrationRecord.query.filter_by(status='completed').count(),
                'failed': MigrationRecord.query.filter_by(status='failed').count(),
                'pending': MigrationRecord.query.filter_by(status='in_progress').count() + 
                          MigrationRecord.query.filter_by(status='pending').count()
            }
            
            return jsonify({
                'success': True,
                'stats': stats
            })
            
        except Exception as e:
            logger.error(f"Failed to get migration stats: {e}")
            return jsonify({
                'success': False,
                'error': str(e),
                'stats': {
                    'total': 0,
                    'completed': 0,
                    'failed': 0,
                    'pending': 0
                }
            }), 500

    @app.route('/api/migrations/<migration_id>')
    def get_migration_details(migration_id):
        """Get detailed information about a specific migration"""
        try:
            migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
            
            if not migration:
                return jsonify({
                    'success': False,
                    'error': 'Migration not found'
                }), 404
            
            # Get related logs
            logs = MigrationLog.query.filter_by(migration_id=migration_id).order_by(MigrationLog.timestamp.asc()).all()
            
            migration_data = migration.to_dict()
            migration_data['logs'] = [log.to_dict() for log in logs]
            
            return jsonify(migration_data)
            
        except Exception as e:
            logger.error(f"Failed to get migration details: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/api/migrations/<migration_id>/rollback', methods=['POST'])
    def rollback_migration(migration_id):
        """Rollback a migration"""
        try:
            migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
            if not migration:
                return jsonify({'status': 'error', 'message': 'Migration not found'}), 404
            
            # TODO: Implement actual rollback logic with Azure APIM
            # For now, just update the status
            migration.status = 'rolled_back'
            migration.updated_at = datetime.now()
            db.session.commit()
            
            return jsonify({'status': 'success', 'message': 'Migration rolled back successfully'})
            
        except Exception as e:
            logger.error(f"Failed to rollback migration: {e}")
            return jsonify({'status': 'error', 'message': str(e)}), 500

    @app.route('/api/migrations/<migration_id>', methods=['DELETE'])
    def delete_migration(migration_id):
        """Delete a migration record"""
        try:
            migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
            if not migration:
                return jsonify({'status': 'error', 'message': 'Migration not found'}), 404
            
            # Delete related logs first
            MigrationLog.query.filter_by(migration_id=migration_id).delete()
            
            # Delete migration record
            db.session.delete(migration)
            db.session.commit()
            
            return jsonify({'status': 'success', 'message': 'Migration deleted successfully'})
            
        except Exception as e:
            logger.error(f"Failed to delete migration: {e}")
            db.session.rollback()
            return jsonify({'status': 'error', 'message': str(e)}), 500

    @app.route('/api/migrations/<migration_id>/download')
    def download_migration_result(migration_id):
        """Download migration result file"""
        try:
            migration = MigrationRecord.query.filter_by(migration_id=migration_id).first()
            if not migration:
                return jsonify({'error': 'Migration not found'}), 404
            
            if migration.status != 'completed':
                return jsonify({'error': 'Migration not completed'}), 400
            
            # TODO: Implement actual file download logic
            # For now, return a placeholder
            return jsonify({'message': 'Download functionality will be implemented'}), 501
            
        except Exception as e:
            logger.error(f"Failed to download migration result: {e}")
            return jsonify({'error': str(e)}), 500

    @app.route('/api/migrations/export')
    def export_migrations():
        """Export migration history as CSV"""
        try:
            import csv
            import io
            
            # Get all migrations
            migrations = MigrationRecord.query.order_by(MigrationRecord.created_at.desc()).all()
            
            # Create CSV content
            output = io.StringIO()
            writer = csv.writer(output)
            
            # Write header
            writer.writerow([
                'Migration ID', 'API Name', 'Status', 'Source Platform', 'Target Platform',
                'Completion Time', 'Created At', 'Azure API ID', 'Error Message'
            ])
            
            # Write data
            for migration in migrations:
                writer.writerow([
                    migration.migration_id,
                    migration.api_name or '',
                    migration.status,
                    migration.source_platform,
                    migration.target_platform,
                    migration.completion_time or '',
                    migration.created_at.isoformat() if migration.created_at else '',
                    migration.azure_api_id or '',
                    migration.error_message or ''
                ])
            
            # Create response
            output.seek(0)
            return send_file(
                io.BytesIO(output.getvalue().encode('utf-8')),
                mimetype='text/csv',
                as_attachment=True,
                download_name=f'migration_history_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
            )
            
        except Exception as e:
            logger.error(f"Failed to export migrations: {e}")
            return jsonify({'error': str(e)}), 500

    @app.route('/api/upload', methods=['POST'])
    def upload_file():
        """Handle file upload with enhanced validation"""
        try:
            if 'file' not in request.files:
                return jsonify({'error': 'No file provided'}), 400
            
            file = request.files['file']
            if file.filename == '':
                return jsonify({'error': 'No file selected'}), 400
            
            # Save uploaded file using enhanced handler
            save_result = file_handler.save_uploaded_file(file, prefix='upload')
            
            if not save_result['success']:
                return jsonify({'error': save_result['error']}), 400
            
            # Read and parse file content
            content_result = file_handler.read_file_content(save_result['file_path'])
            
            if not content_result['success']:
                # Clean up failed file
                file_handler.delete_file(save_result['filename'], 'uploaded')
                return jsonify({'error': content_result['error']}), 400
            
            # Extract API information
            if content_result['parsed_content']:
                api_info = extract_api_info(content_result['parsed_content'])
            else:
                api_info = {}
            
            return jsonify({
                'success': True,
                'file_info': save_result,
                'content_info': {
                    'type': content_result['content_type'],
                    'size': content_result['file_size']
                },
                'api_info': api_info,
                'message': 'File uploaded successfully'
            })
            
        except Exception as e:
            logger.error(f"File upload failed: {e}")
            return jsonify({'error': f'Upload failed: {str(e)}'}), 500

    @app.route('/api/convert', methods=['POST'])
    def convert_api():
        """Convert OpenAPI specification with enhanced file storage and database tracking"""
        migration_record = None
        api_spec_record = None
        
        try:
            data = request.get_json()
            if not data:
                logger.error("No JSON data provided in conversion request")
                return jsonify({'error': 'No JSON data provided'}), 400
            
            logger.info(f"=== CONVERSION REQUEST RECEIVED ===")
            logger.info(f"Request data keys: {list(data.keys())}")
            logger.info(f"spec_content length: {len(data.get('spec_content', ''))}")
            
            # Validate request data
            try:
                request_data = ConversionRequestSchema(**data)
                logger.info("Request data validation successful")
            except Exception as e:
                logger.error(f"ConversionRequestSchema validation failed: {str(e)}")
                return jsonify({
                    'error': f'Invalid request data: {str(e)}',
                    'received_fields': list(data.keys()),
                    'expected_fields': ['spec_content', 'source_format (optional)', 'include_debug (optional)']
                }), 400
            
            # Generate migration ID
            migration_id = generate_id()
            logger.info(f"Generated migration ID: {migration_id}")
            
            # Parse the original spec to extract API info
            try:
                import yaml
                import json
                
                spec_content = request_data.spec_content.strip()
                if spec_content.startswith('{'):
                    original_spec = json.loads(spec_content)
                else:
                    original_spec = yaml.safe_load(spec_content)
                    
                api_info = extract_api_info(original_spec)
                logger.info(f"Extracted API info: {api_info}")
                
            except Exception as e:
                logger.warning(f"Failed to parse original spec for info extraction: {e}")
                api_info = {
                    'title': 'Unknown API',
                    'version': '1.0.0',
                    'format': 'unknown'
                }
            
            # CREATE MIGRATION RECORD IN DATABASE (with fallback)
            migration_record_data = {
                'migration_id': migration_id,
                'original_api_id': api_info.get('title', 'unknown').replace(' ', '_'),
                'api_name': api_info.get('title', 'Unknown API'),
                'api_version': api_info.get('version', '1.0.0'),
                'status': 'in_progress',
                'source_platform': 'file_upload',
                'target_platform': 'azure_apim',
                'start_time': datetime.now(),
                'original_filename': f"{api_info.get('title', 'api')}.json",
                'conversion_method': 'pending',
                'ai_conversion_used': False,
                'migration_metadata': {}
            }
            
            migration_record = create_migration_record_safe(migration_record_data)
            if migration_record:
                logger.info(f"Created migration record with ID: {migration_id}")
            else:
                logger.warning(f"Failed to create migration record - continuing without database tracking")
            
            # CREATE API SPECIFICATION RECORD (with fallback)
            try:
                api_spec_record = APISpecification(
                    api_id=f"{api_info.get('title', 'unknown').replace(' ', '_')}_{migration_id[:8]}",
                    name=api_info.get('title', 'Unknown API'),
                    version=api_info.get('version', '1.0.0'),
                    description=api_info.get('description', ''),
                    format=api_info.get('format', 'unknown'),
                    specification=original_spec,
                    source_platform='file_upload',
                    original_filename=f"{api_info.get('title', 'api')}.json",
                    paths_count=api_info.get('paths_count', 0),
                    operations_count=api_info.get('operations_count', 0),
                    definitions_count=api_info.get('definitions_count', 0),
                    is_valid=True
                )
                
                db.session.add(api_spec_record)
                db.session.commit()
                logger.info(f"Created API specification record with ID: {api_spec_record.api_id}")
                
            except Exception as e:
                logger.warning(f"Failed to create API specification record: {e}")
                # Continue without API spec record
            
            # Log the start of conversion (with fallback)
            try:
                if migration_record:
                    log_entry = MigrationLog(
                        migration_id=migration_id,
                        level='INFO',
                        stage='conversion_start',
                        message='Starting OpenAPI conversion process',
                        details={'source_format': request_data.source_format}
                    )
                    db.session.add(log_entry)
                    db.session.commit()
            except Exception as e:
                logger.warning(f"Failed to create log entry: {e}")
            
            # Perform conversion
            conversion_start_time = datetime.now()
            try:
                logger.info("Starting conversion process...")
                
                # Check if conversion service supports include_debug parameter
                import inspect
                convert_sig = inspect.signature(conversion_service.convert_specification)
                supports_debug = 'include_debug' in convert_sig.parameters
                
                if supports_debug:
                    logger.info("ConversionService supports include_debug parameter")
                    conversion_result = conversion_service.convert_specification(
                        request_data.spec_content,
                        request_data.source_format,
                        include_debug=request_data.include_debug
                    )
                else:
                    logger.info("ConversionService does not support include_debug, calling without it")
                    conversion_result = conversion_service.convert_specification(
                        request_data.spec_content,
                        request_data.source_format
                    )
                    
                    # Add placeholder debug info if requested but not supported
                    if request_data.include_debug:
                        logger.info("Adding placeholder debug information")
                        conversion_result['raw_openai_response'] = "Debug info not available - ConversionService needs to be updated"
                        conversion_result['cleaned_json'] = "Debug info not available - ConversionService needs to be updated"
                        conversion_result['cleaning_issues'] = "ConversionService does not support debug mode yet"
                
                conversion_end_time = datetime.now()
                conversion_time = (conversion_end_time - conversion_start_time).total_seconds()
                
                logger.info(f"Conversion completed with status: {conversion_result.get('status')}")
                
                # UPDATE MIGRATION RECORD WITH CONVERSION RESULTS (with fallback)
                if migration_record:
                    update_data = {}
                    if conversion_result.get('status') == 'success':
                        update_data.update({
                            'status': 'completed',
                            'end_time': conversion_end_time,
                            'completion_time': conversion_time,
                            'conversion_method': 'ai_powered' if conversion_result.get('ai_conversion_used') else 'programmatic',
                            'ai_conversion_used': conversion_result.get('ai_conversion_used', False),
                            'conversion_notes': f"Conversion completed successfully in {conversion_time:.2f}s",
                            'migration_metadata': {
                                'conversion_time': conversion_time,
                                'ai_used': conversion_result.get('ai_conversion_used', False),
                                'conversion_metadata': conversion_result.get('conversion_metadata', {}),
                                'validation_results': conversion_result.get('validation', {})
                            }
                        })
                    else:
                        update_data.update({
                            'status': 'failed',
                            'end_time': conversion_end_time,
                            'error_message': conversion_result.get('message', 'Conversion failed')
                        })
                    
                    if update_migration_record_safe(migration_record, **update_data):
                        logger.info(f"Updated migration record status: {migration_record.status}")
                        
                        # Log conversion completion
                        try:
                            log_entry = MigrationLog(
                                migration_id=migration_id,
                                level='INFO' if conversion_result.get('status') == 'success' else 'ERROR',
                                stage='conversion_complete',
                                message=f"Conversion {conversion_result.get('status')} in {conversion_time:.2f}s",
                                details={
                                    'conversion_time': conversion_time,
                                    'ai_used': conversion_result.get('ai_conversion_used', False),
                                    'status': conversion_result.get('status')
                                }
                            )
                            db.session.add(log_entry)
                            db.session.commit()
                        except Exception as e:
                            logger.warning(f"Failed to create completion log: {e}")
                
                # SAVE CONVERTED FILE if conversion was successful
                if conversion_result.get('status') == 'success' and 'converted_spec' in conversion_result:
                    try:
                        # Generate filename based on API info or timestamp
                        api_info_from_converted = conversion_result.get('converted_spec', {}).get('info', {})
                        api_title = api_info_from_converted.get('title', api_info.get('title', 'converted_api'))
                        original_filename = f"{api_title.replace(' ', '_')}_converted_{migration_id[:8]}.json"
                        
                        # Save converted file
                        save_result = file_handler.save_converted_file(
                            conversion_result['converted_spec'],
                            original_filename,
                            conversion_result.get('conversion_metadata')
                        )
                        
                        if save_result['success']:
                            # Add file info to conversion result
                            conversion_result['converted_file'] = {
                                'filename': save_result['filename'],
                                'download_url': save_result['download_url'],
                                'file_size': save_result['file_size'],
                                'saved_at': save_result['conversion_time']
                            }
                            logger.info(f"Converted file saved: {save_result['filename']}")
                            
                            # Update migration record with file info (with fallback)
                            if migration_record:
                                update_migration_record_safe(migration_record, converted_filename=save_result['filename'])
                                
                        else:
                            logger.warning(f"Failed to save converted file: {save_result.get('error')}")
                            
                    except Exception as save_error:
                        logger.warning(f"Failed to save converted file: {save_error}")
                        # Don't fail the conversion if file saving fails
                
                # Add migration_id to response
                conversion_result['migration_id'] = migration_id
                
                return jsonify(conversion_result)
                
            except Exception as conversion_error:
                logger.error(f"Conversion process failed: {str(conversion_error)}")
                logger.error(f"Conversion error traceback: {traceback.format_exc()}")
                
                # Update migration record with error (with fallback)
                if migration_record:
                    update_migration_record_safe(migration_record, 
                        status='failed',
                        end_time=datetime.now(),
                        error_message=str(conversion_error)
                    )
                    
                    try:
                        log_entry = MigrationLog(
                            migration_id=migration_id,
                            level='ERROR',
                            stage='conversion_error',
                            message=f"Conversion failed: {str(conversion_error)}",
                            details={'error_type': type(conversion_error).__name__}
                        )
                        db.session.add(log_entry)
                        db.session.commit()
                    except Exception as e:
                        logger.warning(f"Failed to log conversion error: {e}")
                
                return jsonify({
                    'status': 'error',
                    'message': f'Conversion failed: {str(conversion_error)}',
                    'error_type': type(conversion_error).__name__,
                    'migration_id': migration_id
                }), 500
            
        except Exception as e:
            logger.error(f"Conversion endpoint failed: {e}")
            logger.error(f"Full traceback: {traceback.format_exc()}")
            
            # Clean up any created records on error (with fallback)
            if migration_record:
                update_migration_record_safe(migration_record, 
                    status='failed',
                    error_message=str(e)
                )
            
            return jsonify({
                'status': 'error',
                'message': f'Conversion failed: {str(e)}'
            }), 500

    @app.route('/api/convert/preview', methods=['POST'])
    def conversion_preview():
        """Get conversion preview without performing full conversion"""
        try:
            data = request.get_json()
            if not data or 'spec_content' not in data:
                return jsonify({'error': 'No specification content provided'}), 400
            
            # Get conversion preview
            preview_result = conversion_service.get_conversion_preview(data['spec_content'])
            
            return jsonify(preview_result)
            
        except Exception as e:
            logger.error(f"Conversion preview failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Preview failed: {str(e)}'
            }), 500

    @app.route('/api/migrate', methods=['POST'])
    def migrate_api():
        """Migrate single API"""
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400
            
            # Validate request data
            try:
                request_data = MigrationRequestSchema(**data)
            except Exception as e:
                return jsonify({'error': f'Invalid request data: {str(e)}'}), 400
            
            # Handle single API migration
            api_id = request_data.api_ids[0] if isinstance(request_data.api_ids, list) else request_data.api_ids
            
            migration_result = migration_service.migrate_single_api(
                api_id,
                request_data.org_name,
                request_data.options
            )
            
            return jsonify(migration_result)
            
        except Exception as e:
            logger.error(f"Migration failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Migration failed: {str(e)}'
            }), 500

    @app.route('/api/migrate/batch', methods=['POST'])
    def migrate_batch():
        """Migrate multiple APIs"""
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400
            
            # Validate request data
            try:
                request_data = BatchMigrationRequestSchema(**data)
            except Exception as e:
                return jsonify({'error': f'Invalid request data: {str(e)}'}), 400
            
            # Perform batch migration based on type
            if request_data.migration_type == 'apis':
                migration_result = migration_service.migrate_multiple_apis(
                    request_data.api_ids,
                    request_data.org_name,
                    request_data.options
                )
            elif request_data.migration_type == 'catalog':
                migration_result = migration_service.migrate_by_catalog(
                    request_data.org_name,
                    request_data.catalog_name,
                    request_data.options
                )
            else:
                return jsonify({'error': 'Invalid migration type'}), 400
            
            return jsonify(migration_result)
            
        except Exception as e:
            logger.error(f"Batch migration failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Batch migration failed: {str(e)}'
            }), 500

    # DEPLOYMENT ROUTES
    @app.route('/api/deploy', methods=['POST'])
    def deploy_to_azure_apim():
        """Deploy converted OpenAPI spec directly to Azure APIM"""
        try:
            logger.info("=== DEPLOY ROUTE CALLED ===")
            
            data = request.get_json()
            if not data:
                logger.error("No JSON data provided in request")
                return jsonify({'error': 'No JSON data provided'}), 400
            
            logger.info(f"Request data keys: {list(data.keys())}")
            
            converted_spec = data.get('converted_spec')
            original_api_id = data.get('original_api_id', 'migrated-api')
            options = data.get('options', {})
            
            if not converted_spec:
                logger.error("No converted specification provided")
                return jsonify({
                    'status': 'error',
                    'message': 'No converted specification provided'
                }), 400
            
            if not isinstance(converted_spec, dict):
                logger.error("Converted spec is not a dictionary")
                return jsonify({
                    'status': 'error',
                    'message': 'Invalid specification format'
                }), 400
            
            required_fields = ['openapi', 'info', 'paths']
            missing_fields = [field for field in required_fields if field not in converted_spec]
            if missing_fields:
                logger.error(f"Missing required OpenAPI fields: {missing_fields}")
                return jsonify({
                    'status': 'error',
                    'message': f'Invalid OpenAPI specification: missing {", ".join(missing_fields)}'
                }), 400
            
            azure_apim_connector = AzureAPIMConnector()
            if not azure_apim_connector.is_available:
                logger.error("Azure APIM connector not available")
                return jsonify({
                    'status': 'error',
                    'message': 'Azure APIM service not available. Please check configuration.'
                }), 503
            
            api_id = options.get('api_id') or _generate_api_id_from_spec(converted_spec, original_api_id)
            logger.info(f"Using API ID: {api_id}")
            
            validation_result = azure_apim_connector.validate_openapi_for_apim(converted_spec.copy())
            if validation_result['issues']:
                logger.warning(f"OpenAPI validation issues: {validation_result['issues']}")
                converted_spec = validation_result['spec']
            
            logger.info("Starting Azure APIM deployment...")
            deployment_result = azure_apim_connector.create_api_from_openapi(converted_spec, api_id)
            
            if deployment_result.get('status') != 'success':
                logger.error(f"Azure APIM deployment failed: {deployment_result.get('message')}")
                return jsonify({
                    'status': 'error',
                    'message': f"Deployment failed: {deployment_result.get('message', 'Unknown error')}"
                }), 400
            
            if options.get('create_product'):
                logger.info("Creating Azure APIM product...")
                product_name = options.get('product_name') or f"Product for {api_id}"
                product_result = azure_apim_connector.create_product(
                    product_name, [api_id], options.get('product_description', '')
                )
                deployment_result['product'] = product_result
            
            deployment_result['management_url'] = azure_apim_connector.get_api_management_url(api_id)
            deployment_result['developer_portal_url'] = azure_apim_connector.get_developer_portal_url()
            
            logger.info("=== DEPLOYMENT SUCCESSFUL ===")
            return jsonify(deployment_result), 200
            
        except Exception as e:
            error_msg = f"Deployment failed: {str(e)}"
            logger.error(f"=== DEPLOYMENT ERROR ===")
            logger.error(error_msg)
            logger.error(traceback.format_exc())
            
            return jsonify({
                'status': 'error',
                'message': error_msg,
                'error_type': type(e).__name__
            }), 500

    @app.route('/api/test-deploy', methods=['POST'])
    def test_deployment():
        """Test deployment with a simple API"""
        try:
            azure_apim_connector = AzureAPIMConnector()
            if not azure_apim_connector.is_available:
                return jsonify({
                    'status': 'error',
                    'message': 'Azure APIM service not available'
                }), 503
            
            test_connection = azure_apim_connector.test_connection()
            if test_connection['status'] != 'success':
                return jsonify({
                    'status': 'error',
                    'message': f"Azure APIM connection failed: {test_connection['message']}"
                }), 503
            
            test_spec = {
                "openapi": "3.0.0",
                "info": {
                    "title": "UI Test API",
                    "version": "1.0.0",
                    "description": "Testing deployment from UI"
                },
                "servers": [{"url": "https://api.example.com"}],
                "paths": {
                    "/test": {
                        "get": {
                            "summary": "Test endpoint",
                            "responses": {
                                "200": {
                                    "description": "Success",
                                    "content": {
                                        "application/json": {
                                            "schema": {
                                                "type": "object",
                                                "properties": {
                                                    "message": {"type": "string"}
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            result = azure_apim_connector.create_api_from_openapi(test_spec, 'ui-test-api')
            return jsonify(result)
            
        except Exception as e:
            error_msg = f"Test deployment failed: {str(e)}"
            logger.error(error_msg)
            return jsonify({
                'status': 'error',
                'message': error_msg
            }), 500

    @app.route('/api/statistics')
    def get_statistics():
        """Get application statistics including file stats"""
        try:
            db_stats = get_database_statistics_safe()
            storage_stats = file_handler.get_storage_stats()
            uptime_seconds = (datetime.now() - app_start_time).total_seconds()
            
            # Get migration stats with fallback
            try:
                migration_stats = migration_service.get_migration_statistics()
            except Exception as e:
                logger.warning(f"Failed to get migration service statistics: {e}")
                migration_stats = db_stats.get('migrations', {})
            
            return jsonify({
                'migrations': migration_stats,
                'database': db_stats,
                'storage': storage_stats.get('totals', {}),
                'storage_by_folder': storage_stats.get('folders', {}),
                'application': {
                    'version': '1.0.0',
                    'uptime_seconds': int(uptime_seconds),
                    'start_time': app_start_time.isoformat()
                }
            })
        except Exception as e:
            logger.error(f"Failed to get statistics: {e}")
            return jsonify({'error': f'Failed to get statistics: {str(e)}'}), 500

    # FILE MANAGEMENT ROUTES
    @app.route('/api/files')
    def list_files():
        """List files with optional filtering"""
        try:
            folder_type = request.args.get('folder_type', 'all')
            files_result = file_handler.list_files(folder_type)
            return jsonify(files_result)
        except Exception as e:
            logger.error(f"Failed to list files: {e}")
            return jsonify({'error': f'Failed to list files: {str(e)}'}), 500

    @app.route('/api/files/converted')
    def list_converted_files():
        """List converted files"""
        try:
            files_result = file_handler.list_files(folder_type='converted')
            return jsonify(files_result)
        except Exception as e:
            logger.error(f"Failed to list converted files: {e}")
            return jsonify({'error': f'Failed to list files: {str(e)}'}), 500

    @app.route('/api/files/<filename>')
    def get_file_info(filename):
        """Get uploaded file information"""
        try:
            file_info = file_handler.get_file_info(filename, folder_type='uploaded')
            return jsonify(file_info)
        except Exception as e:
            logger.error(f"Failed to get file info: {e}")
            return jsonify({'error': f'Failed to get file info: {str(e)}'}), 500

    @app.route('/api/files/converted/<filename>')
    def get_converted_file_info(filename):
        """Get converted file information"""
        try:
            file_info = file_handler.get_file_info(filename, folder_type='converted')
            return jsonify(file_info)
        except Exception as e:
            logger.error(f"Failed to get converted file info: {e}")
            return jsonify({'error': f'Failed to get file info: {str(e)}'}), 500

    @app.route('/api/files/<filename>/download')
    def download_file(filename):
        """Download uploaded file"""
        try:
            file_path = os.path.join(file_handler.upload_folder, filename)
            if not os.path.exists(file_path):
                return jsonify({'error': 'File not found'}), 404
            return send_file(file_path, as_attachment=True, download_name=filename)
        except Exception as e:
            logger.error(f"Failed to download file: {e}")
            return jsonify({'error': f'Failed to download file: {str(e)}'}), 500

    @app.route('/api/files/converted/<filename>/download')
    def download_converted_file(filename):
        """Download converted file"""
        try:
            file_path = os.path.join(file_handler.converted_folder, filename)
            if not os.path.exists(file_path):
                return jsonify({'error': 'File not found'}), 404
            return send_file(file_path, as_attachment=True, download_name=filename)
        except Exception as e:
            logger.error(f"Failed to download converted file: {e}")
            return jsonify({'error': f'Failed to download file: {str(e)}'}), 500

    @app.route('/api/files/<folder_type>/<filename>/delete', methods=['DELETE'])
    def delete_file_route(folder_type, filename):
        """Delete file"""
        try:
            if folder_type not in ['uploaded', 'converted']:
                return jsonify({'error': 'Invalid folder type'}), 400
            
            result = file_handler.delete_file(filename, folder_type)
            return jsonify(result) if result['success'] else (jsonify(result), 404)
        except Exception as e:
            logger.error(f"Failed to delete file: {e}")
            return jsonify({'error': f'Failed to delete file: {str(e)}'}), 500

    # STORAGE MANAGEMENT ROUTES
    @app.route('/api/storage/stats')
    def get_storage_stats():
        """Get storage statistics"""
        try:
            stats = file_handler.get_storage_stats()
            return jsonify(stats)
        except Exception as e:
            logger.error(f"Failed to get storage stats: {e}")
            return jsonify({'error': f'Failed to get storage stats: {str(e)}'}), 500

    @app.route('/api/storage/cleanup', methods=['POST'])
    def cleanup_storage():
        """Clean up old files"""
        try:
            data = request.get_json() or {}
            days_old = data.get('days_old', 7)
            result = file_handler.cleanup_old_files(days_old)
            return jsonify(result)
        except Exception as e:
            logger.error(f"Failed to cleanup storage: {e}")
            return jsonify({'error': f'Failed to cleanup storage: {str(e)}'}), 500

    @app.route('/api/debug/openai-last-response')
    def get_last_openai_response():
        from connectors import AzureOpenAIConnector
        connector = AzureOpenAIConnector()
        return jsonify(connector.get_debug_info())

    # UTILITY FUNCTIONS
    def _generate_api_id_from_spec(spec: dict, fallback: str) -> str:
        """Generate API ID from OpenAPI spec or use fallback"""
        try:
            info = spec.get('info', {})
            title = info.get('title', fallback)
            
            import re
            api_id = re.sub(r'[^a-zA-Z0-9\-_]', '-', title.lower())
            api_id = re.sub(r'-+', '-', api_id)
            api_id = api_id.strip('-_')
            
            if not api_id:
                api_id = fallback
            
            import time
            timestamp = str(int(time.time()))[-6:]
            api_id = f"{api_id}-{timestamp}"
            
            return api_id[:50]
        except Exception:
            return fallback

    def extract_api_info(spec: dict) -> dict:
        """Extract API information from OpenAPI specification"""
        try:
            info = spec.get('info', {})
            return {
                'title': info.get('title', 'Unknown API'),
                'version': info.get('version', '1.0.0'),
                'description': info.get('description', ''),
                'format': spec.get('swagger', spec.get('openapi', 'Unknown')),
                'paths_count': len(spec.get('paths', {})),
                'definitions_count': len(spec.get('definitions', spec.get('components', {}).get('schemas', {}))),
                'operations_count': sum(
                    len([op for op in path_item.values() if isinstance(op, dict) and op.get('responses')])
                    for path_item in spec.get('paths', {}).values()
                    if isinstance(path_item, dict)
                )
            }
        except Exception as e:
            logger.warning(f"Failed to extract API info: {e}")
            return {
                'title': 'Unknown API',
                'version': '1.0.0',
                'description': '',
                'format': 'Unknown',
                'paths_count': 0,
                'definitions_count': 0,
                'operations_count': 0
            }

    def format_file_size(bytes_size):
        """Format file size in human readable format"""
        if bytes_size == 0:
            return '0 B'
        k = 1024
        sizes = ['B', 'KB', 'MB', 'GB']
        i = int(((bytes_size.bit_length() - 1) / 10)) if bytes_size > 0 else 0
        return f"{bytes_size / (k ** i):.1f} {sizes[min(i, len(sizes) - 1)]}"

    # TEMPLATE FILTERS
    @app.template_filter('datetime')
    def datetime_filter(value, format='%Y-%m-%d %H:%M:%S'):
        """Format datetime for templates"""
        if isinstance(value, str):
            try:
                value = datetime.fromisoformat(value.replace('Z', '+00:00'))
            except:
                return value
        
        if isinstance(value, datetime):
            return value.strftime(format)
        
        return value

    @app.template_filter('filesize')
    def filesize_filter(value):
        """Format file size for templates"""
        return format_file_size(value)

    # TEMPLATE CONTEXT PROCESSORS
    @app.context_processor
    def inject_global_vars():
        """Inject global variables into templates"""
        return {
            'app_version': '1.0.0',
            'current_year': datetime.now().year
        }

    return app

# Create app instance
app = create_app()

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('logs', exist_ok=True)
    os.makedirs('static/uploads', exist_ok=True)
    
    # Initialize logging
    logger = setup_logger('app')
    
    # Run the application
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    
    logger.info(f"Starting API Migration Tool on port {port}")
    app.run(host='0.0.0.0', port=port, debug=debug)