import psycopg2
import os

try:
    conn = psycopg2.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=os.getenv("DB_PORT", 5432),
        user=os.getenv("DB_USER", "api_user"),
        password=os.getenv("DB_PASSWORD", "Shiva1714"),
        dbname=os.getenv("DB_NAME", "api_migration_db"),
        sslmode=os.getenv("DB_SSLMODE", "disable")
    )
    print("✅ PostgreSQL connection successful!")
    conn.close()
except Exception as e:
    print(f"❌ Connection failed: {e}")
