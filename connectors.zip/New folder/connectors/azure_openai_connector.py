"""
Azure OpenAI Connector - COMPLETE VERSION WITH UNIVERSAL CONVERTER
Handles OpenAPI 2.0 to 3.0 conversion AND OpenAPI 3.0 normalization using Azure OpenAI services
INCLUDES: Universal converter, debug response capture, comprehensive $ref fixing
"""
import json
import logging
import yaml
import re
import os
import time
from typing import Dict, Any, Optional, Tuple
from config import AzureConfig

logger = logging.getLogger(__name__)

class AzureOpenAIConnector:
    """Azure OpenAI service connector for API specification conversion"""
    
    def __init__(self):
        """Initialize Azure OpenAI client"""
        self.config = AzureConfig
        self._client = None
        self.is_initialized = False
        self._initialization_error = None
        self._auth_method = None
        self._last_openai_response = {}
        
        try:
            self._initialize_client()
        except Exception as e:
            logger.warning(f"Azure OpenAI connector initialization failed: {e}")
            self._initialization_error = str(e)
    
    def _initialize_client(self) -> bool:
        """Initialize Azure OpenAI client with configuration validation"""
        try:
            missing_config = self.config.validate_openai_config()
            if missing_config:
                logger.warning(f"Missing Azure OpenAI configuration: {missing_config}")
                self._initialization_error = f"Missing configuration: {missing_config}"
                return False
            
            try:
                from openai import AzureOpenAI
                
                if hasattr(self.config, 'OPENAI_API_KEY') and self.config.OPENAI_API_KEY:
                    self._client = self._init_with_api_key(AzureOpenAI)
                    self._auth_method = "api_key"
                else:
                    self._client = self._init_with_entra_id(AzureOpenAI)
                    self._auth_method = "entra_id"
                
                if self._client:
                    self.is_initialized = True
                    logger.info(f"Azure OpenAI client initialized successfully using {self._auth_method}")
                    return True
                else:
                    return False
                
            except ImportError as e:
                logger.warning(f"OpenAI library not properly installed: {e}")
                self._initialization_error = f"OpenAI library import failed: {e}"
                return False
            
        except Exception as e:
            logger.warning(f"Failed to initialize Azure OpenAI client: {e}")
            self._client = None
            self.is_initialized = False
            self._initialization_error = str(e)
            return False
    
    def _init_with_api_key(self, AzureOpenAI) -> Optional[object]:
        """Initialize client with API key authentication"""
        try:
            return AzureOpenAI(
                azure_endpoint=self.config.OPENAI_ENDPOINT,
                api_key=self.config.OPENAI_API_KEY,
                api_version=self.config.OPENAI_VERSION,
                timeout=30.0,
                max_retries=2
            )
        except Exception as e:
            logger.warning(f"API key authentication failed: {e}")
            self._initialization_error = f"API key authentication failed: {e}"
            return None
    
    def _init_with_entra_id(self, AzureOpenAI) -> Optional[object]:
        """Initialize client with Entra ID authentication"""
        try:
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider
            
            token_provider = get_bearer_token_provider(
                DefaultAzureCredential(), 
                "https://cognitiveservices.azure.com/.default"
            )
            
            return AzureOpenAI(
                azure_endpoint=self.config.OPENAI_ENDPOINT,
                azure_ad_token_provider=token_provider,
                api_version=self.config.OPENAI_VERSION,
                timeout=30.0,
                max_retries=2
            )
        except ImportError as e:
            logger.warning(f"Azure Identity library not available: {e}")
            self._initialization_error = f"Azure Identity library not available: {e}"
            return None
        except Exception as e:
            logger.warning(f"Entra ID authentication failed: {e}")
            self._initialization_error = f"Entra ID authentication failed: {e}"
            return None
    
    @property
    def is_available(self) -> bool:
        """Check if Azure OpenAI service is available"""
        return self._client is not None and self.is_initialized
    
    def get_debug_info(self) -> Dict[str, Any]:
        """Get the last OpenAI response debug information"""
        return self._last_openai_response.copy()
    
    def parse_api_spec(self, content: str) -> Tuple[Dict[str, Any], str]:
        """Parse API specification from JSON or YAML"""
        try:
            spec = json.loads(content)
            return spec, 'json'
        except json.JSONDecodeError:
            try:
                spec = yaml.safe_load(content)
                return spec, 'yaml'
            except yaml.YAMLError as e:
                raise ValueError(f"Invalid JSON or YAML format: {e}")
    
    def convert_openapi_2_to_3(self, spec_content: str, include_debug: bool = False) -> Dict[str, Any]:
        """
        UNIVERSAL CONVERTER: Handles both OpenAPI 2.0 and 3.0 inputs
        Produces consistent Azure APIM-compatible OpenAPI 3.0 output
        """
        return self.universal_openapi_converter(spec_content, include_debug)
    
    def universal_openapi_converter(self, spec_content: str, include_debug: bool = False) -> Dict[str, Any]:
        """
        Universal converter: Takes ANY OpenAPI 2.0 or 3.0 input and produces 
        Azure APIM-compatible OpenAPI 3.0 output
        """
        self._last_openai_response = {}
        
        try:
            # Step 1: Parse input (JSON/YAML agnostic)
            original_spec, format_type = self.parse_api_spec(spec_content)
            
            # Step 2: Detect version and apply appropriate conversion
            if self._is_openapi_2(original_spec):
                logger.info("Input: OpenAPI 2.0 - Converting to 3.0")
                if self.is_available:
                    # Use AI for 2.0 -> 3.0 conversion
                    converted_spec = self._ai_convert_spec(original_spec, include_debug)
                else:
                    # Use fallback for 2.0 -> 3.0 conversion
                    converted_spec = self._convert_2_to_3(original_spec)
            elif self._is_openapi_3(original_spec):
                logger.info("Input: OpenAPI 3.0 - Normalizing for Azure APIM")
                converted_spec = self._normalize_3_0(original_spec)
            else:
                raise ValueError("Input is neither valid OpenAPI 2.0 nor 3.0")
            
            # Step 3: Apply Azure APIM compatibility fixes (universal)
            converted_spec = self._ensure_azure_apim_compatibility(converted_spec)
            
            # Step 4: Final validation
            if not self._is_valid_openapi_3_for_azure(converted_spec):
                logger.warning("Spec failed Azure validation, applying additional fixes")
                converted_spec = self._apply_emergency_fixes(converted_spec, original_spec)
            
            logger.info("✅ Successfully produced Azure APIM-compatible OpenAPI 3.0")
            
            # Prepare return data
            result = {
                'status': 'success',
                'converted_spec': converted_spec,
                'source_format': format_type,
                'target_format': 'openapi_3.0',
                'ai_conversion_used': self.is_available and self._is_openapi_2(original_spec),
                'conversion_metadata': self._extract_conversion_metadata(original_spec, converted_spec)
            }
            
            # Add debug info if requested
            if include_debug and self._last_openai_response:
                result.update({
                    'raw_openai_response': self._last_openai_response.get('raw'),
                    'cleaned_json': self._last_openai_response.get('cleaned'),
                    'cleaning_issues': self._last_openai_response.get('issues'),
                })
            
            return result
            
        except Exception as e:
            logger.error(f"Universal conversion failed: {e}")
            return {
                'status': 'error',
                'message': f'Universal conversion failed: {str(e)}'
            }
    
    def _convert_2_to_3(self, spec_2: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OpenAPI 2.0 to proper 3.0 (fallback method)"""
        spec_3 = {
            "openapi": "3.0.0",
            "info": spec_2.get("info", {"title": "API", "version": "1.0.0"}),
            "servers": self._create_servers_from_v2(spec_2),
            "paths": {},
            "components": {
                "schemas": spec_2.get("definitions", {}),
                "securitySchemes": self._convert_security_definitions(spec_2.get("securityDefinitions", {}))
            }
        }
        
        # Convert paths with proper 3.0 structure
        for path, path_item in spec_2.get("paths", {}).items():
            spec_3["paths"][path] = self._convert_path_item_2_to_3(path_item)
        
        # Add security if present
        if "security" in spec_2:
            spec_3["security"] = spec_2["security"]
        
        return spec_3
    
    def _convert_path_item_2_to_3(self, path_item: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OpenAPI 2.0 path item to 3.0 format"""
        converted_path = {}
        
        for method, operation in path_item.items():
            if method.lower() in ['get', 'post', 'put', 'patch', 'delete', 'head', 'options']:
                converted_path[method] = self._convert_operation_2_to_3(operation)
            else:
                converted_path[method] = operation
        
        return converted_path
    
    def _convert_operation_2_to_3(self, operation: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OpenAPI 2.0 operation to 3.0 format"""
        if not isinstance(operation, dict):
            return operation
        
        converted_op = {}
        
        # Copy basic fields
        for field in ['summary', 'description', 'operationId', 'tags', 'deprecated', 'security']:
            if field in operation:
                converted_op[field] = operation[field]
        
        # Convert parameters
        if 'parameters' in operation:
            body_params = []
            other_params = []
            
            for param in operation['parameters']:
                if isinstance(param, dict):
                    if param.get('in') == 'body':
                        body_params.append(param)
                    else:
                        converted_param = self._convert_parameter_2_to_3(param)
                        if converted_param:
                            other_params.append(converted_param)
            
            # Add non-body parameters
            if other_params:
                converted_op['parameters'] = other_params
            
            # Convert body parameters to requestBody
            if body_params:
                body_param = body_params[0]
                converted_op['requestBody'] = {
                    'required': body_param.get('required', True),
                    'content': {
                        'application/json': {
                            'schema': body_param.get('schema', {})
                        }
                    }
                }
        
        # Convert responses
        if 'responses' in operation:
            converted_responses = {}
            for status, response in operation['responses'].items():
                converted_responses[status] = self._convert_response_2_to_3(response)
            converted_op['responses'] = converted_responses
        
        return converted_op
    
    def _convert_parameter_2_to_3(self, param: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Convert parameter to OpenAPI 3.0 format"""
        if not isinstance(param, dict) or 'name' not in param or 'in' not in param:
            return None
        
        converted_param = {
            'name': param['name'],
            'in': param['in'],
            'required': param.get('required', param.get('in') == 'path'),
            'schema': {}
        }
        
        if 'description' in param:
            converted_param['description'] = param['description']
        
        # Convert type information to schema
        schema_fields = ['type', 'format', 'enum', 'minimum', 'maximum', 'pattern', 'default', 'items']
        for field in schema_fields:
            if field in param:
                converted_param['schema'][field] = param[field]
        
        if not converted_param['schema']:
            converted_param['schema'] = {'type': 'string'}
        
        return converted_param
    
    def _convert_response_2_to_3(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """Convert response to OpenAPI 3.0 format"""
        if not isinstance(response, dict):
            return response
        
        converted_response = {}
        
        if 'description' in response:
            converted_response['description'] = response['description']
        else:
            converted_response['description'] = 'Response'
        
        # Convert schema to content
        if 'schema' in response:
            converted_response['content'] = {
                'application/json': {
                    'schema': response['schema']
                }
            }
        
        if 'headers' in response:
            converted_response['headers'] = response['headers']
        
        return converted_response
    
    def _normalize_3_0(self, spec_3: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize existing OpenAPI 3.0 to ensure Azure APIM compatibility"""
        normalized = spec_3.copy()
        
        # Remove any 2.0 remnants that might exist
        openapi_2_fields = ['swagger', 'host', 'basePath', 'schemes', 'consumes', 'produces', 'definitions', 'securityDefinitions']
        for field in openapi_2_fields:
            if field in normalized:
                if field == 'definitions' and 'components' in normalized:
                    normalized['components']['schemas'] = normalized['components'].get('schemas', {})
                    normalized['components']['schemas'].update(normalized[field])
                elif field == 'securityDefinitions' and 'components' in normalized:
                    normalized['components']['securitySchemes'] = normalized['components'].get('securitySchemes', {})
                    normalized['components']['securitySchemes'].update(self._convert_security_definitions(normalized[field]))
                del normalized[field]
        
        return normalized
    
    def _ensure_azure_apim_compatibility(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """Universal Azure APIM compatibility fixes"""
        # Fix all $ref paths
        spec = self._fix_all_reference_paths(spec)
        
        # Ensure required structure
        if 'components' not in spec:
            spec['components'] = {}
        if 'schemas' not in spec.get('components', {}):
            spec['components']['schemas'] = {}
        
        # Fix request/response structure
        spec = self._fix_request_response_structure(spec)
        
        # Ensure servers exist
        if 'servers' not in spec or not spec['servers']:
            spec['servers'] = [{"url": "https://api.example.com", "description": "Default server"}]
        
        # Ensure proper OpenAPI version
        spec['openapi'] = '3.0.0'
        
        return spec
    
    def _fix_all_reference_paths(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """Comprehensive fix for all $ref paths in the OpenAPI specification"""
        spec_str = json.dumps(spec)
        
        # Log original problematic references
        problematic_refs = re.findall(r'"[^"]*\/definitions\/[^"]*"', spec_str)
        if problematic_refs:
            logger.info(f"Found problematic references: {problematic_refs}")
        
        # Fix all variations of incorrect $ref paths
        ref_fixes = [
            ('"/definitions/', '"#/components/schemas/'),
            ('"#/definitions/', '"#/components/schemas/'),
            ('"/parameters/', '"#/components/parameters/'),
            ('"/responses/', '"#/components/responses/'),
        ]
        
        for old_ref, new_ref in ref_fixes:
            if old_ref in spec_str:
                spec_str = spec_str.replace(old_ref, new_ref)
        
        # Regex cleanup for any remaining issues
        spec_str = re.sub(r'"(\$ref":\s*)"([^#][^"]*\/definitions\/[^"]*)"', r'"\1"#/components/schemas/\2"', spec_str)
        
        try:
            fixed_spec = json.loads(spec_str)
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error after reference fixes: {e}")
            return spec
        
        # Verify fixes
        verification_str = json.dumps(fixed_spec)
        remaining_issues = re.findall(r'"[^"]*\/definitions\/[^"]*"', verification_str)
        
        if remaining_issues:
            logger.warning(f"Still found problematic references after fixes: {remaining_issues}")
        else:
            logger.info("All reference paths successfully fixed")
        
        return fixed_spec
    
    def _fix_request_response_structure(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """Fix request/response structure for Azure APIM compatibility"""
        for path, path_item in spec.get('paths', {}).items():
            for method, operation in path_item.items():
                if method.lower() not in ['get', 'post', 'put', 'patch', 'delete', 'head', 'options']:
                    continue
                
                if not isinstance(operation, dict):
                    continue
                
                # Fix parameters (remove body params, fix parameter structure)
                if 'parameters' in operation:
                    fixed_params = []
                    for param in operation['parameters']:
                        if isinstance(param, dict):
                            if param.get('in') == 'body':
                                # Convert to requestBody
                                if 'requestBody' not in operation:
                                    operation['requestBody'] = {
                                        'required': param.get('required', True),
                                        'content': {
                                            'application/json': {
                                                'schema': param.get('schema', {})
                                            }
                                        }
                                    }
                            else:
                                # Fix parameter structure
                                if 'type' in param and 'schema' not in param:
                                    schema = {}
                                    for key in ['type', 'format', 'enum', 'minimum', 'maximum', 'pattern', 'default']:
                                        if key in param:
                                            schema[key] = param[key]
                                    
                                    fixed_param = {k: v for k, v in param.items() if k not in ['type', 'format', 'enum', 'minimum', 'maximum', 'pattern', 'default']}
                                    fixed_param['schema'] = schema
                                    fixed_params.append(fixed_param)
                                else:
                                    fixed_params.append(param)
                    
                    if fixed_params:
                        operation['parameters'] = fixed_params
                    else:
                        del operation['parameters']
                
                # Fix responses (ensure content blocks)
                if 'responses' in operation:
                    for status, response in operation['responses'].items():
                        if isinstance(response, dict) and 'schema' in response and 'content' not in response:
                            schema = response.pop('schema')
                            response['content'] = {
                                'application/json': {
                                    'schema': schema
                                }
                            }
        
        return spec
    
    def _is_valid_openapi_3_for_azure(self, spec: Dict[str, Any]) -> bool:
        """Validate that spec is truly Azure APIM-compatible OpenAPI 3.0"""
        # Basic structure check
        if not spec.get('openapi', '').startswith('3.'):
            return False
        
        if not spec.get('info', {}).get('title'):
            return False
        
        if not spec.get('paths'):
            return False
        
        # Check for problematic $ref paths
        spec_str = json.dumps(spec)
        problematic_refs = re.findall(r'"\$ref":\s*"[^#][^"]*\/definitions\/', spec_str)
        if problematic_refs:
            logger.error(f"Found {len(problematic_refs)} problematic $ref paths")
            return False
        
        # Check for OpenAPI 2.0 remnants
        openapi_2_fields = ['swagger', 'definitions', 'securityDefinitions', 'host', 'basePath', 'schemes']
        for field in openapi_2_fields:
            if field in spec:
                logger.error(f"Found OpenAPI 2.0 field: {field}")
                return False
        
        # Check for body parameters
        for path, path_item in spec.get('paths', {}).items():
            for method, operation in path_item.items():
                if isinstance(operation, dict) and 'parameters' in operation:
                    for param in operation['parameters']:
                        if isinstance(param, dict) and param.get('in') == 'body':
                            logger.error(f"Found body parameter in {method} {path}")
                            return False
        
        return True
    
    def _apply_emergency_fixes(self, spec: Dict[str, Any], original_spec: Dict[str, Any]) -> Dict[str, Any]:
        """Apply emergency fixes if validation fails"""
        logger.info("Applying emergency fixes for Azure APIM compatibility")
        
        # Ensure basic structure
        if 'openapi' not in spec:
            spec['openapi'] = '3.0.0'
        
        if 'info' not in spec:
            spec['info'] = original_spec.get('info', {'title': 'API', 'version': '1.0.0'})
        
        if 'paths' not in spec:
            spec['paths'] = original_spec.get('paths', {})
        
        # Force fix $ref paths one more time
        spec = self._fix_all_reference_paths(spec)
        
        # Remove any remaining problematic fields
        problematic_fields = ['swagger', 'definitions', 'securityDefinitions', 'host', 'basePath', 'schemes', 'consumes', 'produces']
        for field in problematic_fields:
            if field in spec:
                del spec[field]
        
        return spec
    
    def _create_servers_from_v2(self, spec: Dict[str, Any]) -> list:
        """Create servers array from OpenAPI 2.0 host/basePath/schemes"""
        servers = []
        host = spec.get('host', 'api.example.com')
        base_path = spec.get('basePath', '')
        schemes = spec.get('schemes', ['https'])
        
        for scheme in schemes:
            url = f"{scheme}://{host}{base_path}"
            servers.append({"url": url})
        
        return servers if servers else [{"url": "https://api.example.com"}]
    
    def _convert_security_definitions(self, security_defs: Dict[str, Any]) -> Dict[str, Any]:
        """Convert securityDefinitions to securitySchemes"""
        security_schemes = {}
        
        for name, definition in security_defs.items():
            if not isinstance(definition, dict):
                continue
            
            scheme_type = definition.get('type')
            if scheme_type == 'apiKey':
                security_schemes[name] = {
                    'type': 'apiKey',
                    'name': definition.get('name'),
                    'in': definition.get('in')
                }
            elif scheme_type == 'oauth2':
                security_schemes[name] = {
                    'type': 'oauth2',
                    'flows': {
                        'implicit': {
                            'authorizationUrl': definition.get('authorizationUrl'),
                            'scopes': definition.get('scopes', {})
                        }
                    }
                }
            elif scheme_type == 'basic':
                security_schemes[name] = {
                    'type': 'http',
                    'scheme': 'basic'
                }
        
        return security_schemes
    
    def _ai_convert_spec(self, original_spec: Dict[str, Any], include_debug: bool = False) -> Dict[str, Any]:
        """Use Azure OpenAI to convert the specification with enhanced prompting"""
        if not self.is_available:
            raise Exception("Azure OpenAI client not available")
        
        prompt = self._create_enhanced_conversion_prompt(original_spec)
        start_time = time.time()
        
        try:
            api_params = {
                "model": self.config.OPENAI_DEPLOYMENT,
                "messages": [
                    {
                        "role": "system", 
                        "content": self._get_enhanced_system_prompt()
                    },
                    {
                        "role": "user", 
                        "content": prompt
                    }
                ],
                # "temperature": 0.1,
                "max_tokens": 4000,
                "stream": False
            }
            
            if include_debug:
                self._last_openai_response = {
                    'model_used': api_params['model'],
                    'prompt_length': len(prompt),
                    # 'temperature': api_params['temperature'],
                    'start_time': start_time
                }
            
            try:
                response = self._client.chat.completions.create(**api_params)
            except Exception as e:
                if "max_tokens" in str(e).lower():
                    api_params.pop("max_tokens", None)
                    api_params["max_completion_tokens"] = 4000
                    response = self._client.chat.completions.create(**api_params)
                else:
                    raise e
            
            raw_content = response.choices[0].message.content
            
            if include_debug:
                self._last_openai_response.update({
                    'raw': raw_content,
                    'response_length': len(raw_content),
                    'api_call_time': time.time() - start_time
                })
            
            # Extract and clean JSON
            cleaned_json = self._extract_and_clean_json(raw_content)
            
            if include_debug:
                self._last_openai_response.update({
                    'cleaned': cleaned_json,
                    'cleaned_length': len(cleaned_json)
                })
            
            # Parse JSON
            converted_spec = json.loads(cleaned_json)
            return converted_spec
            
        except Exception as e:
            logger.error(f"Azure OpenAI API call failed: {e}")
            if include_debug and hasattr(self, '_last_openai_response'):
                self._last_openai_response.update({
                    'error': str(e),
                    'success': False
                })
            raise
    
    def _get_enhanced_system_prompt(self) -> str:
        """Get enhanced system prompt for better OpenAPI conversion"""
        return """You are an expert API specification converter. Convert OpenAPI 2.0 to OpenAPI 3.0 with these requirements:

CRITICAL: Return ONLY valid JSON. No explanatory text, no markdown formatting, no code blocks - just the raw JSON.

Key conversion rules:
1. Change 'swagger: "2.0"' to 'openapi: "3.0.0"'
2. Convert host/basePath/schemes to servers array: [{"url": "scheme://host/basePath"}]
3. Move definitions to components/schemas
4. Convert securityDefinitions to components/securitySchemes
5. Convert body parameters to requestBody with content types
6. Add content types to all responses that return schemas
7. Update all $ref paths from "#/definitions/" to "#/components/schemas/"

CRITICAL $ref conversion:
- NEVER use "/definitions/" - always use "#/components/schemas/"
- Example: {"$ref": "/definitions/User"} becomes {"$ref": "#/components/schemas/User"}

Return the complete OpenAPI 3.0 specification as valid JSON only."""
    
    def _create_enhanced_conversion_prompt(self, spec: Dict[str, Any]) -> str:
        """Create detailed conversion prompt"""
        spec_str = json.dumps(spec, indent=2)
        if len(spec_str) > 8000:
            spec_summary = {
                "swagger": spec.get("swagger"),
                "info": spec.get("info"),
                "host": spec.get("host"),
                "basePath": spec.get("basePath"),
                "schemes": spec.get("schemes"),
                "paths": {k: v for i, (k, v) in enumerate(spec.get("paths", {}).items()) if i < 5},
                "definitions": {k: v for i, (k, v) in enumerate(spec.get("definitions", {}).items()) if i < 5},
                "securityDefinitions": spec.get("securityDefinitions"),
                "_note": f"Truncated - original has {len(spec.get('paths', {}))} paths and {len(spec.get('definitions', {}))} definitions"
            }
            spec_str = json.dumps(spec_summary, indent=2)
        
        return f"Convert this OpenAPI 2.0 specification to OpenAPI 3.0:\n\n{spec_str}"
    
    def _extract_and_clean_json(self, content: str) -> str:
        """Extract and clean JSON from OpenAI response"""
        content = content.strip()
        
        # Handle code block wrapping
        if "```json" in content:
            start = content.find("```json") + 7
            end = content.find("```", start)
            if end == -1:
                end = len(content)
            content = content[start:end].strip()
        elif "```" in content:
            lines = content.split('\n')
            in_code_block = False
            json_lines = []
            
            for line in lines:
                if line.strip().startswith('```'):
                    in_code_block = not in_code_block
                    continue
                if in_code_block:
                    json_lines.append(line)
            
            if json_lines:
                content = '\n'.join(json_lines)
        
        # Remove explanatory text
        explanatory_patterns = [
            r'^.*?Here is the converted.*?\n',
            r'^.*?Here\'s the converted.*?\n',
            r'^.*?The converted specification.*?\n',
            r'^.*?Below is the.*?\n'
        ]
        
        for pattern in explanatory_patterns:
            content = re.sub(pattern, '', content, flags=re.IGNORECASE | re.MULTILINE)
        
        # Find JSON boundaries
        start_idx = content.find('{')
        if start_idx == -1:
            raise ValueError("No JSON object found in response")
        
        # Find matching closing brace
        brace_count = 0
        end_idx = -1
        for i in range(start_idx, len(content)):
            if content[i] == '{':
                brace_count += 1
            elif content[i] == '}':
                brace_count -= 1
                if brace_count == 0:
                    end_idx = i + 1
                    break
        
        if end_idx == -1:
            content = content[start_idx:]
        else:
            content = content[start_idx:end_idx]
        
        return content.strip()
    
    def _extract_conversion_metadata(self, original: Dict[str, Any], converted: Dict[str, Any]) -> Dict[str, Any]:
        """Extract metadata about the conversion"""
        original_info = original.get('info', {})
        converted_info = converted.get('info', {})
        
        metadata = {
            'api_title': original_info.get('title', 'Unknown API'),
            'api_version': original_info.get('version', 'Unknown'),
            'api_description': original_info.get('description', ''),
            'original_paths_count': len(original.get('paths', {})),
            'converted_paths_count': len(converted.get('paths', {})),
            'original_definitions_count': len(original.get('definitions', {})),
            'converted_schemas_count': len(converted.get('components', {}).get('schemas', {})),
            'has_security': bool(original.get('securityDefinitions')),
            'servers_created': len(converted.get('servers', [])),
            'conversion_timestamp': time.time()
        }
        
        if 'servers' in converted and converted['servers']:
            metadata['target_servers'] = [server.get('url') for server in converted['servers']]
        else:
            metadata['target_servers'] = []
        
        return metadata
    
    def _is_openapi_2(self, spec: Dict[str, Any]) -> bool:
        """Check if specification is OpenAPI 2.0"""
        return spec.get('swagger') == '2.0' or spec.get('swagger', '').startswith('2.')
    
    def _is_openapi_3(self, spec: Dict[str, Any]) -> bool:
        """Check if specification is OpenAPI 3.0"""
        return spec.get('openapi', '').startswith('3.')
    
    def test_connection(self) -> Dict[str, Any]:
        """Test connection to Azure OpenAI service"""
        if not self.is_available:
            return {
                'status': 'error',
                'message': f'Azure OpenAI client not initialized: {self._initialization_error or "Unknown error"}'
            }
        
        try:
            api_params = {
                "model": self.config.OPENAI_DEPLOYMENT,
                "messages": [{"role": "user", "content": "test"}],
                "max_tokens": 10,
                "stream": False
            }
            
            try:
                response = self._client.chat.completions.create(**api_params)
            except Exception as e:
                if "max_tokens" in str(e).lower():
                    api_params["max_completion_tokens"] = api_params.pop("max_tokens")
                    response = self._client.chat.completions.create(**api_params)
                else:
                    raise e
            
            return {
                'status': 'success',
                'message': 'Azure OpenAI connection successful',
                'model': self.config.OPENAI_DEPLOYMENT,
                'auth_method': self._auth_method
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Azure OpenAI connection failed: {str(e)}'
            }
            