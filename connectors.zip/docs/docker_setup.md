# Docker Setup Guide

This guide helps you run the API Migration Tool using Docker with PostgreSQL.

## 🐳 Quick Start with Docker Compose

### 1. Prerequisites
```bash
# Install Docker and Docker Compose
# Windows/Mac: Docker Desktop
# Linux: 
sudo apt-get update
sudo apt-get install docker.io docker-compose

# Verify installation
docker --version
docker-compose --version
```

### 2. Environment Setup
```bash
# Clone the repository
git clone <repository-url>
cd api-migration-tool

# Copy environment template
cp .env.example .env

# Edit .env with your Azure and IBM credentials
nano .env
```

### 3. Start Services
```bash
# Start all services (app + PostgreSQL)
docker-compose up -d

# Or start with pgAdmin for database management
docker-compose --profile admin up -d

# View logs
docker-compose logs -f app
```

### 4. Access the Application
- **Application**: http://localhost:8000
- **pgAdmin** (if enabled): http://localhost:5050
  - Email: admin@example.com
  - Password: admin123

### 5. Initialize Database
```bash
# The database is automatically initialized on first startup
# To manually initialize or add sample data:
docker-compose exec app python create_database.py
```

## 🔧 Service Configuration

### PostgreSQL Database
```yaml
# Default configuration in docker-compose.yml
postgres:
  image: postgres:15-alpine
  environment:
    POSTGRES_DB: api_migration_db
    POSTGRES_USER: api_user
    POSTGRES_PASSWORD: migration_password_123
  ports:
    - "5432:5432"
```

### Application
```yaml
app:
  build: .
  environment:
    DATABASE_URL: postgresql://api_user:migration_password_123@postgres:5432/api_migration_db
  ports:
    - "8000:8000"
```

## 📊 Database Management

### Connect to PostgreSQL
```bash
# Using docker-compose
docker-compose exec postgres psql -U api_user -d api_migration_db

# Using external client
psql -h localhost -p 5432 -U api_user -d api_migration_db
```

### Common Database Operations
```sql
-- Check migration statistics
SELECT * FROM migration_dashboard;

-- View recent migrations
SELECT api_name, status, created_at 
FROM migration_records 
ORDER BY created_at DESC 
LIMIT 10;

-- Clean up old logs (keep last 30 days)
SELECT cleanup_old_logs(30);

-- Get table sizes
SELECT * FROM get_migration_stats();
```

### Backup and Restore
```bash
# Create backup
docker-compose exec postgres pg_dump -U api_user api_migration_db > backup.sql

# Restore backup
docker-compose exec -T postgres psql -U api_user api_migration_db < backup.sql
```

## 🔍 Monitoring and Logs

### Application Logs
```bash
# View application logs
docker-compose logs -f app

# View PostgreSQL logs
docker-compose logs -f postgres

# View all logs
docker-compose logs -f
```

### Health Checks
```bash
# Check service status
docker-compose ps

# Check application health
curl http://localhost:8000/api/health

# Check database connection
docker-compose exec app python -c "
from models.database import db
from app import app
with app.app_context():
    print('Database connection:', db.engine.execute('SELECT 1').scalar())
"
```

### Performance Monitoring
```bash
# Database performance
docker-compose exec postgres psql -U api_user -d api_migration_db -c "
SELECT 
    query,
    calls,
    total_time,
    mean_time
FROM pg_stat_statements 
ORDER BY mean_time DESC 
LIMIT 10;
"

# Container resource usage
docker stats
```

## 🚀 Production Deployment

### Environment Configuration
```bash
# Production environment variables
cat > .env.prod << EOF
# Flask
FLASK_DEBUG=False
FLASK_SECRET_KEY=your-production-secret-key

# Database (use external PostgreSQL in production)
DATABASE_URL=postgresql://user:password@external-db:5432/api_migration_db

# Azure Configuration
AZURE_CLIENT_ID=your-client-id
AZURE_CLIENT_SECRET=your-client-secret
# ... other production settings
EOF
```

### Production Docker Compose
```yaml
# docker-compose.prod.yml
version: '3.8'
services:
  app:
    build: .
    environment:
      - FLASK_DEBUG=False
    env_file:
      - .env.prod
    restart: unless-stopped
    depends_on:
      - postgres
    
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: api_migration_db
      POSTGRES_USER: api_user
      POSTGRES_PASSWORD_FILE: /run/secrets/db_password
    secrets:
      - db_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped

secrets:
  db_password:
    file: ./secrets/db_password.txt

volumes:
  postgres_data:
    external: true
```

### Deploy to Production
```bash
# Create external volume for data persistence
docker volume create postgres_data

# Create secrets directory
mkdir secrets
echo "your-secure-password" > secrets/db_password.txt
chmod 600 secrets/db_password.txt

# Deploy
docker-compose -f docker-compose.prod.yml up -d
```

## 🔒 Security Considerations

### Database Security
```bash
# Change default passwords
export POSTGRES_PASSWORD=$(openssl rand -base64 32)

# Use secrets for sensitive data
echo "$POSTGRES_PASSWORD" | docker secret create db_password -

# Enable SSL in production
# Add to postgresql.conf:
ssl = on
ssl_cert_file = '/var/lib/postgresql/server.crt'
ssl_key_file = '/var/lib/postgresql/server.key'
```

### Network Security
```yaml
# Restrict network access
networks:
  api-migration-network:
    driver: bridge
    internal: true  # No external access
  
  web:
    driver: bridge
```

### Container Security
```bash
# Scan images for vulnerabilities
docker scout cves api-migration-tool

# Use non-root user (already configured in Dockerfile)
USER appuser

# Set resource limits
deploy:
  resources:
    limits:
      cpus: '2'
      memory: 2G
    reservations:
      cpus: '0.5'
      memory: 512M
```

## 🛠️ Development Setup

### Development with Live Reload
```yaml
# docker-compose.dev.yml
version: '3.8'
services:
  app:
    build: 
      context: .
      target: builder  # Use builder stage for development
    environment:
      FLASK_DEBUG: "True"
    volumes:
      - .:/app  # Mount source code for live reload
    ports:
      - "5000:5000"
    command: python app.py  # Use development server
```

### Start Development Environment
```bash
# Start development stack
docker-compose -f docker-compose.dev.yml up

# Install additional packages
docker-compose exec app pip install package-name

# Run tests
docker-compose exec app pytest

# Access shell
docker-compose exec app bash
```

## 🧪 Testing

### Run Tests in Container
```bash
# Run full test suite
docker-compose exec app pytest

# Run specific tests
docker-compose exec app pytest tests/test_connectors.py

# Run with coverage
docker-compose exec app pytest --cov=. --cov-report=html

# Run integration tests (requires real services)
docker-compose exec app pytest -m integration
```

### Database Testing
```bash
# Create test database
docker-compose exec postgres createdb -U api_user test_api_migration_db

# Run database tests
docker-compose exec app python -c "
import os
os.environ['DATABASE_URL'] = 'postgresql://api_user:migration_password_123@postgres:5432/test_api_migration_db'
import pytest
pytest.main(['tests/test_models.py'])
"
```

## 🔄 Maintenance

### Update Images
```bash
# Pull latest base images
docker-compose pull

# Rebuild application image
docker-compose build --no-cache app

# Restart services
docker-compose up -d
```

### Database Maintenance
```bash
# Vacuum and analyze
docker-compose exec postgres psql -U api_user -d api_migration_db -c "VACUUM ANALYZE;"

# Reindex
docker-compose exec postgres psql -U api_user -d api_migration_db -c "REINDEX DATABASE api_migration_db;"

# Check database size
docker-compose exec postgres psql -U api_user -d api_migration_db -c "
SELECT pg_size_pretty(pg_database_size('api_migration_db'));
"
```

### Log Rotation
```bash
# Configure log rotation in docker-compose.yml
logging:
  driver: "json-file"
  options:
    max-size: "10m"
    max-file: "3"
```

## 🚨 Troubleshooting

### Common Issues

#### Container Won't Start
```bash
# Check container logs
docker-compose logs app

# Check resource usage
docker stats

# Restart services
docker-compose restart
```

#### Database Connection Issues
```bash
# Check PostgreSQL is running
docker-compose ps postgres

# Test database connection
docker-compose exec postgres pg_isready -U api_user

# Check network connectivity
docker-compose exec app ping postgres
```

#### Application Errors
```bash
# Check application logs
docker-compose logs -f app

# Access application shell
docker-compose exec app bash

# Check Python environment
docker-compose exec app python -c "
import sys
print('Python:', sys.version)
from models.database import db
print('Database:', db)
"
```

### Cleanup
```bash
# Stop and remove containers
docker-compose down

# Remove volumes (WARNING: This deletes data)
docker-compose down -v

# Remove images
docker-compose down --rmi all

# Full cleanup
docker system prune -a
```

## ✅ Docker Quick Reference

```bash
# Essential commands
docker-compose up -d              # Start services
docker-compose down               # Stop services
docker-compose logs -f app        # View logs
docker-compose exec app bash      # Shell access
docker-compose ps                 # Service status
docker-compose restart app        # Restart service

# Database commands
docker-compose exec postgres psql -U api_user -d api_migration_db
docker-compose exec app python create_database.py

# Maintenance
docker-compose pull               # Update images
docker-compose build --no-cache   # Rebuild images
docker system prune              # Cleanup unused resources
```

Your API Migration Tool is now running with PostgreSQL in Docker! 🎉