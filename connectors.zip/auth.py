"""
Authentication Module for API Migration Tool
Handles login, logout, session management, and YAML conversion
"""
import os
import yaml
import json
import logging
from functools import wraps
from datetime import datetime, timedelta
from flask import session, redirect, url_for, flash, render_template, request, jsonify

logger = logging.getLogger('app')


# ==========================================
# AUTHENTICATION DECORATOR
# ==========================================

def login_required(f):
    """Decorator to require login for protected routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            # For API endpoints, return JSON error
            if request.is_json or request.path.startswith('/api/'):
                return jsonify({
                    'success': False,
                    'error': 'Authentication required',
                    'message': 'Please log in to access this resource'
                }), 401
            
            # For regular routes, redirect to login WITHOUT flash message
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


# ==========================================
# SESSION CONFIGURATION
# ==========================================

def configure_session(app):
    """Configure Flask session for authentication"""
    
    # Get SECRET_KEY from environment or use default (CHANGE IN PRODUCTION!)
    secret_key = os.environ.get('SECRET_KEY')
    if not secret_key:
        logger.warning("SECRET_KEY not set in environment! Using default development key.")
        logger.warning("[WARNING] SECURITY WARNING: Set SECRET_KEY environment variable in production!")
        secret_key = 'dev-secret-key-CHANGE-IN-PRODUCTION-' + os.urandom(24).hex()
    
    # Session configuration
    app.config['SECRET_KEY'] = secret_key
    app.config['SESSION_COOKIE_NAME'] = 'api_migration_session'
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    
    # Set secure cookies in production (not in debug mode)
    if not app.config.get('DEBUG'):
        app.config['SESSION_COOKIE_SECURE'] = True
        logger.info("Secure session cookies enabled (HTTPS required)")
    
    # Permanent session lifetime (for "remember me")
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)
    
    logger.info("[OK] Session configuration completed")
    logger.info(f"  - Cookie name: {app.config['SESSION_COOKIE_NAME']}")
    logger.info(f"  - Session lifetime: {app.config['PERMANENT_SESSION_LIFETIME']}")
    logger.info(f"  - Secure cookies: {app.config.get('SESSION_COOKIE_SECURE', False)}")


# ==========================================
# AUTHENTICATION ROUTES
# ==========================================

def register_auth_routes(app):
    """Register authentication and utility routes with the Flask app"""
    
    # ==========================================
    # LOGIN & LOGOUT ROUTES
    # ==========================================
    
    @app.route('/login', methods=['GET'])
    def login():
        """Login page route"""
        # If already logged in, redirect to dashboard
        if 'user_id' in session:
            logger.info(f"User {session.get('username')} already logged in, redirecting to dashboard")
            return redirect(url_for('index'))
        
        return render_template('login.html')
    
    
    @app.route('/logout')
    def logout():
        """Logout route"""
        username = session.get('username', 'User')
        
        # Clear session completely
        session.clear()
        
        logger.info(f"User {username} logged out successfully")
        
        # Flash success message ONLY on logout
        flash(f'{username} logged out successfully.', 'success')
        
        return redirect(url_for('login'))
    
    
    # ==========================================
    # AUTHENTICATION API ENDPOINTS
    # ==========================================
    
    @app.route('/api/auth/login', methods=['POST'])
    def api_login():
        """
        Handle login API request
        Expects JSON: { username, password, remember }
        Returns: { success, message, redirect_url, user }
        """
        try:
            data = request.get_json()
            username = data.get('username', '').strip()
            password = data.get('password', '')
            remember = data.get('remember', False)
            
            # Validate input
            if not username or not password:
                logger.warning("Login attempt with missing credentials")
                return jsonify({
                    'success': False,
                    'message': 'Username and password are required'
                }), 400
            
            # ==========================================
            # TODO: REPLACE WITH YOUR ACTUAL AUTHENTICATION
            # ==========================================
            # This is a simple hardcoded authentication for demonstration
            # In production, you should:
            # 1. Query your user database
            # 2. Verify hashed passwords (use werkzeug.security)
            # 3. Implement rate limiting
            # 4. Add account lockout after failed attempts
            # 5. Use proper user session management
            
            valid_users = {
                'admin': 'admin',
                'user': 'password',
                'demo': 'demo123'
            }
            
            if username in valid_users and valid_users[username] == password:
                # Successful authentication
                session['user_id'] = username
                session['username'] = username
                session['logged_in_at'] = datetime.now().isoformat()
                
                # Set session to permanent if remember me is checked
                if remember:
                    session.permanent = True
                
                logger.info(f"[OK] User '{username}' logged in successfully (remember_me: {remember})")
                
                return jsonify({
                    'success': True,
                    'message': 'Login successful',
                    'redirect_url': url_for('index'),
                    'user': {
                        'username': username,
                        'logged_in_at': session['logged_in_at']
                    }
                })
            else:
                # Failed authentication
                logger.warning(f"[FAILED] Failed login attempt for username: '{username}'")
                return jsonify({
                    'success': False,
                    'message': 'Invalid username or password'
                }), 401
                
        except Exception as e:
            logger.error(f"Login error: {e}")
            return jsonify({
                'success': False,
                'message': f'Login error: {str(e)}'
            }), 500
    
    
    @app.route('/api/auth/verify', methods=['POST', 'GET'])
    def api_verify_token():
        """
        Verify authentication session
        Returns: { valid, user_id, username, logged_in_at }
        """
        try:
            # Check session-based auth
            if 'user_id' in session:
                return jsonify({
                    'valid': True,
                    'user_id': session.get('user_id'),
                    'username': session.get('username'),
                    'logged_in_at': session.get('logged_in_at')
                })
            
            return jsonify({'valid': False}), 401
            
        except Exception as e:
            logger.error(f"Token verification error: {e}")
            return jsonify({'valid': False, 'error': str(e)}), 500
    
    
    @app.route('/api/auth/session')
    def get_session_info():
        """Get current session information"""
        if 'user_id' not in session:
            return jsonify({
                'authenticated': False,
                'message': 'No active session'
            }), 401
        
        return jsonify({
            'authenticated': True,
            'user': {
                'user_id': session.get('user_id'),
                'username': session.get('username'),
                'logged_in_at': session.get('logged_in_at')
            },
            'session': {
                'permanent': session.permanent,
                'new': session.new
            }
        })
    
    
    # ==========================================
    # OAUTH PLACEHOLDER ROUTES - NO FLASH MESSAGES
    # ==========================================
    
    @app.route('/api/auth/microsoft')
    def auth_microsoft():
        """Redirect to Microsoft OAuth (placeholder)"""
        logger.info("Microsoft OAuth attempted (not implemented)")
        # Redirect back to login without flash message
        return redirect(url_for('login'))
    
    
    @app.route('/api/auth/google')
    def auth_google():
        """Redirect to Google OAuth (placeholder)"""
        logger.info("Google OAuth attempted (not implemented)")
        # Redirect back to login without flash message
        return redirect(url_for('login'))
    
    
    # ==========================================
    # YAML CONVERTER API ENDPOINTS (PROTECTED)
    # ==========================================
    
    @app.route('/api/yaml/convert', methods=['POST'])
    @login_required
    def api_convert_yaml():
        """
        Convert YAML to JSON via API
        Expects JSON: { yaml_content, indent }
        Returns: { success, json_content, size, lines }
        """
        try:
            data = request.get_json()
            yaml_content = data.get('yaml_content', '')
            indent = data.get('indent', 2)
            
            if not yaml_content:
                return jsonify({
                    'success': False,
                    'error': 'No YAML content provided'
                }), 400
            
            # Parse YAML
            try:
                parsed_data = yaml.safe_load(yaml_content)
            except yaml.YAMLError as e:
                logger.warning(f"YAML parsing error: {str(e)}")
                return jsonify({
                    'success': False,
                    'error': f'YAML parsing error: {str(e)}'
                }), 400
            
            # Convert to JSON with specified indent
            if indent == 'tab':
                json_content = json.dumps(parsed_data, indent='\t')
            elif indent == '0':
                json_content = json.dumps(parsed_data)
            else:
                json_content = json.dumps(parsed_data, indent=int(indent))
            
            logger.info(f"YAML converted successfully by user {session.get('username')} - {len(json_content)} bytes")
            
            return jsonify({
                'success': True,
                'json_content': json_content,
                'size': len(json_content),
                'lines': len(json_content.split('\n'))
            })
            
        except Exception as e:
            logger.error(f"YAML conversion error: {e}")
            return jsonify({
                'success': False,
                'error': f'Conversion error: {str(e)}'
            }), 500
    
    
    @app.route('/api/yaml/validate', methods=['POST'])
    @login_required
    def api_validate_yaml():
        """
        Validate YAML syntax
        Expects JSON: { yaml_content }
        Returns: { valid, error, message }
        """
        try:
            data = request.get_json()
            yaml_content = data.get('yaml_content', '')
            
            if not yaml_content:
                return jsonify({
                    'valid': False,
                    'error': 'No YAML content provided'
                })
            
            try:
                yaml.safe_load(yaml_content)
                return jsonify({
                    'valid': True,
                    'message': 'YAML is valid'
                })
            except yaml.YAMLError as e:
                return jsonify({
                    'valid': False,
                    'error': str(e),
                    'message': f'YAML validation failed: {str(e)}'
                })
                
        except Exception as e:
            logger.error(f"YAML validation error: {e}")
            return jsonify({
                'valid': False,
                'error': str(e)
            }), 500
    
    
    logger.info("[OK] Authentication routes registered successfully")
    logger.info("  - /login (GET) - Login page")
    logger.info("  - /logout (GET) - Logout")
    logger.info("  - /api/auth/login (POST) - Login API")
    logger.info("  - /api/auth/verify (POST/GET) - Verify session")
    logger.info("  - /api/auth/session (GET) - Session info")
    logger.info("  - /api/yaml/convert (POST) - YAML to JSON converter")
    logger.info("  - /api/yaml/validate (POST) - YAML validator")


# ==========================================
# USER MANAGEMENT FUNCTIONS
# ==========================================

def get_current_user():
    """Get current logged-in user from session"""
    if 'user_id' in session:
        return {
            'user_id': session.get('user_id'),
            'username': session.get('username'),
            'logged_in_at': session.get('logged_in_at')
        }
    return None


def is_authenticated():
    """Check if current user is authenticated"""
    return 'user_id' in session


# ==========================================
# PASSWORD HASHING UTILITIES (FOR PRODUCTION)
# ==========================================

def hash_password(password: str) -> str:
    """
    Hash a password for storing in database
    Use this in production instead of plain text passwords!
    """
    from werkzeug.security import generate_password_hash
    return generate_password_hash(password, method='pbkdf2:sha256')


def verify_password(stored_password_hash: str, provided_password: str) -> bool:
    """
    Verify a stored password hash against a provided password
    Use this in production for secure password verification!
    """
    from werkzeug.security import check_password_hash
    return check_password_hash(stored_password_hash, provided_password)