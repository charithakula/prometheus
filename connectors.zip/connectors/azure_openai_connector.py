"""
Azure OpenAI Connector - UNIVERSAL API CONVERTER (FULLY FIXED FOR AZURE APIM)
Handles ALL conversion scenarios with proper $ref handling and component creation
"""
import json
import logging
import yaml
import re
import os
import time
from typing import Dict, Any, Optional, Tuple, Literal
from config import AzureConfig

logger = logging.getLogger(__name__)

class AzureOpenAIConnector:
    """Azure OpenAI service connector for API specification conversion"""
    
    def __init__(self):
        """Initialize Azure OpenAI client"""
        self.config = AzureConfig
        self._client = None
        self.is_initialized = False
        self._initialization_error = None
        self._auth_method = None
        self._last_openai_response = {}
        
        try:
            self._initialize_client()
        except Exception as e:
            logger.warning(f"Azure OpenAI connector initialization failed: {e}")
            self._initialization_error = str(e)
    
    def _initialize_client(self) -> bool:
        """Initialize Azure OpenAI client with configuration validation"""
        try:
            missing_config = self.config.validate_openai_config()
            if missing_config:
                logger.warning(f"Missing Azure OpenAI configuration: {missing_config}")
                self._initialization_error = f"Missing configuration: {missing_config}"
                return False
            
            try:
                from openai import AzureOpenAI
                
                if hasattr(self.config, 'OPENAI_API_KEY') and self.config.OPENAI_API_KEY:
                    self._client = self._init_with_api_key(AzureOpenAI)
                    self._auth_method = "api_key"
                else:
                    self._client = self._init_with_entra_id(AzureOpenAI)
                    self._auth_method = "entra_id"
                
                if self._client:
                    self.is_initialized = True
                    logger.info(f"Azure OpenAI client initialized successfully using {self._auth_method}")
                    return True
                else:
                    return False
                
            except ImportError as e:
                logger.warning(f"OpenAI library not properly installed: {e}")
                self._initialization_error = f"OpenAI library import failed: {e}"
                return False
            
        except Exception as e:
            logger.warning(f"Failed to initialize Azure OpenAI client: {e}")
            self._client = None
            self.is_initialized = False
            self._initialization_error = str(e)
            return False
    
    def _init_with_api_key(self, AzureOpenAI) -> Optional[object]:
        """Initialize client with API key authentication - INCREASED TIMEOUT"""
        try:
            return AzureOpenAI(
                azure_endpoint=self.config.OPENAI_ENDPOINT,
                api_key=self.config.OPENAI_API_KEY,
                api_version=self.config.OPENAI_VERSION,
                timeout=120.0,
                max_retries=3
            )
        except Exception as e:
            logger.warning(f"API key authentication failed: {e}")
            self._initialization_error = f"API key authentication failed: {e}"
            return None
    
    def _init_with_entra_id(self, AzureOpenAI) -> Optional[object]:
        """Initialize client with Entra ID authentication - INCREASED TIMEOUT"""
        try:
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider
            
            token_provider = get_bearer_token_provider(
                DefaultAzureCredential(), 
                "https://cognitiveservices.azure.com/.default"
            )
            
            return AzureOpenAI(
                azure_endpoint=self.config.OPENAI_ENDPOINT,
                azure_ad_token_provider=token_provider,
                api_version=self.config.OPENAI_VERSION,
                timeout=120.0,
                max_retries=3
            )
        except ImportError as e:
            logger.warning(f"Azure Identity library not available: {e}")
            self._initialization_error = f"Azure Identity library not available: {e}"
            return None
        except Exception as e:
            logger.warning(f"Entra ID authentication failed: {e}")
            self._initialization_error = f"Entra ID authentication failed: {e}"
            return None
    
    @property
    def is_available(self) -> bool:
        """Check if Azure OpenAI service is available"""
        return self._client is not None and self.is_initialized
    
    def get_debug_info(self) -> Dict[str, Any]:
        """Get the last OpenAI response debug information"""
        return self._last_openai_response.copy()
    
    def parse_api_spec(self, content: str) -> Tuple[Dict[str, Any], str]:
        """Parse API specification from JSON or YAML"""
        try:
            spec = json.loads(content)
            return spec, 'json'
        except json.JSONDecodeError:
            try:
                spec = yaml.safe_load(content)
                return spec, 'yaml'
            except yaml.YAMLError as e:
                raise ValueError(f"Invalid JSON or YAML format: {e}")
    
    def convert_specification(
        self, 
        spec_content: str, 
        target_format: Literal['json', 'yaml'] = 'json',
        target_version: Literal['2.0', '3.0', 'auto'] = 'auto',
        include_debug: bool = False
    ) -> Dict[str, Any]:
        """
        ✅ UNIVERSAL CONVERTER - Handles all conversion scenarios
        """
        self._last_openai_response = {}
        
        try:
            # Step 1: Parse input
            original_spec, source_format = self.parse_api_spec(spec_content)
            source_version = self._detect_openapi_version(original_spec)
            
            logger.info(f"📥 Input: OpenAPI {source_version} ({source_format.upper()})")
            
            # Step 2: Determine target version
            if target_version == 'auto':
                target_version = '3.0'
            
            logger.info(f"🎯 Target: OpenAPI {target_version} ({target_format.upper()})")
            
            # Step 3: Perform version conversion if needed
            if source_version != target_version:
                if source_version == '2.0' and target_version == '3.0':
                    logger.info("🔄 Converting OpenAPI 2.0 → 3.0")
                    converted_spec = self._convert_2_to_3_with_retry(original_spec, include_debug)
                elif source_version == '3.0' and target_version == '2.0':
                    logger.info("🔄 Converting OpenAPI 3.0 → 2.0 (downgrade)")
                    converted_spec = self._convert_3_to_2(original_spec)
                else:
                    raise ValueError(f"Unsupported version conversion: {source_version} → {target_version}")
            else:
                # Same version - just normalize/format conversion
                if source_version == '3.0':
                    logger.info("🔄 Normalizing OpenAPI 3.0")
                    converted_spec = self._normalize_3_0(original_spec)
                else:
                    logger.info("🔄 Normalizing OpenAPI 2.0")
                    converted_spec = self._normalize_2_0(original_spec)
            
            # Step 4: Apply Azure APIM compatibility (if 3.0)
            if target_version == '3.0':
                converted_spec = self._ensure_azure_apim_compatibility(converted_spec)
            
            # Step 5: Format conversion (JSON ↔ YAML)
            output_content = self._convert_format(converted_spec, target_format)
            
            logger.info(f"✅ Conversion complete: {source_version} ({source_format}) → {target_version} ({target_format})")
            
            # Prepare result
            result = {
                'status': 'success',
                'converted_spec': converted_spec,
                'converted_content': output_content,
                'source_format': source_format,
                'source_version': source_version,
                'target_format': target_format,
                'target_version': target_version,
                'conversion_type': self._get_conversion_type(source_version, source_format, target_version, target_format),
                'ai_conversion_used': self.is_available and source_version == '2.0' and target_version == '3.0',
                'conversion_metadata': self._extract_conversion_metadata(original_spec, converted_spec)
            }
            
            # Add debug info if requested
            if include_debug and self._last_openai_response:
                result.update({
                    'raw_openai_response': self._last_openai_response.get('raw'),
                    'cleaned_json': self._last_openai_response.get('cleaned'),
                    'cleaning_issues': self._last_openai_response.get('issues'),
                })
            
            return result
            
        except Exception as e:
            logger.error(f"Universal conversion failed: {e}")
            return {
                'status': 'error',
                'message': f'Conversion failed: {str(e)}'
            }
    
    def convert_openapi_2_to_3(self, spec_content: str, include_debug: bool = False) -> Dict[str, Any]:
        """Backward compatibility: Convert OpenAPI 2.0 to 3.0"""
        return self.convert_specification(
            spec_content, 
            target_format='json',
            target_version='3.0',
            include_debug=include_debug
        )
    
    def universal_openapi_converter(self, spec_content: str, include_debug: bool = False) -> Dict[str, Any]:
        """Backward compatibility: Universal converter defaults to 3.0 JSON"""
        return self.convert_specification(
            spec_content,
            target_format='json',
            target_version='3.0',
            include_debug=include_debug
        )
    
    def _detect_openapi_version(self, spec: Dict[str, Any]) -> str:
        """Detect OpenAPI version from specification"""
        if 'swagger' in spec:
            return '2.0'
        elif 'openapi' in spec:
            version = spec['openapi']
            if version.startswith('3.'):
                return '3.0'
            elif version.startswith('3.1'):
                return '3.1'
        raise ValueError("Cannot determine OpenAPI version")
    
    def _get_conversion_type(self, source_ver: str, source_fmt: str, target_ver: str, target_fmt: str) -> str:
        """Get human-readable conversion type"""
        if source_ver != target_ver and source_fmt != target_fmt:
            return f"version_and_format"
        elif source_ver != target_ver:
            return f"version_upgrade"
        elif source_fmt != target_fmt:
            return f"format_conversion"
        else:
            return "normalization"
    
    def _convert_format(self, spec: Dict[str, Any], target_format: str) -> str:
        """Convert specification to target format (JSON or YAML)"""
        if target_format == 'json':
            return json.dumps(spec, indent=2)
        elif target_format == 'yaml':
            return yaml.dump(spec, default_flow_style=False, sort_keys=False, allow_unicode=True)
        else:
            raise ValueError(f"Unsupported target format: {target_format}")
    
    def _normalize_2_0(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize OpenAPI 2.0 specification"""
        normalized = spec.copy()
        
        if 'swagger' not in normalized:
            normalized['swagger'] = '2.0'
        
        if 'info' not in normalized:
            normalized['info'] = {'title': 'API', 'version': '1.0.0'}
        
        if 'paths' not in normalized:
            normalized['paths'] = {}
        
        if 'host' not in normalized:
            normalized['host'] = 'api.example.com'
        
        if 'schemes' not in normalized:
            normalized['schemes'] = ['https']
        
        return normalized
    
    def _convert_2_to_3_with_retry(self, original_spec: Dict[str, Any], include_debug: bool = False) -> Dict[str, Any]:
        """Convert OpenAPI 2.0 to 3.0 with retry logic"""
        if self.is_available:
            try:
                return self._ai_convert_spec_with_retry(original_spec, include_debug)
            except Exception as e:
                logger.warning(f"AI conversion failed, using fallback: {e}")
                return self._convert_2_to_3(original_spec)
        else:
            logger.info("AI not available, using programmatic converter")
            return self._convert_2_to_3(original_spec)
    
    def _convert_2_to_3(self, spec_2: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OpenAPI 2.0 to proper 3.0 (fallback method) - ENHANCED"""
        spec_3 = {
            "openapi": "3.0.0",
            "info": spec_2.get("info", {"title": "API", "version": "1.0.0"}),
            "servers": self._create_servers_from_v2(spec_2),
            "paths": {},
            "components": {
                "schemas": spec_2.get("definitions", {}),
                "securitySchemes": self._convert_security_definitions(spec_2.get("securityDefinitions", {}))
            }
        }
        
        # ✅ NEW: Convert global parameters to components.parameters
        if 'parameters' in spec_2:
            spec_3['components']['parameters'] = {}
            for param_name, param_def in spec_2['parameters'].items():
                converted_param = self._convert_parameter_2_to_3(param_def)
                if converted_param:
                    # Remove 'name' and 'in' from the parameter definition in components
                    # These will be in the $ref usage, not in the component definition
                    spec_3['components']['parameters'][param_name] = converted_param
        
        # ✅ NEW: Convert global responses to components.responses
        if 'responses' in spec_2:
            spec_3['components']['responses'] = {}
            for response_name, response_def in spec_2['responses'].items():
                spec_3['components']['responses'][response_name] = self._convert_response_2_to_3(response_def)
        
        for path, path_item in spec_2.get("paths", {}).items():
            spec_3["paths"][path] = self._convert_path_item_2_to_3(path_item)
        
        if "security" in spec_2:
            spec_3["security"] = spec_2["security"]
        
        return spec_3
    
    def _convert_path_item_2_to_3(self, path_item: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OpenAPI 2.0 path item to 3.0 format"""
        converted_path = {}
        
        for method, operation in path_item.items():
            if method.lower() in ['get', 'post', 'put', 'patch', 'delete', 'head', 'options']:
                converted_path[method] = self._convert_operation_2_to_3(operation)
            else:
                converted_path[method] = operation
        
        return converted_path
    
    def _convert_operation_2_to_3(self, operation: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OpenAPI 2.0 operation to 3.0 format"""
        if not isinstance(operation, dict):
            return operation
        
        converted_op = {}
        
        for field in ['summary', 'description', 'operationId', 'tags', 'deprecated', 'security']:
            if field in operation:
                converted_op[field] = operation[field]
        
        if 'parameters' in operation:
            body_params = []
            other_params = []
            
            for param in operation['parameters']:
                if isinstance(param, dict):
                    if param.get('in') == 'body':
                        body_params.append(param)
                    else:
                        converted_param = self._convert_parameter_2_to_3(param)
                        if converted_param:
                            other_params.append(converted_param)
            
            if other_params:
                converted_op['parameters'] = other_params
            
            if body_params:
                body_param = body_params[0]
                converted_op['requestBody'] = {
                    'required': body_param.get('required', True),
                    'content': {
                        'application/json': {
                            'schema': body_param.get('schema', {})
                        }
                    }
                }
        
        if 'responses' in operation:
            converted_responses = {}
            for status, response in operation['responses'].items():
                converted_responses[status] = self._convert_response_2_to_3(response)
            converted_op['responses'] = converted_responses
        
        return converted_op
    
    def _convert_parameter_2_to_3(self, param: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Convert parameter to OpenAPI 3.0 format"""
        if not isinstance(param, dict) or 'name' not in param or 'in' not in param:
            return None
        
        converted_param = {
            'name': param['name'],
            'in': param['in'],
            'required': param.get('required', param.get('in') == 'path'),
            'schema': {}
        }
        
        if 'description' in param:
            converted_param['description'] = param['description']
        
        schema_fields = ['type', 'format', 'enum', 'minimum', 'maximum', 'pattern', 'default', 'items']
        for field in schema_fields:
            if field in param:
                converted_param['schema'][field] = param[field]
        
        if not converted_param['schema']:
            converted_param['schema'] = {'type': 'string'}
        
        return converted_param
    
    def _convert_response_2_to_3(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """Convert response to OpenAPI 3.0 format"""
        if not isinstance(response, dict):
            return response
        
        converted_response = {}
        
        if 'description' in response:
            converted_response['description'] = response['description']
        else:
            converted_response['description'] = 'Response'
        
        if 'schema' in response:
            converted_response['content'] = {
                'application/json': {
                    'schema': response['schema']
                }
            }
        
        if 'headers' in response:
            converted_response['headers'] = response['headers']
        
        return converted_response
    
    def _normalize_3_0(self, spec_3: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize existing OpenAPI 3.0 to ensure Azure APIM compatibility"""
        normalized = spec_3.copy()
        
        openapi_2_fields = ['swagger', 'host', 'basePath', 'schemes', 'consumes', 'produces', 'definitions', 'securityDefinitions']
        for field in openapi_2_fields:
            if field in normalized:
                if field == 'definitions' and 'components' in normalized:
                    normalized['components']['schemas'] = normalized['components'].get('schemas', {})
                    normalized['components']['schemas'].update(normalized[field])
                elif field == 'securityDefinitions' and 'components' in normalized:
                    normalized['components']['securitySchemes'] = normalized['components'].get('securitySchemes', {})
                    normalized['components']['securitySchemes'].update(self._convert_security_definitions(normalized[field]))
                del normalized[field]
        
        return normalized
    
    def _ensure_azure_apim_compatibility(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """Universal Azure APIM compatibility fixes - ENHANCED"""
        # Fix all reference paths first
        spec = self._fix_all_reference_paths(spec)
        
        if 'components' not in spec:
            spec['components'] = {}
        if 'schemas' not in spec.get('components', {}):
            spec['components']['schemas'] = {}
        
        # ✅ NEW: Create missing components for any referenced but missing parameters/responses
        spec = self._create_missing_components(spec)
        
        # Fix request/response structure
        spec = self._fix_request_response_structure(spec)
        
        if 'servers' not in spec or not spec['servers']:
            spec['servers'] = [{"url": "https://api.example.com", "description": "Default server"}]
        
        spec['openapi'] = '3.0.0'
        
        return spec
    
    def _fix_all_reference_paths(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """Comprehensive fix for all $ref paths - ENHANCED"""
        spec_str = json.dumps(spec)
        
        # Fix all reference formats to OpenAPI 3.0 style
        ref_fixes = [
            # OpenAPI 2.0 style refs
            ('"/definitions/', '"#/components/schemas/'),
            ('"#/definitions/', '"#/components/schemas/'),
            ('"/parameters/', '"#/components/parameters/'),
            ('"/responses/', '"#/components/responses/'),
            
            # ✅ NEW: Partial refs without #/components (common issue)
            ('"#/responses/', '"#/components/responses/'),
            ('"#/parameters/', '"#/components/parameters/'),
        ]
        
        for old_ref, new_ref in ref_fixes:
            if old_ref in spec_str:
                logger.info(f"Fixing reference: {old_ref} → {new_ref}")
                spec_str = spec_str.replace(old_ref, new_ref)
        
        # Additional regex-based fixes
        spec_str = re.sub(r'"(\$ref":\s*)"([^#][^"]*\/definitions\/[^"]*)"', r'"\1"#/components/schemas/\2"', spec_str)
        
        try:
            fixed_spec = json.loads(spec_str)
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error after reference fixes: {e}")
            return spec
        
        # Verify fixes
        verification_str = json.dumps(fixed_spec)
        remaining_issues = re.findall(r'"\$ref":\s*"#/(responses|parameters)/', verification_str)
        
        if remaining_issues:
            logger.info(f"Found {len(remaining_issues)} references that need component creation")
        else:
            logger.info("All reference paths successfully fixed")
        
        return fixed_spec
    
    def _create_missing_components(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """✅ ENHANCED: Create stub components for any referenced but missing parameters/responses/schemas"""
        spec_str = json.dumps(spec)
        
        # Find all $ref references to parameters, responses, and schemas
        all_refs = re.findall(r'"\$ref":\s*"#/components/(parameters|responses|schemas)/([^"]+)"', spec_str)
        
        if not all_refs:
            return spec
        
        if 'components' not in spec:
            spec['components'] = {}
        
        # ========== PARAMETERS ==========
        if 'parameters' not in spec['components']:
            spec['components']['parameters'] = {}
        
        param_refs = [ref for ref in all_refs if ref[0] == 'parameters']
        for ref_type, ref_name in param_refs:
            if ref_name not in spec['components']['parameters']:
                logger.warning(f"Creating stub parameter: {ref_name}")
                param_in = 'path' if 'id' in ref_name.lower() else 'query'
                spec['components']['parameters'][ref_name] = {
                    'name': ref_name.lower().replace('id', '_id') if 'id' in ref_name.lower() else ref_name,
                    'in': param_in,
                    'required': param_in == 'path',
                    'schema': {'type': 'string'},
                    'description': f'{ref_name} parameter'
                }
        
        # ========== RESPONSES ==========
        if 'responses' not in spec['components']:
            spec['components']['responses'] = {}
        
        response_refs = [ref for ref in all_refs if ref[0] == 'responses']
        for ref_type, ref_name in response_refs:
            if ref_name not in spec['components']['responses']:
                logger.warning(f"Creating stub response: {ref_name}")
                
                # Determine description
                if 'unauthorized' in ref_name.lower() or '401' in ref_name:
                    description = 'Unauthorized'
                elif 'notfound' in ref_name.lower() or 'not_found' in ref_name.lower() or '404' in ref_name:
                    description = 'Not Found'
                elif 'badrequest' in ref_name.lower() or 'bad_request' in ref_name.lower() or '400' in ref_name:
                    description = 'Bad Request'
                elif 'forbidden' in ref_name.lower() or '403' in ref_name:
                    description = 'Forbidden'
                elif 'error' in ref_name.lower():
                    description = 'Error'
                else:
                    description = f'{ref_name} response'
                
                spec['components']['responses'][ref_name] = {
                    'description': description,
                    'content': {
                        'application/json': {
                            'schema': {
                                'type': 'object',
                                'properties': {
                                    'code': {'type': 'string'},
                                    'message': {'type': 'string'}
                                }
                            }
                        }
                    }
                }
        
        # ========== SCHEMAS (NEW) ==========
        if 'schemas' not in spec['components']:
            spec['components']['schemas'] = {}
        
        schema_refs = [ref for ref in all_refs if ref[0] == 'schemas']
        for ref_type, ref_name in schema_refs:
            if ref_name not in spec['components']['schemas']:
                logger.warning(f"Creating stub schema: {ref_name}")
                
                # Create a basic object schema as placeholder
                spec['components']['schemas'][ref_name] = {
                    'type': 'object',
                    'description': f'{ref_name} object (auto-generated stub)',
                    'properties': {
                        'id': {
                            'type': 'string',
                            'description': f'{ref_name} identifier'
                        },
                        'name': {
                            'type': 'string',
                            'description': f'{ref_name} name'
                        }
                    }
                }
        
        logger.info(f"Created {len(param_refs)} parameter stubs, {len(response_refs)} response stubs, and {len(schema_refs)} schema stubs")
        
        return spec
    
    def _fix_request_response_structure(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """Fix request/response structure for Azure APIM compatibility"""
        for path, path_item in spec.get('paths', {}).items():
            for method, operation in path_item.items():
                if method.lower() not in ['get', 'post', 'put', 'patch', 'delete', 'head', 'options']:
                    continue
                
                if not isinstance(operation, dict):
                    continue
                
                if 'parameters' in operation:
                    fixed_params = []
                    for param in operation['parameters']:
                        if isinstance(param, dict):
                            if param.get('in') == 'body':
                                if 'requestBody' not in operation:
                                    operation['requestBody'] = {
                                        'required': param.get('required', True),
                                        'content': {
                                            'application/json': {
                                                'schema': param.get('schema', {})
                                            }
                                        }
                                    }
                            else:
                                if 'type' in param and 'schema' not in param:
                                    schema = {}
                                    for key in ['type', 'format', 'enum', 'minimum', 'maximum', 'pattern', 'default']:
                                        if key in param:
                                            schema[key] = param[key]
                                    
                                    fixed_param = {k: v for k, v in param.items() if k not in ['type', 'format', 'enum', 'minimum', 'maximum', 'pattern', 'default']}
                                    fixed_param['schema'] = schema
                                    fixed_params.append(fixed_param)
                                else:
                                    fixed_params.append(param)
                    
                    if fixed_params:
                        operation['parameters'] = fixed_params
                    else:
                        del operation['parameters']
                
                if 'responses' in operation:
                    for status, response in operation['responses'].items():
                        if isinstance(response, dict) and 'schema' in response and 'content' not in response:
                            schema = response.pop('schema')
                            response['content'] = {
                                'application/json': {
                                    'schema': schema
                                }
                            }
        
        return spec
    
    def _convert_3_to_2(self, spec_3: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OpenAPI 3.0 to 2.0 (downgrade) - Lossy conversion"""
        logger.warning("Converting 3.0 → 2.0 is lossy. Some features will be simplified.")
        
        spec_2 = {
            "swagger": "2.0",
            "info": spec_3.get("info", {"title": "API", "version": "1.0.0"}),
            "paths": {}
        }
        
        # Extract host/basePath from servers
        servers = spec_3.get('servers', [])
        if servers:
            first_server = servers[0]
            url = first_server.get('url', 'https://api.example.com')
            
            match = re.match(r'(https?):\/\/([^\/]+)(\/.*)?', url)
            if match:
                scheme, host, base_path = match.groups()
                spec_2['schemes'] = [scheme]
                spec_2['host'] = host
                if base_path:
                    spec_2['basePath'] = base_path
        else:
            spec_2['host'] = 'api.example.com'
            spec_2['schemes'] = ['https']
        
        # Convert paths
        for path, path_item in spec_3.get('paths', {}).items():
            spec_2['paths'][path] = self._convert_path_item_3_to_2(path_item)
        
        # Convert components
        components = spec_3.get('components', {})
        
        if 'schemas' in components:
            spec_2['definitions'] = components['schemas']
        
        if 'securitySchemes' in components:
            spec_2['securityDefinitions'] = self._convert_security_schemes_3_to_2(components['securitySchemes'])
        
        if 'security' in spec_3:
            spec_2['security'] = spec_3['security']
        
        return spec_2
    
    def _convert_path_item_3_to_2(self, path_item: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OpenAPI 3.0 path item to 2.0"""
        converted = {}
        
        for method, operation in path_item.items():
            if method.lower() in ['get', 'post', 'put', 'patch', 'delete', 'head', 'options']:
                converted[method] = self._convert_operation_3_to_2(operation)
            else:
                converted[method] = operation
        
        return converted
    
    def _convert_operation_3_to_2(self, operation: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OpenAPI 3.0 operation to 2.0"""
        if not isinstance(operation, dict):
            return operation
        
        converted = {}
        
        for field in ['summary', 'description', 'operationId', 'tags', 'deprecated', 'security']:
            if field in operation:
                converted[field] = operation[field]
        
        if 'parameters' in operation:
            converted['parameters'] = []
            for param in operation['parameters']:
                converted_param = self._convert_parameter_3_to_2(param)
                if converted_param:
                    converted['parameters'].append(converted_param)
        else:
            converted['parameters'] = []
        
        if 'requestBody' in operation:
            body_param = {
                'name': 'body',
                'in': 'body',
                'required': operation['requestBody'].get('required', False)
            }
            
            content = operation['requestBody'].get('content', {})
            if 'application/json' in content:
                body_param['schema'] = content['application/json'].get('schema', {})
            elif content:
                first_content = next(iter(content.values()))
                body_param['schema'] = first_content.get('schema', {})
            
            converted['parameters'].append(body_param)
        
        if 'responses' in operation:
            converted['responses'] = {}
            for status, response in operation['responses'].items():
                converted['responses'][status] = self._convert_response_3_to_2(response)
        
        return converted
    
    def _convert_parameter_3_to_2(self, param: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Convert parameter from 3.0 to 2.0 format"""
        if not isinstance(param, dict):
            return None
        
        converted = {
            'name': param.get('name'),
            'in': param.get('in'),
            'required': param.get('required', False)
        }
        
        if 'description' in param:
            converted['description'] = param['description']
        
        schema = param.get('schema', {})
        for field in ['type', 'format', 'enum', 'minimum', 'maximum', 'pattern', 'default', 'items']:
            if field in schema:
                converted[field] = schema[field]
        
        return converted
    
    def _convert_response_3_to_2(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """Convert response from 3.0 to 2.0 format"""
        if not isinstance(response, dict):
            return response
        
        converted = {
            'description': response.get('description', 'Response')
        }
        
        content = response.get('content', {})
        if 'application/json' in content:
            converted['schema'] = content['application/json'].get('schema', {})
        elif content:
            first_content = next(iter(content.values()))
            converted['schema'] = first_content.get('schema', {})
        
        if 'headers' in response:
            converted['headers'] = response['headers']
        
        return converted
    
    def _convert_security_schemes_3_to_2(self, security_schemes: Dict[str, Any]) -> Dict[str, Any]:
        """Convert securitySchemes from 3.0 to 2.0"""
        security_defs = {}
        
        for name, scheme in security_schemes.items():
            if not isinstance(scheme, dict):
                continue
            
            scheme_type = scheme.get('type')
            
            if scheme_type == 'apiKey':
                security_defs[name] = {
                    'type': 'apiKey',
                    'name': scheme.get('name'),
                    'in': scheme.get('in')
                }
            elif scheme_type == 'http':
                if scheme.get('scheme') == 'basic':
                    security_defs[name] = {'type': 'basic'}
                elif scheme.get('scheme') == 'bearer':
                    security_defs[name] = {
                        'type': 'apiKey',
                        'name': 'Authorization',
                        'in': 'header'
                    }
            elif scheme_type == 'oauth2':
                flows = scheme.get('flows', {})
                if 'implicit' in flows:
                    flow = flows['implicit']
                    security_defs[name] = {
                        'type': 'oauth2',
                        'flow': 'implicit',
                        'authorizationUrl': flow.get('authorizationUrl'),
                        'scopes': flow.get('scopes', {})
                    }
                elif 'authorizationCode' in flows:
                    flow = flows['authorizationCode']
                    security_defs[name] = {
                        'type': 'oauth2',
                        'flow': 'accessCode',
                        'authorizationUrl': flow.get('authorizationUrl'),
                        'tokenUrl': flow.get('tokenUrl'),
                        'scopes': flow.get('scopes', {})
                    }
        
        return security_defs
    
    def _ai_convert_spec_with_retry(self, original_spec: Dict[str, Any], include_debug: bool = False, max_retries: int = 3) -> Dict[str, Any]:
        """Use Azure OpenAI with RETRY LOGIC"""
        if not self.is_available:
            raise Exception("Azure OpenAI client not available")
        
        prompt = self._create_optimized_conversion_prompt(original_spec)
        start_time = time.time()
        
        last_error = None
        
        for attempt in range(max_retries):
            try:
                logger.info(f"🔄 Conversion attempt {attempt + 1}/{max_retries}")
                
                api_params = {
                    "model": self.config.OPENAI_DEPLOYMENT,
                    "messages": [
                        {"role": "system", "content": self._get_enhanced_system_prompt()},
                        {"role": "user", "content": prompt}
                    ],
                    "max_tokens": 4000,
                    "stream": False
                }
                
                if include_debug:
                    self._last_openai_response = {
                        'model_used': api_params['model'],
                        'prompt_length': len(prompt),
                        'start_time': start_time,
                        'attempt': attempt + 1,
                        'max_retries': max_retries
                    }
                
                try:
                    response = self._client.chat.completions.create(**api_params)
                except Exception as e:
                    if "max_tokens" in str(e).lower():
                        logger.info("Adjusting to max_completion_tokens parameter")
                        api_params.pop("max_tokens", None)
                        api_params["max_completion_tokens"] = 4000
                        response = self._client.chat.completions.create(**api_params)
                    else:
                        raise e
                
                raw_content = response.choices[0].message.content
                
                if include_debug:
                    self._last_openai_response.update({
                        'raw': raw_content,
                        'response_length': len(raw_content),
                        'api_call_time': time.time() - start_time
                    })
                
                cleaned_json = self._extract_and_clean_json(raw_content)
                
                if include_debug:
                    self._last_openai_response.update({
                        'cleaned': cleaned_json,
                        'cleaned_length': len(cleaned_json),
                        'success': True
                    })
                
                converted_spec = json.loads(cleaned_json)
                
                logger.info(f"✅ Conversion successful on attempt {attempt + 1}")
                return converted_spec
                
            except Exception as e:
                last_error = e
                error_msg = str(e)
                
                is_timeout = any(keyword in error_msg.lower() for keyword in ['timeout', 'timed out', 'deadline'])
                
                logger.warning(f"❌ Attempt {attempt + 1} failed: {error_msg}")
                
                if include_debug:
                    self._last_openai_response.update({
                        'error': error_msg,
                        'attempt': attempt + 1,
                        'is_timeout': is_timeout
                    })
                
                if attempt < max_retries - 1:
                    wait_time = 2 ** (attempt + 1)
                    logger.info(f"⏳ Waiting {wait_time}s before retry...")
                    time.sleep(wait_time)
                else:
                    logger.error(f"❌ All {max_retries} attempts failed")
                    if include_debug:
                        self._last_openai_response.update({
                            'success': False,
                            'attempts': max_retries,
                            'final_error': error_msg
                        })
                    
                    if is_timeout:
                        logger.warning("⚠️ Timeout detected - falling back to programmatic converter")
                        return self._convert_2_to_3(original_spec)
                    
                    raise Exception(f"Conversion failed after {max_retries} attempts: {error_msg}")
        
        raise last_error if last_error else Exception("Unknown conversion error")
    
    def _create_optimized_conversion_prompt(self, spec: Dict[str, Any]) -> str:
        """Create OPTIMIZED prompt for large specifications"""
        spec_str = json.dumps(spec, indent=2)
        
        estimated_tokens = len(spec_str) // 4
        max_prompt_tokens = 6000
        
        if estimated_tokens > max_prompt_tokens:
            logger.info(f"📊 Large spec detected ({estimated_tokens} tokens)")
            
            spec_summary = {
                "swagger": spec.get("swagger"),
                "info": spec.get("info"),
                "host": spec.get("host"),
                "basePath": spec.get("basePath"),
                "schemes": spec.get("schemes"),
                "consumes": spec.get("consumes"),
                "produces": spec.get("produces"),
                "securityDefinitions": spec.get("securityDefinitions"),
                "tags": spec.get("tags"),
                "_stats": {
                    "total_paths": len(spec.get('paths', {})),
                    "total_definitions": len(spec.get('definitions', {}))
                }
            }
            
            paths = spec.get('paths', {})
            if paths:
                spec_summary["paths"] = dict(list(paths.items())[:3])
            
            definitions = spec.get('definitions', {})
            if definitions:
                spec_summary["definitions"] = dict(list(definitions.items())[:5])
            
            spec_str = json.dumps(spec_summary, indent=2)
            
            return f"""Convert this OpenAPI 2.0 to 3.0. Large API with {len(paths)} paths, {len(definitions)} definitions.

{spec_str}

Return complete OpenAPI 3.0 as valid JSON."""
        else:
            return f"Convert this OpenAPI 2.0 to OpenAPI 3.0:\n\n{spec_str}"
    
    def _create_servers_from_v2(self, spec: Dict[str, Any]) -> list:
        """Create servers from OpenAPI 2.0"""
        servers = []
        host = spec.get('host', 'api.example.com')
        base_path = spec.get('basePath', '')
        schemes = spec.get('schemes', ['https'])
        
        for scheme in schemes:
            url = f"{scheme}://{host}{base_path}"
            servers.append({"url": url})
        
        return servers if servers else [{"url": "https://api.example.com"}]
    
    def _convert_security_definitions(self, security_defs: Dict[str, Any]) -> Dict[str, Any]:
        """Convert securityDefinitions to securitySchemes"""
        security_schemes = {}
        
        for name, definition in security_defs.items():
            if not isinstance(definition, dict):
                continue
            
            scheme_type = definition.get('type')
            if scheme_type == 'apiKey':
                security_schemes[name] = {
                    'type': 'apiKey',
                    'name': definition.get('name'),
                    'in': definition.get('in')
                }
            elif scheme_type == 'oauth2':
                security_schemes[name] = {
                    'type': 'oauth2',
                    'flows': {
                        'implicit': {
                            'authorizationUrl': definition.get('authorizationUrl'),
                            'scopes': definition.get('scopes', {})
                        }
                    }
                }
            elif scheme_type == 'basic':
                security_schemes[name] = {
                    'type': 'http',
                    'scheme': 'basic'
                }
        
        return security_schemes
    
    def _get_enhanced_system_prompt(self) -> str:
        """Get enhanced system prompt"""
        return """You are an expert API converter. Convert OpenAPI 2.0 to 3.0.

CRITICAL: Return ONLY valid JSON.

Rules:
1. 'swagger: "2.0"' → 'openapi: "3.0.0"'
2. host/basePath/schemes → servers array
3. definitions → components/schemas
4. securityDefinitions → components/securitySchemes
5. body parameters → requestBody
6. Add content types to responses
7. $ref: "#/definitions/" → "#/components/schemas/"

Return complete OpenAPI 3.0 as valid JSON only."""
    
    def _extract_and_clean_json(self, content: str) -> str:
        """Extract JSON from OpenAI response"""
        content = content.strip()
        
        if "```json" in content:
            start = content.find("```json") + 7
            end = content.find("```", start)
            if end == -1:
                end = len(content)
            content = content[start:end].strip()
        elif "```" in content:
            lines = content.split('\n')
            in_code_block = False
            json_lines = []
            
            for line in lines:
                if line.strip().startswith('```'):
                    in_code_block = not in_code_block
                    continue
                if in_code_block:
                    json_lines.append(line)
            
            if json_lines:
                content = '\n'.join(json_lines)
        
        start_idx = content.find('{')
        if start_idx == -1:
            raise ValueError("No JSON found")
        
        brace_count = 0
        end_idx = -1
        for i in range(start_idx, len(content)):
            if content[i] == '{':
                brace_count += 1
            elif content[i] == '}':
                brace_count -= 1
                if brace_count == 0:
                    end_idx = i + 1
                    break
        
        if end_idx == -1:
            content = content[start_idx:]
        else:
            content = content[start_idx:end_idx]
        
        return content.strip()
    
    def _extract_conversion_metadata(self, original: Dict[str, Any], converted: Dict[str, Any]) -> Dict[str, Any]:
        """Extract conversion metadata"""
        original_info = original.get('info', {})
        
        metadata = {
            'api_title': original_info.get('title', 'Unknown'),
            'api_version': original_info.get('version', '1.0.0'),
            'api_description': original_info.get('description', ''),
            'original_paths_count': len(original.get('paths', {})),
            'converted_paths_count': len(converted.get('paths', {})),
            'original_definitions_count': len(original.get('definitions', {})),
            'converted_schemas_count': len(converted.get('components', {}).get('schemas', {})),
            'has_security': bool(original.get('securityDefinitions')),
            'servers_created': len(converted.get('servers', [])),
            'conversion_timestamp': time.time()
        }
        
        if 'servers' in converted and converted['servers']:
            metadata['target_servers'] = [server.get('url') for server in converted['servers']]
        else:
            metadata['target_servers'] = []
        
        return metadata
    
    def test_connection(self) -> Dict[str, Any]:
        """Test Azure OpenAI connection"""
        if not self.is_available:
            return {
                'status': 'error',
                'message': f'Azure OpenAI not initialized: {self._initialization_error or "Unknown"}'
            }
        
        try:
            api_params = {
                "model": self.config.OPENAI_DEPLOYMENT,
                "messages": [{"role": "user", "content": "test"}],
                "max_tokens": 10,
                "stream": False
            }
            
            try:
                response = self._client.chat.completions.create(**api_params)
            except Exception as e:
                if "max_tokens" in str(e).lower():
                    api_params["max_completion_tokens"] = api_params.pop("max_tokens")
                    response = self._client.chat.completions.create(**api_params)
                else:
                    raise e
            
            return {
                'status': 'success',
                'message': 'Azure OpenAI connected',
                'model': self.config.OPENAI_DEPLOYMENT,
                'auth_method': self._auth_method
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Connection failed: {str(e)}'
            }