"""
Utils package for utility functions
Contains file handling, logging, and helper utilities
"""

# Import logger setup first
from .logger import setup_logger, get_logger

# Import file handlers
from .file_handler import FileHandler
from .enhanced_file_handler import EnhancedFileHandler

# Import helper functions
from .helpers import (
    generate_id,
    format_datetime,
    calculate_file_hash,
    sanitize_filename,
    validate_json,
    validate_yaml,
    parse_api_spec,
    extract_api_info,
    format_file_size,
    get_current_timestamp,
    validate_email
)

__all__ = [
    # Logging utilities
    'setup_logger',
    'get_logger',
    
    # File handling
    'FileHandler',
    'EnhancedFileHandler',
    
    # Helper functions
    'generate_id',
    'format_datetime', 
    'calculate_file_hash',
    'sanitize_filename',
    'validate_json',
    'validate_yaml',
    'parse_api_spec',
    'extract_api_info',
    'format_file_size',
    'get_current_timestamp',
    'validate_email'
]